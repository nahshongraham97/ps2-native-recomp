
int FUN_000056fc(int param_1,int param_2)

{
  int iVar1;
  undefined1 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  
  if (iRam000248e0 == 0) {
    if (param_1 == 0) {
      param_1 = 0x101e8;
    }
    if (param_2 == 0) {
      param_2 = 0x10200;
    }
    iRam000248e0 = 0x248e4;
    func_0x0000a7cc(0x24c90);
    func_0x0000a7cc(0x248d4);
    func_0x0000a7cc(0x248c8);
    func_0x0000a7cc(0x10b10);
    func_0x0000a7cc(0x24cc8);
    func_0x00004f98();
    func_0x00004ec4();
    *(uint *)(iRam000248e0 + 0x3bc) = *(uint *)(param_1 + 4) | *(uint *)(param_2 + 4);
    if ((*(uint *)(iRam000248e0 + 0x3bc) & 1) != 0) {
      iVar6 = 0;
      do {
        iVar5 = iVar6 * 0x3fff;
        iVar1 = 199 - iVar6;
        iVar6 = iVar6 + 1;
        *(short *)(iVar1 * 2 + 0x102ac) = (short)(iVar5 / 199);
      } while (iVar6 < 200);
      iVar6 = 99;
      do {
        iVar5 = iVar6 << 1;
        puVar2 = (undefined1 *)(iVar6 + 0x1043c);
        iVar6 = iVar6 + -1;
        *puVar2 = (char)iVar5;
      } while (-1 < iVar6);
    }
    uVar3 = func_0x00006b4c(0x180);
    *(undefined4 *)(iRam000248e0 + 0x268) = uVar3;
    if (*(int *)(iRam000248e0 + 0x268) == 0) {
      iVar6 = 0;
    }
    else {
      *(short *)(iRam000248e0 + 0x264) = (short)*(undefined4 *)(param_1 + 8);
      for (iVar6 = 0; iVar6 < 0x30; iVar6 = iVar6 + 1) {
        uVar3 = func_0x0000f4f4(0x20);
        *(undefined4 *)(*(int *)(iRam000248e0 + 0x268) + iVar6 * 8 + 4) = uVar3;
        puVar4 = (undefined4 *)(*(int *)(iRam000248e0 + 0x268) + iVar6 * 8);
        if (puVar4[1] == 0) {
          for (iVar6 = 0; iVar6 < (int)(uint)*(ushort *)(iRam000248e0 + 0x264); iVar6 = iVar6 + 1) {
            func_0x000053b8(iRam000248e0,iVar6);
          }
          func_0x00006bc8(*(undefined4 *)(iRam000248e0 + 0x268));
          return 0;
        }
        *puVar4 = 0;
      }
      *(undefined4 *)(iRam000248e0 + 0x290) = 0x4000;
      *(undefined4 *)(iRam000248e0 + 0x294) = 0;
      *(undefined4 *)(iRam000248e0 + 0x298) = 0x1000;
      *(undefined4 *)(iRam000248e0 + 0x29c) = 0x4000;
      *(undefined4 *)(iRam000248e0 + 0x2a0) = 0;
      *(undefined4 *)(iRam000248e0 + 0x2a4) = 0x1000;
      *(undefined4 *)(iRam000248e0 + 0x270) = 3;
      *(undefined4 *)(iRam000248e0 + 0x2a8) = 1;
      *(undefined4 *)(iRam000248e0 + 0x3b8) = 0;
      func_0x00000280(0);
      func_0x0000cd08(0x5010,0x1faff0);
      func_0x0000c2f0();
      func_0x0000ca00();
      func_0x0000ec50();
      func_0x0000ff1c();
      func_0x00005318(iRam000248e0);
      uVar7 = 0;
      do {
        func_0x00000288(uVar7 & 0xffff | 0x800,0xffc);
        func_0x00000288(uVar7 & 0xffff | 0x980,0x3fff);
        func_0x00000288(uVar7 & 0xffff | 0xa80,0x3fff);
        func_0x00000290(uVar7 & 0xffff | 0x1800,0xffffff);
        func_0x00000290(uVar7 & 0xffff | 0x1a00,0xffffff);
        iVar5 = 0;
        iVar6 = uVar7 * 300;
        do {
          iVar1 = iVar5 * 0xc;
          iVar5 = iVar5 + 1;
          *(undefined2 *)(iVar6 + iRam000248e0 + iVar1 + 8) = 0;
          *(undefined2 *)(iVar6 + iRam000248e0 + iVar1 + 10) = 0;
          *(undefined2 *)(iVar6 + iRam000248e0 + iVar1 + 0xc) = 0;
          *(undefined4 *)(iVar6 + iRam000248e0 + iVar1 + 0x10) = 0;
        } while (iVar5 < 0x18);
        uVar7 = uVar7 + 1;
        *(undefined2 *)(iRam000248e0 + iVar6 + 0x12a) = 0;
        *(undefined2 *)(iRam000248e0 + iVar6 + 0x128) = 0;
        *(undefined4 *)(iRam000248e0 + iVar6) = 0;
        *(undefined2 *)(iRam000248e0 + iVar6 + 6) = 0;
        *(undefined2 *)(iRam000248e0 + iVar6 + 4) = 0;
      } while ((int)uVar7 < 2);
      *(undefined4 *)(iRam000248e0 + 0x274) = 0;
      *(undefined4 *)(iRam000248e0 + 0x278) = 0;
      *(undefined4 *)(iRam000248e0 + 0x27c) = 0;
      func_0x00000334(*(undefined4 *)(param_2 + 0xc));
      iVar6 = iRam000248e0;
    }
  }
  else {
    iVar6 = 0;
  }
  return iVar6;
}

