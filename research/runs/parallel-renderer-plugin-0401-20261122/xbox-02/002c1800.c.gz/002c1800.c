
void FUN_002c1800(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  fVar1 = *param_2;
  fVar2 = param_2[1];
  fVar3 = param_3[1];
  fVar4 = param_3[2];
  fVar5 = param_3[5];
  fVar6 = param_3[6];
  fVar7 = param_2[2];
  *param_1 = param_3[8] * fVar7 + param_3[4] * fVar2 + *param_3 * fVar1;
  param_1[1] = param_3[9] * fVar7 + fVar5 * fVar2 + fVar3 * fVar1;
  param_1[2] = param_3[10] * fVar7 + fVar6 * fVar2 + fVar4 * fVar1;
  return;
}

