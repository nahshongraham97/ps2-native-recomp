
float * FUN_002c10f0(float *param_1,float *param_2,uint param_3,float *param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float *pfVar10;
  int iVar11;
  
  iVar11 = param_3 - 1;
  pfVar10 = param_1;
  if (3 < (int)param_3) {
    param_3 = param_3 >> 2;
    iVar11 = iVar11 + param_3 * -4;
    do {
      fVar1 = *param_2;
      fVar2 = param_4[1];
      fVar3 = param_4[2];
      fVar4 = param_2[1];
      fVar5 = param_4[5];
      fVar6 = param_4[6];
      fVar7 = param_4[9];
      fVar8 = param_2[2];
      fVar9 = param_4[10];
      *param_1 = param_4[8] * fVar8 + param_4[4] * fVar4 + *param_4 * fVar1 + param_4[0xc];
      param_1[1] = fVar7 * fVar8 + fVar5 * fVar4 + fVar2 * fVar1 + param_4[0xd];
      param_1[2] = param_4[0xe] + fVar9 * fVar8 + fVar6 * fVar4 + fVar3 * fVar1;
      fVar1 = param_2[3];
      fVar2 = param_4[1];
      fVar3 = param_4[2];
      fVar4 = param_2[4];
      fVar5 = param_4[5];
      fVar6 = param_4[6];
      fVar7 = param_4[9];
      fVar8 = param_2[5];
      fVar9 = param_4[10];
      param_1[3] = param_4[8] * fVar8 + param_4[4] * fVar4 + *param_4 * fVar1 + param_4[0xc];
      param_1[4] = fVar7 * fVar8 + fVar5 * fVar4 + fVar2 * fVar1 + param_4[0xd];
      param_1[5] = param_4[0xe] + fVar9 * fVar8 + fVar6 * fVar4 + fVar3 * fVar1;
      fVar1 = param_2[6];
      fVar2 = param_4[1];
      fVar3 = param_4[2];
      fVar4 = param_2[7];
      fVar5 = param_4[5];
      fVar6 = param_4[6];
      fVar7 = param_4[9];
      fVar8 = param_2[8];
      fVar9 = param_4[10];
      param_1[6] = param_4[8] * fVar8 + param_4[4] * fVar4 + *param_4 * fVar1 + param_4[0xc];
      param_1[7] = fVar7 * fVar8 + fVar5 * fVar4 + fVar2 * fVar1 + param_4[0xd];
      param_1[8] = param_4[0xe] + fVar9 * fVar8 + fVar6 * fVar4 + fVar3 * fVar1;
      fVar1 = param_2[9];
      fVar2 = param_4[1];
      fVar3 = param_4[2];
      fVar4 = param_2[10];
      fVar5 = param_4[5];
      fVar6 = param_4[6];
      fVar7 = param_4[9];
      fVar8 = param_2[0xb];
      fVar9 = param_4[10];
      param_1[9] = param_4[8] * fVar8 + param_4[4] * fVar4 + *param_4 * fVar1 + param_4[0xc];
      param_1[10] = fVar7 * fVar8 + fVar5 * fVar4 + fVar2 * fVar1 + param_4[0xd];
      param_1[0xb] = param_4[0xe] + fVar9 * fVar8 + fVar6 * fVar4 + fVar3 * fVar1;
      param_1 = param_1 + 0xc;
      param_2 = param_2 + 0xc;
      param_3 = param_3 - 1;
    } while (param_3 != 0);
  }
  if (-1 < iVar11) {
    iVar11 = iVar11 + 1;
    do {
      fVar1 = *param_2;
      fVar2 = param_4[1];
      fVar3 = param_4[2];
      fVar4 = param_2[1];
      fVar5 = param_4[5];
      fVar6 = param_4[6];
      fVar7 = param_4[9];
      fVar8 = param_2[2];
      fVar9 = param_4[10];
      *param_1 = param_4[8] * fVar8 + param_4[4] * fVar4 + *param_4 * fVar1 + param_4[0xc];
      param_1[1] = fVar7 * fVar8 + fVar5 * fVar4 + fVar2 * fVar1 + param_4[0xd];
      param_1[2] = param_4[0xe] + fVar9 * fVar8 + fVar6 * fVar4 + fVar3 * fVar1;
      param_1 = param_1 + 3;
      param_2 = param_2 + 3;
      iVar11 = iVar11 + -1;
    } while (iVar11 != 0);
  }
  return pfVar10;
}

