
undefined8 FUN_001a36c0(undefined8 param_1,float *param_2,float *param_3)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  
  pfVar1 = (float *)param_1;
  fVar7 = *param_2;
  fVar2 = param_3[1];
  fVar4 = param_3[2];
  fVar9 = param_2[1];
  fVar5 = param_3[5];
  fVar8 = param_3[6];
  fVar10 = param_2[2];
  fVar6 = param_3[9];
  fVar3 = param_3[10];
  *pfVar1 = fVar10 * param_3[8] + fVar9 * param_3[4] + fVar7 * *param_3 + 0.0 + param_3[0xc];
  pfVar1[1] = fVar10 * fVar6 + fVar9 * fVar5 + fVar7 * fVar2 + 0.0 + 0.0 + param_3[0xd];
  pfVar1[2] = fVar10 * fVar3 + fVar9 * fVar8 + fVar7 * fVar4 + 0.0 + 0.0 + param_3[0xe];
  return param_1;
}

