
undefined8 FUN_001a3800(undefined8 param_1,float *param_2,float *param_3)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  pfVar1 = (float *)param_1;
  fVar7 = *param_2;
  fVar4 = param_3[2];
  fVar2 = param_3[1];
  fVar8 = param_2[1];
  fVar5 = param_3[5];
  fVar6 = param_3[6];
  fVar3 = param_2[2];
  *pfVar1 = fVar3 * param_3[8] + fVar8 * param_3[4] + fVar7 * *param_3 + 0.0;
  pfVar1[1] = fVar3 * param_3[9] + fVar8 * fVar5 + fVar7 * fVar2 + 0.0 + 0.0;
  pfVar1[2] = fVar3 * param_3[10] + fVar8 * fVar6 + fVar7 * fVar4 + 0.0 + 0.0;
  return param_1;
}

