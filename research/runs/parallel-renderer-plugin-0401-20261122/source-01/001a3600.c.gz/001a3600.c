
float * FUN_001a3600(float *param_1,float *param_2,int param_3,float *param_4)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  
  pfVar1 = param_1;
  while (param_3 = param_3 + -1, -1 < param_3) {
    fVar8 = *param_2;
    fVar2 = param_4[1];
    fVar5 = param_4[2];
    fVar9 = param_2[1];
    fVar3 = param_4[5];
    fVar6 = param_4[6];
    fVar10 = param_2[2];
    fVar4 = param_4[9];
    fVar7 = param_4[10];
    param_2 = param_2 + 3;
    *param_1 = fVar10 * param_4[8] + fVar9 * param_4[4] + fVar8 * *param_4 + 0.0 + param_4[0xc];
    param_1[1] = fVar10 * fVar4 + fVar9 * fVar3 + fVar8 * fVar2 + 0.0 + 0.0 + param_4[0xd];
    param_1[2] = fVar10 * fVar7 + fVar9 * fVar6 + fVar8 * fVar5 + 0.0 + 0.0 + param_4[0xe];
    param_1 = param_1 + 3;
  }
  return pfVar1;
}

