
undefined8 FUN_001a3a90(undefined8 param_1)

{
  (**(code **)(iGpffffa3c0 + 0x69f29c))();
  return param_1;
}

