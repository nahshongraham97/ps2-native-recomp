
undefined4
FUN_001a3880(undefined1 *param_1,undefined1 *param_2,undefined1 *param_3,undefined1 *param_4)

{
  if (param_1 == (undefined1 *)0x0) {
    param_1 = &LAB_001a36c0;
  }
  *(undefined1 **)(iRam0064e4b0 + 0x69f298) = param_1;
  if (param_2 == (undefined1 *)0x0) {
    param_2 = &LAB_001a3600;
  }
  *(undefined1 **)(iRam0064e4b0 + 0x69f29c) = param_2;
  if (param_3 == (undefined1 *)0x0) {
    param_3 = &LAB_001a3800;
  }
  *(undefined1 **)(iRam0064e4b0 + 0x69f2a0) = param_3;
  if (param_4 == (undefined1 *)0x0) {
    param_4 = &LAB_001a3760;
  }
  *(undefined1 **)(iRam0064e4b0 + 0x69f2a4) = param_4;
  return 1;
}

