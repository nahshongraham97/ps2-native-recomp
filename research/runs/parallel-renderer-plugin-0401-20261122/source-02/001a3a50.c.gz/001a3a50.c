
undefined8 FUN_001a3a50(undefined8 param_1)

{
  (**(code **)(iGpffffa3c0 + 0x69f298))();
  return param_1;
}

