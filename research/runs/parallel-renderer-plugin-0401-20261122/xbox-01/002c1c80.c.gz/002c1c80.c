
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_002c1c80(undefined4 param_1)

{
  _DAT_005c7410 = _DAT_005c7410 + -1;
  return param_1;
}

