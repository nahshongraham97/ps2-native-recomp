
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_002c1c90(undefined4 param_1,int param_2)

{
  *(undefined1 **)((int)&DAT_00835348 + param_2) = &LAB_002c1450;
  *(undefined1 **)(&DAT_0083534c + param_2) = &LAB_002c10f0;
  *(undefined1 **)((int)&DAT_00835350 + param_2) = &LAB_002c1800;
  DAT_005c740c = param_2;
  *(undefined1 **)((int)&DAT_00835354 + param_2) = &LAB_002c1500;
  _DAT_005c7410 = _DAT_005c7410 + 1;
  return param_1;
}

