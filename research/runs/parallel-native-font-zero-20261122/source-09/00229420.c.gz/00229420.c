
long FUN_00229420(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  long lVar3;
  long lVar4;
  undefined8 uVar5;
  int iVar6;
  int iVar7;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined2 uStack_54;
  ushort uStack_52;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined2 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_c;
  uint uStack_8;
  int iStack_4;
  
  lVar3 = FUN_0019f1e0(param_1,1,&iStack_4,&uStack_8);
  if (lVar3 != 0) {
    if ((uStack_8 < 0x34000) || (0x36003 < uStack_8)) {
      uStack_20 = 0x116;
      uStack_1c = FUN_0019f510(0xffffffff80000004);
      FUN_0019f460(&uStack_20);
    }
    else {
      FUN_001dba60(&uStack_60,0,0x40);
      lVar3 = FUN_0019f380(param_1,&uStack_60,iStack_4);
      uVar1 = iGpffff83f8;
      iGpffff83f8 = uVar1;
      if (lVar3 != 0) {
        if (uStack_52 < 2) {
          uGpffffa7f0 = 1;
        }
        iGpffff83f8 = (uStack_44 >> 2) + 1;
        lVar3 = FUN_001a87f0(uStack_60,uStack_5c,uStack_58,uStack_54);
        uGpffffa7f0 = 0;
        iGpffff83f8 = uVar1;
        if (lVar3 != 0) {
          iVar6 = (int)lVar3;
          iVar2 = iVar6 + iGpffffa560;
          *(undefined4 *)(iVar2 + 8) = uStack_50;
          *(undefined4 *)(iVar2 + 0xc) = uStack_4c;
          *(undefined4 *)(iVar2 + 0x10) = uStack_48;
          *(char *)(iVar2 + 0x16) = (char)uStack_44;
          *(undefined4 *)(iVar2 + 0x18) = uStack_40;
          *(undefined4 *)(iVar2 + 0x1c) = uStack_3c;
          *(undefined4 *)(iVar2 + 0x20) = uStack_38;
          *(undefined4 *)(iVar2 + 0x24) = uStack_34;
          *(undefined4 *)(iVar2 + 0x28) = uStack_30;
          *(undefined4 *)(iVar2 + 0x2c) = uStack_2c;
          *(undefined4 *)(iVar2 + 0x30) = uStack_28;
          *(undefined2 *)(iVar2 + 0x14) = uStack_24;
          if (uStack_52 < 2) {
            *(int *)(iVar6 + 8) = *(int *)(iVar6 + 4) + *(int *)(iVar2 + 0x28);
            if (uStack_52 == 1) {
              if ((*(byte *)(iVar2 + 0x36) & 1) != 0) {
                FUN_001a85a0(lVar3);
                return 0;
              }
              *(byte *)(iVar2 + 0x36) = *(byte *)(iVar2 + 0x36) | 2;
            }
            else {
              if ((*(byte *)(iVar2 + 0x36) & 1) != 0) {
                FUN_001a85a0(lVar3);
                return 0;
              }
              *(byte *)(iVar2 + 0x36) = *(byte *)(iVar2 + 0x36) & 0xfd;
            }
          }
          lVar4 = FUN_0019f1e0(param_1,1,&iStack_4,&uStack_8);
          if (lVar4 == 0) {
            FUN_001a85a0(lVar3);
          }
          else if ((uStack_8 < 0x34000) || (0x36003 < uStack_8)) {
            uStack_18 = 0x116;
            uStack_14 = FUN_0019f510(0xffffffff80000004);
            FUN_0019f460(&uStack_18);
          }
          else if (uStack_52 < 2) {
            iVar2 = FUN_001a2610(param_1,*(undefined4 *)(iVar6 + 4),iStack_4);
            if (iStack_4 == iVar2) {
              FUN_0010d0d8(*(int *)(iVar6 + 4),*(int *)(iVar6 + 4) + iStack_4 + 0x7f);
              return lVar3;
            }
            FUN_001a85a0(lVar3);
          }
          else if (uStack_52 == 2) {
            lVar4 = FUN_001a2610(param_1,&uStack_c,4);
            if (lVar4 == 4) {
              lVar4 = FUN_001a2610(param_1,&gp0xffffa7f4);
              if (lVar4 == 4) {
                lVar4 = FUN_001a2610(param_1,&gp0xffffa7f8);
                if (lVar4 == 4) {
                  iVar7 = (int)param_1;
                  uVar5 = FUN_0022c5d0(*(undefined4 *)(iVar7 + 0xc));
                  FUN_001a27b0(param_1,uVar5);
                  iVar2 = *(int *)(iVar7 + 0x14);
                  iVar7 = *(int *)(iVar7 + 0xc);
                  FUN_001a27b0(param_1,uStack_c);
                  *(int *)(iVar6 + 4) = iVar2 + iVar7;
                  (*pcRam0069f3c8)(*(undefined4 *)(iVar6 + 0x24));
                  FUN_002297f0(lVar3,uStack_54);
                  return lVar3;
                }
                FUN_001a85a0(lVar3);
              }
              else {
                FUN_001a85a0(lVar3);
              }
            }
            else {
              FUN_001a85a0(lVar3);
            }
          }
          else {
            FUN_001a85a0(lVar3);
          }
        }
      }
    }
  }
  return 0;
}

