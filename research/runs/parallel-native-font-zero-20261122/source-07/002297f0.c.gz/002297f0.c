
undefined8 FUN_002297f0(int param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  ulong uVar7;
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 in_zero_qw [16];
  uint uVar17;
  int iVar18;
  long lVar19;
  ulong extraout_v0_udw;
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 auVar25 [16];
  undefined1 auVar26 [16];
  undefined1 auVar27 [16];
  undefined1 auVar28 [16];
  undefined1 auVar29 [16];
  uint uVar30;
  undefined8 in_v1_udw;
  undefined1 auVar31 [16];
  undefined1 auVar32 [16];
  undefined1 auVar33 [16];
  undefined1 auVar34 [16];
  undefined1 auVar35 [16];
  undefined8 in_a0_udw;
  undefined1 auVar36 [16];
  undefined1 auVar37 [16];
  byte bVar38;
  int iVar39;
  uint uVar40;
  undefined8 in_a1_udw;
  undefined1 auVar41 [16];
  undefined1 auVar42 [16];
  undefined1 auVar43 [16];
  undefined1 auVar44 [16];
  int iVar45;
  undefined4 in_a2_udw;
  undefined4 in_register_0000006c;
  uint uVar46;
  uint uVar47;
  uint uVar48;
  uint uVar49;
  int iVar50;
  ulong *puVar51;
  ulong *puVar52;
  uint *puVar53;
  ulong in_t4_udw;
  ulong in_t5_udw;
  undefined1 auVar54 [16];
  undefined4 uVar55;
  undefined4 uVar57;
  undefined4 uVar58;
  undefined1 auVar56 [16];
  undefined4 uVar59;
  undefined4 *puVar60;
  ulong uVar61;
  undefined1 in_s1_qw [16];
  undefined1 auVar62 [16];
  ulong uVar65;
  undefined1 auVar63 [16];
  undefined1 auVar64 [16];
  int iVar66;
  undefined4 *puVar67;
  undefined4 in_s4_udw;
  undefined4 in_register_0000014c;
  undefined4 in_s5_udw;
  undefined4 in_register_0000015c;
  uint uVar68;
  undefined1 auVar69 [16];
  undefined8 in_hi;
  int iStack_140;
  long lStack_120;
  int iStack_110;
  int iStack_100;
  int iStack_f0;
  uint auStack_e0 [8];
  ulong auStack_c0 [8];
  ulong auStack_80 [8];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  uint uStack_10;
  int iStack_c;
  int iStack_8;
  uint uStack_4;
  
  uVar48 = (uint)((ulong)in_hi >> 0x20);
  iVar66 = param_1 + iGpffffa560;
  lVar19 = FUN_001b1790(0);
  if (lVar19 == 0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined1 *)(iVar66 + 0x17) = 0;
  *(undefined1 *)(iVar66 + 0x34) = 0;
  *(undefined4 *)(iVar66 + 0x38) = 0;
  *(undefined4 *)(iVar66 + 0x3c) = 0;
  *(undefined4 *)(iVar66 + 0x40) = 0;
  *(undefined4 *)(iVar66 + 0x44) = 0;
  *(undefined4 *)(iVar66 + 0x48) = 0;
  *(undefined4 *)(iVar66 + 0x4c) = 0;
  *(undefined4 *)(iVar66 + 0x50) = 0;
  *(undefined4 *)(iVar66 + 0x54) = 0;
  *(undefined4 *)(iVar66 + 0x58) = 0;
  *(undefined1 *)(iVar66 + 0x36) = 0;
  *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0x24) = 0;
  if ((*(int *)(param_1 + 0xc) == 0) || (*(int *)(param_1 + 0x10) == 0)) {
    *(undefined1 *)(param_1 + 0x21) = 0x80;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x30) = 0;
    goto LAB_0022ae60;
  }
  cVar2 = *(char *)(param_1 + 0x20);
  if (cVar2 == '\x05') {
    return 0;
  }
  if ((((cVar2 == '\x02') || (cVar2 == '\x01')) || (cVar2 == '\0')) || (cVar2 != '\x04')) {
    return 0;
  }
  iVar39 = *(int *)(param_1 + 0x14) * 4;
  iVar50 = *(int *)(&DAT_005fe8dc + iVar39);
  uVar30 = *(uint *)(iVar39 + 0x5fe85c);
  lVar19 = FUN_001af0b0();
  auVar23._8_8_ = in_s1_qw._8_8_;
  if (1 << ((uint)lVar19 & 0x1f) < *(int *)(param_1 + 0xc)) {
    lVar19 = (long)(int)((uint)lVar19 + 1);
    uVar55 = *(undefined4 *)(param_1 + 0x10);
  }
  else {
    uVar55 = *(undefined4 *)(param_1 + 0x10);
  }
  auVar23._0_8_ = lVar19;
  uVar17 = FUN_001af0b0(uVar55);
  if (1 << (uVar17 & 0x1f) < *(int *)(param_1 + 0x10)) {
    uVar17 = uVar17 + 1;
    uVar40 = *(uint *)(param_1 + 0xc);
  }
  else {
    uVar40 = *(uint *)(param_1 + 0xc);
  }
  if (uVar30 < uVar40) {
    uVar40 = (int)uVar40 >> 6;
  }
  else {
    uVar40 = uVar30 >> 6;
  }
  *(uint *)(iVar66 + 8) = uVar17 << 0x1e | (auVar23._0_4_ & 0xf) << 0x1a | uVar40 << 0xe;
  iVar39 = 0x20;
  *(int *)(iVar66 + 0xc) = (int)(uVar17 & 0xf) >> 2;
  *(short *)(iVar66 + 0x14) = (short)uGpffff8628;
  *(undefined1 *)(iVar66 + 0x34) = 1;
  bVar38 = *(byte *)(param_1 + 0x23);
  if ((bVar38 & 0x60) == 0x20) {
    iStack_110 = 0x10;
    iStack_100 = 0x10;
    *(uint *)(iVar66 + 8) = *(uint *)(iVar66 + 8) | 0x1300000;
    uVar17 = *(uint *)(iVar66 + 0xc);
    *(uint *)(iVar66 + 0xc) = uVar17 | 4;
    *(uint *)(iVar66 + 0xc) = uVar17 | 0x20000004;
    bVar38 = *(byte *)(param_1 + 0x23) & 0xf;
    if (bVar38 == 5) {
      iVar45 = 0x40;
      iStack_f0 = 4;
    }
    else {
      if (bVar38 != 1) {
        uStack_28 = 0x116;
        uStack_24 = FUN_0019f510(0xffffffff8000000d);
        FUN_0019f460(&uStack_28);
        return 0;
      }
      iVar45 = 0x40;
      iStack_f0 = 2;
      iVar39 = 0x40;
      *(uint *)(iVar66 + 0xc) = *(uint *)(iVar66 + 0xc) | 0x500000;
    }
  }
  else {
    iVar45 = 0x40;
    if ((bVar38 & 0x60) == 0x40) {
      iStack_110 = 8;
      *(uint *)(iVar66 + 8) = *(uint *)(iVar66 + 8) | 0x1400000;
      uVar17 = *(uint *)(iVar66 + 0xc);
      iStack_100 = 2;
      *(uint *)(iVar66 + 0xc) = uVar17 | 4;
      *(uint *)(iVar66 + 0xc) = uVar17 | 0x20000004;
      bVar38 = *(byte *)(param_1 + 0x23) & 0xf;
      if (bVar38 == 5) {
        iStack_f0 = 4;
      }
      else {
        if (bVar38 != 1) {
          uStack_20 = 0x116;
          uStack_1c = FUN_0019f510(0xffffffff8000000d);
          FUN_0019f460(&uStack_20);
          return 0;
        }
        iVar39 = 0x40;
        iStack_f0 = 2;
        *(uint *)(iVar66 + 0xc) = *(uint *)(iVar66 + 0xc) | 0x500000;
      }
    }
    else {
      if ((bVar38 & 0x60) != 0) {
        uStack_30 = 0x116;
        uStack_2c = FUN_0019f510(0xffffffff8000000d);
        FUN_0019f460(&uStack_30);
        return 0;
      }
      bVar38 = bVar38 & 0xf;
      iStack_100 = 0;
      iVar39 = 0;
      iStack_110 = 0;
      iVar45 = 0;
      iStack_f0 = 0;
      if (bVar38 == 5) {
        *(uint *)(iVar66 + 0xc) = *(uint *)(iVar66 + 0xc) | 4;
      }
      else if (bVar38 == 6) {
        *(uint *)(iVar66 + 8) = *(uint *)(iVar66 + 8) | 0x100000;
      }
      else {
        if (bVar38 != 1) {
          uStack_18 = 0x116;
          uStack_14 = FUN_0019f510(0xffffffff8000000d);
          FUN_0019f460(&uStack_18);
          return 0;
        }
        *(uint *)(iVar66 + 8) = *(uint *)(iVar66 + 8) | 0xa00000;
        *(uint *)(iVar66 + 0xc) = *(uint *)(iVar66 + 0xc) | 4;
      }
    }
  }
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x14) * *(int *)(param_1 + 0xc) >> 3;
  if ((*(byte *)(param_1 + 0x23) & 0x80) == 0) {
    *(uint *)(iVar66 + 0x28) =
         *(int *)(param_1 + 0x10) * *(int *)(param_1 + 0x18) + 0xfU & 0xfffffff0;
    *(undefined4 *)(iVar66 + 0x18) = 0x4000;
    *(undefined4 *)(iVar66 + 0x1c) = 0x400004;
    *(undefined4 *)(iVar66 + 0x20) = 0x4000;
    *(undefined4 *)(iVar66 + 0x24) = 0x400004;
    *(undefined1 *)(iVar66 + 0x16) = 0;
    auStack_80[0] = 0;
    auStack_e0[0] = 0;
    iVar18 = (int)(*(int *)(param_1 + 0xc) + uVar30 + -1) / (int)uVar30;
    auStack_c0[0] = (ulong)((uVar30 >> 6) * iVar18);
    iVar1 = (*(int *)(param_1 + 0x10) + iVar50 + -1) / iVar50;
    *(int *)(iVar66 + 0x30) = iVar18 * iVar1 * 0x800;
    iStack_140 = iStack_f0 * iStack_110 * iStack_100;
    *(int *)(iVar66 + 0x2c) = iStack_140;
    if (iStack_140 == 0) {
      *(undefined4 *)(iVar66 + 0x10) = 0;
    }
    else {
      if (*(int *)(param_1 + 0xc) < (int)(iVar18 * uVar30)) {
        uVar48 = *(uint *)(iVar66 + 0x30);
      }
      else {
        if (iVar1 * iVar50 <= *(int *)(param_1 + 0x10)) {
          *(uint *)(iVar66 + 0x10) = *(uint *)(iVar66 + 0x30) >> 6;
          *(uint *)(iVar66 + 0x30) =
               *(int *)(iVar66 + 0x30) +
               ((iStack_110 + iVar45 + -1) / iVar45) * ((iStack_100 + iVar39 + -1) / iVar39) * 0x800
               & 0xfffff800;
          goto LAB_0022a28c;
        }
        uVar48 = *(uint *)(iVar66 + 0x30);
      }
      *(uint *)(iVar66 + 0x10) = (uVar48 >> 6) - 4;
    }
  }
  else {
    uVar17 = *(uint *)(param_1 + 0xc);
    uVar40 = *(uint *)(param_1 + 0x10);
    auVar56._8_8_ = 0;
    auVar56._0_8_ = auVar23._8_8_;
    auVar23 = auVar56 << 0x40;
    iVar39 = 0;
    uStack_4 = 0;
    auStack_80[2] = 0;
    auStack_80[1] = 0;
    auStack_80[0] = 0;
    auStack_80[5] = 0;
    auStack_80[4] = 0;
    auStack_80[3] = 0;
    auStack_80[6] = 0;
    auStack_c0[2] = 1;
    auStack_c0[1] = 1;
    auStack_c0[0] = 1;
    auStack_c0[5] = 1;
    auStack_c0[4] = 1;
    auStack_c0[3] = 1;
    auStack_c0[6] = 1;
    uVar68 = uVar30;
    if (uVar30 < uVar17) {
      uVar68 = uVar17;
    }
    auVar24._8_8_ = (ulong)(int)(uVar68 >> 6);
    puVar52 = auStack_c0;
    puVar51 = auStack_80;
    uVar68 = 0;
    while (((uVar17 != 0 && (uVar40 != 0)) && (auVar23._0_8_ < (ulong)(long)iGpffff83f8))) {
      if (*(int *)(param_1 + 0xc) < 8) {
        iVar45 = *(int *)(param_1 + 0x14);
      }
      else {
        if ((7 < *(int *)(param_1 + 0x10)) && ((uVar17 < 8 || (uVar40 < 8)))) break;
        iVar45 = *(int *)(param_1 + 0x14);
      }
      iVar39 = iVar39 + ((uVar40 * iVar45 * uVar17 >> 3) + 0xf & 0xfffffff0);
      uVar49 = uVar30;
      if (uVar30 < uVar17) {
        uVar49 = uVar17;
      }
      *puVar52 = (ulong)(uVar49 >> 6);
      iVar45 = *(int *)(param_1 + 0x14);
      lVar19 = *puVar52 << 6;
      auVar56 = _pextlw((ulong)uVar48 << 0x20,(ulong)(uint)(iVar45 * (int)lVar19));
      uVar49 = uStack_4;
      if (auVar24._8_8_ != *puVar52) {
        uVar49 = auVar23._0_4_ - 1;
        iVar18 = iVar50 + -1 + (*(int *)(param_1 + 0x10) >> (uVar49 & 0x1f));
        uVar48 = iVar18 % iVar50 >> 0x1f;
        uVar49 = uVar68 + ((int)((uVar30 - 1) + (*(int *)(param_1 + 0xc) >> (uVar49 & 0x1f))) /
                          (int)uVar30) * (iVar18 / iVar50) * 0x800 & 0xfffff800;
      }
      uVar46 = uVar49 + 0x3f;
      uStack_4 = uVar49;
      uVar47 = (uVar46 & 0x7c0) >> 8;
      uVar68 = *(uint *)(iVar66 + 8) >> 0x14 & 0x3f;
      auVar24._8_8_ = *puVar52;
      if (uVar68 == 0x14) {
        *puVar51 = (ulong)((uVar46 >> 0xb) * 0x20 + *(int *)(&DAT_005fe9e0 + uVar47 * 4));
      }
      else if (uVar68 == 0x13) {
        *puVar51 = (ulong)((uVar46 >> 0xb) * 0x20 + *(int *)(&DAT_005fe9c0 + uVar47 * 4));
      }
      else if (uVar68 == 10) {
        *puVar51 = (ulong)((uVar46 >> 0xb) * 0x20 + *(int *)(&DAT_005fe9a0 + uVar47 * 4));
      }
      else if (uVar68 == 2) {
        *puVar51 = (ulong)((uVar46 >> 0xb) * 0x20 + *(int *)(&DAT_005fe980 + uVar47 * 4));
      }
      else if ((uVar68 == 1) || (uVar68 == 0)) {
        *puVar51 = (ulong)((uVar46 >> 0xb) * 0x20 + *(int *)(&DAT_005fe960 + uVar47 * 4));
      }
      uVar68 = uVar40 * (int)(((ulong)(uint)((int)((ulong)lVar19 >> 0x20) * iVar45) << 0x20) +
                              auVar56._0_8_ >> 3);
      puVar52 = puVar52 + 1;
      puVar51 = puVar51 + 1;
      auVar23._0_8_ = (long)(auVar23._0_4_ + 1);
      uVar17 = uVar17 >> 1;
      uVar40 = uVar40 >> 1;
      uStack_4 = uVar49 + (uVar68 >> 2) + 0x3f & 0xffffffc0;
      uVar68 = uVar49;
    }
    FUN_001b1de0(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10),
                 *(uint *)(iVar66 + 8) >> 0x14 & 0x3f,auStack_80,auStack_c0,auStack_e0,&uStack_4,
                 &iStack_8);
    *(int *)(iVar66 + 0x28) = iVar39;
    *(char *)(iVar66 + 0x16) = (auVar23[0] + -1) * '\x04';
    auVar24._8_8_ =
         (auStack_80[2] & 0x3fff) << 0x14 |
         CONCAT44((int)((auStack_c0[1] << 0xe) >> 0x20),
                  (uint)auStack_80[1] & 0x3fff | (uint)(auStack_c0[1] << 0xe));
    iStack_140 = iStack_f0 * iStack_110 * iStack_100;
    *(int *)(iVar66 + 0x18) = (int)auVar24._8_8_;
    *(uint *)(iVar66 + 0x1c) =
         (uint)((auStack_c0[3] << 0x36) >> 0x20) |
         (uint)(((auStack_80[3] & 0x3fff) << 0x28) >> 0x20) |
         (uint)((auStack_c0[2] << 0x22) >> 0x20) | (uint)(auVar24._8_8_ >> 0x20);
    auVar24._8_8_ = (auStack_80[5] & 0x3fff) << 0x14 | auStack_80[4] & 0x3fff | auStack_c0[4] << 0xe
    ;
    *(int *)(iVar66 + 0x20) = (int)auVar24._8_8_;
    *(uint *)(iVar66 + 0x24) =
         (uint)((auStack_c0[6] << 0x36) >> 0x20) |
         (uint)(((auStack_80[6] & 0x3fff) << 0x28) >> 0x20) |
         (uint)((auStack_c0[5] << 0x22) >> 0x20) | (uint)(auVar24._8_8_ >> 0x20);
    *(int *)(iVar66 + 0x2c) = iStack_140;
    *(uint *)(iVar66 + 0x30) = uStack_4;
    if (*(int *)(iVar66 + 0x2c) == 0) {
      *(undefined4 *)(iVar66 + 0x10) = 0;
    }
    else {
      *(int *)(iVar66 + 0x10) = iStack_8;
      if (iStack_8 << 6 == uStack_4) {
        *(int *)(iVar66 + 0x30) = *(int *)(iVar66 + 0x30) + 0x800;
      }
    }
  }
LAB_0022a28c:
  *(uint *)(iVar66 + 0x28) = *(int *)(iVar66 + 0x28) + 0xfU & 0xfffffff0;
  if ((iGpffffa7f0 == 0) &&
     (*(int *)(param_1 + 0x14) * *(int *)(param_1 + 0x10) * *(int *)(param_1 + 0xc) >> 7 < 0x7fff))
  {
    *(byte *)(iVar66 + 0x36) = *(byte *)(iVar66 + 0x36) | 1;
    lStack_120 = 0;
    if ((*(uint *)(iVar66 + 8) >> 0x14 & 0x3f) == 0x13) {
      *(byte *)(iVar66 + 0x36) = *(byte *)(iVar66 + 0x36) | 2;
      if ((*(uint *)(iVar66 + 0xc) >> 0x13 & 0xf) == 0) {
        iVar50 = (int)(uint)*(byte *)(iVar66 + 0x16) >> 2;
        if (auStack_c0[iVar50] == 2) {
          auVar24._8_8_ = auStack_80[iVar50];
          uVar48 = *(uint *)(iVar66 + 0x10);
          auVar54._8_8_ = in_t4_udw;
          auVar54._0_8_ = 0xffffffffffffffe1;
          uVar30 = *(uint *)((int)auStack_e0 + (*(byte *)(iVar66 + 0x16) & 0xfffffffc));
          auVar56 = _pcpyld(in_zero_qw,auVar54);
          in_t4_udw = auVar56._8_8_;
          uVar48 = ((uVar48 & 0x10) >> 2 |
                   (uVar48 & 8) << 1 | (uVar48 & 4) >> 1 | (uVar48 & 2) << 2 | uVar48 & 0xffffffe1)
                   - ((((uint)((auVar24._8_8_ & 0x10) >> 2) |
                       (uint)((auVar24._8_8_ & 8) << 1) |
                       (uint)((auVar24._8_8_ & 4) >> 1) |
                       (uint)((auVar24._8_8_ & 2) << 2) | (uint)auVar24._8_8_ & auVar56._0_4_) -
                      ((uVar30 & 0x7ff) >> 4)) + ((uVar30 >> 0x10 & 0x7ff) >> 4) * -8);
          uVar30 = (uVar48 & 0x1fffffff) >> 3;
          if (uVar30 << 3 < 0x800) {
            lStack_120 = ((ulong)(uVar30 << 0x13) | (long)(int)(uVar48 * 8) & 0x3fU) << 0x20;
          }
        }
        goto LAB_0022a42c;
      }
      uVar48 = *(uint *)(iVar66 + 8);
    }
    else {
LAB_0022a42c:
      uVar48 = *(uint *)(iVar66 + 8);
    }
    if ((uVar48 >> 0x14 & 0x3f) == 0x14) {
      *(byte *)(iVar66 + 0x36) = *(byte *)(iVar66 + 0x36) | 4;
      if ((*(uint *)(iVar66 + 0xc) >> 0x13 & 0xf) == 2) {
        iVar50 = (int)(uint)*(byte *)(iVar66 + 0x16) >> 2;
        if (auStack_c0[iVar50] == 2) {
          auVar24._8_8_ = auStack_80[iVar50];
          auVar69._8_8_ = in_a1_udw;
          auVar69._0_8_ = 0xffffffffffffffe0;
          uVar48 = *(uint *)(iVar66 + 0x10);
          uVar30 = *(uint *)((int)auStack_e0 + (*(byte *)(iVar66 + 0x16) & 0xfffffffc));
          auVar56 = _pcpyld(in_zero_qw,auVar69);
          in_a0_udw = auVar56._8_8_;
          uVar48 = (uVar48 & 0x10 |
                   (uVar48 & 8) >> 2 |
                   (uVar48 & 4) << 1 | (uVar48 & 2) >> 1 | uVar48 & 0xffffffe0 | (uVar48 & 1) << 2)
                   - ((((uint)auVar24._8_8_ & 0x10 |
                       (uint)((auVar24._8_8_ & 8) >> 2) |
                       (uint)((auVar24._8_8_ & 4) << 1) |
                       (uint)((auVar24._8_8_ & 2) >> 1) |
                       (uint)auVar24._8_8_ & auVar56._0_4_ | (uint)((auVar24._8_8_ & 1) << 2)) -
                      ((uVar30 & 0x7ff) >> 5)) + ((uVar30 >> 0x10 & 0x7ff) >> 4) * -4);
          uVar30 = (uVar48 & 0xfffffff) >> 2;
          if (uVar30 << 3 < 0x800) {
            lStack_120 = ((ulong)(uVar30 << 0x13) | (long)(int)(uVar48 * 0x10) & 0x3fU) << 0x20;
          }
          else {
            lStack_120 = 0;
          }
        }
        else {
          lStack_120 = 0;
        }
      }
      bVar38 = *(byte *)(iVar66 + 0x16);
    }
    else {
      bVar38 = *(byte *)(iVar66 + 0x16);
    }
    *(int *)(iVar66 + 0x28) = (((int)(uint)bVar38 >> 2) + 1) * 0x50;
    FUN_001b33c0(*(uint *)(iVar66 + 8) >> 0x14 & 0x3f,*(undefined1 *)(iVar66 + 0x36),&iStack_c,
                 &uStack_10);
    iVar50 = *(int *)(param_1 + 0xc);
    iVar39 = *(int *)(param_1 + 0x10);
    iVar45 = 0;
    do {
      iVar18 = iStack_c;
      if (iStack_c <= iVar50) {
        iVar18 = iVar50;
      }
      iVar1 = iStack_c;
      if ((int)uStack_10 <= iVar39) {
        iVar1 = iVar39;
      }
      iVar45 = iVar45 + 1;
      iVar50 = iVar50 >> 1;
      *(uint *)(iVar66 + 0x28) =
           *(int *)(iVar66 + 0x28) +
           ((*(int *)(param_1 + 0x14) * iVar18 * iVar1 >> 3) + 0xfU & 0xfffffff0);
      iVar39 = iVar39 >> 1;
    } while (iVar45 <= (int)(uint)*(byte *)(iVar66 + 0x16) >> 2);
    if (*(int *)(iVar66 + 0x2c) == 0) {
      bVar38 = *(byte *)(iVar66 + 0x16);
    }
    else {
      if (iStack_100 == 2) {
        iStack_100 = 3;
      }
      iStack_140 = iStack_f0 * iStack_110 * iStack_100;
      *(int *)(iVar66 + 0x2c) = iStack_140 + 0x50;
      bVar38 = *(byte *)(iVar66 + 0x16);
    }
    iVar39 = 0x10;
    iVar45 = 0;
    iVar50 = 0;
    puVar53 = auStack_e0;
    do {
      if (*puVar53 == 0) {
        iVar39 = iVar39 + 0x40;
        iVar45 = iVar45 + 1;
      }
      iVar50 = iVar50 + 1;
      puVar53 = puVar53 + 1;
    } while (iVar50 <= (int)(uint)bVar38 >> 2);
    if (*(int *)(iVar66 + 0x2c) == 0) {
      piVar3 = *(int **)(param_1 + 4);
    }
    else {
      iVar39 = iVar39 + 0x40;
      iVar45 = iVar45 + 1;
      piVar3 = *(int **)(param_1 + 4);
    }
    if (piVar3 == (int *)0x0) {
      uStack_38 = 0x116;
      uStack_34 = FUN_0019f510(0xffffffff80000013,
                               (*(int *)(iVar66 + 0x2c) + 0x3fU & 0xffffffc0) +
                               iVar39 + 0x70 + (*(int *)(iVar66 + 0x28) + 0x7fU & 0xffffff80));
      FUN_0019f460(&uStack_38);
      return 0;
    }
    *piVar3 = iVar45;
    *(uint *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4) + 0x8f + iVar45 * 0x40 & 0xffffff80
    ;
    *(int *)(*(int *)(param_1 + 4) + 8) = iVar45;
    if (*(int *)(iVar66 + 0x2c) == 0) {
      iVar50 = *(int *)(param_1 + 4);
    }
    else {
      if (lStack_120 == 0) {
        iVar50 = (*(int *)(iVar66 + 0x28) + 0x7fU & 0xffffff80) +
                 (*(int *)(param_1 + 4) + iVar39 + 0x70U & 0xffffff80);
        *(int *)(param_1 + 8) = iVar50;
        *(int *)(param_1 + 8) = iVar50 + 0x50;
      }
      iVar50 = *(int *)(param_1 + 4);
    }
    auVar20._8_8_ = extraout_v0_udw;
    auVar20._0_8_ = 0x1000000000000001;
    auVar34._8_4_ = in_a2_udw;
    auVar34._0_8_ = 0xe;
    auVar34._12_4_ = in_register_0000006c;
    auVar54 = _pcpyld(auVar34,auVar20);
    puVar67 = *(undefined4 **)(iVar50 + 4);
    puVar60 = (undefined4 *)(iVar50 + 0x10);
    auVar31._8_8_ = in_v1_udw;
    auVar31._0_8_ = 0x1000000000000003;
    iVar50 = *(int *)(param_1 + 0xc);
    auVar4._8_4_ = in_a2_udw;
    auVar4._0_8_ = 0xe;
    auVar4._12_4_ = in_register_0000006c;
    auVar56 = _pcpyld(auVar4,auVar31);
    uVar48 = *(uint *)(param_1 + 0x10);
    iVar39 = 0;
    uVar55 = auVar56._0_4_;
    uVar57 = auVar56._4_4_;
    uVar58 = auVar56._8_4_;
    uVar59 = auVar56._12_4_;
    auVar36._8_8_ = in_a0_udw;
    auVar36._0_8_ = 0x53;
    auVar10._8_8_ = 0;
    auVar10._0_8_ = in_t5_udw;
    auVar11._8_8_ = 0;
    auVar11._0_8_ = in_t4_udw;
    auVar32._8_8_ = in_v1_udw;
    auVar32._0_8_ = 0x10000002;
    puVar53 = auStack_e0;
    auVar21._8_8_ = extraout_v0_udw;
    auVar21._0_8_ = 0x5000000200000000;
    puVar52 = auStack_80;
    auVar69 = _pcpyld(auVar21,auVar32);
    puVar51 = auStack_c0;
    auVar56 = _pcpyld(auVar36,auVar10 << 0x40);
    auVar24._8_8_ = extraout_v0_udw;
    do {
      auVar62._8_8_ = auVar23._8_8_;
      auVar33._8_8_ = auVar32._8_8_;
      iVar45 = iStack_c;
      if (iStack_c <= iVar50) {
        iVar45 = iVar50;
      }
      if ((int)uVar48 < (int)uStack_10) {
        *puVar67 = uVar55;
        puVar67[1] = uVar57;
        puVar67[2] = uVar58;
        puVar67[3] = uVar59;
        uVar30 = uStack_10;
      }
      else {
        *puVar67 = uVar55;
        puVar67[1] = uVar57;
        puVar67[2] = uVar58;
        puVar67[3] = uVar59;
        uVar30 = uVar48;
      }
      if ((((*(byte *)(iVar66 + 0x36) & 2) == 0) || ((*(uint *)(iVar66 + 8) >> 0x14 & 0x3f) != 0x13)
          ) && (((*(byte *)(iVar66 + 0x36) & 4) == 0 ||
                ((*(uint *)(iVar66 + 8) >> 0x14 & 0x3f) != 0x14)))) {
        uVar17 = *puVar53;
      }
      else {
        uVar17 = (uint)((((long)(int)*puVar53 & 0xfffefffeU) << 0x1f) >> 0x20);
      }
      auVar22._8_8_ = auVar24._8_8_;
      auVar22._0_8_ = 0x51;
      auVar16._4_4_ = in_s5_udw;
      auVar16._0_4_ = uVar17;
      auVar16._8_4_ = in_register_0000015c;
      auVar16._12_4_ = 0;
      auVar23 = _pcpyld(auVar22,auVar16 << 0x20);
      puVar67[4] = auVar23._0_4_;
      puVar67[5] = auVar23._4_4_;
      puVar67[6] = auVar23._8_4_;
      puVar67[7] = auVar23._12_4_;
      auVar24._8_8_ = auVar23._8_8_;
      if ((((*(byte *)(iVar66 + 0x36) & 2) != 0) && ((*(uint *)(iVar66 + 8) >> 0x14 & 0x3f) == 0x13)
          ) || ((iVar18 = iVar45, uVar17 = uVar30, (*(byte *)(iVar66 + 0x36) & 4) != 0 &&
                ((*(uint *)(iVar66 + 8) >> 0x14 & 0x3f) == 0x14)))) {
        iVar18 = iVar45 >> 1;
        uVar17 = (int)uVar30 >> 1;
      }
      auVar33._0_8_ = 0x52;
      auVar8._4_4_ = iVar45 >> 0x1f | uVar17;
      auVar8._0_4_ = iVar18;
      auVar8._8_4_ = in_s5_udw;
      auVar8._12_4_ = in_register_0000015c;
      auVar34 = _pcpyld(auVar33,auVar8);
      puVar67[8] = auVar34._0_4_;
      puVar67[9] = auVar34._4_4_;
      puVar67[10] = auVar34._8_4_;
      puVar67[0xb] = auVar34._12_4_;
      puVar67[0xc] = auVar56._0_4_;
      puVar67[0xd] = auVar56._4_4_;
      puVar67[0xe] = auVar56._8_4_;
      puVar67[0xf] = auVar56._12_4_;
      uVar30 = ((int)(*(int *)(param_1 + 0x14) * iVar45 * uVar30) >> 3) + 0xf >> 4;
      auVar62._0_8_ = (long)(int)uVar30 | 0x800000000000000;
      uVar30 = uVar30 & 0x7fff;
      auVar23 = _pcpyld(auVar11 << 0x40,auVar62);
      puVar67[0x10] = auVar23._0_4_;
      puVar67[0x11] = auVar23._4_4_;
      puVar67[0x12] = auVar23._8_4_;
      puVar67[0x13] = auVar23._12_4_;
      uVar65 = auVar23._8_8_;
      if (*puVar53 == 0) {
        *puVar60 = auVar69._0_4_;
        puVar60[1] = auVar69._4_4_;
        puVar60[2] = auVar69._8_4_;
        puVar60[3] = auVar69._12_4_;
        puVar60[4] = auVar54._0_4_;
        puVar60[5] = auVar54._4_4_;
        puVar60[6] = auVar54._8_4_;
        puVar60[7] = auVar54._12_4_;
        if (((*(byte *)(iVar66 + 0x36) & 2) == 0) ||
           ((*(uint *)(iVar66 + 8) >> 0x14 & 0x3f) != 0x13)) {
          if (((*(byte *)(iVar66 + 0x36) & 4) == 0) ||
             ((*(uint *)(iVar66 + 8) >> 0x14 & 0x3f) != 0x14)) {
            uVar7 = *puVar51;
            uVar61 = (long)(int)(*(uint *)(iVar66 + 8) >> 0x14) & 0x3f;
            uVar17 = (int)uVar61 << 0x18 | (uint)(uVar7 << 0x10);
            uVar40 = (uint)((uVar61 << 0x38) >> 0x20) |
                     (uint)((uVar7 << 0x30) >> 0x20) | (uint)(uVar7 >> 0x10) | (uint)*puVar52;
          }
          else {
            uVar17 = (uint)((*puVar51 & 0x3e) << 0xf) | 0x2000000;
            uVar40 = (uint)(((*puVar51 & 0x3e) << 0x2f) >> 0x20) | (uint)*puVar52 | 0x2000000;
            uVar65 = extraout_v0_udw;
          }
        }
        else {
          uVar40 = (uint)(((*puVar51 & 0x3e) << 0x2f) >> 0x20) | (uint)*puVar52;
          uVar17 = (uint)((*puVar51 & 0x3e) << 0xf);
        }
        auVar63._8_8_ = uVar65;
        auVar63._0_8_ = 0x50;
        auVar9._4_4_ = uVar40;
        auVar9._0_4_ = uVar17;
        auVar9._8_4_ = in_s5_udw;
        auVar9._12_4_ = in_register_0000015c;
        auVar23 = _pcpyld(auVar63,auVar9);
        puVar60[8] = auVar23._0_4_;
        puVar60[9] = auVar23._4_4_;
        puVar60[10] = auVar23._8_4_;
        puVar60[0xb] = auVar23._12_4_;
        auVar64._8_8_ = auVar23._8_8_;
        auVar64._0_8_ = ((long)(int)(uVar30 + 5) | 0x50000000U) << 0x20;
        auVar6._8_4_ = in_s4_udw;
        auVar6._0_8_ = (long)(int)(uVar30 + 5) | 0x30000000U | ZEXT48(puVar67) << 0x20;
        auVar6._12_4_ = in_register_0000014c;
        auVar23 = _pcpyld(auVar64,auVar6);
        puVar60[0xc] = auVar23._0_4_;
        puVar60[0xd] = auVar23._4_4_;
        puVar60[0xe] = auVar23._8_4_;
        puVar60[0xf] = auVar23._12_4_;
        puVar60 = puVar60 + 0x10;
      }
      else {
        puVar60[-4] = (uint)*(ushort *)(puVar60 + -4) + uVar30 + 5 | 0x30000000;
        auVar14._8_8_ = 0;
        auVar14._0_8_ = uVar65;
        auVar23 = auVar14 << 0x40;
        puVar60[-1] = (uint)*(ushort *)(puVar60 + -1) + uVar30 + 5 | 0x50000000;
      }
      auVar15._8_8_ = 0;
      auVar15._0_8_ = auVar34._8_8_;
      auVar32 = auVar15 << 0x40;
      puVar67 = puVar67 + uVar30 * 4 + 0x14;
      iVar39 = iVar39 + 1;
      iVar50 = iVar50 >> 1;
      uVar48 = (int)uVar48 >> 1;
      puVar53 = puVar53 + 1;
      puVar52 = puVar52 + 1;
      puVar51 = puVar51 + 1;
    } while (iVar39 <= (int)(uint)*(byte *)(iVar66 + 0x16) >> 2);
    if (*(int *)(iVar66 + 0x2c) != 0) {
      if (lStack_120 != 0) {
        *(undefined4 **)(param_1 + 8) = puVar67 + 0x14;
      }
      auVar41._8_8_ = in_a1_udw;
      auVar41._0_8_ = 0x51;
      iVar50 = *(int *)(param_1 + 8);
      *(undefined4 *)(iVar50 + -0x50) = uVar55;
      *(undefined4 *)(iVar50 + -0x4c) = uVar57;
      *(undefined4 *)(iVar50 + -0x48) = uVar58;
      *(undefined4 *)(iVar50 + -0x44) = uVar59;
      auVar37._0_8_ = (long)iStack_110 | (long)iStack_100 << 0x20;
      auVar37._8_8_ = in_a0_udw;
      iVar39 = iStack_140 + 0xf >> 4;
      auVar24._0_8_ = 0x52;
      auVar56 = _pcpyld(auVar24,auVar37);
      auVar25._8_8_ = auVar24._8_8_;
      auVar25._0_8_ = lStack_120;
      auVar23 = _pcpyld(auVar41,auVar25);
      *(int *)(iVar50 + -0x40) = auVar23._0_4_;
      *(int *)(iVar50 + -0x3c) = auVar23._4_4_;
      *(int *)(iVar50 + -0x38) = auVar23._8_4_;
      *(int *)(iVar50 + -0x34) = auVar23._12_4_;
      auVar42._8_8_ = in_a1_udw;
      auVar42._0_8_ = 0x53;
      auVar26._8_8_ = auVar23._8_8_;
      *(int *)(iVar50 + -0x30) = auVar56._0_4_;
      *(int *)(iVar50 + -0x2c) = auVar56._4_4_;
      *(int *)(iVar50 + -0x28) = auVar56._8_4_;
      *(int *)(iVar50 + -0x24) = auVar56._12_4_;
      auVar12._8_8_ = 0;
      auVar12._0_8_ = auVar56._8_8_;
      auVar26._0_8_ = (long)iVar39 | 0x800000000000000;
      auVar56 = _pcpyld(auVar42,auVar12 << 0x40);
      auVar13._8_8_ = 0;
      auVar13._0_8_ = auVar34._8_8_;
      *(int *)(iVar50 + -0x20) = auVar56._0_4_;
      *(int *)(iVar50 + -0x1c) = auVar56._4_4_;
      *(int *)(iVar50 + -0x18) = auVar56._8_4_;
      *(int *)(iVar50 + -0x14) = auVar56._12_4_;
      auVar23 = _pcpyld(auVar13 << 0x40,auVar26);
      *(int *)(iVar50 + -0x10) = auVar23._0_4_;
      *(int *)(iVar50 + -0xc) = auVar23._4_4_;
      *(int *)(iVar50 + -8) = auVar23._8_4_;
      *(int *)(iVar50 + -4) = auVar23._12_4_;
      auVar35._8_8_ = auVar23._8_8_;
      auVar43._8_8_ = auVar56._8_8_;
      auVar43._0_8_ = 0x10000002;
      auVar5._8_4_ = in_a2_udw;
      auVar5._0_8_ = 0x5000000200000000;
      auVar5._12_4_ = in_register_0000006c;
      auVar23 = _pcpyld(auVar5,auVar43);
      *puVar60 = auVar23._0_4_;
      puVar60[1] = auVar23._4_4_;
      puVar60[2] = auVar23._8_4_;
      puVar60[3] = auVar23._12_4_;
      auVar44._8_8_ = auVar23._8_8_;
      puVar60[4] = auVar54._0_4_;
      puVar60[5] = auVar54._4_4_;
      puVar60[6] = auVar54._8_4_;
      puVar60[7] = auVar54._12_4_;
      if (lStack_120 == 0) {
        auVar27._8_8_ = auVar26._8_8_;
        auVar27._0_8_ = 0x50;
        auVar24._8_8_ = (long)(int)(*(uint *)(iVar66 + 0xc) >> 0x13) & 0xf;
        auVar44._0_8_ =
             auVar24._8_8_ << 0x38 |
             auVar24._8_8_ << 0x18 | 0x10000 | (ulong)*(uint *)(iVar66 + 0x10) << 0x20 |
             0x1000000000000;
        auVar28 = _pcpyld(auVar27,auVar44);
        puVar60[8] = auVar28._0_4_;
        puVar60[9] = auVar28._4_4_;
        puVar60[10] = auVar28._8_4_;
        puVar60[0xb] = auVar28._12_4_;
      }
      else {
        puVar60[8] = puVar60[-8];
        puVar60[9] = puVar60[-7];
        puVar60[10] = puVar60[-6];
        puVar60[0xb] = puVar60[-5];
        **(int **)(param_1 + 4) = **(int **)(param_1 + 4) + -1;
        puVar60[-4] = (uint)*(ushort *)(puVar60 + -4) + iVar39 + 5 | 0x30000000;
        auVar28._8_8_ = 0;
        auVar28._0_8_ = auVar26._8_8_;
        auVar28 = auVar28 << 0x40;
        puVar60[-1] = (uint)*(ushort *)(puVar60 + -1) + iVar39 + 5 | 0x50000000;
      }
      auVar29._8_8_ = auVar28._8_8_;
      auVar35._0_8_ = (long)(iVar39 + 5) | 0x30000000U | (long)(iVar50 + -0x50) << 0x20;
      auVar29._0_8_ = ((long)(iVar39 + 5) | 0x50000000U) << 0x20;
      auVar23 = _pcpyld(auVar29,auVar35);
      puVar60[0xc] = auVar23._0_4_;
      puVar60[0xd] = auVar23._4_4_;
      puVar60[0xe] = auVar23._8_4_;
      puVar60[0xf] = auVar23._12_4_;
      goto LAB_0022adf8;
    }
    uVar55 = *(undefined4 *)(param_1 + 4);
  }
  else {
    lVar19 = (*pcRam0069f3c4)(*(int *)(iVar66 + 0x28) + *(int *)(iVar66 + 0x2c),0x30000);
    *(int *)(param_1 + 4) = (int)lVar19;
    if (lVar19 == 0) {
      uStack_40 = 0x116;
      uStack_3c = FUN_0019f510(0xffffffff80000013,*(int *)(iVar66 + 0x28) + *(int *)(iVar66 + 0x2c))
      ;
      FUN_0019f460(&uStack_40);
      return 0;
    }
    if (*(int *)(iVar66 + 0x2c) == 0) {
      iVar50 = *(int *)(param_1 + 0x14);
    }
    else {
      *(int *)(param_1 + 8) = (int)lVar19 + *(int *)(iVar66 + 0x28);
      iVar50 = *(int *)(param_1 + 0x14);
    }
    if (iVar50 == 8) {
      *(byte *)(iVar66 + 0x36) = *(byte *)(iVar66 + 0x36) | 2;
    }
    FUN_001c15a0();
LAB_0022adf8:
    uVar55 = *(undefined4 *)(param_1 + 4);
  }
  *(undefined4 *)(param_1 + 0x24) = uVar55;
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_1 + 0x18);
  if ((*(byte *)(iVar66 + 0x36) & 1) != 0) {
    *(int *)(param_1 + 4) = *(int *)(*(int *)(param_1 + 4) + 4) + 0x50;
  }
  FlushCache(0);
LAB_0022ae60:
  *(undefined4 *)(param_1 + iGpffffa560) = 0;
  *(undefined4 *)(param_1 + iGpffffa560 + 4) = 0;
  return 1;
}

