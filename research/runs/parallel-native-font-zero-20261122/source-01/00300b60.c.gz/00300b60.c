
int FUN_00300b60(long param_1,undefined8 param_2)

{
  int *piVar1;
  int iVar2;
  long lVar3;
  long lVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  iVar2 = FUN_0019c320();
  iVar8 = 1;
  if (0 < iVar2) {
    do {
      if (param_1 == -1) {
        iVar7 = 0;
      }
      else {
        lVar3 = FUN_0019c140(param_1,iVar8);
        if (lVar3 == 0) {
          iVar7 = 0;
        }
        else {
          lVar4 = FUN_00199480(lVar3);
          if (lVar4 == 1) {
            lVar4 = FUN_00199480(lVar3);
            iVar7 = (int)lVar3;
            if ((lVar4 == 2) || (lVar4 == 1)) {
              iVar6 = 0;
              if (0 < *(int *)(iVar7 + 0x14)) {
                iVar5 = 0;
                do {
                  lVar4 = FUN_001deb10(*(undefined4 *)(*(int *)(iVar7 + 0x20) + iVar5 + 0xc),param_2
                                      );
                  if (lVar4 == 0) goto LAB_00300c70;
                  iVar6 = iVar6 + 1;
                  iVar5 = iVar5 + 0x10;
                } while (iVar6 < *(int *)(iVar7 + 0x14));
              }
              iVar6 = -1;
            }
            else {
              iVar6 = -1;
            }
LAB_00300c70:
            if (iVar6 == -1) {
              iVar7 = 0;
            }
            else {
              if (lVar3 == 0) {
                iVar7 = 0;
              }
              else {
                piVar1 = *(int **)(*(int *)(iVar7 + 0x20) + iVar6 * 0x10 + 4);
                iVar7 = 0;
                if (piVar1 != (int *)0x0) {
                  iVar7 = *piVar1;
                }
                if (iVar7 != 0) {
                  *(undefined4 *)(iVar7 + 0x54) = 2;
                }
              }
              if (iVar7 != 0) {
                FUN_001df378(iVar7 + 0x10,param_2,0x1f);
                *(undefined1 *)(iVar7 + 0x2f) = 0;
              }
            }
          }
          else {
            iVar7 = 0;
          }
        }
      }
      if (iVar7 != 0) {
        FUN_001df378(iVar7 + 0x10,param_2,0x1f);
        *(undefined1 *)(iVar7 + 0x2f) = 0;
        return iVar7;
      }
      iVar8 = iVar8 + 1;
    } while (iVar8 <= iVar2);
  }
  return 0;
}

