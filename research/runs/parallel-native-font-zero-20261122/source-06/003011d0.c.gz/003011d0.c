
void FUN_003011d0(undefined8 param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined4 uVar5;
  long lVar6;
  int *piVar7;
  int iVar8;
  uint *puVar9;
  uint uVar10;
  uint *puVar11;
  int iVar12;
  int *piVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  int *piStack_8;
  undefined4 uStack_4;
  
  iVar8 = (int)param_1;
  piStack_8 = *(int **)(iVar8 + 8);
  uStack_4 = *(undefined4 *)(iVar8 + 0xc);
  if (*piStack_8 == 0x53454320) {
    puVar9 = (uint *)(piStack_8 + 7);
    uVar10 = 0;
    *(int *)(iVar8 + 0x14) = piStack_8[4];
    *(int *)(iVar8 + 0x10) = piStack_8[3];
    *(uint **)(iVar8 + 0x20) = puVar9;
    uVar16 = *(uint *)(iVar8 + 0x14);
    puVar11 = puVar9;
    uVar15 = 0;
    if (uVar16 != 0) {
      do {
        uVar15 = uVar10;
        if ((*puVar11 & 0x3fffffff) == 3) break;
        uVar10 = uVar10 + 1;
        puVar11 = puVar11 + 4;
        uVar15 = 0;
      } while (uVar10 < uVar16);
    }
    if ((*(char *)(iVar8 + 0x1d) == '\0') && (uVar10 = 0, uVar16 != 0)) {
      iVar12 = 0;
      do {
        puVar11 = (uint *)(*(int *)(iVar8 + 0x20) + iVar12);
        uVar1 = *puVar11;
        puVar11[3] = (int)puVar9 + puVar11[3] + uVar16 * 0x10;
        if ((puVar11[1] != 0) &&
           (puVar11[1] = puVar11[1] + (int)piStack_8, (uVar1 & 0x3fffffff) == 9)) {
          piVar7 = (int *)puVar11[1];
          iVar14 = 0;
          iVar2 = *piVar7;
          piVar13 = piVar7 + 1;
          if (0 < iVar2) {
            if (8 < iVar2) {
              bVar4 = false;
              if ((-1 < iVar2) && (iVar2 < 0x7fffffff)) {
                bVar4 = true;
              }
              if (bVar4) {
                do {
                  iVar14 = iVar14 + 8;
                  *piVar13 = *piVar13 + (int)piVar7;
                  piVar13[1] = piVar13[1] + (int)piVar7;
                  piVar13[2] = piVar13[2] + (int)piVar7;
                  piVar13[3] = piVar13[3] + (int)piVar7;
                  piVar13[4] = piVar13[4] + (int)piVar7;
                  piVar13[5] = piVar13[5] + (int)piVar7;
                  piVar13[6] = piVar13[6] + (int)piVar7;
                  piVar13[7] = piVar13[7] + (int)piVar7;
                  piVar13 = piVar13 + 8;
                } while (iVar14 < iVar2 + -8);
              }
            }
            for (; iVar14 < iVar2; iVar14 = iVar14 + 1) {
              *piVar13 = *piVar13 + (int)piVar7;
              piVar13 = piVar13 + 1;
            }
          }
        }
        if ((uVar1 & 0x3fffffff) == 4) {
          puVar11 = (uint *)puVar11[1];
          if (*puVar11 <= puVar11[1]) {
            *puVar11 = *puVar11 + uVar15;
            puVar11[1] = puVar11[1] + uVar15;
          }
        }
        uVar10 = uVar10 + 1;
        iVar12 = iVar12 + 0x10;
      } while (uVar10 < *(uint *)(iVar8 + 0x14));
    }
    lVar6 = FUN_001a2a40(3,1,&piStack_8);
    if (lVar6 != 0) {
      uVar16 = 0;
      if (*(int *)(iVar8 + 0x14) != 0) {
        iVar12 = 0;
        do {
          piVar7 = (int *)(*(int *)(iVar8 + 0x20) + iVar12);
          if ((uint)((ulong)((long)*piVar7 << 0x22) >> 0x22) - 2 < 2) {
            *(int *)((int)lVar6 + 0xc) = piVar7[1] - *(int *)((int)lVar6 + 0x14);
            uVar5 = FUN_003015e0(lVar6);
            puVar3 = *(undefined4 **)(*(int *)(iVar8 + 0x20) + uVar16 * 0x10 + 4);
            if (puVar3 != (undefined4 *)0x0) {
              *puVar3 = uVar5;
            }
          }
          uVar16 = uVar16 + 1;
          iVar12 = iVar12 + 0x10;
        } while (uVar16 < *(uint *)(iVar8 + 0x14));
      }
      FUN_001a2910(lVar6,0);
    }
    FUN_003de190(param_1);
    *(undefined1 *)(iVar8 + 0x1c) = 1;
  }
  return;
}

