
undefined4 FUN_0019a5e0(void)

{
  FUN_0026f070(PTR_PTR_005b472c);
  FUN_0019a9d0(10,0x5b4728,0);
  FUN_00215730(1,1,0x5fce60,0);
  return 1;
}

