
uint FUN_0019c320(uint param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint *puVar4;
  
  if (piRam0069f10c == (int *)0x0) {
LAB_0019c358:
    piVar2 = (int *)0x0;
  }
  else {
    iVar1 = *piRam0069f10c;
    piVar2 = piRam0069f10c;
    while (iVar1 != (int)param_1 >> 0x10) {
      piVar2 = (int *)piVar2[6];
      if (piVar2 == (int *)0x0) goto LAB_0019c358;
      iVar1 = *piVar2;
    }
  }
  if (piVar2 != (int *)0x0) {
    puVar4 = (uint *)piVar2[5];
    uVar3 = 0;
    if (piVar2[2] != 0) {
      do {
        if (*puVar4 == (param_1 & 0xffff)) {
          return puVar4[3];
        }
        uVar3 = uVar3 + 1;
        puVar4 = puVar4 + 6;
      } while (uVar3 < (uint)piVar2[2]);
    }
  }
  return uRam0000000c;
}

