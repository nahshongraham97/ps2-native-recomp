
uint FUN_0019c140(uint param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint *puVar4;
  int iVar5;
  
  iVar5 = 1;
  if (piRam0069f10c == (int *)0x0) {
LAB_0019c178:
    piVar2 = (int *)0x0;
  }
  else {
    iVar1 = *piRam0069f10c;
    piVar2 = piRam0069f10c;
    while (iVar1 != (int)param_1 >> 0x10) {
      piVar2 = (int *)piVar2[6];
      if (piVar2 == (int *)0x0) goto LAB_0019c178;
      iVar1 = *piVar2;
    }
  }
  if (piVar2 != (int *)0x0) {
    puVar4 = (uint *)piVar2[5];
    uVar3 = 0;
    if (piVar2[2] != 0) {
      do {
        if (*puVar4 == (param_1 & 0xffff)) {
          uVar3 = puVar4[4];
          goto LAB_0019c1c0;
        }
        uVar3 = uVar3 + 1;
        puVar4 = puVar4 + 6;
      } while (uVar3 < (uint)piVar2[2]);
    }
  }
  puVar4 = (uint *)0x0;
  uVar3 = uRam00000010;
LAB_0019c1c0:
  if (param_2 < 1) {
    uVar3 = 0;
  }
  else if ((int)puVar4[3] < param_2) {
    uVar3 = 0;
  }
  else if (uVar3 == 0) {
    uVar3 = 0;
  }
  else if (1 < param_2) {
    for (uVar3 = *(uint *)(uVar3 + 0x18); uVar3 != 0; uVar3 = *(uint *)(uVar3 + 0x18)) {
      iVar5 = iVar5 + 1;
      if (param_2 <= iVar5) {
        return uVar3;
      }
    }
    uVar3 = 0;
  }
  return uVar3;
}

