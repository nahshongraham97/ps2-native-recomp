
uint FUN_00199480(int *param_1)

{
  uint uVar1;
  
  if (*param_1 == 0) {
    uVar1 = (uint)*(byte *)((int)param_1 + 0x1f);
  }
  else {
    uVar1 = *(uint *)(*param_1 + 8);
  }
  return uVar1;
}

