
void FUN_00334750(void)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  float fVar5;
  float fVar6;
  float afStack_b0 [12];
  undefined1 auStack_80 [128];
  
  iVar1 = iRam0064ed8c;
  if (iRam0064dea4 == 0x11) {
    iVar1 = 7;
  }
  FUN_00141770(*(undefined4 *)(iRam0064ed94 + iVar1 * 0x10));
  iVar1 = iRam006602e8 / 0xe10;
  iVar3 = iRam006602e8 / 0x3c + iVar1 * -0x3c;
  iVar4 = iRam006602e8 - (iVar3 * 0x3c + iVar1 * 0xe10);
  if (iVar1 == 0) {
    uVar2 = FUN_00215810(1,0x40);
    FUN_001de4b0(auStack_80,uVar2,iVar3,iVar4);
    FUN_0016f990(0x209a,0,auStack_80,0x31,399,0x1c);
  }
  else {
    uVar2 = FUN_00215810(1,0x3f);
    FUN_001de4b0(auStack_80,uVar2,iVar1,iVar3,iVar4);
    FUN_0016f990(0x209a,0,auStack_80,0x31,399,0x1c);
  }
  afStack_b0[0] = DAT_005e5740;
  afStack_b0[1] = (float)DAT_005e5744;
  afStack_b0[2] = (float)DAT_005e5748;
  afStack_b0[3] = (float)DAT_005e574c;
  afStack_b0[4] = (float)DAT_005e5750;
  afStack_b0[5] = (float)DAT_005e5754;
  afStack_b0[6] = (float)DAT_005e5758;
  afStack_b0[7] = (float)DAT_005e575c;
  afStack_b0[8] = (float)DAT_005e5760;
  afStack_b0[9] = (float)DAT_005e5764;
  if (iRam006b6f78 < 5) {
    iVar1 = iRam006b6f78;
    if (iRam006b6f78 < 0) {
      iVar1 = 0;
    }
  }
  else {
    iVar1 = 4;
  }
  fVar6 = afStack_b0[iVar1 * 2];
  fVar5 = (afStack_b0[iVar1 * 2 + 1] - fVar6) / 7.0;
  iVar1 = iRam0064ed8c;
  if (iRam0064dea4 == 0x11) {
    iVar1 = 7;
  }
  uVar2 = FUN_0016eb10(0x27);
  FUN_001de4b0(auStack_80,uVar2,(int)(fVar5 * (float)iVar1 + fVar6 + 0.0 + 0.5));
  FUN_0016f990(0x209a,0,auStack_80,0x31,0x17b,0x1c);
  if (((iRam00660134 == 2) && (iRam0064e920 == 1)) || ((iRam0066017c == 2 && (iRam0064e914 == 1))))
  {
    iVar1 = iRam0064ed8c;
    if (iRam0064dea4 == 0x11) {
      iVar1 = 7;
    }
    uVar2 = FUN_00334410(iVar1);
    uRam006602c0 = (undefined4)uVar2;
    FUN_00163d40(0,uVar2);
  }
  return;
}

