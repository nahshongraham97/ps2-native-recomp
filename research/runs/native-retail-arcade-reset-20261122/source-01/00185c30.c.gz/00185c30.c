
/* WARNING: Removing unreachable block (ram,0x00185c74) */

uint FUN_00185c30(uint param_1)

{
  uint uVar1;
  
  uVar1 = FUN_0026d4a0();
  param_1 = param_1 & 0xffff;
  uVar1 = (uVar1 & 0xffff) * param_1 >> 0x10;
  if (param_1 == 0) {
    if (uVar1 != 0) {
      uVar1 = 0;
    }
  }
  else if (param_1 <= uVar1) {
    uVar1 = 0;
  }
  return uVar1;
}

