
void FUN_00334680(void)

{
  uRam0064ed90 = 0xffffffff;
  return;
}

