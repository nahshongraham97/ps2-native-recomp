
undefined4 FUN_00334690(void)

{
  undefined4 uVar1;
  long lVar2;
  int iVar3;
  
  iVar3 = iRam0064ed8c;
  if (iRam0064dea4 == 0x11) {
    iVar3 = 7;
  }
  iVar3 = iVar3 * 0x10;
  lVar2 = FUN_00141770(*(undefined4 *)(iRam0064ed94 + iVar3));
  if (lVar2 == 0) {
    uVar1 = *(undefined4 *)(iRam0064ed94 + iVar3);
  }
  else {
    uVar1 = *(undefined4 *)(iVar3 + iRam0064ed94 + 4);
  }
  return uVar1;
}

