
undefined4 FUN_00334520(void)

{
  undefined4 uVar1;
  
  uVar1 = uRam0064ed8c;
  if (iRam0064dea4 == 0x11) {
    uVar1 = 7;
  }
  return uVar1;
}

