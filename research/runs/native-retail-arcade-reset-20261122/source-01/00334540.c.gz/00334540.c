
undefined4 FUN_00334540(void)

{
  uint uVar1;
  undefined4 uVar2;
  long lVar3;
  int iVar4;
  
  iVar4 = iRam0064ed8c;
  if (iRam0064dea4 == 0x11) {
    iVar4 = 7;
  }
  if ((iVar4 == 0) || (iRam0064ed90 == -1)) {
    if (iRam00660134 == 2) {
      iRam0064ed90 = iRam00660158;
    }
    else {
      iRam0064ed90 = iRam006601a0;
    }
  }
  iRam0064ed8c = iRam0064ed8c + 1;
  if (iRam0064ed8c == 8) {
    iRam0064ed90 = -1;
    iRam0064ed8c = 0;
    bRam00660081 = bRam00660081 & 0xfb | 4;
    uRam006602e8 = 0;
    uVar1 = FUN_00185c30(0x13);
    DAT_0064cc84 = uVar1 & 0xffff;
    puRam0064ed94 = (&PTR_DAT_005e5630)[DAT_0064cc84];
    uVar2 = 1;
  }
  else {
    iVar4 = iRam0064ed8c;
    if (iRam0064dea4 == 0x11) {
      iVar4 = 7;
    }
    iVar4 = iVar4 * 0x10;
    lVar3 = FUN_00141770(*(undefined4 *)(puRam0064ed94 + iVar4));
    if (lVar3 == 0) {
      uRam00660094 = *(undefined4 *)(puRam0064ed94 + iVar4);
    }
    else {
      uRam00660094 = *(undefined4 *)(puRam0064ed94 + iVar4 + 4);
    }
    uVar2 = 0;
  }
  return uVar2;
}

