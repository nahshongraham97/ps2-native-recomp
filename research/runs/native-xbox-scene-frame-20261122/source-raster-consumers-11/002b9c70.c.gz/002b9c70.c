
undefined4 FUN_002b9c70(undefined4 param_1)

{
  FUN_002c2bf0(&DAT_005a66f8,param_1);
  (*DAT_0083539c)(0,param_1,0);
  (*DAT_00835488)(*(undefined4 *)((int)&DAT_008353a0 + DAT_005c7304),param_1);
  return 1;
}

