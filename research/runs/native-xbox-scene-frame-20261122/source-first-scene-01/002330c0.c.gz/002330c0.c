
undefined4 FUN_002330c0(void)

{
  FUN_001b20e0(PTR_PTR_005589a0);
  FUN_00232f20(10,&PTR_s_sysart_sec_0055899c,0);
  FUN_001b0380(1,1,"permanent_strings_eng.mko",0);
  return 1;
}

