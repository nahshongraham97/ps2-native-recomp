
undefined4 FUN_002694f0(void)

{
  FUN_0027c410();
  DAT_00831e1c = 0x280;
  DAT_00831e18 = 0x1e0;
  return 1;
}

