
undefined4 FUN_0007d460(void)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 local_8;
  
  FUN_0007d680(1);
  uVar1 = FUN_0027c5d0(0,0x100000);
  iVar2 = FUN_002c03c0(uVar1);
  if (iVar2 == 0) {
    uVar1 = 0;
  }
  else {
    FUN_00269520();
    iVar2 = FUN_0007ebf0();
    if (iVar2 == 0) {
      uVar1 = 0;
    }
    else {
      local_8 = 0;
      FUN_002695f0(&local_8);
      iVar2 = FUN_002c0310(&local_8);
      if (iVar2 == 0) {
        FUN_002bffe0();
        uVar1 = 0;
      }
      else {
        iVar2 = FUN_00269530();
        if (iVar2 == 0) {
          uVar1 = 0;
        }
        else {
          FUN_00284200();
          iVar2 = FUN_002bfeb0();
          if (iVar2 == 0) {
            FUN_002bff80();
            FUN_002bffe0();
            uVar1 = 0;
          }
          else {
            DAT_005b7b04 = 1;
            FUN_002725c0();
            FUN_00284220();
            FUN_001b2760();
            FUN_001c6030();
            uVar1 = 1;
          }
        }
      }
    }
  }
  return uVar1;
}

