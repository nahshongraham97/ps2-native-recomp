
void FUN_000a0dc0(void)

{
  int iVar1;
  int local_1c;
  int local_10;
  int local_c;
  int local_8;
  
  for (local_c = 0; local_c < 5; local_c = local_c + 1) {
    if ((((*(uint *)(&DAT_00831c0c + local_c * 0x20) >> 1 & 1) != 0) &&
        ((*(uint *)(&DAT_00831c0c + local_c * 0x20) & 1) == 0)) &&
       (*(int *)(&DAT_00831c14 + local_c * 0x20) != 0)) {
      for (local_1c = 0; local_1c < 0x10; local_1c = local_1c + 1) {
        if ((*(uint *)(&DAT_00831c20 + local_c * 0x20) &
            *(uint *)(local_1c * 0xc + *(int *)(&DAT_00831c10 + local_c * 0x20))) != 0) {
          iVar1 = FUN_001c2770(0x3002,6,*(undefined4 *)
                                         (*(int *)(&DAT_00831c10 + local_c * 0x20) + 4 +
                                         local_1c * 0xc),0xc,&local_10);
          if (iVar1 != 0) {
            *(code **)(iVar1 + 0x28) = FUN_000a0ae0;
            *(code **)(iVar1 + 0x2c) = FUN_000a0af0;
            *(undefined4 *)(local_10 + 8) = *(undefined4 *)(&DAT_00831c14 + local_c * 0x20);
            if (*(int *)(local_10 + 8) != 0) {
              local_8 = FUN_0007cb80(&DAT_0054cca0,
                                     *(undefined4 *)
                                      (*(int *)(&DAT_00831c10 + local_c * 0x20) + local_1c * 0xc));
              if (local_8 < 0) {
                local_8 = local_1c;
              }
              FUN_000a1590(*(undefined4 *)(*(int *)(local_10 + 8) + 4),local_1c,DAT_00709e6c,
                           *(undefined4 *)
                            (*(int *)(&DAT_00831c10 + local_c * 0x20) + 8 + local_1c * 0xc),local_8)
              ;
            }
          }
        }
      }
    }
  }
  return;
}

