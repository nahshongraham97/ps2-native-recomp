
void FUN_0019cc00(void)

{
  int iVar1;
  undefined4 local_8;
  
  if (0x16 < DAT_005b888c) {
    DAT_005b8890 = 0;
    FUN_0025c740(0,0);
    FUN_0019cd10();
  }
  FUN_0019ccb0(&local_8);
  (*(code *)(&PTR_FUN_0059c8d8)[DAT_005b888c])();
  if (((DAT_008292f8 == 8) && (iVar1 = FUN_0019cbb0(), iVar1 == 0)) &&
     (iVar1 = FUN_001c4870(0x301e), iVar1 != 0)) {
    *(uint *)(iVar1 + 0x20) = *(uint *)(iVar1 + 0x20) | 0x10;
  }
  FUN_0019ccd0(local_8);
  return;
}

