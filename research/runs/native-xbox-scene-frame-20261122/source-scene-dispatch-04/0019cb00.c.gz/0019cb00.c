
void FUN_0019cb00(void)

{
  int iVar1;
  
  DAT_005b8890 = 1;
  if (DAT_007350c0 != 0) {
    *(uint *)(DAT_007350c0 + 0x20) = *(uint *)(DAT_007350c0 + 0x20) & 0xffffffef;
  }
  FUN_0025c740(1);
  iVar1 = FUN_00258e60();
  if (iVar1 != 0x15) {
    FUN_00258f20(0x15);
  }
  return;
}

