
void FUN_0026ece0(void)

{
  undefined4 uVar1;
  int iVar2;
  
  if (DAT_0059cf8c == 5) {
    uVar1 = FUN_0019cf90(0);
    iVar2 = FUN_001df4e0(uVar1);
    if (iVar2 == 0) {
      uVar1 = FUN_0019cfb0(0);
      iVar2 = FUN_001df4e0(uVar1);
      if (iVar2 == 0) {
        uVar1 = FUN_0019cf90(1);
        iVar2 = FUN_001df4e0(uVar1);
        if (iVar2 == 0) {
          uVar1 = FUN_0019cfb0(1);
          iVar2 = FUN_001df4e0(uVar1);
          if (iVar2 == 0) {
            return;
          }
        }
        uVar1 = FUN_0019cf90(1);
        FUN_001df590(uVar1);
        uVar1 = FUN_0019cfb0(1);
        FUN_001df590(uVar1);
        FUN_0023c150(0x2508);
        DAT_005b8890 = 0;
        FUN_0025c740(0);
        FUN_0019cd10();
        DAT_005c0074 = 2;
        return;
      }
    }
    uVar1 = FUN_0019cf90(0);
    FUN_001df590(uVar1);
    uVar1 = FUN_0019cfb0(0);
    FUN_001df590(uVar1);
    FUN_0023c150(0x2508);
    DAT_005b8890 = 0;
    FUN_0025c740(0);
    FUN_0019cd10();
    DAT_005c0074 = 1;
  }
  else if (DAT_0059cf8c == 0) {
    uVar1 = FUN_0019cf90(0);
    iVar2 = FUN_001df4e0(uVar1);
    if (iVar2 == 0) {
      uVar1 = FUN_0019cf90(1);
      iVar2 = FUN_001df4e0(uVar1);
      if (iVar2 != 0) {
        uVar1 = FUN_0019cf90(1);
        FUN_001df590(uVar1);
        uVar1 = FUN_0019cfb0(1);
        FUN_001df590(uVar1);
        FUN_0023c150(0x2508);
        DAT_005b8890 = 0;
        FUN_0025c740(0);
        FUN_0019cd10();
        DAT_005c0074 = 2;
      }
    }
    else {
      uVar1 = FUN_0019cf90(0);
      FUN_001df590(uVar1);
      uVar1 = FUN_0019cfb0(0);
      FUN_001df590(uVar1);
      FUN_0023c150(0x2508);
      DAT_005b8890 = 0;
      FUN_0025c740(0);
      FUN_0019cd10();
      DAT_005c0074 = 1;
    }
  }
  else if (DAT_0059cf8c == 1) {
    uVar1 = FUN_0019cfb0(0);
    iVar2 = FUN_001df4e0(uVar1);
    if (iVar2 == 0) {
      uVar1 = FUN_0019cfb0(1);
      iVar2 = FUN_001df4e0(uVar1);
      if (iVar2 != 0) {
        uVar1 = FUN_0019cf90(1);
        FUN_001df590(uVar1);
        uVar1 = FUN_0019cfb0(1);
        FUN_001df590(uVar1);
        FUN_0023c150(0x2508);
        DAT_005b8890 = 0;
        FUN_0025c740(0);
        FUN_0019cd10();
        DAT_005c0074 = 2;
      }
    }
    else {
      uVar1 = FUN_0019cf90(0);
      FUN_001df590(uVar1);
      uVar1 = FUN_0019cfb0(0);
      FUN_001df590(uVar1);
      FUN_0023c150(0x2508);
      DAT_005b8890 = 0;
      FUN_0025c740(0);
      FUN_0019cd10();
      DAT_005c0074 = 1;
    }
  }
  return;
}

