
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000a2760(void)

{
  _DAT_00831ca0 = (DAT_00831c9c ^ _DAT_00831c98) & DAT_00831c9c;
  _DAT_00831c98 = DAT_00831c9c;
  DAT_00831c9c = 0;
  return;
}

