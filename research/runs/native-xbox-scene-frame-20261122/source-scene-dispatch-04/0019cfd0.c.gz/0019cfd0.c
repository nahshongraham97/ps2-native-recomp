
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_0019cfd0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 local_c2c [768];
  undefined4 local_2c;
  undefined4 *local_28;
  int local_24;
  undefined4 local_20;
  int local_1c;
  undefined4 local_18;
  undefined4 local_14;
  int local_10;
  undefined4 local_c;
  int local_8;
  
  local_2c = DAT_005af7d0;
  local_24 = -1;
  local_18 = 0xffffffff;
  local_20 = 5;
  local_8 = 0;
  local_10 = 0;
  while (DAT_005b7d40 != 0) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
    local_10 = local_10 + 1;
    if (0x3b < local_10) {
      FUN_0019ca30(3,FUN_0019d370);
    }
  }
  while (iVar1 = FUN_0007be10(), iVar1 != 0) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  while( true ) {
    local_14 = 0x17;
    switch(param_1) {
    case -0x17:
      local_14 = 0x17;
      local_c = 0x18;
      break;
    case -0x16:
      local_14 = 0x1d;
      local_c = 0x23;
      break;
    default:
      local_c = 0x18;
      break;
    case -0x10:
      local_14 = 0x1d;
      local_c = 0x22;
      break;
    case -0xf:
      local_c = 0x21;
      break;
    case -0xe:
      local_c = 0x1f;
      FUN_0008d240();
      local_20 = 4;
      local_18 = 5;
      local_8 = 1;
      break;
    case -0xd:
      local_14 = 0x1d;
      local_c = 0x1e;
      break;
    case -6:
      local_c = 0x1c;
      break;
    case -5:
      local_c = 0x1b;
      break;
    case -4:
      local_c = 0x1a;
      break;
    case -3:
      local_c = 0x19;
    }
    iVar1 = FUN_00098050();
    if (iVar1 != 0) {
      if (DAT_005ac748 == 0) {
        FUN_0025c740(0);
        FUN_001de3a0();
      }
      else {
        FUN_001de5a0();
        uVar2 = FUN_0019ff60();
        FUN_00232790(uVar2);
      }
    }
    while (DAT_005b7d40 != 0) {
      FUN_0025c740(0);
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    DAT_007350c0[8] = DAT_007350c0[8] | 0x10;
    FUN_0025c740(1);
    local_1c = 6;
    FUN_0019ccf0();
    uVar2 = FUN_001df630(local_14,1);
    FUN_0019ce40(uVar2);
    uVar2 = FUN_001df630(local_c,1);
    FUN_0019cea0(uVar2);
    if (param_1 == -0xf) {
      FUN_0019cf00(&DAT_004dc930);
    }
    else if (param_1 == -0xe) {
      uVar2 = FUN_001df630(0x25,1);
      FUN_0019cf00(uVar2);
    }
    else {
      uVar2 = FUN_001df630(0x20,1);
      FUN_0019cf00(uVar2);
    }
    FUN_0019cf60(local_20);
    if (DAT_008292f8 == 8) break;
    FUN_0019cd50();
    DAT_005b888c = 0x16;
    FUN_0019cb00();
    local_24 = FUN_0019d400(1,local_1c,local_18);
    if (local_24 != -1) {
LAB_0019d2b5:
      FUN_0023c150(0x2508);
      DAT_005b8890 = 0;
      FUN_0008d280();
      FUN_0019cd10();
      if ((local_8 != 0) && (local_24 == local_1c)) {
        local_28 = local_c2c;
        puVar3 = local_c2c;
        for (iVar1 = 0x300; iVar1 != 0; iVar1 = iVar1 + -1) {
          *puVar3 = 0;
          puVar3 = puVar3 + 1;
        }
        local_c2c[0] = 6;
        XAPILIB::XLaunchNewImageA(0,local_28);
      }
      if (DAT_005ac748 == 0) {
        FUN_0019cb50();
      }
      return;
    }
  }
  iVar1 = FUN_00136ef0(local_8);
  if (iVar1 != 0) {
    local_24 = local_1c;
  }
  goto LAB_0019d2b5;
}

