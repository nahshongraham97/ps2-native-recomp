
undefined4 FUN_001eb220(void)

{
  DAT_005bbea8 = 0;
  return 1;
}

