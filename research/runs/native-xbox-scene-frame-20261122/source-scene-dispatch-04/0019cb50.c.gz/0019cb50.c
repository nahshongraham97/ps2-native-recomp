
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0019cb50(void)

{
  int iVar1;
  
  _DAT_005b8894 = 0;
  if (DAT_007350c0 != 0) {
    *(uint *)(DAT_007350c0 + 0x20) = *(uint *)(DAT_007350c0 + 0x20) & 0xffffffef;
  }
  FUN_0025c740(0);
  iVar1 = FUN_0026f4b0();
  if (iVar1 != 0) {
    iVar1 = FUN_00258e60();
    if (iVar1 == 0x15) {
      FUN_00258f90(0x15);
    }
  }
  DAT_005b8890 = 0;
  return;
}

