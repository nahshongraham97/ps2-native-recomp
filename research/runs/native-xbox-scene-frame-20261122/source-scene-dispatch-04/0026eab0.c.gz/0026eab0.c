
void FUN_0026eab0(void)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_0019cf90(0);
  iVar2 = FUN_001df4e0(uVar1);
  if (iVar2 == 0) {
    uVar1 = FUN_0019cfb0(0);
    iVar2 = FUN_001df4e0(uVar1);
    if (iVar2 == 0) {
      return;
    }
  }
  uVar1 = FUN_0019cf90(0);
  FUN_001df590(uVar1);
  uVar1 = FUN_0019cfb0(0);
  FUN_001df590(uVar1);
  FUN_0023c150(0x2508);
  DAT_005b8890 = 0;
  FUN_0025c740(0);
  FUN_0019cd10();
  return;
}

