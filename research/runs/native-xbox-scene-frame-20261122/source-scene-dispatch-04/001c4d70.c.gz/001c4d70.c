
void FUN_001c4d70(void)

{
  FUN_001c4dd0(&DAT_007350bc);
  FUN_001c4dd0(&DAT_007350b8);
  FUN_001c74e0(&DAT_007350b8);
  DAT_007350c0 = 0;
  DAT_007350c8 = 0;
  return;
}

