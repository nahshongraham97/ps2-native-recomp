
void FUN_0019cad0(void)

{
  DAT_005b8890 = 0;
  *(uint *)(DAT_007350c0 + 0x20) = *(uint *)(DAT_007350c0 + 0x20) | 0x10;
  FUN_0025c740(1);
  return;
}

