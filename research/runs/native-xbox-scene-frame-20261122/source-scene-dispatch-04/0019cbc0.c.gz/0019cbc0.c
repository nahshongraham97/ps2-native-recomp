
bool FUN_0019cbc0(void)

{
  int iVar1;
  bool bVar2;
  
  bVar2 = false;
  iVar1 = FUN_0026f4b0();
  if (iVar1 == 0) {
    if (DAT_005b888c != 0) {
      bVar2 = true;
    }
  }
  else {
    bVar2 = DAT_005b8890 == 1;
  }
  return bVar2;
}

