
void FUN_001b27f0(void)

{
  if (DAT_005b8aa0 == 0) {
    FUN_001b2830(&DAT_005b8a8c,10,&DAT_005b89e0,0x10,&DAT_005b8a80);
    DAT_005b8aa0 = 1;
  }
  return;
}

