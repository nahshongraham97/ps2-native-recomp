
undefined4 FUN_00269530(void)

{
  undefined8 uVar1;
  undefined4 uVar2;
  int iVar3;
  int local_c;
  int local_8;
  
  DAT_005bfa48 = FUN_002bfad0();
  if (DAT_005bfa48 == 0) {
    uVar2 = 0;
  }
  else {
    local_c = DAT_005bfa48;
    if (0x10 < DAT_005bfa48) {
      local_c = 0x10;
    }
    DAT_005bfa48 = local_c;
    for (local_8 = 0; local_8 < DAT_005bfa48; local_8 = local_8 + 1) {
      FUN_002bfb00(local_8 * 0x50 + 0x5bf548,local_8);
    }
    DAT_005bfa4c = FUN_002bfb70();
    uVar1 = rdtsc();
    DAT_005bfa54 = (undefined4)((ulonglong)uVar1 >> 0x20);
    DAT_005bfa58 = (undefined4)uVar1;
    iVar3 = FUN_002bfb90(DAT_005bfa4c);
    if (iVar3 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = 1;
    }
  }
  return uVar2;
}

