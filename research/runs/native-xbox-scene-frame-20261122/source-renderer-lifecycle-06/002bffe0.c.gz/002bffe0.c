
bool FUN_002bffe0(void)

{
  bool bVar1;
  
  bVar1 = DAT_005c7404 == 0;
  if (bVar1) {
    FUN_002c2830();
    FUN_002c0e50();
    thunk_FUN_002c4460();
    DAT_00835490 = 0;
  }
  return bVar1;
}

