
int FUN_002bff80(void)

{
  int iVar1;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  iVar1 = (*DAT_00835354)(1,0,0,0);
  if (iVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x18,1);
    FUN_002c2370(&uStack_8);
    return 0;
  }
  DAT_005c7404 = DAT_005c7404 + -1;
  DAT_00835490 = 1;
  return iVar1;
}

