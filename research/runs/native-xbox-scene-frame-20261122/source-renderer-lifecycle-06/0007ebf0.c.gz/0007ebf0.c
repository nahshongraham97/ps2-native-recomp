
undefined4 FUN_0007ebf0(void)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_002daa90();
  if (iVar1 == 0) {
    FUN_000a0ab0("RpWorldPluginAttach failed.");
    uVar2 = 0;
  }
  else {
    iVar1 = FUN_002e66c0();
    if (iVar1 == 0) {
      FUN_000a0ab0("RpSkinPluginAttach failed.");
      uVar2 = 0;
    }
    else {
      FUN_002eb700();
      iVar1 = FUN_002aef40();
      if (iVar1 == 0) {
        FUN_000a0ab0("RpHAnimPluginAttach failed.");
        uVar2 = 0;
      }
      else {
        iVar1 = FUN_002eb3e0();
        if (iVar1 == 0) {
          FUN_000a0ab0("RpSpecularPluginAttach failed.");
          uVar2 = 0;
        }
        else {
          iVar1 = FUN_0023ec80();
          if (iVar1 == 0) {
            FUN_000a0ab0(&DAT_004da1a0);
            uVar2 = 0;
          }
          else {
            iVar1 = FUN_002b14f0();
            if (iVar1 == 0) {
              FUN_000a0ab0("RpMatFXPluginAttach failed.");
              uVar2 = 0;
            }
            else {
              iVar1 = FUN_002eb5f0();
              if (iVar1 == 0) {
                FUN_000a0ab0(&DAT_004da164);
                uVar2 = 0;
              }
              else {
                iVar1 = FUN_001c3320();
                if (iVar1 == 0) {
                  FUN_000a0ab0(&DAT_004da140);
                  uVar2 = 0;
                }
                else {
                  iVar1 = FUN_001c3480();
                  if (iVar1 == 0) {
                    FUN_000a0ab0(&DAT_004da11c);
                    uVar2 = 0;
                  }
                  else {
                    iVar1 = FUN_001c36e0();
                    if (iVar1 == 0) {
                      FUN_000a0ab0("RpMaterialMkmaterialPluginAttach failed.");
                      uVar2 = 0;
                    }
                    else {
                      iVar1 = FUN_001c3e90();
                      if (iVar1 == 0) {
                        FUN_000a0ab0("RpColorSetPluginAttach failed.");
                        uVar2 = 0;
                      }
                      else {
                        uVar2 = 1;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return uVar2;
}

