
int FUN_002c0310(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 local_8;
  undefined4 local_4;
  
  if (DAT_00835490 != 1) {
    local_8 = 1;
    local_4 = FUN_002c2400(0x80000001);
    FUN_002c2370(&local_8);
    return 0;
  }
  if (param_1 != 0) {
    iVar1 = FUN_002c7670();
    iVar2 = 0;
    if (iVar1 != 0) {
      iVar2 = FUN_002c0250(param_1);
      if (iVar2 != 0) {
        DAT_00835490 = 2;
      }
    }
    return iVar2;
  }
  local_8 = 1;
  local_4 = FUN_002c2400(0x80000016);
  FUN_002c2370(&local_8);
  return 0;
}

