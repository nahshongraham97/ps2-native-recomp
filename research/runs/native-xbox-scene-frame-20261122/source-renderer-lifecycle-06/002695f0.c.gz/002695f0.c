
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_002695f0(undefined4 param_1,undefined4 *param_2)

{
  uint uVar1;
  
  uVar1 = XAPILIB::XGetVideoFlags(param_1);
  FUN_002c63b0(&DAT_005bf520);
  DAT_0071f764 = 0x3f800000;
  _DAT_0071f760 = 0x3f800000;
  _DAT_005bf530 = 0x11;
  if ((uVar1 & 2) == 0) {
    if ((uVar1 & 8) == 0) {
      DAT_005bf53c = 0x20;
    }
    else {
      DAT_005bf53c = 0x40;
    }
    if ((uVar1 & 1) == 0) {
      DAT_005bf520 = 0x280;
      DAT_005bf53c = DAT_005bf53c | 0x100;
      DAT_0054ca88 = 0x3faaaaab;
    }
    else {
      DAT_005bf520 = 0x2d0;
      DAT_005bf53c = DAT_005bf53c | 0x10;
      DAT_0054ca88 = 0x3fe38e39;
      DAT_0054ca8c = 0x42b05bf5;
      DAT_0054dfac = 0x2b2;
      DAT_0054dfa8 = 0x28a;
      DAT_005b7d08 = 0;
      DAT_0054dfa4 = 0x28;
      _DAT_0054dfb0 = 0x28;
      DAT_00562358 = 0x30;
      DAT_0056235c = 0x168;
    }
    DAT_005bf524 = 0x1e0;
    _DAT_005bf528 = 0x12;
  }
  else {
    DAT_005bfa64 = 1;
    DAT_005bfa68 = 1;
    DAT_005bf520 = 0x500;
    DAT_005bf53c = 0x50;
    DAT_0054ca88 = 0x3fe38e39;
    DAT_0054ca8c = 0x42b05bf5;
    DAT_0054dfac = 0x2b2;
    DAT_0054dfa8 = 0x28a;
    DAT_005b7d08 = 0;
    DAT_0054dfa4 = 0x28;
    _DAT_0054dfb0 = 0x28;
    DAT_00562358 = 0x30;
    DAT_0056235c = 0x168;
    DAT_005bf524 = 0x2d0;
    _DAT_005bf528 = 0x11;
    DAT_0071f764 = 0x3fe38e39;
    _DAT_0071f760 = 0x3fc00000;
  }
  _DAT_005bf544 = 0x80000001;
  _DAT_005bf534 = 2;
  _DAT_005bf52c = 1;
  _DAT_005bf540 = 0x3c;
  DAT_00831e1c = DAT_005bf520;
  DAT_0071f76c = DAT_005bf520;
  DAT_00831e18 = DAT_005bf524;
  DAT_0071f768 = DAT_005bf524;
  *param_2 = &DAT_005bf520;
  return;
}

