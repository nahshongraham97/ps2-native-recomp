
void FUN_0007d680(undefined4 param_1)

{
  DAT_005b7ab0 = param_1;
  return;
}

