
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 scene_callback_002bb510(undefined4 param_1,int param_2)

{
  int iVar1;
  
  DAT_005c7354 = param_2;
  iVar1 = FUN_002c4620(DAT_005a6718,DAT_005a6730,0x10,DAT_005a6734,&DAT_005c7330,0x40005);
  *(int *)((int)&DAT_00835340 + DAT_005c7354) = iVar1;
  if (iVar1 == 0) {
    return 0;
  }
  _DAT_005c7358 = _DAT_005c7358 + 1;
  return param_1;
}

