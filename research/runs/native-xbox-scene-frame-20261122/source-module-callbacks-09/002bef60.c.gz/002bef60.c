
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 scene_callback_002bef60(undefined4 param_1,int param_2)

{
  int iVar1;
  
  DAT_005c73fc = param_2;
  iVar1 = FUN_002c4620(DAT_005a6768,DAT_005a6780,0x10,DAT_005a6784,&DAT_005c73d8,0x4000e);
  *(int *)((int)&DAT_00835340 + DAT_005c73fc) = iVar1;
  if (iVar1 == 0) {
    return 0;
  }
  DAT_008353fc = &DAT_008353fc;
  _DAT_00835400 = &DAT_008353fc;
  _DAT_005c7400 = _DAT_005c7400 + 1;
  return param_1;
}

