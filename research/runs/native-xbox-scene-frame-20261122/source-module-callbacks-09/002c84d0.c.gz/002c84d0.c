
bool FUN_002c84d0(void)

{
  DAT_008343fc = FUN_002b9cf0(0x18,0x40c,0,0,0);
  return -1 < DAT_008343fc;
}

