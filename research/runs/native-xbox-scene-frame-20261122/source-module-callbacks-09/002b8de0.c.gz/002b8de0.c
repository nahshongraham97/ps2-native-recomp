
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 scene_callback_002b8de0(undefined4 param_1,int param_2)

{
  int iVar1;
  
  DAT_005c72d8 = param_2;
  iVar1 = FUN_002c4620(0x24,DAT_005a66f0,4,DAT_005a66f4,&DAT_005c72e0,0x40404);
  *(int *)((int)&DAT_00835340 + DAT_005c72d8) = iVar1;
  if (iVar1 == 0) {
    return 0;
  }
  _DAT_005c72dc = _DAT_005c72dc + 1;
  return param_1;
}

