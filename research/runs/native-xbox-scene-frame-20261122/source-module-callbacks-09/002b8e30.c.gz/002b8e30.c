
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 scene_callback_002b8e30(undefined4 param_1)

{
  if (*(int *)((int)&DAT_00835340 + DAT_005c72d8) != 0) {
    FUN_002c3fc0(*(int *)((int)&DAT_00835340 + DAT_005c72d8));
  }
  _DAT_005c72dc = _DAT_005c72dc + -1;
  return param_1;
}

