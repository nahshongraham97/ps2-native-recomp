
void FUN_0025c1e0(void)

{
  int iVar1;
  
  DAT_005bf29c = DAT_005bf29c + 1;
  if (0x3b < DAT_005bf29c) {
    DAT_005bf29c = 0;
    DAT_00831ce4 = DAT_00831ce4 + 1;
    iVar1 = FUN_00258e60();
    if (iVar1 == 6) {
      DAT_00831ce8 = DAT_00831ce8 + 1;
    }
  }
  return;
}

