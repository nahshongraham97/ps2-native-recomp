
undefined4 FUN_0019cbb0(void)

{
  return DAT_005b8890;
}

