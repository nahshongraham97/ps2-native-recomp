
undefined4 FUN_0019c930(void)

{
  FUN_001b27f0();
  FUN_001eb220();
  return 1;
}

