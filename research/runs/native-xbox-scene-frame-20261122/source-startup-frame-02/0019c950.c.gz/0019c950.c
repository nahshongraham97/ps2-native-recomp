
void FUN_0019c950(void)

{
  int iVar1;
  
  FUN_00380800();
  FUN_00378740();
  if (DAT_005b7adc != 0) {
    FUN_0007d810();
    iVar1 = FUN_00409d50();
    if (iVar1 == 1) {
      FUN_0007d810();
    }
  }
  return;
}

