#pragma once
#include "mka/retail_main.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <thread>
#include <utility>

namespace mka::retail {
class NativeRetailInputParticipant;
class NativeRetailInputAssignments;
class NativeRetailParticipants;
class NativeRetailAssignedPoll;

enum class RetailInputRole : std::uint8_t { role0, role1, role2, role3 };
enum class RetailInputRoleError { none, wrong_thread, invalid_role, invalid_action_row, invalid_mapping_table, allocation, native_exception };
struct RetailInputRoleFailure { RetailInputRoleError kind{RetailInputRoleError::none}; };

struct NativeRetailInputRoleObservation {
    bool initialized, dispatch_blocked, analog_mapping;
    std::uint32_t previous, current, rising;
    // Native host stick values retain full signed 16-bit precision. Source
    // zero-born axis storage is represented by absence until first sample.
    std::optional<std::array<std::int16_t, 4>> axes;
    std::shared_ptr<NativeRetailInputParticipant> participant;
    // Original role source value at 0x660268, cleared on participant detach.
    // The producer and gameplay meaning are not yet joined.
    std::uint32_t source_control_word{};
};

// Owned role records initialized by the 281E00 action-record initialization.
// A role is a retail identity, independent of a host sample route or a real
// participant. This component does not bind either association implicitly.
class NativeRetailInputRoles final {
public:
    static std::shared_ptr<NativeRetailInputRoles> create(
        RetailInputRoleFailure&) noexcept;
    NativeRetailInputRoles(const NativeRetailInputRoles&) = delete;
    NativeRetailInputRoles& operator=(const NativeRetailInputRoles&) = delete;

    std::optional<NativeRetailInputRoleObservation> observe(
        RetailInputRole, RetailInputRoleFailure&) const noexcept;
    std::optional<RetailActionRowObservation> observe_action_row(
        RetailInputRole, std::size_t row, RetailInputRoleFailure&) const noexcept;
    // The source initializes four game roles, while 281870 resets two
    // separate physical-position mapping pairs. Both retain this owner.
    bool initialize_roles_from_281e00(RetailInputRoleFailure&) noexcept;
    bool reset_first_two_mapping_tables_from_281870(
        RetailInputRoleFailure&) noexcept;
    // Actual shared words cleared by2811F0/2817B0 and written0/1 by153660.
    // These leaf stores do not implement the latter's task/profile effects.
    std::optional<std::uint32_t> profile_mapping_word(
        std::size_t position, RetailInputRoleFailure&) const noexcept;
    bool store_profile_mapping_active_from_source(
        std::size_t position, bool, RetailInputRoleFailure&) noexcept;
    // Full-word storage leaf of281550; no sample/mapping producer is implied.
    bool store_source_control_word_from_source(
        RetailInputRole, std::uint32_t, RetailInputRoleFailure&) noexcept;
    std::optional<std::array<RetailActionBinding,16>> observe_mapping_table(
        std::size_t position, std::size_t variant,
        RetailInputRoleFailure&) const noexcept;
    // 163BA0 clears the three digital words for roles 0..2, preserving
    // source association, status, mapping and native host axes.
    bool clear_digital_first_three_from_163ba0(
        RetailInputRoleFailure&) noexcept;
    // 163A50 tests the participant link, not initialized status, before
    // clearing role status bit 0 for roles 0..2.
    bool clear_dispatch_blocked_first_three_from_163a50(
        RetailInputRoleFailure&) noexcept;

private:
    friend class NativeRetailInputAssignments;
    friend class NativeRetailAssignedPoll;
    NativeRetailInputRoles() noexcept;
    struct RoleState {
        std::array<RetailActionBinding, 16> action_rows{};
        std::uint32_t previous{}, current{}, rising{};
        std::optional<std::array<std::int16_t, 4>> axes;
        std::weak_ptr<NativeRetailInputParticipant> participant;
        std::uint32_t source_control_word{};
        bool initialized{}, dispatch_blocked{}, analog_mapping{true};
    };
    const RoleState* role(RetailInputRole, RetailInputRoleFailure&) const noexcept;

    // Four initialized source roles. This is not a physical input or host
    // controller capacity; the platform owner stores endpoints independently.
    std::array<RoleState, 4> roles_;
    // Two distinct source tables for each of the first two physical positions.
    std::array<std::array<std::array<RetailActionBinding,16>,2>,2> mapping_tables_{};
    // position0/1 are the actual64EA94/64EA90 values, respectively.
    std::array<std::uint32_t,2> mapping_reset_words_{};
    // The association count is game context state, not a property of an
    // adapter. 281E00 role-record initialization does not reset it.
    std::int32_t association_count_{};
    std::weak_ptr<NativeRetailParticipants> assignment_domain_;
    bool assignment_domain_bound_{};
    const std::thread::id thread_{std::this_thread::get_id()};
};

// A retained reference to an actual role slot, like the281830 result. Rebinding
// a participant does not redirect this reference to a different role/domain.
class NativeRetailRoleControlReference final {
public:
    // Reference values copy their retained capability, including rvalues.
    // There is no public empty construction or destructive move state.
    NativeRetailRoleControlReference(const NativeRetailRoleControlReference&) noexcept = default;
    NativeRetailRoleControlReference& operator=(const NativeRetailRoleControlReference&) noexcept = default;
    RetailInputRole role() const noexcept { return role_; }
    std::optional<std::uint32_t> observe(RetailInputRoleFailure&) const noexcept;
    bool clear_from_245dd0(RetailInputRoleFailure&) noexcept;
private:
    friend class NativeRetailInputAssignments;
    NativeRetailRoleControlReference(std::shared_ptr<NativeRetailInputRoles> owner,
        RetailInputRole role) noexcept : owner_(std::move(owner)), role_(role) {}
    std::shared_ptr<NativeRetailInputRoles> owner_;
    RetailInputRole role_;
};
} // namespace mka::retail
