
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_0023ad80(void)

{
  bool bVar1;
  
  FUN_0023bad0();
  _DAT_005be3bc = 0;
  DAT_005be3c0 = FUN_003755a0(&DAT_00568558,&DAT_00568564);
  bVar1 = DAT_005be3c0 != 0;
  if (bVar1) {
    FUN_00375de0(DAT_005be3c0,"/sounds/");
  }
  return bVar1;
}

