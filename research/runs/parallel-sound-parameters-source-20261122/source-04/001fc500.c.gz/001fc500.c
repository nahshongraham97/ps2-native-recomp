
undefined4 FUN_001fc500(void)

{
  int iVar1;
  long lVar2;
  long lVar3;
  int iVar4;
  
  if (iRam0064dfbc == iRam00660160) {
    DAT_0064c3bc = DAT_0064c3ac;
    uRam0064df94 = *(undefined4 *)(DAT_0064c3ac * 0x14 + 0x65ed40);
    uRam0064df90 = *(undefined4 *)(DAT_0064c3ac * 0x14 + 0x65ed44);
  }
  else {
    DAT_0064c3c0 = DAT_0064c3b0;
    uRam0064df8c = *(undefined4 *)(DAT_0064c3b0 * 0x14 + 0x65eae0);
    uRam0064df88 = *(undefined4 *)(DAT_0064c3b0 * 0x14 + 0x65eae4);
  }
  *(undefined4 *)(iRam0064dfc0 + 0x30c) = 1;
  lVar2 = FUN_001e4c30();
  if (lVar2 != 0) {
    iVar4 = *(int *)(iRam0064dfc0 + 0x2f0);
    if (iVar4 == 0x3e) {
      FUN_00161ed0(2);
    }
    else if (iVar4 == 5) {
      FUN_001e9150();
      FUN_00162300(0x5a58e0);
    }
    else if (iVar4 == 0x1e) {
      FUN_001e9150();
      FUN_00162300(0x5a6e80);
    }
    else if (iVar4 == 0xe) {
      FUN_001e9150();
      FUN_00162300(0x5a6650);
    }
    else if ((iVar4 == 0x17) && (*(int *)(iRam0064dfb4 + 0x394) < 5)) {
      FUN_001e9150();
      FUN_00162300(0x5a66f0);
    }
  }
  FUN_001fdd10(2);
  iVar4 = *(int *)(*(int *)(iRam0064dfc0 + 0x44c) + 4);
  lVar2 = FUN_001ef2b0();
  if (lVar2 == 2) {
    FUN_001e9de0();
    FUN_001e9ff0(0x1300);
  }
  iVar1 = iRam0064e11c;
  if (iRam0064dea4 == 9) {
    iVar1 = 0;
  }
  if ((iVar1 != 0) && (lVar3 = FUN_00529aa0(iRam0064dfc0,2), -1 < lVar3)) {
    *(int *)(iRam0064dfc0 + 1000) = (int)lVar3;
    FUN_005270e0();
  }
  switch(*(undefined4 *)(iRam0064dfc0 + 0x2f0)) {
  case 0:
    FUN_00162300(0x5a55e0);
    break;
  case 1:
    FUN_00162300(0x5a5690);
    break;
  case 2:
    FUN_00162300(0x5a5320);
    break;
  case 3:
  case 7:
  case 0xe:
  case 0x11:
  case 0x1d:
  case 0x27:
    break;
  case 4:
    FUN_00162300(0x5a6320);
    break;
  case 5:
    FUN_00162300(0x5a58b0);
    break;
  case 6:
    FUN_00162300(0x5a6de0);
    break;
  case 8:
    FUN_00162300(0x5a5be0);
    break;
  case 9:
    FUN_00162300(0x5a5fd0);
    break;
  case 10:
    FUN_00162300(0x5a61b0);
    break;
  case 0xb:
    if ((*(uint *)(iRam0064dfb4 + 0x388) & 0x400) == 0) {
      FUN_00162300(0x5a63b0);
    }
    break;
  case 0xc:
    FUN_00162300(0x5a5500);
    break;
  case 0xd:
    if ((*(uint *)(iRam0064dfb4 + 0x388) & 0x400) == 0) {
      FUN_00162300(0x5a6560);
    }
    break;
  case 0xf:
    if ((*(uint *)(iRam0064dfb4 + 0x388) & 0x400) == 0) {
      FUN_00162300(0x5a62d0);
    }
    break;
  case 0x10:
    FUN_00162300(0x5a5f50);
    break;
  case 0x12:
    FUN_00162300(0x5a6bf0);
    break;
  case 0x13:
    FUN_00162300(0x5a5830);
    break;
  case 0x14:
    FUN_00162300(0x5a5c40);
    break;
  case 0x15:
    FUN_00162300(0x5a6500);
    break;
  case 0x16:
    FUN_00162300(0x64c5c4);
    break;
  case 0x17:
    if (*(int *)(iRam0064dfb4 + 0x394) < 5) {
      FUN_00162300(0x5a66d0);
    }
    break;
  case 0x18:
    FUN_00162300(0x5a6410);
    break;
  case 0x19:
    FUN_00162300(0x5a5700);
    break;
  case 0x1a:
    FUN_00162300(0x5a6b90);
    break;
  case 0x1b:
    FUN_00162300(0x5a5ec0);
    break;
  case 0x1c:
    FUN_00162300(0x5a64a0);
    break;
  case 0x1e:
    FUN_00162300(0x5a6e60);
    break;
  case 0x1f:
    FUN_00162300(0x5a53a0);
    break;
  case 0x20:
    FUN_00162300(0x5a5de0);
    break;
  case 0x21:
    FUN_00162300(0x5a6f60);
    break;
  case 0x22:
    FUN_00162300(0x5a7160);
    break;
  case 0x23:
    FUN_00162300(0x64c5b8);
    break;
  case 0x24:
    FUN_00162300(0x5a7000);
    break;
  case 0x25:
    FUN_00162300(0x5a6d20);
    break;
  case 0x26:
    FUN_00162300(0x5a6c80);
    break;
  case 0x28:
    FUN_00162300(0x5a7070);
    break;
  case 0x29:
    if (*(int *)(iRam0064dfb4 + 0x394) < 5) {
      FUN_00162300(0x5a5ab0);
    }
    break;
  case 0x2a:
    FUN_00162300(0x5a6ee0);
    break;
  case 0x2b:
    FUN_00162300(0x5a5e60);
    break;
  case 0x2c:
    FUN_00162300(0x5a6770);
    break;
  case 0x2d:
    FUN_00162300(0x5a6810);
    break;
  case 0x2e:
    FUN_00162300(0x5a6890);
    break;
  case 0x2f:
    FUN_00162300(0x5a6b20);
    break;
  case 0x30:
    FUN_00162300(0x5a59d0);
    break;
  case 0x31:
    FUN_00162300(0x5a6a70);
    break;
  case 0x32:
    FUN_00162300(0x5a6120);
    break;
  case 0x33:
    FUN_00162300(0x5a6260);
    break;
  case 0x34:
    if ((*(uint *)(iRam0064dfb4 + 0x388) & 0x400) == 0) {
      FUN_00162300(0x5a6990);
    }
    break;
  case 0x35:
    FUN_00162300(0x5a65f0);
    break;
  case 0x36:
    FUN_00162300(0x5a6070);
    break;
  case 0x37:
    FUN_00162300(0x5a5650);
    break;
  case 0x38:
    FUN_00162300(0x5a5b30);
    break;
  case 0x39:
    FUN_00162300(0x5a7100);
    break;
  case 0x3a:
    FUN_00162300(0x5a6920);
    break;
  case 0x3b:
    if (*(int *)(iRam0064dfb4 + 0x394) < 2) {
      FUN_00162300(0x5a57b0);
    }
    break;
  case 0x3c:
    if (*(int *)(iRam0064dfb4 + 0x394) < 5) {
      FUN_00162300(0x5a5d60);
    }
    break;
  case 0x3d:
    FUN_00162300(0x5a6a10);
    break;
  case 0x3e:
    lVar3 = FUN_004ef220(iRam0064dfc0,2);
    if (lVar3 != 0) {
      FUN_00161ed0(2);
    }
    break;
  default:
    goto switchD_001fc730_default;
  }
switchD_001fc730_default:
  iVar4 = iVar4 + 0x144 + (int)lVar2 * 8;
  lVar3 = FUN_0028e550(6);
  if (lVar3 != 0) {
    FUN_0028a700((uint)(iVar4 - (*(int *)(*(int *)(iRam0064dfc0 + 0x44c) + 4) + 0xf4)) >> 3,
                 lVar2 == 2);
    FUN_0028e010();
  }
  FUN_001fe0d0();
  if (lVar2 == 2) {
    FUN_001e9ff0(0x1300);
  }
  FUN_001fa7e0(iVar4);
  return 0x3f800000;
}

