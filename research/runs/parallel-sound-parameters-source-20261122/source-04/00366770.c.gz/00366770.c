
void FUN_00366770(int param_1,undefined1 *param_2)

{
  undefined8 uVar1;
  
  *param_2 = 0;
  if (*(int *)(param_1 + 0x1a0) == 0) {
    uVar1 = FUN_00343480(0x64d130,0x64d138,0x5e6f50,0x5e6f60,0x5e6f70);
    FUN_001de4b0(param_2,uVar1);
  }
  else {
    FUN_0035ce00(param_2,*(int *)(param_1 + 0x1a0) + 0x1d);
  }
  return;
}

