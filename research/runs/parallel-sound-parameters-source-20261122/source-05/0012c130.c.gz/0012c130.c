
/* WARNING: Removing unreachable block (ram,0x0012c168) */

undefined8 FUN_0012c130(long param_1)

{
  bool bVar1;
  undefined8 uVar2;
  uint uVar3;
  
  if (param_1 == -1) {
    bVar1 = false;
  }
  else {
    uVar3 = (uint)param_1 >> 0x10;
    if (0x157 < uVar3) {
      uVar3 = 0;
    }
    if (uVar3 == 0xffffffff) {
      bVar1 = false;
    }
    else if (uVar3 < 0x158) {
      bVar1 = true;
    }
    else {
      bVar1 = false;
    }
  }
  if (bVar1) {
    uVar2 = FUN_0012c030(0x3f800000);
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

