
/* WARNING: Removing unreachable block (ram,0x0012bf4c) */

undefined8 FUN_0012bf10(uint param_1)

{
  bool bVar1;
  undefined8 uVar2;
  long lVar3;
  uint uVar4;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  
  if (param_1 == 0xffffffff) {
    bVar1 = false;
  }
  else {
    uVar4 = param_1 >> 0x10;
    if (0x157 < uVar4) {
      uVar4 = 0;
    }
    if (uVar4 == 0xffffffff) {
      bVar1 = false;
    }
    else if (uVar4 < 0x158) {
      bVar1 = true;
    }
    else {
      bVar1 = false;
    }
  }
  if (bVar1) {
    uStack_38 = DAT_005f7328;
    uStack_34 = DAT_005f732c;
    uStack_30 = DAT_005f7330;
    uStack_2c = DAT_005f7334;
    uStack_28 = DAT_005f7338;
    uStack_20 = DAT_005f7340;
    uStack_1c = DAT_005f7344;
    uStack_18 = DAT_005f7348;
    uStack_14 = DAT_005f734c;
    uStack_10 = DAT_005f7350;
    uStack_3c = 0x3f800000;
    uStack_24 = 1;
    uStack_40 = param_1;
    lVar3 = FUN_0012c440(&uStack_40);
    if (lVar3 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_00315c70(uStack_3c,uStack_18,uStack_2c,(undefined4)uStack_10,uStack_14,
                           uStack_10._4_4_);
    }
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

