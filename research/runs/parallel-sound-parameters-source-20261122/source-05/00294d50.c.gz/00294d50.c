
void FUN_00294d50(undefined4 param_1,int param_2)

{
  switch(param_1) {
  case 0x332c:
    if ((-1 < param_2) && (param_2 < 5)) {
      iRam006b6f78 = param_2;
    }
    break;
  case 0x332d:
    if ((-1 < param_2) && (param_2 < 5)) {
      iRam006b6f7c = param_2;
    }
    break;
  case 0x332f:
    if ((0 < param_2) && (param_2 < 4)) {
      iRam006b6f80 = param_2;
    }
    break;
  case 0x3331:
    if ((0x13 < param_2) && (param_2 < 0x60)) {
      if (param_2 < iRam006b6f84) {
        iRam006b6f84 = iRam006b6f84 + -5;
        if (iRam006b6f84 < 0x14) {
          iRam006b6f84 = 0x14;
        }
      }
      else {
        iRam006b6f84 = iRam006b6f84 + 5;
        if (0x5f < iRam006b6f84) {
          iRam006b6f84 = 0x5f;
        }
      }
    }
    break;
  case 0x3332:
    if ((-1 < param_2) && (param_2 < 2)) {
      iRam006b6f8c = param_2;
    }
    break;
  case 0x3333:
    if ((-1 < param_2) && (param_2 < 4)) {
      iRam006b6f88 = param_2;
    }
  }
  return;
}

