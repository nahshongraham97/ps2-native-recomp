
undefined4 FUN_0023be30(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 local_44 [5];
  undefined4 local_30;
  undefined4 local_28;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  uint local_10;
  undefined4 *local_c;
  undefined4 local_8;
  
  local_8 = 0;
  puVar2 = &DAT_00502a08;
  puVar3 = local_44;
  for (iVar1 = 0xe; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  local_44[0] = param_1;
  local_44[1] = param_2;
  local_28 = 1;
  iVar1 = FUN_0023bee0(local_44);
  if ((iVar1 != 0) && (local_c = (undefined4 *)FUN_0023c110(), local_c != (undefined4 *)0x0)) {
    local_10 = local_10 | 9;
    local_8 = FUN_003797d0(local_1c,local_30,local_14,local_18,local_44[1],local_10);
    local_c[2] = param_1;
    local_c[1] = local_1c;
    *local_c = local_8;
  }
  return local_8;
}

