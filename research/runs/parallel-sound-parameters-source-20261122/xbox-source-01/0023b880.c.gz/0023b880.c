
undefined4 FUN_0023b880(undefined4 param_1,byte *param_2)

{
  int iVar1;
  undefined4 local_8;
  
  local_8 = 0;
  *param_2 = 0;
  iVar1 = FUN_0023ba40(param_1);
  if (iVar1 != 0) {
    iVar1 = FUN_0023b930(param_1);
    *param_2 = (byte)((uint)*(undefined4 *)(&DAT_0056cbe0 + iVar1 * 4) >> 0x19);
    if (*param_2 < 0x27) {
      local_8 = 1;
    }
  }
  return local_8;
}

