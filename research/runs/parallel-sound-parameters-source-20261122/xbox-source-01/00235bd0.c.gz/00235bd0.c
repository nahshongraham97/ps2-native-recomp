
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00235bd0(void)

{
  DAT_00723ba0 = DAT_005684b0;
  _DAT_00723ba4 = DAT_005684b4;
  _DAT_00723ba8 = DAT_005684b8;
  _DAT_00723bac = DAT_005684bc;
  _DAT_00723bb0 = DAT_005684c0;
  _DAT_00723bb4 = DAT_005684c4;
  return;
}

