
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_0023b9c0(undefined4 param_1)

{
  int iVar1;
  float local_c;
  
  iVar1 = FUN_0023b930(param_1);
  local_c = (float)(*(uint *)(&DAT_0056cbe0 + iVar1 * 4) >> 0xd & 0x7f) / _DAT_004d7ca0;
  if (local_c < _DAT_004d7c38) {
    local_c = 0.0;
  }
  if (_DAT_004d7ca0 < local_c) {
    local_c = 100.0;
  }
  return (float10)local_c;
}

