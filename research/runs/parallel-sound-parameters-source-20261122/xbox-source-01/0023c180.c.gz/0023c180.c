
undefined4 FUN_0023c180(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 local_40 [5];
  undefined4 local_2c;
  undefined4 local_24;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_8 = 0;
  puVar2 = &DAT_00502a08;
  puVar3 = local_40;
  for (iVar1 = 0xe; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  local_40[0] = param_1;
  local_40[1] = param_2;
  local_24 = 1;
  iVar1 = FUN_0023bee0(local_40);
  if (iVar1 != 0) {
    local_8 = FUN_003797d0(local_18,local_2c,local_10,local_14,local_40[1],local_c);
  }
  return local_8;
}

