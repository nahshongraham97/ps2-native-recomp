
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0023bee0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  float local_10;
  undefined4 local_c;
  byte local_6;
  byte local_5;
  
  local_c = 0;
  local_6 = 0;
  local_5 = 0;
  local_10 = 1.0;
  if ((float)param_1[1] < _DAT_004d7c38) {
    param_1[1] = 0;
  }
  if (DAT_004d7b54 < (float)param_1[1]) {
    param_1[1] = 0x3f800000;
  }
  if ((float)param_1[2] < _DAT_004d7ccc) {
    param_1[2] = 0xc0000000;
  }
  if (DAT_004d7cd0 < (float)param_1[2]) {
    param_1[2] = 0x40000000;
  }
  if ((float)param_1[3] < DAT_004d7c30) {
    param_1[3] = 0x3f000000;
  }
  if (DAT_004d7c34 < (float)param_1[3]) {
    param_1[3] = 0x40400000;
  }
  iVar1 = FUN_0023ba40(*param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_0023e020(*param_1);
    param_1[10] = uVar2;
    if ((((param_1[10] != 0) && (iVar1 = FUN_0023b880(*param_1,&local_6), iVar1 != 0)) &&
        (local_5 = (&DAT_005783cc)[(uint)local_6 * 8], local_5 < 6)) &&
       (iVar1 = FUN_0023b7f0(*param_1,&local_10), iVar1 != 0)) {
      param_1[1] = local_10 * (float)param_1[1] * *(float *)(&DAT_005783c8 + (uint)local_6 * 8) *
                   (float)(&DAT_00723ba0)[local_5];
      if ((float)param_1[1] < _DAT_004d7c38) {
        param_1[1] = 0;
      }
      if (DAT_004d7b54 < (float)param_1[1]) {
        param_1[1] = 0x3f800000;
      }
      iVar1 = FUN_0023b660(*param_1,param_1 + 5);
      if (((iVar1 != 0) && (iVar1 = FUN_0023b6b0(*param_1,param_1 + 0xb), iVar1 != 0)) &&
         (iVar1 = FUN_0023b700(*param_1,param_1 + 0xc), iVar1 != 0)) {
        param_1[0xd] = 1;
        local_c = 1;
      }
    }
  }
  return local_c;
}

