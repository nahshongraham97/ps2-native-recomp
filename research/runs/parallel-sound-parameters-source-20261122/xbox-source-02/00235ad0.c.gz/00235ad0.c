
void FUN_00235ad0(undefined4 param_1)

{
  FUN_00235af0(param_1,&DAT_005684b0);
  return;
}

