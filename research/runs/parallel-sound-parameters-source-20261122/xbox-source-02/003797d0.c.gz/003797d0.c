
undefined4
FUN_003797d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,uint param_6)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  if (param_1 == 0) {
    uVar1 = 0;
  }
  else {
    iVar2 = FUN_003794f0(param_1,param_2);
    if ((iVar2 == 0) || (iVar3 = FUN_003790f0(iVar2,DAT_00707874), iVar3 == 0)) {
      uVar1 = 0;
    }
    else {
      iVar4 = FUN_0037dad0(0,iVar3);
      uVar1 = FUN_0037db80(&DAT_00707860,iVar3);
      *(uint *)(iVar4 + 0x44) = *(uint *)(iVar4 + 0x44) | param_6;
      *(undefined4 *)(iVar4 + 0x10) = param_4;
      *(undefined4 *)(iVar4 + 0xc) = param_3;
      *(undefined4 *)(iVar4 + 0x14) = param_5;
      FUN_00378d60(DAT_00707874,param_1,iVar2,FUN_00378e80,iVar3);
    }
  }
  return uVar1;
}

