
void FUN_002362e0(void)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 6; local_8 = local_8 + 1) {
    (&DAT_00723ba0)[local_8] = (&DAT_005684b0)[local_8];
  }
  return;
}

