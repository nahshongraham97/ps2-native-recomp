
void FUN_00336410(undefined8 param_1,undefined8 param_2,undefined8 param_3,long param_4)

{
  bool bVar1;
  long lVar2;
  long lVar3;
  int iVar4;
  int *piVar5;
  int iStack_4;
  
  FUN_00315680(uRam0064df20);
  FUN_003162d0();
  FUN_001ba120();
  FUN_00294900();
  lVar2 = FUN_00336b90(0,1,0,param_2,param_3,0,4000000);
  if (lVar2 == 0) {
    trap(7);
    FUN_001d8ea8(0xffffffffffffffff);
    goto LAB_00336800;
  }
  piVar5 = (int *)lVar2;
  FUN_00337260(uRam006b6f60,piVar5[1]);
  if (param_4 != 0) {
    FUN_00336f90(param_4);
  }
  lVar3 = FUN_00182e30();
  if (lVar3 == 2) {
    FUN_003e4e50();
LAB_00336530:
    iVar4 = *piVar5;
  }
  else {
    if (lVar3 == 3) {
      FUN_003e4e50(1);
      goto LAB_00336530;
    }
    if (lVar3 == 4) {
      FUN_003e4e50(4);
      goto LAB_00336530;
    }
    if (lVar3 != 1) {
      FUN_003e4e50(0);
      goto LAB_00336530;
    }
    FUN_003e4e50();
    iVar4 = *piVar5;
  }
  if (iVar4 == 0) {
    iVar4 = piVar5[1];
  }
  else {
    if ((iVar4 != 1) && (iVar4 != 2)) {
      FUN_003363c0(0x632900);
      goto LAB_003365c8;
    }
    if (iVar4 != 0) {
      if (iVar4 == 1) {
        iVar4 = piVar5[1];
      }
      else {
        if (iVar4 != 2) {
          FUN_003363c0(0x6328d0);
          goto LAB_003365a8;
        }
        FUN_003375b0(piVar5[1]);
        iVar4 = piVar5[1];
      }
      FUN_00337500(iVar4);
      *piVar5 = 0;
    }
LAB_003365a8:
    iVar4 = piVar5[1];
  }
  FUN_00337380(iVar4,param_1);
  *piVar5 = 1;
LAB_003365c8:
  iVar4 = *piVar5;
  do {
    if (iVar4 == 1) {
      if (piVar5[2] != 0) {
        FUN_003dabe0();
      }
      lVar3 = FUN_00337670(piVar5[1]);
      if (lVar3 == 0) goto LAB_00336640;
      *piVar5 = 0;
      bVar1 = true;
    }
    else {
      if ((iVar4 != 0) && (iVar4 != 2)) {
        FUN_003363c0(0x632930);
      }
LAB_00336640:
      bVar1 = false;
    }
    if (bVar1) break;
    iVar4 = *piVar5;
  } while( true );
  iVar4 = *piVar5;
  if (iVar4 == 0) {
    iVar4 = *piVar5;
  }
  else {
    if (iVar4 == 1) {
      iVar4 = piVar5[1];
LAB_00336688:
      FUN_00337500(iVar4);
      *piVar5 = 0;
    }
    else {
      if (iVar4 == 2) {
        FUN_003375b0(piVar5[1]);
        iVar4 = piVar5[1];
        goto LAB_00336688;
      }
      FUN_003363c0(0x6328d0);
    }
    iVar4 = *piVar5;
  }
  if (iVar4 == 0) {
    iVar4 = piVar5[1];
LAB_00336728:
    FUN_00337340(iVar4);
    piVar5[1] = 0;
    FUN_003363d0(lVar2);
    iRam0064eda0 = iRam0064eda0 + -1;
  }
  else {
    if (iVar4 == 1) {
      iVar4 = *piVar5;
LAB_003366d8:
      if (iVar4 != 0) {
        if (iVar4 == 1) {
          iVar4 = piVar5[1];
        }
        else {
          if (iVar4 != 2) {
            FUN_003363c0(0x6328d0);
            goto LAB_00336724;
          }
          FUN_003375b0(piVar5[1]);
          iVar4 = piVar5[1];
        }
        FUN_00337500(iVar4);
        *piVar5 = 0;
      }
LAB_00336724:
      iVar4 = piVar5[1];
      goto LAB_00336728;
    }
    if (iVar4 == 2) {
      FUN_003375b0(piVar5[1]);
      iVar4 = *piVar5;
      goto LAB_003366d8;
    }
    FUN_003363c0(0x632960);
  }
  if ((iRam0064eda0 == 0) && (iRam0064ed9c != 0)) {
    FUN_00337140();
    if (-1 < DAT_0064cc94) {
      FUN_00115538(DAT_0064cc94,0,0,&iStack_4);
      if (iStack_4 < 0) {
        FUN_001dcc58(0x632990);
      }
      else {
        lVar2 = FUN_00115740(DAT_0064cc94);
        iStack_4 = (int)lVar2;
        if (lVar2 < 0) {
          FUN_001dcc58(0x6329c0,lVar2);
        }
        else {
          DAT_0064cc94 = -1;
        }
      }
    }
    iRam0064ed9c = 0;
    FUN_003dda70(1);
  }
LAB_00336800:
  FUN_00294900();
  FUN_001ba160();
  FUN_00316280();
  return;
}

