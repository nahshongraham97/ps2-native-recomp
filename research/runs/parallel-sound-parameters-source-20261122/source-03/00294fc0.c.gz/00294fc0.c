
undefined4 FUN_00294fc0(void)

{
  int iVar1;
  long lVar2;
  undefined8 uVar3;
  long lVar4;
  int iVar5;
  
  iVar1 = iRam0064eac0;
LAB_00294fd4:
  lVar2 = FUN_00170c20();
  if (lVar2 == 0) {
    FUN_002236b0(0);
  }
  if ((iVar1 < 0) || (1 < iVar1)) {
    lVar2 = 0;
  }
  else {
    iVar5 = iVar1 * 0x1e218;
    if (*(int *)(iVar5 + 0x660640) == 0) {
      uVar3 = FUN_00263e40(0x14,1);
      lVar2 = FUN_001712c0(iVar1,2,uVar3,iVar5 + 0x660678,0,iVar5 + 0x660644,iVar5 + 0x660648);
      if (lVar2 != 0) {
        iRam0064eac0 = iVar1;
        return 1;
      }
      lVar2 = 0;
      iRam0064eac0 = -1;
    }
    else {
      lVar2 = 0;
    }
  }
LAB_002950a0:
  lVar4 = FUN_00170c20();
  if (lVar4 == 0) {
    FUN_002236b0(0);
  }
  if (lVar2 == 0) {
    iVar1 = FUN_00295520();
    if (iVar1 != -1) {
      lVar2 = 1;
    }
  }
  if (lVar2 == 0) {
    iVar1 = FUN_00295470();
    if (iVar1 != -1) {
      FUN_0027c790(iVar1);
      if (iRam0064ea4c == 1) {
        lVar2 = 0;
        lVar4 = FUN_001709b0(iVar1);
        if (((lVar4 != 0) && (FUN_0027c530(iVar1), iRam0064ea50 == 1)) &&
           (lVar2 = FUN_00222400(iVar1), lVar2 == 0)) {
          iVar1 = -1;
          goto LAB_00294fd4;
        }
        if (*(int *)(iVar1 * 0x1e218 + 0x660640) == 2) {
          lVar2 = FUN_00170d40(iVar1);
        }
      }
      else {
        lVar2 = 0;
      }
      FUN_0027b490();
    }
  }
  if (lVar2 == 0) {
    if ((iRam00660640 == 1) && (iRam0067e858 == 1)) goto code_r0x002951ec;
    goto LAB_00295210;
  }
  goto LAB_00294fd4;
code_r0x002951ec:
  FUN_0027b8f0();
  FUN_0027b490();
  if (iRam0064ea6c != 2) {
LAB_00295210:
    if (iRam00660640 == 5) {
      FUN_0027e5a0(0);
      FUN_0027b490();
      if (iRam0064ea20 == 2) goto LAB_002950a0;
    }
    if (iRam0067e858 == 5) {
      FUN_0027e5a0(1);
      FUN_0027b490();
      if (iRam0064ea20 == 2) goto LAB_002950a0;
    }
    lVar2 = FUN_00182e30();
    if (lVar2 == 2) {
      uVar3 = FUN_00263e40(0x15,1);
      FUN_0027f8b0(uVar3);
    }
    else {
      uVar3 = FUN_00263e40(0x14,1);
      FUN_0027f8b0(uVar3);
    }
    FUN_0027b490();
    iRam0064eac0 = 0xffffffff;
    return 0;
  }
  goto LAB_002950a0;
}

