
undefined4 FUN_002456a0(void)

{
  long lVar1;
  undefined1 auStack_c [4];
  undefined1 auStack_8 [4];
  undefined1 auStack_4 [4];
  
  FUN_00181ad0();
  FUN_002f1ad0(0x5ff150,0x8002a,0,0);
  FUN_002236b0(0);
  uRam0064df58 = 0x3f800000;
  (**(code **)(*piRam0064df54 + 0x14))();
  FUN_00222840();
  FUN_00295380();
  iRam0064e904 = 0;
  FUN_0012edc0(0x3008);
  iRam0064e904 = 0;
  FUN_0012dda0(0x3008,0x24,0x245500,8,auStack_4);
  FUN_001708d0(0);
  FUN_002f09e0(0x1fb7,0);
  FUN_001844a0(10,1);
  uRam0064df58 = 0x41200000;
  (**(code **)(*piRam0064df54 + 0x14))();
  while( true ) {
    FUN_002f09e0(0x1fb7,0);
    FUN_0016ffe0();
    while (iRam0064e904 == 0) {
      lVar1 = FUN_002236b0(1);
      if (lVar1 != 0) {
        uRam0064df58 = 0x3f800000;
        (**(code **)(*piRam0064df54 + 0x14))();
        FUN_002f09e0(0x1fb7,0);
        FUN_0012edc0(0x3008);
        iRam0064e904 = 0;
        FUN_0012dda0(0x3008,0x24,0x245500,8,auStack_8);
      }
      FUN_0016fec0();
      uRam0064df58 = 0x40000000;
      (**(code **)(*piRam0064df54 + 0x14))();
    }
    FUN_002f09e0(0x1fb7,0);
    FUN_0027b730();
    if (iRam0064ea70 != 2) break;
    iRam0064e904 = 0;
    FUN_0012edc0(0x3008);
    iRam0064e904 = 0;
    FUN_0012dda0(0x3008,0x24,0x245500,8,auStack_c);
    FUN_002f0670();
    FUN_002f09e0(0x1ff1,0);
  }
  FUN_00295380();
  uRam0064df58 = 0x42480000;
  (**(code **)(*piRam0064df54 + 0x14))();
  FUN_00184500(10,1);
  FUN_00181a30();
  FUN_002f09e0(0x1fbe,0);
  uRam0064df58 = 0x3f800000;
  (**(code **)(*piRam0064df54 + 0x14))();
  FUN_001225d0(0,0x18db60);
  return 0xbf800000;
}

