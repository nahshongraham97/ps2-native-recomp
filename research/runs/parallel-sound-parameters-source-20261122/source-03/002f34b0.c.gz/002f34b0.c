
void FUN_002f34b0(undefined8 param_1,long param_2,long param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  if ((param_2 < 0x332c) || (0x3333 < param_2)) {
    uVar6 = (undefined4)param_3;
    uVar1 = uGpffffaa78;
    uVar2 = uGpffffaa7c;
    uVar3 = uGpffffaa80;
    uVar4 = uGpffffaa84;
    uVar5 = uVar6;
    if (param_2 != 0x13c5) {
      uVar5 = uGpffffaa88;
      if (param_2 == 0x2008) {
        if (param_3 < 1) {
          param_3 = 0xf;
        }
        uGpffff8720 = (undefined4)param_3;
      }
      else if (param_2 == 0x2f50) {
        FUN_00182e40(param_3);
        uGpffff9f9c = 1;
        uVar1 = uGpffffaa78;
        uVar2 = uGpffffaa7c;
        uVar3 = uGpffffaa80;
        uVar4 = uGpffffaa84;
        uVar5 = uGpffffaa88;
      }
      else if (param_2 != 0x1ff2) {
        if (param_2 == 0x1ff5) {
          if (param_3 == 0) {
            uGpffffaa98 = 0;
          }
          else {
            uGpffffaa98 = 1;
          }
        }
        else if (param_2 == 0x3716) {
          FUN_001532a0();
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x3717) {
          FUN_001532f0();
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x3714) {
          FUN_001533c0(param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x3715) {
          FUN_00153430(param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x1ffa) {
          FUN_00153cd0(param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x1ff9) {
          FUN_00153d90(param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x2f4f) {
          FUN_00242070(param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x1fdf) {
          FUN_00153660(1,param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x1fde) {
          FUN_00153660(0,param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x2f46) {
          FUN_002417f0(param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x1fd2) {
          FUN_00241ed0(param_3);
          uVar1 = uGpffffaa78;
          uVar2 = uGpffffaa7c;
          uVar3 = uGpffffaa80;
          uVar4 = uGpffffaa84;
          uVar5 = uGpffffaa88;
        }
        else if (param_2 == 0x2f44) {
          if (param_3 == 0) {
            FUN_00241ec0(1);
            uVar1 = uGpffffaa78;
            uVar2 = uGpffffaa7c;
            uVar3 = uGpffffaa80;
            uVar4 = uGpffffaa84;
            uVar5 = uGpffffaa88;
          }
          else {
            FUN_00241ec0(2);
            uVar1 = uGpffffaa78;
            uVar2 = uGpffffaa7c;
            uVar3 = uGpffffaa80;
            uVar4 = uGpffffaa84;
            uVar5 = uGpffffaa88;
          }
        }
        else {
          uVar3 = uVar6;
          if (param_2 != 0x1fd4) {
            if (param_2 == 0x1fdd) {
              FUN_001707f0(param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x2b60) {
              FUN_00294f10(4,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x2b5f) {
              FUN_00294f10(3,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x2b5e) {
              FUN_00294f10(2,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x2b5d) {
              FUN_00294f10(1,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x2b5c) {
              FUN_00294f10(0,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x1fb0) {
              FUN_00170850(param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x1fc7) {
              FUN_00153c70(0,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x1fcb) {
              uGpffffa230 = uVar6;
              FUN_00189830(1,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else if (param_2 == 0x1fca) {
              uGpffffa234 = uVar6;
              FUN_00189830(0,param_3);
              uVar1 = uGpffffaa78;
              uVar2 = uGpffffaa7c;
              uVar3 = uGpffffaa80;
              uVar4 = uGpffffaa84;
              uVar5 = uGpffffaa88;
            }
            else {
              uVar3 = uGpffffaa80;
              uVar4 = uVar6;
              if (((param_2 != 0x1ffe) && (uVar2 = uVar6, uVar4 = uGpffffaa84, param_2 != 0x1fc6))
                 && (uVar1 = uVar6, uVar2 = uGpffffaa7c, param_2 != 0x238e)) {
                if (param_2 == 0x2009) {
                  FUN_00153610(param_3);
                  uVar1 = uGpffffaa78;
                  uVar2 = uGpffffaa7c;
                  uVar3 = uGpffffaa80;
                  uVar4 = uGpffffaa84;
                  uVar5 = uGpffffaa88;
                }
                else if (param_2 == 0x238d) {
                  FUN_00342900(param_3);
                  uVar1 = uGpffffaa78;
                  uVar2 = uGpffffaa7c;
                  uVar3 = uGpffffaa80;
                  uVar4 = uGpffffaa84;
                  uVar5 = uGpffffaa88;
                }
                else {
                  uVar1 = uGpffffaa78;
                  if (param_2 == 0x1f94) {
                    FUN_001899a0(param_3);
                    uVar1 = uGpffffaa78;
                    uVar2 = uGpffffaa7c;
                    uVar3 = uGpffffaa80;
                    uVar4 = uGpffffaa84;
                    uVar5 = uGpffffaa88;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  else {
    FUN_00294d50(param_2,param_3);
    uVar1 = uGpffffaa78;
    uVar2 = uGpffffaa7c;
    uVar3 = uGpffffaa80;
    uVar4 = uGpffffaa84;
    uVar5 = uGpffffaa88;
  }
  uGpffffaa88 = uVar5;
  uGpffffaa84 = uVar4;
  uGpffffaa80 = uVar3;
  uGpffffaa7c = uVar2;
  uGpffffaa78 = uVar1;
  return;
}

