
void FUN_002955d0(undefined8 param_1)

{
  FUN_001db8a8(param_1,0x5be650,0x58);
  return;
}

