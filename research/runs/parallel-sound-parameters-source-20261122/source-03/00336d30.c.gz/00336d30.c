
undefined4 FUN_00336d30(long param_1,long param_2)

{
  bool bVar1;
  long lVar2;
  undefined8 uVar3;
  int iVar4;
  uint auStack_30 [3];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  code *pcStack_18;
  code *pcStack_14;
  code *pcStack_10;
  code *pcStack_c;
  
  lVar2 = FUN_002207e0();
  auStack_30[0] = (uint)(lVar2 == 0x32);
  auStack_30[1] = 0;
  auStack_30[2] = FUN_002209d0();
  if (param_1 == 0) {
    uStack_24 = 0;
  }
  else {
    uStack_24 = 1;
    iVar4 = 0;
    uStack_20 = uRam006b6f60;
    uVar3 = FUN_002209e0(0x632a10,0);
    if (DAT_0064cc94 < 0) {
      do {
        lVar2 = FUN_00115b68(uVar3,0x14,0x632a30);
        DAT_0064cc94 = (int)lVar2;
        if ((lVar2 < 0) && (iVar4 = iVar4 + 1, 0x19 < iVar4)) {
          bVar1 = false;
          goto LAB_00336dec;
        }
      } while (lVar2 < 0);
    }
    bVar1 = true;
LAB_00336dec:
    if (!bVar1) {
      return 0;
    }
  }
  if (iRam0064ed9c == 0) {
    FUN_003dda70(2);
  }
  if (param_2 == 0) {
    pcStack_18 = FUN_003da7d0;
    pcStack_14 = FUN_003da780;
    pcStack_10 = FUN_003da740;
    pcStack_c = FUN_003da600;
  }
  else {
    pcStack_18 = (code *)&LAB_003dabd0;
    pcStack_14 = (code *)&LAB_003dabc0;
    pcStack_10 = (code *)&LAB_003dabb0;
    pcStack_c = (code *)&LAB_003dab90;
  }
  uStack_1c = 0;
  FUN_00336fa0(auStack_30);
  iRam0064ed9c = 1;
  return 1;
}

