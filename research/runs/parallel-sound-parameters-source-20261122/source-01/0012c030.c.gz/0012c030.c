
undefined8 FUN_0012c030(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  long lVar2;
  undefined8 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  ulong uStack_10;
  
  uStack_38 = DAT_005f7328;
  uStack_34 = DAT_005f732c;
  uStack_30 = DAT_005f7330;
  uStack_2c = DAT_005f7334;
  uStack_28 = DAT_005f7338;
  uVar3 = 0;
  uStack_20 = DAT_005f7340;
  uStack_1c = DAT_005f7344;
  uStack_18 = DAT_005f7348;
  uStack_14 = DAT_005f734c;
  uStack_10 = DAT_005f7350;
  uStack_24 = 1;
  uStack_40 = param_2;
  uStack_3c = param_1;
  lVar2 = FUN_0012c440(&uStack_40);
  if (lVar2 == 0) {
    uVar3 = 0;
  }
  else {
    if (iRam0064df24 < 0x10) {
      puVar4 = (undefined4 *)(iRam0064df24 * 0xc + 0x65b9c0);
      iRam0064df24 = iRam0064df24 + 1;
    }
    else {
      puVar4 = (undefined4 *)0x0;
    }
    if (puVar4 != (undefined4 *)0x0) {
      uVar1 = (undefined4)uStack_10;
      uStack_10 = uStack_10 | 0x900000000;
      uVar3 = FUN_00315c70(uStack_3c,uStack_18,uStack_2c,uVar1,uStack_14);
      puVar4[2] = param_2;
      puVar4[1] = uStack_18;
      *puVar4 = (int)uVar3;
    }
  }
  return uVar3;
}

