
void FUN_00294f10(int param_1,int param_2)

{
  int iVar1;
  float fVar2;
  
  fVar2 = 0.005;
  iVar1 = param_2;
  if (param_2 < 1) {
    fVar2 = 0.0;
    iVar1 = 0;
  }
  if (100 < param_2) {
    iVar1 = 100;
  }
  *(float *)(param_1 * 4 + 0x6b6f60) = (float)iVar1 / 100.0 + fVar2;
  return;
}

