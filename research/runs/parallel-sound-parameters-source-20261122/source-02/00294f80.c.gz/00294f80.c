
int FUN_00294f80(int param_1)

{
  return (int)(*(float *)(param_1 * 4 + 0x6b6f60) * 100.0);
}

