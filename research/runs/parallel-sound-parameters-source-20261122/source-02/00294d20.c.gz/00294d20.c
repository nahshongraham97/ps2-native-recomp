
void FUN_00294d20(void)

{
  uRam006b6f60 = DAT_005be650;
  uRam006b6f64 = DAT_005be654;
  uRam006b6f68 = DAT_005be658;
  uRam006b6f6c = DAT_005be65c;
  uRam006b6f70 = DAT_005be660;
  return;
}

