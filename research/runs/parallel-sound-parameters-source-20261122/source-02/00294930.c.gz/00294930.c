
void FUN_00294930(void)

{
  uRam006b6e80 = 0xd000000000008001;
  uRam006b6e88 = 0xee;
  uRam006b6e89 = 0xee;
  uRam006b6e8a = 0xee;
  uRam006b6e8b = 0xee;
  uRam006b6e8c = 0xee;
  bRam006b6e8e = bRam006b6e8e & 0xf0 | 0xe;
  uRam006b6e8d = 0xee;
  uRam006b6e90 = 0;
  uRam006b6ea0 = 0;
  uRam006b6ea8 = 0x42;
  uRam006b6eb0 = 0x100000;
  uRam006b6eb8 = 0x4c;
  uRam006b6ec0 = 1;
  uRam006b6ec8 = 0x1a;
  uRam006b6e98 = 0x45;
  uRam006b6ed0 = 0x3ff000003ff0000;
  uRam006b6ed8 = 0x40;
  uRam006b6ee0 = 0x30000;
  uRam006b6ee8 = 0x47;
  uRam006b6ef0 = 0;
  uRam006b6ef8 = 0x18;
  uRam006b6f00 = 0x10a000100;
  uRam006b6f08 = 0x4e;
  uRam006b6f10 = 6;
  uRam006b6f18 = 0;
  uRam006b6f20 = 0;
  uRam006b6f30 = 0;
  uRam006b6f28 = 1;
  uRam006b6f38 = 5;
  uRam006b6f40 = 0;
  uRam006b6f48 = 1;
  uRam006b6f50 = 0x3fff3fff;
  uRam006b6f58 = 5;
  FUN_0010d0d8(0x6b6e80,0x6b6fdf);
  return;
}

