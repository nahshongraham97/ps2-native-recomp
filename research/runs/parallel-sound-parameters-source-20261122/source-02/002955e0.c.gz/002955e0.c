
undefined4 FUN_002955e0(long param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  if ((param_1 < 0) || (1 < param_1)) {
    uVar1 = 0;
  }
  else {
    iVar2 = (int)param_1 * 0x1e218;
    if (*(int *)(iVar2 + 0x660640) == 0) {
      FUN_001db8a8(iVar2 + 0x660678,0x6b6f60,0x58);
      uVar1 = 1;
    }
    else {
      uVar1 = 0;
    }
  }
  return uVar1;
}

