
undefined4 FUN_00295380(void)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  
  lVar1 = FUN_00170c20();
  if (lVar1 == 0) {
    FUN_002236b0(0);
  }
  lVar1 = FUN_00295520();
  if (lVar1 == -1) {
    uVar3 = 0;
  }
  else if (lVar1 < 0) {
    uVar3 = 0;
  }
  else if (lVar1 < 2) {
    lVar2 = FUN_00170b70(lVar1);
    if (lVar2 == 0) {
      uVar3 = 0;
    }
    else {
      FUN_001db8a8(0x6b6f60,(int)lVar1 * 0x1e218 + 0x660678,0x58);
      uRam0064eac4 = 1;
      iRam0064eac0 = (int)lVar1;
      FUN_001531d0();
      uVar3 = 1;
    }
  }
  else {
    uVar3 = 0;
  }
  return uVar3;
}

