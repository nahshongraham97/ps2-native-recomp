
undefined4 FUN_00154410(void)

{
  long lVar1;
  undefined8 uVar2;
  undefined1 auStack_60 [92];
  int iStack_4;
  
  FUN_002955c0(auStack_60,0x6b6f60);
  FUN_002f0660();
  FUN_002f1ad0(0x5f9000,0x8002a,0,1);
  FUN_00181ad0();
  FUN_00163a50();
  FUN_00185d60(8);
  FUN_002f8250(6);
  lVar1 = FUN_0012de80(0x20a1,0x20,0x154300,0xc,&iStack_4);
  if (lVar1 != 0) {
    *(undefined4 *)(iStack_4 + 8) = 0;
  }
  uVar2 = FUN_0012bf10(0x1253c);
  lVar1 = FUN_0012df70(0xc);
  if (lVar1 != 0) {
    FUN_0012fee0(lVar1,iRam0064df54 + 0xe8);
    *(int *)((int)lVar1 + 8) = (int)uVar2;
  }
  FUN_002f19b0();
  FUN_0012edc0(0x11000);
  FUN_00185d30();
  DAT_0064c394 = FUN_002207e0();
  lVar1 = FUN_002f3fe0();
  if (lVar1 == 0) {
    FUN_002955c0(0x6b6f60,auStack_60);
    FUN_00225e50(uRam006b6fb0,uRam006b6fa8);
  }
  else {
    FUN_00294fc0();
  }
  FUN_00163ba0();
  FUN_002f8240();
  FUN_0012ba50(uVar2);
  FUN_001225d0(3,0x155250);
  return 0xbf800000;
}

