
void FUN_00295660(void)

{
  FUN_001db8a8(0x6b6f60,0x5be650,0x58);
  uRam0064eac4 = 0;
  uRam0064eac0 = 0xffffffff;
  return;
}

