
/* WARNING: Removing unreachable block (ram,0x0012c920) */
/* WARNING: Removing unreachable block (ram,0x0012c6f4) */
/* WARNING: Removing unreachable block (ram,0x0012c530) */
/* WARNING: Removing unreachable block (ram,0x0012c5f8) */
/* WARNING: Removing unreachable block (ram,0x0012c864) */
/* WARNING: Removing unreachable block (ram,0x0012c9e0) */

undefined4 FUN_0012c440(uint *param_1)

{
  byte bVar1;
  bool bVar2;
  bool bVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  ulong uVar8;
  uint uVar9;
  float fVar10;
  
  uVar4 = 0;
  if ((float)param_1[1] < 0.0) {
    param_1[1] = 0;
  }
  if (1.0 < (float)param_1[1]) {
    param_1[1] = 0x3f800000;
    fVar10 = (float)param_1[2];
  }
  else {
    fVar10 = (float)param_1[2];
  }
  if (fVar10 < -2.0) {
    param_1[2] = 0xc0000000;
    fVar10 = (float)param_1[2];
  }
  else {
    fVar10 = (float)param_1[2];
  }
  if (2.0 < fVar10) {
    param_1[2] = 0x40000000;
    fVar10 = (float)param_1[3];
  }
  else {
    fVar10 = (float)param_1[3];
  }
  if (fVar10 < 0.5) {
    param_1[3] = 0x3f000000;
    fVar10 = (float)param_1[3];
  }
  else {
    fVar10 = (float)param_1[3];
  }
  if (3.0 < fVar10) {
    param_1[3] = 0x40400000;
    uVar5 = *param_1;
  }
  else {
    uVar5 = *param_1;
  }
  if (uVar5 == 0xffffffff) {
    bVar2 = false;
  }
  else {
    uVar5 = uVar5 >> 0x10;
    if (0x157 < uVar5) {
      uVar5 = 0;
    }
    if (uVar5 == 0xffffffff) {
      bVar2 = false;
    }
    else if (uVar5 < 0x158) {
      bVar2 = true;
    }
    else {
      bVar2 = false;
    }
  }
  if (bVar2) {
    uVar5 = *param_1 >> 0x10;
    if (uVar5 < 0x158) {
      iVar6 = uVar5 << 2;
    }
    else {
      uVar5 = 0;
      iVar6 = 0;
    }
    uVar5 = *(uint *)(&DAT_0059bc30 + (iVar6 + uVar5) * 8);
    param_1[10] = uVar5;
    if (uVar5 != 0) {
      uVar5 = *param_1;
      bVar2 = false;
      if (uVar5 == 0xffffffff) {
        bVar3 = false;
      }
      else {
        uVar7 = uVar5 >> 0x10;
        if (0x157 < uVar7) {
          uVar7 = 0;
        }
        if (uVar7 == 0xffffffff) {
          bVar3 = false;
        }
        else if (uVar7 < 0x158) {
          bVar3 = true;
        }
        else {
          bVar3 = false;
        }
      }
      uVar7 = 0;
      if (bVar3) {
        uVar7 = uVar5 & 0xffff;
        if (0x25b7 < uVar7) {
          uVar7 = 0;
        }
        bVar1 = (byte)(&DAT_005c0d23)[uVar7 * 4] >> 1;
        uVar7 = (uint)bVar1;
        if (bVar1 < 0x27) {
          bVar2 = true;
          uVar7 = (uint)bVar1;
        }
      }
      if (bVar2) {
        if ((byte)(&DAT_005e2944)[uVar7 * 8] < 6) {
          bVar2 = false;
          if (uVar5 == 0xffffffff) {
            bVar3 = false;
          }
          else {
            uVar9 = uVar5 >> 0x10;
            if (0x157 < uVar9) {
              uVar9 = 0;
            }
            if (uVar9 == 0xffffffff) {
              bVar3 = false;
            }
            else if (uVar9 < 0x158) {
              bVar3 = true;
            }
            else {
              bVar3 = false;
            }
          }
          fVar10 = 1.0;
          if (bVar3) {
            uVar5 = uVar5 & 0xffff;
            if (0x25b7 < uVar5) {
              uVar5 = 0;
            }
            uVar8 = ((long)*(int *)(&DAT_005c0d20 + uVar5 * 4) & 0xfffffU) >> 0xd;
            fVar10 = 1.0;
            if (uVar8 < 0x65) {
              uVar5 = (uint)((ulong)((long)*(int *)(&DAT_005c0d20 + uVar5 * 4) << 0x2c) >> 0x20);
              if ((long)uVar8 < 0) {
                fVar10 = (float)(uVar5 >> 0x1a | uVar5 >> 0x19 & 1);
                fVar10 = fVar10 + fVar10;
              }
              else {
                fVar10 = (float)(uVar5 >> 0x19);
              }
              bVar2 = true;
              fVar10 = fVar10 / 100.0;
            }
          }
          if (bVar2) {
            fVar10 = *(float *)((uint)(byte)(&DAT_005e2944)[uVar7 * 8] * 4 + 0x6b6f60) *
                     (float)param_1[1] * fVar10 * *(float *)(&DAT_005e2940 + uVar7 * 8);
            param_1[1] = (uint)fVar10;
            if (fVar10 < 0.0) {
              param_1[1] = 0;
            }
            if (1.0 < (float)param_1[1]) {
              param_1[1] = 0x3f800000;
              uVar5 = *param_1;
            }
            else {
              uVar5 = *param_1;
            }
            bVar2 = false;
            if (uVar5 == 0xffffffff) {
              bVar3 = false;
            }
            else {
              uVar7 = uVar5 >> 0x10;
              if (0x157 < uVar7) {
                uVar7 = 0;
              }
              if (uVar7 == 0xffffffff) {
                bVar3 = false;
              }
              else if (uVar7 < 0x158) {
                bVar3 = true;
              }
              else {
                bVar3 = false;
              }
            }
            if (bVar3) {
              uVar5 = uVar5 & 0xffff;
              if (0x25b7 < uVar5) {
                uVar5 = 0;
              }
              bVar2 = true;
              param_1[5] = *(ushort *)(&DAT_005c0d20 + uVar5 * 4) & 0x3ff;
            }
            if (bVar2) {
              uVar5 = *param_1;
              bVar2 = false;
              if (uVar5 == 0xffffffff) {
                bVar3 = false;
              }
              else {
                uVar7 = uVar5 >> 0x10;
                if (0x157 < uVar7) {
                  uVar7 = 0;
                }
                if (uVar7 == 0xffffffff) {
                  bVar3 = false;
                }
                else if (uVar7 < 0x158) {
                  bVar3 = true;
                }
                else {
                  bVar3 = false;
                }
              }
              if (bVar3) {
                uVar5 = uVar5 & 0xffff;
                if (0x25b7 < uVar5) {
                  uVar5 = 0;
                }
                bVar2 = true;
                param_1[0xb] = (uint)(((ulong)*(ushort *)(&DAT_005c0d22 + uVar5 * 4) << 0x37) >>
                                     0x3e);
              }
              if (bVar2) {
                uVar5 = *param_1;
                bVar2 = false;
                if (uVar5 == 0xffffffff) {
                  bVar3 = false;
                }
                else {
                  uVar7 = uVar5 >> 0x10;
                  if (0x157 < uVar7) {
                    uVar7 = 0;
                  }
                  if (uVar7 == 0xffffffff) {
                    bVar3 = false;
                  }
                  else if (uVar7 < 0x158) {
                    bVar3 = true;
                  }
                  else {
                    bVar3 = false;
                  }
                }
                if (bVar3) {
                  uVar5 = uVar5 & 0xffff;
                  if (0x25b7 < uVar5) {
                    uVar5 = 0;
                  }
                  bVar2 = true;
                  param_1[0xc] = (uint)(((long)(char)(&DAT_005c0d22)[uVar5 * 4] << 0x39) >> 0x3d);
                }
                if (bVar2) {
                  uVar4 = 1;
                  param_1[0xd] = 1;
                }
              }
            }
          }
        }
      }
    }
  }
  return uVar4;
}

