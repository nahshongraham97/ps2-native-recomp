
void FUN_002955c0(undefined8 param_1,undefined8 param_2)

{
  FUN_001db8a8(param_1,param_2,0x58);
  return;
}

