
long FUN_00315c70(float param_1,long param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  undefined4 *puVar1;
  long lVar2;
  long lVar3;
  undefined8 uVar4;
  undefined4 uStack_4;
  
  if (param_2 == 0) {
    lVar2 = 0;
  }
  else {
    WaitSema(uRam0064ecb4);
    lVar2 = FUN_003172b0(0x79a150);
    if (lVar2 == 0) {
      SignalSema(uRam0064ecb4);
      lVar2 = 0;
    }
    else {
      SignalSema(uRam0064ecb4);
      lVar2 = FUN_00317140(0x79a150,lVar2);
    }
    if (lVar2 != 0) {
      lVar3 = FUN_00316620(8,0,0);
      if (lVar3 == 0) {
        WaitSema(uRam0064ecb4);
        lVar2 = FUN_00317170(0x79a150,lVar2);
        uStack_4 = (undefined4)lVar2;
        if (lVar2 != 0) {
          uVar4 = FUN_00317080(&uStack_4);
          FUN_003171f0(0x79a150,uVar4);
        }
        SignalSema(uRam0064ecb4);
        lVar2 = 0;
      }
      else {
        puVar1 = (undefined4 *)lVar3;
        *puVar1 = 0x36;
        param_1 = param_1 * 16384.0;
        puVar1[1] = (int)param_2;
        puVar1[2] = param_3;
        puVar1[3] = param_4;
        puVar1[4] = param_5;
        if (param_1 < 2.1474836e+09) {
          puVar1[5] = (int)param_1;
        }
        else {
          puVar1[5] = (int)(param_1 - 2.1474836e+09) | 0x80000000;
        }
        puVar1[6] = param_6;
        puVar1[7] = (int)lVar2;
        FUN_003165e0();
      }
    }
  }
  return lVar2;
}

