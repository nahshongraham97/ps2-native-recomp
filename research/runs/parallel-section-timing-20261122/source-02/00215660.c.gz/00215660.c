
void FUN_00215660(undefined8 param_1,int param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  int iVar2;
  int iVar3;
  long lVar4;
  
  if (iRam0064e800 == 0) {
LAB_002156a8:
    iVar3 = 0;
  }
  else {
    iVar2 = *(int *)(iRam0064e800 + 0x44);
    iVar3 = iRam0064e800;
    while (param_2 != iVar2) {
      iVar3 = *(int *)(iVar3 + 0x40);
      if (iVar3 == 0) goto LAB_002156a8;
      iVar2 = *(int *)(iVar3 + 0x44);
    }
  }
  if (iVar3 == 0) {
    lVar4 = FUN_0026ec40(param_3);
    if (lVar4 == 0) {
      lVar4 = 0;
    }
    else {
      uVar1 = FUN_00182e30();
      uVar1 = FUN_0026ef70(lVar4,uVar1);
      lVar4 = FUN_00215180(param_1,uVar1,1,param_4);
    }
    if (lVar4 != 0) {
      iVar2 = FUN_0019c140(param_1);
      *(int *)(*(int *)(iVar2 + 0x2c) + 0x44) = param_2;
    }
  }
  else {
    uRam0064e7fc = 0;
  }
  return;
}

