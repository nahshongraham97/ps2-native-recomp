
void FUN_00215730(undefined8 param_1,int param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  long lVar2;
  undefined8 uVar3;
  int iVar4;
  
  if (iRam0064e800 == 0) {
LAB_00215778:
    iVar4 = 0;
  }
  else {
    iVar1 = *(int *)(iRam0064e800 + 0x44);
    iVar4 = iRam0064e800;
    while (param_2 != iVar1) {
      iVar4 = *(int *)(iVar4 + 0x40);
      if (iVar4 == 0) goto LAB_00215778;
      iVar1 = *(int *)(iVar4 + 0x44);
    }
  }
  if (iVar4 == 0) {
    lVar2 = FUN_0026ec40(param_3);
    if (lVar2 == 0) {
      lVar2 = 0;
    }
    else {
      uVar3 = FUN_00182e30();
      uVar3 = FUN_0026ef70(lVar2,uVar3);
      lVar2 = FUN_00215180(param_1,uVar3,1,param_4);
    }
    if (lVar2 != 0) {
      iVar1 = FUN_0019c140(param_1,lVar2);
      *(int *)(*(int *)(iVar1 + 0x2c) + 0x44) = param_2;
    }
  }
  else {
    uRam0064e7fc = 0;
  }
  FUN_0019b3e0(param_1);
  return;
}

