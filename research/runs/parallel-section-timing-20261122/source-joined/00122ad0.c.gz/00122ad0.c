
void FUN_00122ad0(void)

{
  long lVar1;
  
  if (((bRam00660084 & 1) == 0) || (iGpffff9dd4 == 0)) {
    lVar1 = FUN_002207e0();
    if (lVar1 == 0x32) {
      uGpffff9da0 = 0x3f555555;
      uGpffff9da4 = 0x3f99999a;
      uGpffff9d9c = 0x3f8c378c;
    }
    else {
      uGpffff9da4 = 0x3f800000;
      uGpffff9da0 = 0x3f800000;
      uGpffff9d9c = 0x3f800000;
    }
  }
  else {
    uGpffff9da4 = 0x3f800000;
    uGpffff9da0 = 0x3f800000;
    uGpffff9d9c = 0x3f800000;
  }
  return;
}

