
long FUN_00215180(undefined8 param_1,undefined8 param_2,long param_3,undefined8 param_4)

{
  int iVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  if ((param_3 != 0) || (lVar2 = FUN_0019c080(), lVar2 == 0)) {
    iVar1 = iRam0064e804;
    if (iRam0064e804 != 0) {
      iRam0064e804 = *(int *)(iRam0064e804 + 0x40);
      FUN_001dba60(iVar1,0,0x9c);
      *(undefined4 *)(iVar1 + 0x44) = 0xffffffff;
      *(int *)(iVar1 + 0x40) = iRam0064e800;
      iRam0064e800 = iVar1;
    }
    uVar3 = FUN_0019c430(param_1);
    uVar4 = FUN_0019bfa0(uVar3);
    lVar2 = FUN_0019c320(param_1);
    *(int *)(iVar1 + 0x48) = (int)param_1;
    *(int *)(iVar1 + 0x4c) = (int)uVar4;
    *(int *)((int)uVar4 + 0x2c) = iVar1;
    FUN_003ddc90(uVar4,uVar3,param_1,param_2,3,param_4);
    FUN_001df378(iVar1,*(undefined4 *)param_2,0x3f);
    *(undefined1 *)(iVar1 + 0x3f) = 0;
  }
  return lVar2;
}

