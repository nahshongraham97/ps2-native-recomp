
void FUN_0019aa30(uint param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  uint *puVar4;
  uint uVar5;
  
  if (piRam0069f10c == (int *)0x0) {
LAB_0019aa70:
    piVar2 = (int *)0x0;
  }
  else {
    iVar3 = *piRam0069f10c;
    piVar2 = piRam0069f10c;
    while (iVar3 != (int)param_1 >> 0x10) {
      piVar2 = (int *)piVar2[6];
      if (piVar2 == (int *)0x0) goto LAB_0019aa70;
      iVar3 = *piVar2;
    }
  }
  if (piVar2 != (int *)0x0) {
    puVar4 = (uint *)piVar2[5];
    uVar5 = 0;
    if (piVar2[2] != 0) {
      do {
        if (*puVar4 == (param_1 & 0xffff)) break;
        uVar5 = uVar5 + 1;
        puVar4 = puVar4 + 6;
      } while (uVar5 < (uint)piVar2[2]);
    }
  }
  FUN_0019b530();
  if (piRam0069f10c == (int *)0x0) {
LAB_0019aae0:
    piVar2 = (int *)0x0;
  }
  else {
    iVar3 = *piRam0069f10c;
    piVar2 = piRam0069f10c;
    while (iVar3 != (int)param_1 >> 0x10) {
      piVar2 = (int *)piVar2[6];
      if (piVar2 == (int *)0x0) goto LAB_0019aae0;
      iVar3 = *piVar2;
    }
  }
  if (piVar2 == (int *)0x0) {
    puVar4 = (uint *)0x0;
  }
  else {
    puVar4 = (uint *)piVar2[5];
    uVar5 = 0;
    if (piVar2[2] != 0) {
      do {
        if (*puVar4 == (param_1 & 0xffff)) goto LAB_0019ab24;
        uVar5 = uVar5 + 1;
        puVar4 = puVar4 + 6;
      } while (uVar5 < (uint)piVar2[2]);
    }
    puVar4 = (uint *)0x0;
  }
LAB_0019ab24:
  if (((puVar4 != (uint *)0x0) && (piVar2 = (int *)puVar4[4], piVar2 != (int *)0x0)) &&
     (piVar2 != (int *)0x0)) {
    cVar1 = (char)piVar2[7];
    while( true ) {
      if (((cVar1 == '\0') && (FUN_003ddef0(piVar2), (char)piVar2[7] == '\0')) && (*piVar2 != 0)) {
        iVar3 = *(int *)(*piVar2 + 8);
        if (iVar3 == 3) {
          FUN_00215120(piVar2);
        }
        else if (iVar3 == 1) {
          FUN_003011d0(piVar2);
        }
        else if (iVar3 == 2) {
          FUN_002ffe40(piVar2);
        }
      }
      piVar2 = (int *)piVar2[6];
      if (piVar2 == (int *)0x0) break;
      cVar1 = (char)piVar2[7];
    }
  }
  return;
}

