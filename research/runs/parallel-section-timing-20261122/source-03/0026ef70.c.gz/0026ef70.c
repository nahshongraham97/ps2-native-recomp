
undefined4 FUN_0026ef70(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = 0;
  iVar1 = *(int *)(iRam0064e998 + 0xc);
  piVar2 = (int *)(iRam0064e998 + 0xc);
  do {
    if (iVar1 == 0) {
LAB_0026efa8:
      return *(undefined4 *)(param_2 * 0xc + iRam0064e998 + 0xc);
    }
    if (iVar1 == param_1) {
      param_2 = param_2 + iVar3;
      goto LAB_0026efa8;
    }
    piVar2 = piVar2 + 3;
    iVar1 = *piVar2;
    iVar3 = iVar3 + 1;
  } while( true );
}

