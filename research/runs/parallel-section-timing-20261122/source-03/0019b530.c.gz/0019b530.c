
undefined4 FUN_0019b530(uint param_1,int param_2,undefined8 param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined8 uVar4;
  int *piVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  
  if (piRam0069f10c == (int *)0x0) {
LAB_0019b590:
    piVar5 = (int *)0x0;
  }
  else {
    iVar3 = *piRam0069f10c;
    piVar5 = piRam0069f10c;
    while (iVar3 != (int)param_1 >> 0x10) {
      piVar5 = (int *)piVar5[6];
      if (piVar5 == (int *)0x0) goto LAB_0019b590;
      iVar3 = *piVar5;
    }
  }
  if (piVar5 != (int *)0x0) {
    puVar8 = (uint *)piVar5[5];
    uVar6 = 0;
    if (piVar5[2] != 0) {
      do {
        if (*puVar8 == (param_1 & 0xffff)) {
          piVar5 = (int *)puVar8[4];
          goto LAB_0019b5d8;
        }
        uVar6 = uVar6 + 1;
        puVar8 = puVar8 + 6;
      } while (uVar6 < (uint)piVar5[2]);
    }
  }
  puVar8 = (uint *)0x0;
  piVar5 = piRam00000010;
LAB_0019b5d8:
  if (piVar5 != (int *)0x0) {
    if ((param_2 == *piVar5) && (piVar5[6] == 0)) {
      return 1;
    }
    if (piRam0069f10c == (int *)0x0) {
LAB_0019b628:
      piVar5 = (int *)0x0;
    }
    else {
      iVar3 = *piRam0069f10c;
      piVar5 = piRam0069f10c;
      while (iVar3 != (int)param_1 >> 0x10) {
        piVar5 = (int *)piVar5[6];
        if (piVar5 == (int *)0x0) goto LAB_0019b628;
        iVar3 = *piVar5;
      }
    }
    if (piVar5 != (int *)0x0) {
      puVar7 = (uint *)piVar5[5];
      uVar6 = 0;
      if (piVar5[2] != 0) {
        do {
          if (*puVar7 == (param_1 & 0xffff)) {
            piVar5 = (int *)puVar7[4];
            goto joined_r0x0019b670;
          }
          uVar6 = uVar6 + 1;
          puVar7 = puVar7 + 6;
        } while (uVar6 < (uint)piVar5[2]);
      }
    }
    puVar7 = (uint *)0x0;
    piVar5 = piRam00000010;
joined_r0x0019b670:
    while (piVar5 != (int *)0x0) {
      piVar1 = (int *)piVar5[6];
      FUN_0019cfa0(piVar5,puVar7);
      piVar5 = piVar1;
    }
    uVar6 = puVar7[4];
    while (uVar6 != 0) {
      uVar2 = *(uint *)(uVar6 + 0x18);
      thunk_FUN_004293f0(uVar6,0,0);
      uVar6 = uVar2;
    }
    puVar7[4] = 0;
    puVar7[3] = 0;
  }
  uVar4 = FUN_00429d20(uGpffffab88,0x34,3,0,0,0);
  FUN_001dba60(uVar4,0,0x34);
  FUN_0019c010(puVar8,uVar4);
  FUN_003ddc90(uVar4,puVar8,param_1,param_2,1,param_3);
  return 1;
}

