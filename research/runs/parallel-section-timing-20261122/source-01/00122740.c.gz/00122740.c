
undefined8 FUN_00122740(undefined8 param_1,undefined4 *param_2)

{
  int iVar1;
  uint uVar2;
  long lVar3;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  
  FUN_002218d0();
  FUN_00294520();
  FUN_003ddc00(*param_2);
  FUN_003343e0();
  FUN_00310690();
  FUN_00182670();
  FUN_00186150(3);
  FUN_0016aa10();
  FUN_002df470(0);
  FUN_003dda60();
  FUN_00212b30();
  FUN_00182e50();
  if (((bRam00660084 & 1) == 0) || (iGpffff9dd4 == 0)) {
    lVar3 = FUN_002207e0();
    if (lVar3 == 0x32) {
      uGpffff9da0 = 0x3f555555;
      uGpffff9da4 = 0x3f99999a;
      uGpffff9d9c = 0x3f8c378c;
    }
    else {
      uGpffff9da4 = 0x3f800000;
      uGpffff9da0 = 0x3f800000;
      uGpffff9d9c = 0x3f800000;
    }
  }
  else {
    uGpffff9da4 = 0x3f800000;
    uGpffff9da0 = 0x3f800000;
    uGpffff9d9c = 0x3f800000;
  }
  iVar1 = FUN_002207e0();
  fGpffff9db8 = 1000.0 / (float)iVar1;
  FUN_00185ec0();
  FUN_00185d60(0);
  FUN_001303f0();
  FUN_0019c4c0();
  FUN_0026f1e0();
  FUN_00163210();
  lVar3 = FUN_00225db0();
  if (lVar3 != 0) {
    FUN_002e06e0();
    FUN_00219050();
    lVar3 = FUN_00221c90(1);
    if ((lVar3 != 0) && (lVar3 = FUN_00171b10(), lVar3 != 0)) {
      uStack_20 = uGpffffab50;
      uStack_1c = uGpffffab50;
      uStack_18 = uGpffffab50;
      uStack_14 = uGpffffab50;
      uStack_10 = uGpffffab50;
      FUN_003432d0(&uStack_20);
      FUN_00164130();
      FUN_0012d7e0();
      FUN_002460b0();
      FUN_00295660();
      FUN_0012a4f0(0);
      FUN_0019a630();
      lVar3 = FUN_00127260();
      if (lVar3 != 0) {
        FUN_001861b0();
        FUN_0019a5e0();
        uGpffff9d90 = 1;
        thunk_FUN_002e8e10();
        uVar2 = FUN_001860d0(3);
        FUN_0026d8e0(uVar2 & 0xffff | Count << 0x10);
        FUN_0012dcc0(0x2001,0x20,0x18e100,0,0);
        iGpffff9dc4 = 0;
        iGpffff9dc0 = 0;
        uGpffff9db0 = FUN_001ddf40(0x65b890);
        do {
          iGpffff9dc4 = iGpffff9dc4 + 1;
          if ((-1 < (long)((ulong)bRam00660081 << 0x3a)) && (iGpffff9e74 == 0)) {
            iGpffff9dc0 = iGpffff9dc0 + 1;
          }
          FUN_0012d930();
          FUN_002214d0();
          FUN_00161e90();
          FUN_003429e0();
          FUN_001830a0();
          lVar3 = FUN_002807b0();
          if ((lVar3 == 0) && (lVar3 = FUN_0027b310(), lVar3 != 0)) {
            FUN_0027b1d0();
          }
          if (-1 < (long)((ulong)bRam00660081 << 0x3a)) {
            FUN_001637d0();
          }
          FUN_00210570();
          FUN_0012e4e0();
          FUN_00328ce0();
          FUN_003152c0();
          if (iGpffff9de4 != 0) {
            FUN_00126940();
          }
          FUN_001304f0();
        } while( true );
      }
    }
  }
  return 0;
}

