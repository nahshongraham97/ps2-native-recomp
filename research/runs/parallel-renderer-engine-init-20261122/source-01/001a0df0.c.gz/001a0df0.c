
void FUN_001a0df0(undefined4 param_1)

{
  uGpffff8368 = param_1;
  return;
}

