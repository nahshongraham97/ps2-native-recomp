
undefined4 FUN_001a40b0(void)

{
  pcRam0069f380 = FUN_001de4b0;
  pcRam0069f384 = FUN_001e3520;
  pcRam0069f388 = FUN_001dec58;
  pcRam0069f38c = FUN_001df378;
  pcRam0069f390 = FUN_001de850;
  pcRam0069f394 = FUN_001df010;
  puRam0069f398 = &LAB_001a4070;
  puRam0069f39c = &LAB_001a4030;
  pcRam0069f3a0 = FUN_001df5a0;
  pcRam0069f3a4 = FUN_001deb10;
  pcRam0069f3a8 = FUN_001df1c0;
  puRam0069f3ac = &LAB_001a3ed0;
  pcRam0069f3b0 = FUN_001dee00;
  puRam0069f3b4 = &LAB_001a3f90;
  puRam0069f3b8 = &LAB_001a3fe0;
  pcRam0069f3bc = FUN_001e04a8;
  pcRam0069f3c0 = FUN_001de528;
  return 1;
}

