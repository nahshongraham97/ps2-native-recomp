
undefined4 FUN_0019f5b0(void)

{
  pcRam0069f354 = FUN_0019f560;
  puRam0069f358 = &LAB_001d9668;
  pcRam0069f35c = FUN_001d8f30;
  pcRam0069f360 = FUN_001d9718;
  pcRam0069f364 = FUN_001da698;
  puRam0069f368 = &LAB_001d9158;
  pcRam0069f36c = FUN_001d96c8;
  puRam0069f370 = &LAB_001d9038;
  pcRam0069f374 = FUN_001d9c68;
  pcRam0069f378 = FUN_001d9048;
  pcRam0069f37c = FUN_001da140;
  return 1;
}

