
undefined8 FUN_001a1340(undefined8 param_1,uint param_2)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  byte *pbVar5;
  uint uVar6;
  int iVar7;
  
  piVar3 = (int *)param_1;
  uVar1 = piVar3[2];
  piVar2 = (int *)piVar3[4];
  while( true ) {
    while( true ) {
      if (piVar2 == piVar3 + 4) {
        return 0;
      }
      uVar6 = (int)piVar2 + uVar1 + 8;
      if (uVar6 <= param_2) break;
      piVar2 = (int *)*piVar2;
    }
    if (param_2 <= uVar6 + piVar3[1] * *piVar3) break;
    piVar2 = (int *)*piVar2;
  }
  uVar6 = (int)(param_2 - uVar6) / *piVar3;
  uVar4 = uVar6 >> 3;
  pbVar5 = (byte *)((int)piVar2 + uVar4 + 8);
  *pbVar5 = *pbVar5 & ~(byte)(0x80 >> (uVar6 + uVar4 * -8 & 0x1f));
  if ((piVar3[6] & 2U) == 0) {
    return param_1;
  }
  iVar7 = 0;
  uVar6 = 0;
  if (uVar1 != 0) {
    if (8 < uVar1) {
      do {
        pbVar5 = (byte *)((int)piVar2 + uVar6 + 8);
        uVar6 = uVar6 + 8;
        iVar7 = iVar7 + (uint)*pbVar5 + (uint)pbVar5[1] + (uint)pbVar5[2] + (uint)pbVar5[3] +
                (uint)pbVar5[4] + (uint)pbVar5[5] + (uint)pbVar5[6] + (uint)pbVar5[7];
      } while (uVar6 < uVar1 - 8);
    }
    for (; uVar6 < uVar1; uVar6 = uVar6 + 1) {
      iVar7 = iVar7 + (uint)*(byte *)((int)piVar2 + uVar6 + 8);
    }
  }
  if (iVar7 != 0) {
    return param_1;
  }
  *(int *)piVar2[1] = *piVar2;
  *(int *)(*piVar2 + 4) = piVar2[1];
  (*pcRam0069f3c8)();
  return param_1;
}

