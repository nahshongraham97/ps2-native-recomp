
bool FUN_001b72b0(void)

{
  bool bVar1;
  long lVar2;
  
  lVar2 = FUN_001a8610(0x5c,0x40c,0,0,0);
  uRam0064e650 = (undefined4)lVar2;
  if (lVar2 < 0) {
    bVar1 = false;
  }
  else {
    lVar2 = FUN_001a6510(0xd8,0x40c,0,0,0);
    uRam0064e64c = (undefined4)lVar2;
    bVar1 = false;
    if (-1 < lVar2) {
      lVar2 = FUN_001a9c50(0,0x110,0,0,0);
      uRam0064e648 = (undefined4)lVar2;
      bVar1 = false;
      if (-1 < lVar2) {
        lVar2 = FUN_001a4bd0(0x110,0x1b0710,0,0x1b0790);
        uRam0064e648 = (undefined4)lVar2;
        bVar1 = -1 < lVar2;
      }
    }
  }
  return bVar1;
}

