
bool FUN_001a2f40(void)

{
  long lVar1;
  
  lVar1 = thunk_FUN_001a0e00(0x3c,uGpffff8380,4,uGpffff8384,0x69f200,0x40000);
  uGpffffa3b8 = (int)lVar1;
  if (lVar1 != 0) {
    uGpffffa3b4 = 0;
  }
  return lVar1 != 0;
}

