
bool FUN_001a66a0(void)

{
  ulong uVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  ulong uVar9;
  ulong uVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  ulong uVar14;
  ulong uVar15;
  
  uVar1 = FUN_001a6a20(8,0x40f,0x19f410,0x19f440);
  uVar2 = FUN_001a6a20(0x18,0x401,0x1a3af0,0x1a3ad0);
  uVar3 = FUN_001a6a20(0,0x40d,0x19f3d0,0x19f3f0);
  uVar4 = FUN_001a6a20(0x18,0x402,0x1a0160,0x1a00f0);
  uVar5 = FUN_001a6a20(4,0x403,0x1a6f40,0x1a6fd0);
  uVar6 = FUN_001a6a20(4,0x404,0x1a2270,0x1a22f0);
  uVar7 = FUN_001a6a20(4,0x405,0x1a61d0,0x1a6160);
  uVar8 = FUN_001a6a20(0x220,0x406,0x1a7de0,0x1a8000);
  uVar9 = FUN_001a6a20(100,0x407,0x1a89c0,0x1a8950);
  uVar10 = FUN_001a6a20(0x34,0x408,0x1a9e80,0x1a9cc0);
  uVar11 = FUN_001a6a20(0x60,0x409,0x1c4a80,0x1c4ac0);
  uVar12 = FUN_001a6a20(4,0x412,0x1a3df0,0x1a3e70);
  uVar13 = FUN_001c4af0();
  uVar14 = FUN_001a6a20(0x7c,0x40a,0x1c49b0,0x1c4950);
  uVar15 = FUN_001a6a20(0x28,0x40b,0x1a1b30,0x1a1b90);
  return -1 < (long)(uVar1 | uVar2 | uVar3 | uVar4 | uVar5 | uVar6 | uVar7 | uVar8 | uVar9 | uVar10
                     | uVar11 | uVar12 | uVar13 | uVar14 | uVar15);
}

