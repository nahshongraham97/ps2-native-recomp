
undefined4 FUN_001a2fd0(void)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  if (iGpffffa3b8 != 0) {
    FUN_001a1650(iGpffffa3b8,0x1a2f90,iGpffffa3b8);
    if (pcRam0069f3d4 != FUN_001a1180) {
      uVar4 = 0;
      if (uGpffffa3b4 != 0) {
        iVar2 = 0;
        do {
          iVar1 = *(int *)(*(int *)(iGpffffa3b0 + iVar2) + 0x10);
          puVar3 = (undefined4 *)0x0;
          if (iVar1 != 0) {
            puVar3 = *(undefined4 **)(iVar1 + 0x38);
            do {
              iVar1 = *(int *)(iVar1 + 0x30);
              (*pcRam0069f3d8)(0);
            } while (iVar1 != 0);
          }
          if ((puVar3 != (undefined4 *)0x0) && (puVar3[4] != 0)) {
            *puVar3 = puVar3[1];
            puVar3[4] = 0;
            puVar3[5] = 0;
          }
          uVar4 = uVar4 + 1;
          iVar2 = iVar2 + 4;
        } while (uVar4 < uGpffffa3b4);
      }
      if (iGpffffa3b0 != 0) {
        (*pcRam0069f3c8)();
        iGpffffa3b0 = 0;
      }
    }
    FUN_001a10a0(iGpffffa3b8);
    iGpffffa3b8 = 0;
  }
  return 1;
}

