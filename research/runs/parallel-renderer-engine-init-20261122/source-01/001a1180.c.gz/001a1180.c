
uint FUN_001a1180(int *param_1)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  long lVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  uint uVar10;
  int *piVar11;
  
  uVar3 = 0;
  uVar2 = param_1[2];
  piVar11 = (int *)param_1[4];
  do {
    if ((piVar11 == param_1 + 4) || (uVar3 != 0)) {
      if (uVar3 == 0) {
        lVar4 = (*pcRam0069f3c4)(param_1[3] + uVar2 + 7 + param_1[1] * *param_1);
        if (lVar4 == 0) {
          uVar3 = 0;
        }
        else {
          piVar11 = (int *)lVar4;
          FUN_001dba60(piVar11 + 2,0,uVar2);
          *piVar11 = param_1[4];
          piVar11[1] = (int)(param_1 + 4);
          *(int **)(param_1[4] + 4) = piVar11;
          param_1[4] = (int)piVar11;
          *(undefined1 *)(piVar11 + 2) = 0x80;
          uVar3 = (int)piVar11 + param_1[3] + uVar2 + 7 & ~(param_1[3] - 1U);
        }
      }
      return uVar3;
    }
    iVar6 = param_1[1];
    uVar7 = 0;
    if (uVar2 != 0) {
      iVar5 = 0;
      do {
        pbVar9 = (byte *)((int)piVar11 + uVar7 + 8);
        bVar1 = *pbVar9;
        if (bVar1 == 0xff) {
          iVar6 = iVar6 + -8;
        }
        else {
          uVar10 = 0;
          while( true ) {
            if ((7 < uVar10) || (iVar6 == 0)) goto LAB_001a1260;
            uVar8 = 0x80 >> (uVar10 & 0x1f);
            if (((uint)bVar1 & uVar8 & 0xff) == 0) break;
            uVar10 = uVar10 + 1;
            iVar6 = iVar6 + -1;
          }
          *pbVar9 = (byte)uVar8 | bVar1;
          uVar3 = ((int)piVar11 + param_1[3] + uVar2 + 7 & ~(param_1[3] - 1U)) +
                  *param_1 * (iVar5 + uVar10);
        }
LAB_001a1260:
        if (uVar3 != 0) break;
        uVar7 = uVar7 + 1;
        iVar5 = iVar5 + 8;
      } while (uVar7 < uVar2);
    }
    piVar11 = (int *)*piVar11;
  } while( true );
}

