
int FUN_002c03c0(undefined4 param_1,byte param_2,undefined4 param_3)

{
  int iVar1;
  bool bVar2;
  
  bVar2 = (param_2 & 1) == 0;
  if (bVar2) {
    DAT_00835484 = &UNK_002c4020;
    DAT_00835488 = FUN_002c4180;
  }
  else {
    DAT_00835484 = &UNK_002bf950;
    DAT_00835488 = (code *)&UNK_002bf960;
  }
  FUN_002c3f50(bVar2);
  DAT_00835494 = param_3;
  if (DAT_00835490 == 0) {
    iVar1 = FUN_002ccec0();
    if (iVar1 != 0) {
      iVar1 = FUN_002c46c0(param_1);
      if (iVar1 != 0) {
        iVar1 = FUN_002c0dd0();
        if (iVar1 != 0) {
          iVar1 = FUN_002c27b0();
          if (iVar1 != 0) {
            iVar1 = FUN_002c0020();
            if (iVar1 != 0) {
              iVar1 = thunk_FUN_002c84d0();
              if (iVar1 != 0) {
                DAT_00835490 = 1;
                return iVar1;
              }
            }
            FUN_002c2830();
          }
          FUN_002c0e50();
        }
        thunk_FUN_002c4460();
      }
      FUN_002ccf70();
    }
  }
  return 0;
}

