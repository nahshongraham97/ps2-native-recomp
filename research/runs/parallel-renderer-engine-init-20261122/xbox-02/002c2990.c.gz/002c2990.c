
int FUN_002c2990(int *param_1,int param_2,int param_3,undefined1 *param_4,undefined1 *param_5,
                undefined1 *param_6)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  undefined4 local_8;
  undefined4 local_4;
  
  if (DAT_005c7440 != 0) {
    iVar1 = FUN_002bfa60();
    if (iVar1 == 0) {
      if (DAT_00835484 != (code *)&UNK_002c4020) {
        uVar2 = 0;
        if (DAT_005c7448 != 0) {
          do {
            if (param_1 == (int *)DAT_005c7444[uVar2]) break;
            uVar2 = uVar2 + 1;
          } while (uVar2 < DAT_005c7448);
        }
        if (DAT_005c7448 == uVar2) {
          puVar3 = (undefined4 *)(*DAT_00835474)(DAT_005c7448 * 4 + 4,0x40000);
          uVar2 = DAT_005c7448;
          uVar7 = 0;
          if (DAT_005c7444 != (undefined4 *)0x0) {
            if (DAT_005c7448 != 0) {
              iVar1 = (int)DAT_005c7444 - (int)puVar3;
              puVar4 = puVar3;
              uVar6 = DAT_005c7448;
              do {
                *puVar4 = *(undefined4 *)(iVar1 + (int)puVar4);
                puVar4 = puVar4 + 1;
                uVar6 = uVar6 - 1;
                uVar7 = uVar2;
              } while (uVar6 != 0);
            }
            (*DAT_00835478)(DAT_005c7444);
          }
          DAT_005c7448 = DAT_005c7448 + 1;
          puVar3[uVar7] = param_1;
          DAT_005c7444 = puVar3;
        }
      }
      for (piVar5 = (int *)param_1[4]; piVar5 != (int *)0x0; piVar5 = (int *)piVar5[0xc]) {
        if (piVar5[2] == param_3) {
          local_8 = 1;
          local_4 = FUN_002c2400(0x80000017);
          FUN_002c2370(&local_8);
          return *piVar5;
        }
      }
      iVar1 = (param_2 + 3U & 0xfffffffc) + *param_1;
      if (((param_1[2] == 0) || (iVar1 <= param_1[2])) &&
         (piVar5 = (int *)(*DAT_00835484)(DAT_005c7440,0x40000), piVar5 != (int *)0x0)) {
        *piVar5 = *param_1;
        *param_1 = iVar1;
        piVar5[2] = param_3;
        piVar5[1] = param_2;
        piVar5[3] = 0;
        piVar5[4] = 0;
        piVar5[5] = 0;
        piVar5[6] = 0;
        piVar5[7] = 0;
        if (param_4 == (undefined1 *)0x0) {
          param_4 = &LAB_002c28f0;
        }
        piVar5[8] = (int)param_4;
        if (param_5 == (undefined1 *)0x0) {
          param_5 = &LAB_002c2900;
        }
        piVar5[9] = (int)param_5;
        if (param_6 == (undefined1 *)0x0) {
          param_6 = &LAB_002c2910;
        }
        piVar5[10] = (int)param_6;
        piVar5[0xb] = 0;
        piVar5[0xc] = 0;
        piVar5[0xd] = 0;
        piVar5[0xe] = (int)param_1;
        if (param_1[4] == 0) {
          param_1[4] = (int)piVar5;
          param_1[5] = (int)piVar5;
          return *piVar5;
        }
        *(int **)(param_1[5] + 0x30) = piVar5;
        piVar5[0xd] = param_1[5];
        param_1[5] = (int)piVar5;
        return *piVar5;
      }
      return -1;
    }
    local_8 = 1;
    local_4 = FUN_002c2400(0x80000017);
    FUN_002c2370(&local_8);
  }
  return -1;
}

