
void FUN_001a6a20(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  FUN_001a3190(0x5a3680,param_1,param_2,param_3,param_4,0);
  return;
}

