
void FUN_001a4bd0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  FUN_001a2af0(0x5a3720,param_1,param_2,param_3,param_4);
  return;
}

