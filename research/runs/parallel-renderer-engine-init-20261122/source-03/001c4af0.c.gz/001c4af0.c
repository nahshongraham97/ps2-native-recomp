
undefined4 FUN_001c4af0(void)

{
  return 1;
}

