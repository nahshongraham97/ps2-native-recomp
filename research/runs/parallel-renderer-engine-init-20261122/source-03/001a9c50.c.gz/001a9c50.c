
void FUN_001a9c50(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5)

{
  FUN_001a3190(0x5a3720,param_1,param_2,param_3,param_4,param_5);
  return;
}

