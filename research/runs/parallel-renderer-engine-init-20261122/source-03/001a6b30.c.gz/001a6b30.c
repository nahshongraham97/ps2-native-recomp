
undefined4 FUN_001a6b30(void)

{
  undefined4 uVar1;
  long lVar2;
  
  lVar2 = FUN_001a68f0(0x69f2a0,2,0,0,0);
  if (lVar2 == 0) {
    uVar1 = 0;
  }
  else {
    lVar2 = FUN_001a3480(0x5a3680,0x69f290);
    if (lVar2 == 0) {
      FUN_001a68f0(0x69f2a0,3,0,0,0);
      uVar1 = 0;
    }
    else {
      FUN_001a8380(uRam0069f2a0);
      FUN_001a68f0(0x69f2a0,0x11,0,0,0);
      uRam0069f3e0 = 3;
      uVar1 = 1;
    }
  }
  return uVar1;
}

