
bool FUN_001a6c30(long param_1)

{
  bool bVar1;
  long lVar2;
  long lVar3;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  if (iRam0069f3e0 == 1) {
    if (param_1 == 0) {
      uStack_8 = 1;
      uStack_4 = FUN_0019f510(0xffffffff80000016);
      FUN_0019f460(&uStack_8);
      bVar1 = false;
    }
    else {
      lVar2 = FUN_001ba110();
      if (lVar2 == 0) {
        bVar1 = false;
      }
      else {
        FUN_001a68f0(lVar2,4,0x69f2a0,0x69f3c4,0);
        lVar3 = FUN_001a68f0(lVar2,0,0,param_1,0);
        bVar1 = lVar3 != 0;
        if (bVar1) {
          FUN_001a68f0(lVar2,0xb,0x69f2d8,0,0x1d);
          iRam0064e4c8 = iRam0064e4c8 + 1;
          iRam0069f3e0 = 2;
        }
      }
    }
  }
  else {
    uStack_10 = 1;
    uStack_c = FUN_0019f510(0xffffffff80000001);
    FUN_0019f460(&uStack_10);
    bVar1 = false;
  }
  return bVar1;
}

