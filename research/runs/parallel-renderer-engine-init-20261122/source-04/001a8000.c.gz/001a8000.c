
undefined8 FUN_001a8000(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  if (*(int *)(iGpffffa3e8 + 0x69f4a0) != 0) {
    (*pcRam0069f3c8)();
    *(undefined4 *)(iGpffffa3e8 + 0x69f4a0) = 0;
    *(undefined4 *)(iGpffffa3e8 + 0x69f4a4) = 0;
  }
  if (*(int *)(iGpffffa3e8 + 0x69f294) != 0) {
    (*pcRam0069f3c8)();
    *(undefined4 *)(iGpffffa3e8 + 0x69f294) = 0;
    *(undefined4 *)(iGpffffa3e8 + 0x69f298) = 0;
  }
  iVar2 = iGpffffa3e8 + 0x69f290;
  if (*(int *)(iGpffffa3e8 + 0x69f4ac) != 0) {
    uVar1 = *(undefined4 *)(*(int *)(iGpffffa3e8 + 0x69f4ac) + 0x30);
    while( true ) {
      *(undefined4 *)(iVar2 + 0x21c) = uVar1;
      (*pcRam0069f3d8)(*(undefined4 *)(iGpffffa3e8 + 0x69f4a8));
      iVar2 = iGpffffa3e8 + 0x69f290;
      if (*(int *)(iGpffffa3e8 + 0x69f4ac) == 0) break;
      uVar1 = *(undefined4 *)(*(int *)(iGpffffa3e8 + 0x69f4ac) + 0x30);
    }
  }
  if (*(int *)(iVar2 + 0x218) != 0) {
    FUN_001a10a0();
    *(undefined4 *)(iGpffffa3e8 + 0x69f4a8) = 0;
  }
  if (*(int *)(iGpffffa3e8 + 0x69f290) != 0) {
    FUN_001a10a0();
    *(undefined4 *)(iGpffffa3e8 + 0x69f290) = 0;
  }
  iGpffffa3ec = iGpffffa3ec + -1;
  return param_1;
}

