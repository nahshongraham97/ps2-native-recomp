
undefined8 FUN_001a6160(undefined8 param_1)

{
  if (*(int *)(iRam0064e4c0 + 0x69f290) != 0) {
    FUN_001a10a0();
    *(undefined4 *)(iRam0064e4c0 + 0x69f290) = 0;
  }
  iRam0064e4c4 = iRam0064e4c4 + -1;
  return param_1;
}

