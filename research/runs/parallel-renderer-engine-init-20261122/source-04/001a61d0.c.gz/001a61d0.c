
undefined8 FUN_001a61d0(undefined8 param_1,int param_2)

{
  long lVar1;
  
  iRam0064e4c0 = param_2;
  lVar1 = thunk_FUN_001a0e00(DAT_005a3630,DAT_0064c484,0x10,DAT_0064c488,0x69f260,0x40005);
  *(int *)(iRam0064e4c0 + 0x69f290) = (int)lVar1;
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else {
    iRam0064e4c4 = iRam0064e4c4 + 1;
  }
  return param_1;
}

