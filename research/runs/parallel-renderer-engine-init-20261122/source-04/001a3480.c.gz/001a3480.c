
undefined8 FUN_001a3480(undefined8 param_1,undefined8 param_2)

{
  undefined4 uVar1;
  long lVar2;
  undefined4 *puVar3;
  
  puVar3 = *(undefined4 **)((int)param_1 + 0x10);
  if (puVar3 != (undefined4 *)0x0) {
    uVar1 = *puVar3;
    while (lVar2 = (*(code *)puVar3[8])(param_2,uVar1,puVar3[1]), lVar2 != 0) {
      puVar3 = (undefined4 *)puVar3[0xc];
      if (puVar3 == (undefined4 *)0x0) {
        return param_1;
      }
      uVar1 = *puVar3;
    }
    puVar3 = (undefined4 *)puVar3[0xd];
    if (puVar3 != (undefined4 *)0x0) {
      uVar1 = *puVar3;
      while( true ) {
        (*(code *)puVar3[9])(param_2,uVar1,puVar3[1]);
        puVar3 = (undefined4 *)puVar3[0xd];
        if (puVar3 == (undefined4 *)0x0) break;
        uVar1 = *puVar3;
      }
    }
    param_1 = 0;
  }
  return param_1;
}

