
undefined8 FUN_001a22f0(undefined8 param_1)

{
  if (*(int *)(iGpffffa3a8 + 0x69f290) != 0) {
    FUN_001a10a0();
  }
  iGpffffa3ac = iGpffffa3ac + -1;
  return param_1;
}

