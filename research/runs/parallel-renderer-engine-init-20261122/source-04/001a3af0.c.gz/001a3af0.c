
undefined8 FUN_001a3af0(undefined8 param_1,int param_2)

{
  iGpffffa3c0 = param_2;
  *(undefined1 **)(param_2 + 0x69f298) = &LAB_001a36c0;
  *(undefined1 **)(param_2 + 0x69f29c) = &LAB_001a3600;
  *(undefined1 **)(param_2 + 0x69f2a0) = &LAB_001a3800;
  *(undefined1 **)(param_2 + 0x69f2a4) = &LAB_001a3760;
  iGpffffa3c4 = iGpffffa3c4 + 1;
  return param_1;
}

