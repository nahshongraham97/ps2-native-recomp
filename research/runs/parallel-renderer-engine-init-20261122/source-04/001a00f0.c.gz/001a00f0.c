
undefined8 FUN_001a00f0(undefined8 param_1)

{
  if (*(int *)(iRam0064e478 + 0x69f290) != 0) {
    FUN_001a10a0();
    *(undefined4 *)(iRam0064e478 + 0x69f290) = 0;
  }
  iRam0064e47c = iRam0064e47c + -1;
  return param_1;
}

