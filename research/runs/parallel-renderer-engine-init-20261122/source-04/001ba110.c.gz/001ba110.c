
undefined * FUN_001ba110(void)

{
  return &DAT_005a4130;
}

