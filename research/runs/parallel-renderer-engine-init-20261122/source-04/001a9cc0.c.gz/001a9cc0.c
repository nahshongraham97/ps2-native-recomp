
undefined8 FUN_001a9cc0(undefined8 param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  
  if (*(int *)(iGpffffa400 + 0x69f2b4) != 0) {
    (*pcRam0069f3c8)();
    *(undefined4 *)(iGpffffa400 + 0x69f2b4) = 0;
    *(undefined2 *)(iGpffffa400 + 0x69f2b8) = 0;
  }
  piVar2 = piGpffffa3f8;
  piVar5 = (int *)(iGpffffa400 + 0x69f290);
  if (((*(int *)(iGpffffa400 + 0x69f298) != 0) && (*(int *)(iGpffffa400 + 0x69f29c) != 0)) &&
     (piVar4 = (int *)*piVar5, piVar4 != piVar5)) {
    piVar3 = (int *)*piVar4;
    while (piVar1 = piVar3, piVar4 + -4 != piGpffffa3f8) {
      if (piVar1 == piVar5) goto LAB_001a9df8;
      piVar3 = (int *)*piVar1;
      piVar4 = piVar1;
    }
    if (*(int **)(iGpffffa400 + 0x69f2a0) == piGpffffa3f8) {
      *(undefined4 *)(iGpffffa400 + 0x69f2a0) = 0;
    }
    FUN_001a96a0(piGpffffa3f8,0x1a97e0,0);
    FUN_001a3520(0x5a3740,piVar2);
    *(int *)piVar2[5] = piVar2[4];
    *(int *)(piVar2[4] + 4) = piVar2[5];
    (*pcRam0069f3d8)(*(undefined4 *)(iGpffffa400 + 0x69f29c),piVar2);
    piGpffffa3f8 = (int *)0x0;
    piVar5 = (int *)(iGpffffa400 + 0x69f290);
  }
LAB_001a9df8:
  if (piVar5[2] != 0) {
    FUN_001a10a0();
    *(undefined4 *)(iGpffffa400 + 0x69f298) = 0;
  }
  if (*(int *)(iGpffffa400 + 0x69f29c) != 0) {
    FUN_001a10a0();
    *(undefined4 *)(iGpffffa400 + 0x69f29c) = 0;
  }
  iGpffffa404 = iGpffffa404 + -1;
  return param_1;
}

