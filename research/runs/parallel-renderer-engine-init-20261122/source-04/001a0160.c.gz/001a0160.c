
undefined8 FUN_001a0160(undefined8 param_1,int param_2)

{
  int iVar1;
  long lVar2;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  iRam0064e478 = param_2;
  lVar2 = thunk_FUN_001a0e00(0x40,DAT_0064c450,0x10,DAT_0064c454,0x69f170,0x4000d);
  iVar1 = iRam0064e478;
  *(int *)(iRam0064e478 + 0x69f290) = (int)lVar2;
  if (lVar2 == 0) {
    param_1 = 0;
  }
  else {
    *(undefined4 *)(iVar1 + 0x69f294) = 0x20000;
    *(undefined1 **)(iVar1 + 0x69f298) = &LAB_0019f680;
    uStack_10 = DAT_005a3600;
    uStack_8 = DAT_005a3608;
    FUN_001a0210(&uStack_10);
    iRam0064e47c = iRam0064e47c + 1;
  }
  return param_1;
}

