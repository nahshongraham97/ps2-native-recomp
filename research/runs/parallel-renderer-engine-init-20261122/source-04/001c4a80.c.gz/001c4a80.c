
undefined8 FUN_001c4a80(undefined8 param_1,undefined4 param_2)

{
  long lVar1;
  
  uRam0064e6d0 = param_2;
  lVar1 = FUN_001c4c10();
  if (lVar1 == 0) {
    param_1 = 0;
  }
  return param_1;
}

