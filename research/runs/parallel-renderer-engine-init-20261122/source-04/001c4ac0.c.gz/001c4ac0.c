
undefined8 FUN_001c4ac0(undefined8 param_1)

{
  FUN_001c4bb0();
  return param_1;
}

