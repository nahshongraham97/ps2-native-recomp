
undefined8 FUN_001a2270(undefined8 param_1,int param_2)

{
  long lVar1;
  
  iGpffffa3a8 = param_2;
  lVar1 = thunk_FUN_001a0e00(0x24,uGpffff836c,4,uGpffff8370,0x69f1d0,0x40404);
  *(int *)(iGpffffa3a8 + 0x69f290) = (int)lVar1;
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else {
    iGpffffa3ac = iGpffffa3ac + 1;
  }
  return param_1;
}

