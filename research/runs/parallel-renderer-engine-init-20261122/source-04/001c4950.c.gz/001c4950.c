
undefined8 FUN_001c4950(undefined8 param_1)

{
  FUN_001c9030(iRam0064e6c8 + 0x69f2b0);
  FUN_001c9010(iRam0064e6c8 + 0x69f2ac);
  iRam0064e6cc = iRam0064e6cc + -1;
  return param_1;
}

