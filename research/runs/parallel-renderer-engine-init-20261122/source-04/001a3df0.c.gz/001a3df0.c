
undefined8 FUN_001a3df0(undefined8 param_1,int param_2)

{
  long lVar1;
  
  iGpffffa3c8 = param_2;
  lVar1 = thunk_FUN_001a0e00(0x21,uGpffff8388,4,uGpffff838c,0x69f230,0x40412);
  *(int *)(iGpffffa3c8 + 0x69f290) = (int)lVar1;
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else {
    iGpffffa3cc = iGpffffa3cc + 1;
  }
  return param_1;
}

