
undefined8 FUN_001c49b0(undefined8 param_1,int param_2)

{
  long lVar1;
  long lVar2;
  
  iRam0064e6c4 = param_2 + 0x69f290;
  iRam0064e6cc = iRam0064e6cc + 1;
  iRam0064e6c8 = param_2;
  FUN_001dba60(iRam0064e6c4,0,0x7c);
  lVar1 = FUN_001c9020(iRam0064e6c8 + 0x69f2ac);
  lVar2 = 0;
  if (lVar1 != 0) {
    lVar2 = FUN_001c9040(iRam0064e6c8 + 0x69f2b0);
  }
  if (lVar2 == 0) {
    FUN_001c9030(iRam0064e6c8 + 0x69f2b0);
    FUN_001c9010(iRam0064e6c8 + 0x69f2ac);
    param_1 = 0;
    iRam0064e6cc = iRam0064e6cc + -1;
  }
  return param_1;
}

