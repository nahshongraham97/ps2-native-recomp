
undefined8 FUN_001a6f40(undefined8 param_1,int param_2)

{
  long lVar1;
  
  iRam0064e4d0 = param_2;
  lVar1 = thunk_FUN_001a0e00(DAT_005a36c0,DAT_0064c48c,0x10,DAT_0064c490,0x6a3290,0x4000e);
  *(int *)(iRam0064e4d0 + 0x69f290) = (int)lVar1;
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else {
    uRam0069f350 = 0x69f34c;
    uRam0069f34c = 0x69f34c;
    iRam0064e4d4 = iRam0064e4d4 + 1;
  }
  return param_1;
}

