
undefined8 FUN_001a3e70(undefined8 param_1)

{
  if (*(int *)(iGpffffa3c8 + 0x69f290) != 0) {
    FUN_001a10a0();
  }
  iGpffffa3cc = iGpffffa3cc + -1;
  return param_1;
}

