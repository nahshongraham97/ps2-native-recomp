
undefined8 FUN_001a9e80(undefined8 param_1,int param_2)

{
  long lVar1;
  int iVar2;
  undefined1 *puVar3;
  
  iGpffffa400 = param_2;
  lVar1 = thunk_FUN_001a0e00(DAT_005a3720,uGpffff83c0,4,uGpffff83c4,0x6a3380,0x40006);
  *(int *)(iGpffffa400 + 0x69f298) = (int)lVar1;
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else {
    lVar1 = thunk_FUN_001a0e00(DAT_005a3740,uGpffff83c8,4,uGpffff83cc,0x6a3350,0x40408);
    iVar2 = iGpffffa400 + 0x69f290;
    *(int *)(iGpffffa400 + 0x69f29c) = (int)lVar1;
    if (lVar1 == 0) {
      FUN_001a10a0(*(undefined4 *)(iGpffffa400 + 0x69f298));
      param_1 = 0;
      *(undefined4 *)(iGpffffa400 + 0x69f298) = 0;
    }
    else {
      *(int *)iVar2 = iVar2;
      *(int *)(iGpffffa400 + 0x69f294) = iVar2;
      iGpffffa404 = iGpffffa404 + 1;
      lVar1 = (*pcRam0069f3d4)(*(undefined4 *)(iGpffffa400 + 0x69f29c),0x30016);
      if (lVar1 == 0) {
        lVar1 = 0;
      }
      else {
        puVar3 = (undefined1 *)lVar1;
        *puVar3 = 6;
        puVar3[1] = 0;
        puVar3[2] = 0;
        puVar3[3] = 0;
        *(undefined4 *)(puVar3 + 4) = 0;
        *(undefined4 *)(puVar3 + 0x10) = *(undefined4 *)(iGpffffa400 + 0x69f290);
        *(int *)(puVar3 + 0x14) = iGpffffa400 + 0x69f290;
        *(undefined1 **)(*(int *)(iGpffffa400 + 0x69f290) + 4) = puVar3 + 0x10;
        *(undefined1 **)(iGpffffa400 + 0x69f290) = puVar3 + 0x10;
        *(undefined1 **)(puVar3 + 8) = puVar3 + 8;
        *(undefined1 **)(puVar3 + 0xc) = puVar3 + 8;
        FUN_001a3480(0x5a3740,lVar1);
      }
      uGpffffa3f8 = (undefined4)lVar1;
      *(undefined4 *)(iGpffffa400 + 0x69f2a0) = uGpffffa3f8;
      if (lVar1 == 0) {
        FUN_001a10a0(*(undefined4 *)(iGpffffa400 + 0x69f29c));
        *(undefined4 *)(iGpffffa400 + 0x69f29c) = 0;
        FUN_001a10a0(*(undefined4 *)(iGpffffa400 + 0x69f298));
        param_1 = 0;
        *(undefined4 *)(iGpffffa400 + 0x69f298) = 0;
      }
      else {
        *(undefined4 *)(iGpffffa400 + 0x69f2ac) = 0;
        *(undefined4 *)(iGpffffa400 + 0x69f2b0) = 0;
        *(code **)(iGpffffa400 + 0x69f2a8) = FUN_001a93b0;
        *(undefined1 **)(iGpffffa400 + 0x69f2a4) = &LAB_001a92c0;
        *(undefined1 **)(iGpffffa400 + 0x69f2bc) = &LAB_001a92d0;
        *(code **)(iGpffffa400 + 0x69f2c0) = FUN_001a9200;
        *(undefined4 *)(iGpffffa400 + 0x69f2b4) = 0;
        *(undefined2 *)(iGpffffa400 + 0x69f2b8) = 0;
      }
    }
  }
  return param_1;
}

