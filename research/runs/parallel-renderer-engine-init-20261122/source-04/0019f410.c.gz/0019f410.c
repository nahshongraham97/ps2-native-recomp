
undefined8 FUN_0019f410(undefined8 param_1,int param_2)

{
  iGpffffa380 = param_2;
  *(undefined4 *)(param_2 + 0x69f290) = 0;
  *(undefined4 *)(param_2 + 0x69f294) = 0x80000000;
  iGpffffa384 = iGpffffa384 + 1;
  return param_1;
}

