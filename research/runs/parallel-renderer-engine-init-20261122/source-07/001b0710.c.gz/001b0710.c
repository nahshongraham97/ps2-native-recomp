
undefined8 FUN_001b0710(undefined8 param_1,long param_2,long param_3)

{
  long lVar1;
  undefined2 auStack_4 [2];
  
  if (param_2 == 4) {
    if (param_3 == 0) {
      return 0;
    }
    if (*(int *)param_3 != 0) {
      lVar1 = FUN_0019f380(param_1,auStack_4);
      if (lVar1 == 0) {
        return 0;
      }
      *(undefined2 *)(*(int *)param_3 + iRam0064e650 + 0x14) = auStack_4[0];
      return param_1;
    }
  }
  return 0;
}

