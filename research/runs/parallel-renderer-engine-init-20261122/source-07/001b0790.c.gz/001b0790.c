
undefined4 FUN_001b0790(long param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if ((param_1 != 0) && (*(int *)param_1 != 0)) {
    uVar1 = 4;
  }
  return uVar1;
}

