
undefined4
FUN_001a2af0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  
  puVar3 = *(undefined4 **)(param_1 + 0x10);
  if (puVar3 != (undefined4 *)0x0) {
    iVar1 = puVar3[2];
    while ((iVar1 != param_2 && (puVar3 = (undefined4 *)puVar3[0xc], puVar3 != (undefined4 *)0x0)))
    {
      iVar1 = puVar3[2];
    }
  }
  if (puVar3 == (undefined4 *)0x0) {
    uVar2 = 0xffffffff;
  }
  else {
    puVar3[3] = param_3;
    puVar3[4] = param_4;
    puVar3[5] = param_5;
    uVar2 = *puVar3;
  }
  return uVar2;
}

