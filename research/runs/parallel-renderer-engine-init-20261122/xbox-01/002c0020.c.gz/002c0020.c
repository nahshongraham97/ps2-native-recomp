
bool FUN_002c0020(void)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  
  uVar1 = FUN_002c2990(&DAT_005a6788,8,0x40f,&LAB_002c2330,&LAB_002c2360,0);
  uVar2 = FUN_002c2990(&DAT_005a6788,0x18,0x401,&LAB_002c1c90,&LAB_002c1c80,0);
  uVar3 = FUN_002c2990(&DAT_005a6788,0,0x40d,&LAB_002cdaa0,&LAB_002cdab0,0);
  uVar4 = FUN_002c2990(&DAT_005a6788,0x18,0x402,&LAB_002beea0,&LAB_002be230,0);
  uVar5 = FUN_002c2990(&DAT_005a6788,4,0x403,&LAB_002bef60,&LAB_002befc0,0);
  uVar6 = FUN_002c2990(&DAT_005a6788,4,0x404,&LAB_002b8de0,&LAB_002b8e30,0);
  uVar7 = FUN_002c2990(&DAT_005a6788,4,0x405,&LAB_002bb510,&LAB_002bb4b0,0);
  uVar8 = FUN_002c2990(&DAT_005a6788,0x220,0x406,&LAB_002bce10,&LAB_002bbc00,0);
  uVar9 = FUN_002c2990(&DAT_005a6788,100,0x407,&LAB_002b9f70,&LAB_002b9f10,0);
  uVar10 = FUN_002c2990(&DAT_005a6788,0x34,0x408,&LAB_002b8c70,&LAB_002b8ba0,0);
  uVar11 = FUN_002c2990(&DAT_005a6788,0x60,0x409,&LAB_002c9840,&LAB_002c9860,0);
  uVar12 = FUN_002c2990(&DAT_005a6788,4,0x412,&LAB_002cd7d0,&LAB_002cd820,0);
  uVar13 = FUN_002c9870();
  uVar14 = FUN_002c2990(&DAT_005a6788,0x74,0x40a,&LAB_002c0cf0,&LAB_002c0cb0,0);
  uVar15 = FUN_002c2990(&DAT_005a6788,0x28,0x40b,&LAB_002c2d40,&LAB_002c30a0,0);
  return -1 < (int)(uVar15 | uVar14 |
                   uVar13 | uVar12 | uVar11 | uVar10 | uVar9 | uVar8 | uVar7 | uVar6 | uVar5 | uVar4
                   | uVar3 | uVar2 | uVar1);
}

