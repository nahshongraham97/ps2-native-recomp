
long FUN_001a3fe0(long param_1)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = (char *)param_1;
  if ((param_1 != 0) && (*pcVar2 != '\0')) {
    cVar1 = *pcVar2;
    while( true ) {
      if (('@' < cVar1) && (cVar1 < '[')) {
        *pcVar2 = cVar1 + ' ';
      }
      pcVar2 = pcVar2 + 1;
      if (*pcVar2 == '\0') break;
      cVar1 = *pcVar2;
    }
  }
  return param_1;
}

