
void FUN_001de4b0(undefined1 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  undefined1 *apuStack_a0 [2];
  undefined4 uStack_98;
  undefined2 uStack_94;
  undefined1 *puStack_90;
  undefined4 uStack_8c;
  undefined *puStack_4c;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  undefined8 uStack_8;
  
  uStack_94 = 0x208;
  uStack_8c = 0x7fffffff;
  puStack_4c = PTR_DAT_005a4b68;
  uStack_98 = 0x7fffffff;
  apuStack_a0[0] = param_1;
  puStack_90 = param_1;
  uStack_30 = param_3;
  uStack_28 = param_4;
  uStack_20 = param_5;
  uStack_18 = param_6;
  uStack_10 = param_7;
  uStack_8 = param_8;
  FUN_001e0e40(apuStack_a0,param_2,&uStack_30);
  *apuStack_a0[0] = 0;
  return;
}

