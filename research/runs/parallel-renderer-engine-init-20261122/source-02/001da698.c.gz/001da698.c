
int FUN_001da698(undefined4 param_1,long param_2,int param_3,undefined8 param_4)

{
  int iVar1;
  long lVar2;
  undefined4 *puStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined4 uStack_30;
  int iStack_2c;
  
  puStack_40 = &uStack_30;
  iVar1 = param_3 * (int)param_2;
  uStack_3c = 1;
  iStack_38 = iVar1;
  uStack_30 = param_1;
  iStack_2c = iVar1;
  lVar2 = FUN_001da240(param_4,&puStack_40);
  if (lVar2 != 0) {
    if (param_2 == 0) {
      trap(7);
    }
    param_3 = (iVar1 - iStack_38) / (int)param_2;
  }
  return param_3;
}

