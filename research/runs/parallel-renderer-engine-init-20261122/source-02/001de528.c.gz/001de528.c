
void FUN_001de528(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined2 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined1 *puStack_80;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  undefined *puStack_4c;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  undefined8 uStack_8;
  
  uStack_94 = 4;
  uStack_a0 = param_1;
  uStack_90 = param_1;
  uStack_30 = param_3;
  uStack_28 = param_4;
  uStack_20 = param_5;
  uStack_18 = param_6;
  uStack_10 = param_7;
  uStack_8 = param_8;
  uStack_9c = FUN_001dee00();
  uStack_70 = 0;
  uStack_5c = 0;
  puStack_80 = &LAB_001de520;
  puStack_4c = PTR_DAT_005a4b68;
  uStack_8c = uStack_9c;
  FUN_001e2750(PTR_DAT_005a4b68,&uStack_a0,param_2,&uStack_30);
  return;
}

