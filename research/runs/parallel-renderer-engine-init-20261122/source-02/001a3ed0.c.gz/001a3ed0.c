
int FUN_001a3ed0(char *param_1,char *param_2)

{
  char cVar1;
  char cVar2;
  
  if ((param_1 != (char *)0x0) && (param_2 != (char *)0x0)) {
    cVar2 = *param_1;
    while( true ) {
      cVar1 = *param_2;
      if (('@' < cVar2) && (cVar2 < '[')) {
        cVar2 = cVar2 + ' ';
      }
      if (('@' < cVar1) && (cVar1 < '[')) {
        cVar1 = cVar1 + ' ';
      }
      if (cVar2 != cVar1) {
        return (int)cVar2 - (int)cVar1;
      }
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
      if ((cVar2 == '\0') || (cVar1 == '\0')) break;
      cVar2 = *param_1;
    }
    if (cVar2 != cVar1) {
      return (int)cVar2 - (int)cVar1;
    }
  }
  return 0;
}

