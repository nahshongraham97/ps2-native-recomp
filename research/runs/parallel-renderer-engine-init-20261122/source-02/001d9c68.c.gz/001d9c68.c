
undefined4 FUN_001d9c68(undefined8 param_1,ulong param_2,long param_3)

{
  int iVar1;
  bool bVar2;
  undefined *puVar3;
  undefined4 uVar4;
  long lVar5;
  long lVar6;
  int *piVar7;
  int *piVar8;
  ushort uVar9;
  int iVar10;
  undefined4 *puVar11;
  uint uVar12;
  long unaff_s3;
  code *pcVar13;
  ulong uVar14;
  undefined1 auStack_c0 [4];
  uint uStack_bc;
  long lStack_b0;
  
  puVar3 = PTR_DAT_005a4b68;
  piVar7 = (int *)param_1;
  puVar11 = (undefined4 *)piVar7[0x15];
  if ((undefined4 *)piVar7[0x15] == (undefined4 *)0x0) {
    piVar7[0x15] = (int)PTR_DAT_005a4b68;
    puVar11 = (undefined4 *)puVar3;
  }
  if (puVar11[0xe] == 0) {
    FUN_001d9468(puVar11);
    puVar11 = (undefined4 *)piVar7[0x15];
    uVar12 = piVar7[3];
  }
  else {
    uVar12 = piVar7[3];
  }
  if ((uVar12 & 0x108) == 0x108) {
    FUN_001d9048(param_1);
    pcVar13 = (code *)piVar7[10];
  }
  else {
    pcVar13 = (code *)piVar7[10];
  }
  if (pcVar13 == (code *)0x0) {
    uVar4 = 0x1d;
    goto LAB_001d9cfc;
  }
  if (param_3 == 1) {
    FUN_001d9048(param_1);
    uVar9 = *(ushort *)(piVar7 + 3);
    if ((uVar9 & 0x1000) == 0) {
      unaff_s3 = (*pcVar13)(piVar7[7],0,1);
      if (unaff_s3 == -1) {
        return 0xffffffff;
      }
      uVar9 = *(ushort *)(piVar7 + 3);
    }
    else {
      unaff_s3 = (long)piVar7[0x14];
    }
    if ((uVar9 & 4) == 0) {
      iVar10 = piVar7[4];
      if (((uVar9 & 8) != 0) && (*piVar7 != 0)) {
        unaff_s3 = unaff_s3 + (*piVar7 - iVar10);
      }
    }
    else {
      unaff_s3 = unaff_s3 - piVar7[1];
      if (piVar7[0xc] == 0) {
        iVar10 = piVar7[4];
      }
      else {
        iVar10 = piVar7[4];
        unaff_s3 = unaff_s3 - piVar7[0xf];
      }
    }
    param_2 = param_2 + unaff_s3;
    param_3 = 0;
    bVar2 = true;
  }
  else {
    if (param_3 < 2) {
      if (param_3 != 0) {
        uVar4 = 0x16;
LAB_001d9cfc:
        *puVar11 = uVar4;
        return 0xffffffff;
      }
    }
    else if (param_3 != 2) {
      uVar4 = 0x16;
      goto LAB_001d9cfc;
    }
    iVar10 = piVar7[4];
    bVar2 = false;
  }
  if (iVar10 == 0) {
    FUN_001daa40(param_1);
    uVar9 = *(ushort *)(piVar7 + 3);
  }
  else {
    uVar9 = *(ushort *)(piVar7 + 3);
  }
  if ((uVar9 & 0x81a) != 0) goto LAB_001d9dc4;
  if ((uVar9 & 0x400) == 0) {
    uVar9 = uVar9 | 0x800;
    if ((pcVar13 == FUN_001de728) && (-1 < *(short *)((int)piVar7 + 0xe))) {
      lVar5 = FUN_001da0e8(puVar11,*(short *)((int)piVar7 + 0xe),auStack_c0);
      if (lVar5 == 0) {
        if ((uStack_bc & 0xf000) == 0x8000) {
          piVar7[0x13] = 0x400;
          *(ushort *)(piVar7 + 3) = *(ushort *)(piVar7 + 3) | 0x400;
          goto LAB_001d9e44;
        }
        uVar9 = *(ushort *)(piVar7 + 3);
      }
      else {
        uVar9 = *(ushort *)(piVar7 + 3);
      }
      uVar9 = uVar9 | 0x800;
    }
    *(ushort *)(piVar7 + 3) = uVar9;
    goto LAB_001d9dc4;
  }
LAB_001d9e44:
  uVar14 = param_2;
  if (param_3 != 0) {
    lVar5 = FUN_001da0e8(puVar11,*(undefined2 *)((int)piVar7 + 0xe),auStack_c0);
    if (lVar5 != 0) goto LAB_001d9dc4;
    uVar14 = lStack_b0 + param_2;
  }
  uVar9 = *(ushort *)(piVar7 + 3);
  if (bVar2) {
    lVar5 = (long)piVar7[1];
    piVar8 = (int *)piVar7[0xc];
LAB_001d9e98:
    if (piVar8 == (int *)0x0) {
      iVar10 = *piVar7;
      goto LAB_001d9fec;
    }
    iVar1 = piVar7[4];
    uVar12 = (piVar7[0xe] - iVar1) + piVar7[0xf];
    lVar5 = (lVar5 + unaff_s3) - (ulong)(uint)(piVar7[0xe] - iVar1);
  }
  else {
    if ((uVar9 & 0x1000) == 0) {
      lVar6 = (*pcVar13)(piVar7[7],0,1);
      if (lVar6 == -1) goto LAB_001d9dc4;
      uVar9 = *(ushort *)(piVar7 + 3);
    }
    else {
      lVar6 = (long)piVar7[0x14];
    }
    lVar5 = (long)piVar7[1];
    piVar8 = (int *)piVar7[0xc];
    unaff_s3 = lVar6 - lVar5;
    if (piVar8 != (int *)0x0) {
      unaff_s3 = unaff_s3 - piVar7[0xf];
      goto LAB_001d9e98;
    }
    iVar10 = *piVar7;
LAB_001d9fec:
    iVar1 = piVar7[4];
    uVar12 = (iVar10 - iVar1) + (int)lVar5;
    lVar5 = unaff_s3 - (ulong)(uint)(iVar10 - iVar1);
  }
  if ((uVar9 & 0x2000) == 0) {
    if ((long)uVar14 < lVar5) {
      iVar10 = piVar7[0x13];
    }
    else {
      iVar10 = (int)uVar14 - (int)lVar5;
      if ((long)uVar14 < (long)(lVar5 + (ulong)uVar12)) {
        piVar7[1] = uVar12 - iVar10;
        *piVar7 = iVar1 + iVar10;
        if (piVar8 != (int *)0x0) {
          if (piVar8 == piVar7 + 0x10) {
            piVar7[0xc] = 0;
          }
          else {
            FUN_001d9828(piVar7[0x15]);
            uVar9 = *(ushort *)(piVar7 + 3);
            piVar7[0xc] = 0;
          }
        }
        *(ushort *)(piVar7 + 3) = uVar9 & 0xffdf;
        return 0;
      }
      iVar10 = piVar7[0x13];
    }
  }
  else {
    iVar10 = piVar7[0x13];
  }
  lVar5 = (*pcVar13)(piVar7[7],(long)-iVar10 & uVar14,0);
  if (lVar5 == -1) {
LAB_001d9dc4:
    lVar5 = FUN_001d9048(param_1);
    uVar4 = 0xffffffff;
    if (lVar5 == 0) {
      lVar5 = (*pcVar13)(piVar7[7],param_2,param_3);
      if (lVar5 == -1) {
        uVar4 = 0xffffffff;
      }
      else {
        if ((int *)piVar7[0xc] != (int *)0x0) {
          if ((int *)piVar7[0xc] == piVar7 + 0x10) {
            piVar7[0xc] = 0;
          }
          else {
            FUN_001d9828(piVar7[0x15]);
            piVar7[0xc] = 0;
          }
        }
        uVar4 = 0;
        piVar7[1] = 0;
        *(ushort *)(piVar7 + 3) = *(ushort *)(piVar7 + 3) & 0xffdf;
        *piVar7 = piVar7[4];
      }
    }
    return uVar4;
  }
  piVar7[1] = 0;
  *piVar7 = piVar7[4];
  if ((int *)piVar7[0xc] != (int *)0x0) {
    if ((int *)piVar7[0xc] == piVar7 + 0x10) {
      piVar7[0xc] = 0;
    }
    else {
      FUN_001d9828(piVar7[0x15]);
      piVar7[0xc] = 0;
    }
  }
  uVar12 = (int)uVar14 - (int)((long)-iVar10 & uVar14);
  *(ushort *)(piVar7 + 3) = *(ushort *)(piVar7 + 3) & 0xffdf;
  if (uVar12 != 0) {
    lVar5 = FUN_001ddd48(param_1);
    if ((lVar5 != 0) || ((uint)piVar7[1] < uVar12)) goto LAB_001d9dc4;
    piVar7[1] = piVar7[1] - uVar12;
    *piVar7 = *piVar7 + uVar12;
  }
  return 0;
}

