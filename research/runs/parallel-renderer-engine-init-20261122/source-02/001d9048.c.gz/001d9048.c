
undefined8 FUN_001d9048(long param_1)

{
  ushort uVar1;
  undefined *puVar2;
  code *pcVar3;
  undefined8 uVar4;
  long lVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  
  puVar2 = PTR_DAT_005a4b68;
  if (param_1 == 0) {
    uVar4 = FUN_001da608(PTR_DAT_005a4b68,0x1d9048);
    return uVar4;
  }
  piVar6 = (int *)param_1;
  if (piVar6[0x15] == 0) {
    piVar6[0x15] = (int)PTR_DAT_005a4b68;
    iVar9 = *(int *)(puVar2 + 0x38);
  }
  else {
    iVar9 = *(int *)(piVar6[0x15] + 0x38);
  }
  if (iVar9 == 0) {
    FUN_001d9468();
    uVar1 = *(ushort *)(piVar6 + 3);
  }
  else {
    uVar1 = *(ushort *)(piVar6 + 3);
  }
  if ((uVar1 & 8) != 0) {
    iVar9 = piVar6[4];
    if (iVar9 != 0) {
      iVar8 = *piVar6;
      iVar7 = 0;
      *piVar6 = iVar9;
      iVar8 = iVar8 - iVar9;
      if ((uVar1 & 3) == 0) {
        iVar7 = piVar6[5];
      }
      piVar6[2] = iVar7;
      if (0 < iVar8) {
        pcVar3 = (code *)piVar6[9];
        while( true ) {
          lVar5 = (*pcVar3)(piVar6[7],iVar9,iVar8);
          iVar8 = iVar8 - (int)lVar5;
          iVar9 = iVar9 + (int)lVar5;
          if (lVar5 < 1) {
            *(ushort *)(piVar6 + 3) = *(ushort *)(piVar6 + 3) | 0x40;
            return 0xffffffffffffffff;
          }
          if (iVar8 < 1) break;
          pcVar3 = (code *)piVar6[9];
        }
      }
    }
  }
  return 0;
}

