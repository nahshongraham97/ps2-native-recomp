
int FUN_001d9718(int param_1,long param_2,int param_3,undefined8 param_4)

{
  uint uVar1;
  int iVar2;
  long lVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  
  piVar4 = (int *)param_4;
  uVar1 = param_3 * (int)param_2;
  iVar2 = 0;
  if (uVar1 != 0) {
    uVar5 = piVar4[1];
    if ((int)uVar5 < 0) {
      piVar4[1] = 0;
      uVar5 = 0;
    }
    uVar6 = uVar1;
    if (uVar5 < uVar1) {
      iVar2 = *piVar4;
      while( true ) {
        uVar6 = uVar6 - uVar5;
        FUN_001db8a8(param_1,iVar2,uVar5);
        param_1 = param_1 + uVar5;
        *piVar4 = *piVar4 + uVar5;
        lVar3 = FUN_001ddd48(param_4);
        if (lVar3 != 0) break;
        uVar5 = piVar4[1];
        if (uVar6 <= uVar5) goto LAB_001d97c0;
        iVar2 = *piVar4;
      }
      iVar2 = (int)(uVar1 - uVar6) / (int)param_2;
      if (param_2 == 0) {
        trap(7);
      }
    }
    else {
LAB_001d97c0:
      FUN_001db8a8(param_1,*piVar4,uVar6);
      piVar4[1] = piVar4[1] - uVar6;
      *piVar4 = *piVar4 + uVar6;
      iVar2 = param_3;
    }
  }
  return iVar2;
}

