
void FUN_001d96c8(undefined4 param_1,undefined8 param_2)

{
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uStack_20 = param_1;
  uStack_28 = FUN_001dee00();
  puStack_30 = &uStack_20;
  uStack_2c = 1;
  uStack_1c = uStack_28;
  FUN_001da240(param_2,&puStack_30);
  return;
}

