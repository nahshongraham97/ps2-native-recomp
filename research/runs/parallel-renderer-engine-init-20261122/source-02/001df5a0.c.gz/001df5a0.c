
char * FUN_001df5a0(char *param_1,char *param_2)

{
  int iVar1;
  char *pcVar2;
  char *pcVar3;
  
  if (*param_1 == '\0') {
    if (*param_2 != '\0') {
      param_1 = (char *)0x0;
    }
    return param_1;
  }
  iVar1 = 0;
  while( true ) {
    do {
      pcVar3 = param_2 + iVar1;
      pcVar2 = param_1 + iVar1;
      if (*pcVar3 == '\0') {
        return param_1;
      }
      iVar1 = iVar1 + 1;
    } while (*pcVar3 == *pcVar2);
    param_1 = param_1 + 1;
    if (*param_1 == '\0') break;
    iVar1 = 0;
  }
  return (char *)0x0;
}

