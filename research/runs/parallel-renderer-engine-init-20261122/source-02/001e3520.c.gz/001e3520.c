
void FUN_001e3520(undefined1 *param_1)

{
  undefined1 *apuStack_70 [2];
  undefined4 uStack_68;
  undefined2 uStack_64;
  undefined1 *puStack_60;
  undefined4 uStack_5c;
  undefined *puStack_1c;
  
  uStack_5c = 0x7fffffff;
  uStack_64 = 0x208;
  puStack_1c = PTR_DAT_005a4b68;
  uStack_68 = 0x7fffffff;
  apuStack_70[0] = param_1;
  puStack_60 = param_1;
  FUN_001e0e40(apuStack_70);
  *apuStack_70[0] = 0;
  return;
}

