
long FUN_001da140(undefined8 param_1)

{
  ushort uVar1;
  undefined *puVar2;
  long lVar3;
  int *piVar4;
  int iVar5;
  
  puVar2 = PTR_DAT_005a4b68;
  piVar4 = (int *)param_1;
  if (piVar4[0x15] == 0) {
    piVar4[0x15] = (int)PTR_DAT_005a4b68;
    iVar5 = *(int *)(puVar2 + 0x38);
  }
  else {
    iVar5 = *(int *)(piVar4[0x15] + 0x38);
  }
  if (iVar5 == 0) {
    FUN_001d9468();
    iVar5 = piVar4[10];
  }
  else {
    iVar5 = piVar4[10];
  }
  if (iVar5 == 0) {
    lVar3 = -1;
    *(undefined4 *)piVar4[0x15] = 0x1d;
  }
  else {
    FUN_001d9048(param_1);
    uVar1 = *(ushort *)(piVar4 + 3);
    if ((uVar1 & 0x1000) == 0) {
      lVar3 = (*(code *)piVar4[10])(piVar4[7],0,1);
      if (lVar3 == -1) {
        return -1;
      }
      uVar1 = *(ushort *)(piVar4 + 3);
    }
    else {
      lVar3 = (long)piVar4[0x14];
    }
    if ((uVar1 & 4) == 0) {
      if (((uVar1 & 8) != 0) && (*piVar4 != 0)) {
        lVar3 = lVar3 + (*piVar4 - piVar4[4]);
      }
    }
    else {
      lVar3 = lVar3 - piVar4[1];
      if (piVar4[0xc] != 0) {
        lVar3 = lVar3 - piVar4[0xf];
      }
    }
  }
  return lVar3;
}

