
char * FUN_001e04a8(char *param_1,char *param_2)

{
  char *pcVar1;
  char *pcVar2;
  undefined4 *puVar3;
  char cVar4;
  char *pcVar5;
  char cVar6;
  
  puVar3 = (undefined4 *)(PTR_DAT_005a4b68 + 0x5c);
  if (param_1 == (char *)0x0) {
    param_1 = (char *)*puVar3;
    if (param_1 == (char *)0x0) {
      return (char *)0x0;
    }
    cVar4 = *param_1;
  }
  else {
    cVar4 = *param_1;
  }
  do {
    cVar6 = *param_2;
    pcVar1 = param_1 + 1;
    pcVar5 = param_2;
    while( true ) {
      if (cVar6 == '\0') {
        if (cVar4 == '\0') {
          *puVar3 = 0;
          return (char *)0x0;
        }
        cVar4 = *pcVar1;
        do {
          pcVar2 = pcVar1 + 1;
          cVar6 = *param_2;
          pcVar5 = param_2;
          while( true ) {
            pcVar5 = pcVar5 + 1;
            if (cVar6 == cVar4) {
              if (cVar6 == '\0') {
                pcVar2 = (char *)0x0;
              }
              else {
                *pcVar1 = '\0';
              }
              *puVar3 = pcVar2;
              return param_1;
            }
            if (cVar6 == '\0') break;
            cVar6 = *pcVar5;
          }
          cVar4 = *pcVar2;
          pcVar1 = pcVar2;
        } while( true );
      }
      pcVar5 = pcVar5 + 1;
      if (cVar4 == cVar6) break;
      cVar6 = *pcVar5;
    }
    cVar4 = *pcVar1;
    param_1 = pcVar1;
  } while( true );
}

