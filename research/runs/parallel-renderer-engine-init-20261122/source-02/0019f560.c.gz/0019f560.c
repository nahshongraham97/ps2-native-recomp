
bool FUN_0019f560(undefined8 param_1)

{
  long lVar1;
  
  lVar1 = (*pcRam0069f358)(param_1,0x64c44c);
  if (lVar1 != 0) {
    (*pcRam0069f35c)(lVar1);
  }
  return lVar1 != 0;
}

