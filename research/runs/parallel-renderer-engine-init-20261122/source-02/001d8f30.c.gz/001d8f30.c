
undefined8 FUN_001d8f30(long param_1)

{
  ushort uVar1;
  undefined *puVar2;
  undefined8 uVar3;
  long lVar4;
  int iVar5;
  int iVar6;
  
  puVar2 = PTR_DAT_005a4b68;
  uVar3 = 0;
  if (param_1 != 0) {
    iVar5 = (int)param_1;
    if (*(int *)(iVar5 + 0x54) == 0) {
      *(undefined **)(iVar5 + 0x54) = PTR_DAT_005a4b68;
      iVar6 = *(int *)(puVar2 + 0x38);
    }
    else {
      iVar6 = *(int *)(*(int *)(iVar5 + 0x54) + 0x38);
    }
    if (iVar6 == 0) {
      FUN_001d9468();
      uVar1 = *(ushort *)(iVar5 + 0xc);
    }
    else {
      uVar1 = *(ushort *)(iVar5 + 0xc);
    }
    uVar3 = 0;
    if (uVar1 != 0) {
      uVar3 = 0;
      if ((uVar1 & 8) != 0) {
        uVar3 = FUN_001d9048(param_1);
      }
      if (*(code **)(iVar5 + 0x2c) == (code *)0x0) {
        uVar1 = *(ushort *)(iVar5 + 0xc);
      }
      else {
        lVar4 = (**(code **)(iVar5 + 0x2c))(*(undefined4 *)(iVar5 + 0x1c));
        if (lVar4 < 0) {
          uVar3 = 0xffffffffffffffff;
        }
        uVar1 = *(ushort *)(iVar5 + 0xc);
      }
      if ((uVar1 & 0x80) == 0) {
        iVar6 = *(int *)(iVar5 + 0x30);
      }
      else {
        FUN_001d9828(*(undefined4 *)(iVar5 + 0x54),*(undefined4 *)(iVar5 + 0x10));
        iVar6 = *(int *)(iVar5 + 0x30);
      }
      if (iVar6 != 0) {
        if (iVar6 == iVar5 + 0x40) {
          *(undefined4 *)(iVar5 + 0x30) = 0;
        }
        else {
          FUN_001d9828(*(undefined4 *)(iVar5 + 0x54));
          *(undefined4 *)(iVar5 + 0x30) = 0;
        }
      }
      if (*(int *)(iVar5 + 0x44) == 0) {
        *(undefined2 *)(iVar5 + 0xc) = 0;
      }
      else {
        FUN_001d9828(*(undefined4 *)(iVar5 + 0x54));
        *(undefined4 *)(iVar5 + 0x44) = 0;
        *(undefined2 *)(iVar5 + 0xc) = 0;
      }
    }
  }
  return uVar3;
}

