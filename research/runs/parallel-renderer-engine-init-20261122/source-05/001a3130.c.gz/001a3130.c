
undefined8 FUN_001a3130(undefined8 param_1)

{
  return param_1;
}

