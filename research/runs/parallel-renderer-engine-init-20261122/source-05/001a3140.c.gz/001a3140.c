
undefined8 FUN_001a3140(undefined8 param_1)

{
  return param_1;
}

