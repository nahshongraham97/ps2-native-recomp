
undefined8 FUN_0019f460(undefined8 param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)param_1;
  piVar2 = (int *)(iRam0064e470 + 0x69f290);
  if ((*piVar2 == 0) && (*(int *)(iRam0064e470 + 0x69f294) == -0x80000000)) {
    if ((piVar1[1] & 0x80000000U) == 0) {
      *piVar2 = *piVar1;
    }
    else {
      *piVar2 = 0;
    }
    *(int *)(iRam0064e470 + 0x69f294) = piVar1[1];
  }
  return param_1;
}

