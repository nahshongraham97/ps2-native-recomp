
undefined8 FUN_0019f4a0(undefined8 param_1,undefined4 *param_2)

{
  undefined4 in_v0_lo;
  
  *param_2 = 0;
  *param_2 = in_v0_lo;
  *(undefined4 *)(iGpffffa380 + 0x69f294) = *(undefined4 *)((int)param_1 + 4);
  return param_1;
}

