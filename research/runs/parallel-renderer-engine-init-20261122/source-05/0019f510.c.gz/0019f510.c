
undefined4 FUN_0019f510(undefined4 param_1)

{
  return param_1;
}

