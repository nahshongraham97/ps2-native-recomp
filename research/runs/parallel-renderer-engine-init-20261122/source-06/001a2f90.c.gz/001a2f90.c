
void FUN_001a2f90(undefined8 param_1,undefined8 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = (int)param_1;
  puVar1 = *(undefined4 **)(iVar2 + 0x38);
  if (puVar1[4] != 0) {
    *puVar1 = puVar1[1];
    *(undefined4 *)(*(int *)(iVar2 + 0x38) + 0x10) = 0;
    *(undefined4 *)(*(int *)(iVar2 + 0x38) + 0x14) = 0;
  }
                    /* WARNING: Could not recover jumptable at 0x001a2fc8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*pcRam0069f3d8)(param_2,param_1);
  return;
}

