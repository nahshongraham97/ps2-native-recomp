
undefined8 FUN_0019f4d0(undefined8 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(iRam0064e470 + 0x69f294);
  *(undefined4 *)param_1 = *(undefined4 *)(iRam0064e470 + 0x69f290);
  ((undefined4 *)param_1)[1] = uVar2;
  iVar1 = iRam0064e470;
  *(undefined4 *)(iRam0064e470 + 0x69f290) = 0;
  *(undefined4 *)(iVar1 + 0x69f294) = 0x80000000;
  return param_1;
}

