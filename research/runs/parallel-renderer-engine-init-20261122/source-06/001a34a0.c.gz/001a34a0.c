
void FUN_001a34a0(undefined8 param_1,undefined8 param_2)

{
  undefined4 uVar1;
  long lVar2;
  undefined4 *unaff_s0_lo;
  undefined4 *puVar3;
  
  uVar1 = *unaff_s0_lo;
  while( true ) {
    lVar2 = (*(code *)unaff_s0_lo[8])(param_2,uVar1,unaff_s0_lo[1]);
    if (lVar2 == 0) {
      puVar3 = (undefined4 *)unaff_s0_lo[0xd];
      if (puVar3 != (undefined4 *)0x0) {
        uVar1 = *puVar3;
        while( true ) {
          (*(code *)puVar3[9])(param_2,uVar1,puVar3[1]);
          puVar3 = (undefined4 *)puVar3[0xd];
          if (puVar3 == (undefined4 *)0x0) break;
          uVar1 = *puVar3;
        }
      }
      return;
    }
    unaff_s0_lo = (undefined4 *)unaff_s0_lo[0xc];
    if (unaff_s0_lo == (undefined4 *)0x0) break;
    uVar1 = *unaff_s0_lo;
  }
  return;
}

