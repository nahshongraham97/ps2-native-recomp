
undefined4 FUN_001a3170(undefined8 param_1,int param_2)

{
  undefined4 *in_v1_lo;
  
  while( true ) {
    if (in_v1_lo == (undefined4 *)0x0) {
      return 0xffffffff;
    }
    if (in_v1_lo[2] == param_2) break;
    in_v1_lo = (undefined4 *)in_v1_lo[0xc];
  }
  return *in_v1_lo;
}

