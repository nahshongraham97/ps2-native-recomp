
void FUN_0000bcc0(int param_1,int param_2,undefined2 param_3)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  
  bVar1 = *(byte *)(param_1 + 8);
  bVar2 = *(byte *)(param_1 + 9);
  bVar3 = *(byte *)(param_2 + 8);
  bVar4 = *(byte *)(param_2 + 9);
  *(undefined2 *)(param_1 + 0xe) = param_3;
  *(undefined2 *)(param_2 + 0xe) = param_3;
  if (*(char *)(param_1 + 10) == '\x01') {
    func_0x00000288((uint)bVar1 | (uint)bVar2 << 1 | 0x200,param_3);
    func_0x00000288((uint)bVar3 | (uint)bVar4 << 1 | 0x200,param_3);
  }
  return;
}

