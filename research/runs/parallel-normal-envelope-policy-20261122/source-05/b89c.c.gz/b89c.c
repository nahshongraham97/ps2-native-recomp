
void FUN_0000b89c(int *param_1)

{
  *param_1 = (int)piRam00028518;
  param_1[1] = 0x28518;
  *(int **)((int)piRam00028518 + 4) = param_1;
  piRam00028518 = param_1;
  return;
}

