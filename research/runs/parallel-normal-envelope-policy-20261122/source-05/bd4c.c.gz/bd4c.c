
void FUN_0000bd4c(int param_1,int param_2,int param_3)

{
  byte bVar1;
  byte bVar2;
  
  *(char *)(param_2 + 0xb) = (char)param_3;
  *(char *)(param_1 + 0xb) = (char)param_3;
  if (param_3 == 0) {
    bVar1 = *(byte *)(param_2 + 8);
    bVar2 = *(byte *)(param_2 + 9);
    func_0x000002a0((uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1 | 0x2140,0x5000
                   );
    func_0x000002a0((uint)bVar1 | (uint)bVar2 << 1 | 0x2140,0x5000);
  }
  return;
}

