
void FUN_0000c160(int param_1,int param_2)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = *(byte *)(param_2 + 8);
  bVar2 = *(byte *)(param_2 + 9);
  func_0x00000288((uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1 | 0x200,
                  *(undefined2 *)(param_1 + 0xe));
  func_0x00000288((uint)bVar1 | (uint)bVar2 << 1 | 0x200,*(undefined2 *)(param_2 + 0xe));
  *(undefined1 *)(param_1 + 10) = 1;
  *(undefined1 *)(param_2 + 10) = 1;
  return;
}

