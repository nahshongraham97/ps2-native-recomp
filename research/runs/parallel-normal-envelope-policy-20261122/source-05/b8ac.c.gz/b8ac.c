
void FUN_0000b8ac(int param_1)

{
  *(undefined2 *)(param_1 + 0xe) = 0x1000;
  *(undefined4 *)(param_1 + 0x10) = 0x5000;
  *(undefined4 *)(param_1 + 0x14) = 0x500f;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined1 *)(param_1 + 0xc) = 0;
  *(undefined1 *)(param_1 + 0xb) = 0;
  return;
}

