
void FUN_0000bc30(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  
  bVar1 = *(byte *)(param_2 + 8);
  bVar2 = *(byte *)(param_2 + 9);
  uVar3 = (uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1;
  func_0x00000288(uVar3,param_3);
  func_0x00000288(uVar3 | 0x100,0);
  uVar3 = (uint)bVar1 | (uint)bVar2 << 1;
  func_0x00000288(uVar3,0);
  func_0x00000288(uVar3 | 0x100,param_4);
  return;
}

