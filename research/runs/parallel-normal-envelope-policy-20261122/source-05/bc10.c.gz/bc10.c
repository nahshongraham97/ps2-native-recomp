
uint FUN_0000bc10(int param_1,undefined2 param_2)

{
  *(undefined2 *)(param_1 + 0xe) = param_2;
  return (uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1 | 0x200;
}

