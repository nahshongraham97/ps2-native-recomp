
void FUN_0000b258(int *param_1)

{
  *(int *)param_1[1] = *param_1;
  *(int *)(*param_1 + 4) = param_1[1];
  param_1[1] = 0;
  *param_1 = 0;
  return;
}

