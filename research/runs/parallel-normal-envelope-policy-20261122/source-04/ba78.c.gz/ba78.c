
void FUN_0000ba78(void)

{
  uint unaff_s0;
  
  if (unaff_s0 != 0) {
    if ((unaff_s0 < 0x28520) || (0x28d34 < unaff_s0)) {
      FUN_0000b780();
    }
    else if ((*(char *)(unaff_s0 + 10) != '\x04') && (*(char *)(unaff_s0 + 10) != '\0')) {
      func_0x000001dc(uRam000104a8);
      if (*(char *)(unaff_s0 + 10) != '\x03') {
        FUN_0000b780();
        func_0x0000bf3c();
      }
      func_0x000002a0((uint)*(byte *)(unaff_s0 + 8) | (uint)*(byte *)(unaff_s0 + 9) << 1 | 0x2040,
                      0x5000);
      func_0x000002a0((uint)*(byte *)(unaff_s0 + 8) | (uint)*(byte *)(unaff_s0 + 9) << 1 | 0x2140,
                      0x5000);
      *(undefined1 *)(unaff_s0 + 10) = 4;
      func_0x000001cc(uRam000104a8);
    }
  }
  return;
}

