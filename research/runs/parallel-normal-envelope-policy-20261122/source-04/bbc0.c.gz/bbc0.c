
void FUN_0000bbc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  
  uVar1 = (uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1;
  func_0x00000288(uVar1);
  func_0x00000288(uVar1 | 0x100,param_3);
  return;
}

