
int FUN_0000b780(int param_1)

{
  return (param_1 + -0x28520) / 0x2c;
}

