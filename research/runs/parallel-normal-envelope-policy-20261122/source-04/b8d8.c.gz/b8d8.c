
void FUN_0000b8d8(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  *param_1 = 0;
  *param_2 = 0;
  func_0x000001dc(uRam000104a8);
  iVar1 = func_0x0000b3a0();
  iVar2 = func_0x0000b3a0();
  if ((iVar1 != 0) && (iVar2 != 0)) {
    iVar3 = iVar1;
    if (*(char *)(iVar1 + 8) != *(char *)(iVar2 + 8)) {
      iVar3 = func_0x0000b3a0();
      if (iVar3 == 0) goto LAB_0000ba3c;
      if (*(char *)(iVar3 + 8) == *(char *)(iVar1 + 8)) {
        iVar2 = iVar3;
        iVar3 = iVar1;
      }
    }
    if (iVar3 != iVar2) {
      *param_1 = iVar3;
      *param_2 = iVar2;
      func_0x0000b258(iVar3);
      func_0x0000b258(iVar2);
      func_0x0000b8ac(iVar3);
      func_0x0000b8ac(iVar2);
      *(undefined1 *)(iVar3 + 10) = 3;
      *(undefined1 *)(iVar2 + 10) = 3;
      iRam00028504 = iRam00028504 + 2;
      iRam00028508 = iRam00028508 + -2;
      if (iRam0002850c < iRam00028504) {
        iRam0002850c = iRam00028504;
      }
      func_0x0000b89c(iVar3);
      func_0x0000b89c(iVar2);
      if (iRam000284fc == 0) {
        func_0x00000254(uRam000104ac);
        iRam000284fc = 1;
      }
    }
  }
LAB_0000ba3c:
  func_0x000001cc(uRam000104a8);
  return;
}

