
void FUN_0000c1e8(int param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = (uint)*(byte *)(param_1 + 8);
  uVar3 = (uint)*(byte *)(param_1 + 9);
  uVar2 = (uint)*(byte *)(param_2 + 8);
  uVar1 = (uint)*(byte *)(param_2 + 9);
  if ((*(char *)(param_1 + 10) != '\x03') || (*(char *)(param_2 + 10) != '\x03')) {
    func_0x00000288(uVar4 | uVar3 << 1 | 0x200,0);
    func_0x00000288(uVar2 | uVar1 << 1 | 0x200,0);
    if (uVar4 == uVar2) {
      func_0x00000290(uVar4 | 0x1600,1 << (uVar3 & 0x1f) | 1 << (uVar1 & 0x1f));
    }
    else {
      func_0x00000290(uVar4 | 0x1600,1 << (uVar3 & 0x1f));
      func_0x00000290(uVar2 | 0x1600,1 << (uVar1 & 0x1f));
    }
    *(undefined1 *)(param_1 + 10) = 3;
    *(undefined1 *)(param_2 + 10) = 3;
  }
  return;
}

