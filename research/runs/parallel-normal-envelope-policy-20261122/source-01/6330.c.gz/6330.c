
undefined4 FUN_00006330(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  func_0x0000a7d8(param_1 + 0x3ac);
  iVar1 = func_0x00005010(param_1,param_2);
  if (iVar1 < 0) {
    func_0x0000a7e4(param_1 + 0x3ac);
    uVar2 = 1;
  }
  else {
    FUN_00003fcc(param_1,*(undefined4 *)(param_2 + 8),param_2);
    if (param_3 == 1) {
      if (*(short *)(param_2 + 0x4a) == 2) {
        func_0x0000bdbc(*(undefined4 *)(param_2 + 0x2c));
        func_0x0000bdbc(*(undefined4 *)(param_2 + 0x30),1);
        iVar1 = *(int *)(*(int *)(param_2 + 0x14) + 4);
        func_0x0000bdfc(*(undefined4 *)(param_2 + 0x2c),iVar1,
                        iVar1 + *(int *)(*(int *)(param_2 + 0x14) + 8));
        iVar1 = *(int *)(*(int *)(param_2 + 0x18) + 4);
        func_0x0000bdfc(*(undefined4 *)(param_2 + 0x30),iVar1,
                        iVar1 + *(int *)(*(int *)(param_2 + 0x18) + 8));
        func_0x0000bfbc(*(undefined4 *)(param_2 + 0x2c),*(undefined4 *)(param_2 + 0x30));
      }
      else {
        func_0x0000bdbc(*(undefined4 *)(param_2 + 0x2c));
        iVar1 = *(int *)(*(int *)(param_2 + 0x14) + 4);
        func_0x0000bdfc(*(undefined4 *)(param_2 + 0x2c),iVar1,
                        iVar1 + *(int *)(*(int *)(param_2 + 0x14) + 8));
        func_0x0000beb8(*(undefined4 *)(param_2 + 0x2c));
      }
    }
    uVar2 = FUN_0000a8c4();
    *(undefined4 *)(param_2 + 0x3c) = uVar2;
    func_0x0000a7e4(param_1 + 0x3ac);
    uVar2 = 0;
  }
  return uVar2;
}

