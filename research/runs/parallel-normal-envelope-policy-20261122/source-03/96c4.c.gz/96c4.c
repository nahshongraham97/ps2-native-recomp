
void FUN_000096c4(undefined4 param_1,int param_2)

{
  undefined2 uVar1;
  int iVar2;
  int in_v1;
  ushort *unaff_s0;
  ushort *unaff_s1;
  int unaff_s2;
  
  param_2 = param_2 + (uint)*(byte *)((in_v1 + 0x1fff >> 0xd) + 0x1049f);
  if (199 < param_2) {
    param_2 = 199;
  }
  *unaff_s1 = -*(short *)(param_2 * 2 + 0x102ac);
  if (*(short *)(unaff_s2 + 0x52) == -0x1000) {
    *(ushort *)(unaff_s2 + 0x50) = *unaff_s1;
    *(ushort *)(unaff_s2 + 0x52) = *unaff_s0;
  }
  if ((*(short *)(unaff_s2 + 0x54) != 4) && (iVar2 = FUN_00009534(), iVar2 != 0)) {
    *(ushort *)(unaff_s2 + 0x58) = *(short *)(unaff_s2 + 0x50) - *unaff_s1;
    uVar1 = func_0x0000934c((int)*(short *)(unaff_s2 + 0x58) / 0x9c4);
    *(undefined2 *)(unaff_s2 + 0x5a) = uVar1;
    *(undefined2 *)(unaff_s2 + 0x56) = *(undefined2 *)(unaff_s2 + 0x5a);
  }
  if (0 < *(short *)(unaff_s2 + 0x56)) {
    *unaff_s1 = *(short *)(unaff_s2 + 0x50) -
                *(short *)(unaff_s2 + 0x58) / *(short *)(unaff_s2 + 0x5a);
    *(short *)(unaff_s2 + 0x56) = *(short *)(unaff_s2 + 0x56) + -1;
  }
  *(undefined2 *)(unaff_s2 + 0x54) = 4;
  *(ushort *)(unaff_s2 + 0x50) = *unaff_s1;
  *(ushort *)(unaff_s2 + 0x52) = *unaff_s0;
  if ((short)*unaff_s1 < 0) {
    *unaff_s1 = *unaff_s1 & 0x7fff;
  }
  if ((short)*unaff_s0 < 0) {
    *unaff_s0 = *unaff_s0 & 0x7fff;
  }
  return;
}

