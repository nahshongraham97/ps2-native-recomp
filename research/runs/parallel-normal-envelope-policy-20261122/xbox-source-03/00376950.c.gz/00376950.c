
int FUN_00376950(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (*(int *)(param_2 + 8) == 0) {
    iVar1 = -0x7fffbffb;
  }
  else {
    *(undefined4 *)(param_2 + 0x6c) = 0xffffffff;
    if ((*(int *)(param_2 + 0x58) < 2) || (iVar1 = FUN_00376620(param_1,param_2), iVar1 == 0)) {
      if (param_3 == 1) {
        if ((*(uint *)(param_2 + 4) & 1) == 0) {
          uVar5 = 0;
          uVar4 = 0;
          uVar3 = 0;
          uVar2 = FUN_00378d50(0,0,0);
          iVar1 = FUN_00378bb0(uVar2,uVar3,uVar4,uVar5);
        }
        else {
          uVar5 = 1;
          uVar4 = 0;
          uVar3 = 0;
          uVar2 = FUN_00378d50(0,0,1);
          iVar1 = FUN_00378bb0(uVar2,uVar3,uVar4,uVar5);
        }
        if (iVar1 < 0) {
          return iVar1;
        }
      }
      iVar1 = 0;
    }
    else {
      iVar1 = 1;
    }
  }
  return iVar1;
}

