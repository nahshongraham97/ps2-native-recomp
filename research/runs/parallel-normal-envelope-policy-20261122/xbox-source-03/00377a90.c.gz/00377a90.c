
int FUN_00377a90(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint local_8;
  
  local_8 = (uint)((*(uint *)(param_2 + 4) & 1) != 0);
  uVar4 = 0;
  uVar3 = 0;
  uVar1 = FUN_00378d50(0,0,local_8);
  iVar2 = FUN_00378bb0(uVar1,uVar3,uVar4,local_8);
  if (-1 < iVar2) {
    iVar2 = 0;
  }
  return iVar2;
}

