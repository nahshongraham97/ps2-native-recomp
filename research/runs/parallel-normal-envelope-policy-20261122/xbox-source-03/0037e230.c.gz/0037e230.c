
undefined4 FUN_0037e230(undefined4 param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  
  uVar1 = param_2 + 0x7fU & 0xffffff80;
  uVar2 = FUN_00378d50(uVar1);
  FUN_00378c20(uVar2,uVar1);
  return 0;
}

