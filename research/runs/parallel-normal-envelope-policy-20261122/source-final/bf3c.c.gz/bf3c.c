
void FUN_0000bf3c(int param_1)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = *(byte *)(param_1 + 8);
  bVar2 = *(byte *)(param_1 + 9);
  if (*(char *)(param_1 + 10) != '\x03') {
    func_0x00000288((uint)bVar1 | (uint)bVar2 << 1 | 0x200,0);
    func_0x00000290(bVar1 | 0x1600,1 << (bVar2 & 0x1f));
    *(undefined1 *)(param_1 + 10) = 3;
  }
  return;
}

