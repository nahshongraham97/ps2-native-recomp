
int FUN_0000b7a8(void)

{
  int iVar1;
  
  func_0x000001dc(uRam000104a8);
  iVar1 = func_0x0000b3a0();
  if (iVar1 != 0) {
    func_0x0000b258(iVar1);
    func_0x0000b8ac();
    *(undefined1 *)(iVar1 + 10) = 3;
    iRam00028504 = iRam00028504 + 1;
    iRam00028508 = iRam00028508 + -1;
    if (iRam0002850c < iRam00028504) {
      iRam0002850c = iRam00028504;
    }
    func_0x0000b89c(iVar1);
    if (iRam000284fc == 0) {
      func_0x00000254(uRam000104ac);
      iRam000284fc = 1;
    }
  }
  func_0x000001cc(uRam000104a8);
  return iVar1;
}

