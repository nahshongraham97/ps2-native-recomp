
undefined4 FUN_00009f1c(int param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  short sStack_4;
  short sStack_2;
  
  if (param_3 < 0) {
    param_3 = 0;
  }
  if (0x4000 < param_3) {
    param_3 = 0x4000;
  }
  if (param_4 < -0x4000) {
    param_4 = -0x4000;
  }
  if (0x4000 < param_4) {
    param_4 = 0x4000;
  }
  for (iVar1 = 0; iVar1 < *(short *)(param_2 + 0x4a); iVar1 = iVar1 + 1) {
    if ((*(ushort *)(*(int *)(param_2 + 8) + 0x1e) & 4) == 0) {
      FUN_0000959c(*(undefined4 *)(param_1 + 0x270),param_2,(int)(short)param_3,(int)(short)param_4,
                   &sStack_2,&sStack_4);
      if ((1 < *(short *)(param_2 + 0x4a)) && (*(int *)(param_1 + 0x270) != 0)) {
        if (iVar1 == 0) {
          sStack_4 = 0;
        }
        else {
          sStack_2 = 0;
        }
      }
    }
    else {
      param_4 = 0;
      FUN_0000959c(*(undefined4 *)(param_1 + 0x270),param_2,(int)(short)param_3,0,&sStack_2,
                   &sStack_4);
      if ((*(short *)(param_2 + 0x4a) < 2) || (*(int *)(param_1 + 0x270) == 0)) {
        sStack_4 = 0x7fff - sStack_2;
      }
      else if (iVar1 == 0) {
        sStack_4 = 0;
      }
      else {
        sStack_4 = 0x7fff - sStack_2;
        sStack_2 = 0;
      }
    }
    func_0x0000bbc0(*(undefined4 *)(param_2 + iVar1 * 4 + 0x2c),sStack_2,sStack_4);
  }
  return 0;
}

