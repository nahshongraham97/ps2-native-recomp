
void FUN_0000ba68(uint param_1)

{
  if (param_1 != 0) {
    if ((param_1 < 0x28520) || (0x28d34 < param_1)) {
      func_0x0000b780(param_1);
    }
    else if ((*(char *)(param_1 + 10) != '\x04') && (*(char *)(param_1 + 10) != '\0')) {
      func_0x000001dc(uRam000104a8);
      if (*(char *)(param_1 + 10) != '\x03') {
        func_0x0000b780(param_1);
        FUN_0000bf3c();
      }
      func_0x000002a0((uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1 | 0x2040,
                      0x5000);
      func_0x000002a0((uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1 | 0x2140,
                      0x5000);
      *(undefined1 *)(param_1 + 10) = 4;
      func_0x000001cc(uRam000104a8);
    }
  }
  return;
}

