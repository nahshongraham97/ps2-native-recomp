
void FUN_0000beb8(int param_1)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  
  bVar1 = *(byte *)(param_1 + 9);
  bVar2 = *(byte *)(param_1 + 8);
  uVar3 = (uint)bVar2 | (uint)bVar1 << 1;
  func_0x000002a0(uVar3 | 0x2040,*(undefined4 *)(param_1 + 0x10));
  func_0x00000288(uVar3 | 0x200,*(undefined2 *)(param_1 + 0xe));
  func_0x00000290(bVar2 | 0x1500,1 << (bVar1 & 0x1f));
  *(undefined1 *)(param_1 + 10) = 1;
  return;
}

