
void FUN_0000bfbc(int param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  uVar3 = (uint)*(byte *)(param_2 + 8);
  uVar2 = (uint)*(byte *)(param_2 + 9);
  uVar4 = (uint)*(byte *)(param_1 + 9);
  uVar5 = (uint)*(byte *)(param_1 + 8);
  uVar1 = uVar5 | uVar4 << 1;
  func_0x000002a0(uVar1 | 0x2040,*(undefined4 *)(param_1 + 0x10));
  uVar6 = uVar3 | uVar2 << 1;
  func_0x000002a0(uVar6 | 0x2040,*(undefined4 *)(param_2 + 0x10));
  func_0x00000288(uVar1 | 0x200,*(undefined2 *)(param_1 + 0xe));
  func_0x00000288(uVar6 | 0x200,*(undefined2 *)(param_2 + 0xe));
  if (uVar5 == uVar3) {
    func_0x00000290(uVar5 | 0x1500,1 << (uVar4 & 0x1f) | 1 << (uVar2 & 0x1f));
  }
  else {
    func_0x00000290(uVar5 | 0x1500,1 << (uVar4 & 0x1f));
    func_0x00000290(uVar3 | 0x1500,1 << (uVar2 & 0x1f));
  }
  *(undefined1 *)(param_1 + 10) = 1;
  *(undefined1 *)(param_2 + 10) = 1;
  return;
}

