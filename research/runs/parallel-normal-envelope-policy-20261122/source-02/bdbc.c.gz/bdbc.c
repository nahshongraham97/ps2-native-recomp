
void FUN_0000bdbc(int param_1,int param_2)

{
  *(char *)(param_1 + 0xb) = (char)param_2;
  if (param_2 == 0) {
    func_0x000002a0((uint)*(byte *)(param_1 + 8) | (uint)*(byte *)(param_1 + 9) << 1 | 0x2140,0x5000
                   );
  }
  return;
}

