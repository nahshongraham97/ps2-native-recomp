
undefined4 FUN_00005010(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iStack_8;
  int iStack_4;
  
  uVar2 = 0xffffffff;
  func_0x0000a7d8(param_1 + 0x3ac);
  if (*(short *)(param_2 + 0x4a) == 2) {
    func_0x0000b8d8(&iStack_4,&iStack_8);
    if ((iStack_4 == 0) || (iStack_8 == 0)) {
      *(undefined4 *)(param_2 + 0x2c) = 0;
      *(undefined4 *)(param_2 + 0x30) = 0;
    }
    else {
      *(int *)(param_2 + 0x2c) = iStack_4;
      uVar2 = 1;
      *(int *)(param_2 + 0x30) = iStack_8;
    }
  }
  else {
    iVar1 = func_0x0000b7a8();
    if (iVar1 == 0) {
      *(undefined4 *)(param_2 + 0x2c) = 0;
      *(undefined4 *)(param_2 + 0x30) = 0;
    }
    else {
      *(int *)(param_2 + 0x2c) = iVar1;
      *(undefined4 *)(param_2 + 0x30) = 0;
      uVar2 = 1;
    }
  }
  func_0x0000a7e4(param_1 + 0x3ac);
  return uVar2;
}

