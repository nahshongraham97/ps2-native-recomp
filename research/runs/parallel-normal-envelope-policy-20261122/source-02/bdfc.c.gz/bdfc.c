
void FUN_0000bdfc(int param_1,undefined4 param_2,undefined4 param_3)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = *(byte *)(param_1 + 8);
  bVar2 = *(byte *)(param_1 + 9);
  *(undefined4 *)(param_1 + 0x10) = param_2;
  *(undefined4 *)(param_1 + 0x14) = param_3;
  if (*(char *)(param_1 + 10) == '\x03') {
    func_0x000002a0((uint)bVar1 | (uint)bVar2 << 1 | 0x2040,*(undefined4 *)(param_1 + 0x10));
  }
  else {
    func_0x0000b780();
  }
  if (*(char *)(param_1 + 0xb) == '\x01') {
    func_0x000002a0((uint)bVar1 | (uint)bVar2 << 1 | 0x2140,*(undefined4 *)(param_1 + 0x10));
  }
  return;
}

