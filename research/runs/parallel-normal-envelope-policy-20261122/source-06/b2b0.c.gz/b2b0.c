
int FUN_0000b2b0(void)

{
  int iVar1;
  int iVar2;
  
  iVar1 = func_0x0000b378();
  iVar2 = iVar1;
  do {
    if (0x2e < iVar2) {
      iVar2 = 0;
      do {
        if (iVar1 <= iVar2) {
          return 0;
        }
        iVar2 = iVar2 + 1;
      } while (*(char *)(iVar2 * 0x2c + 0x2852a) != '\0');
      return iVar2 * 0x2c + 0x28520;
    }
    iVar2 = iVar2 + 1;
  } while (*(char *)(iVar2 * 0x2c + 0x2852a) != '\0');
  return iVar2 * 0x2c + 0x28520;
}

