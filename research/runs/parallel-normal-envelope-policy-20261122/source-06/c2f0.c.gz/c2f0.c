
void FUN_0000c2f0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 auStack_2c [2];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 auStack_10 [2];
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  if (iRam000284f4 != 1) {
    iVar2 = 0;
    do {
      uVar3 = iVar2 << 1;
      func_0x00000288(uVar3 & 0xffff | 0x300,0xf);
      func_0x00000288(uVar3 & 0xffff | 0x400,0x1fc6);
      func_0x00000288(uVar3 & 0xffff | 0x301,0xf);
      func_0x00000288(uVar3 & 0xffff | 0x401,0x1fc6);
      iVar2 = iVar2 + 1;
    } while (iVar2 < 0x18);
    uRam00028504 = 0;
    uRam0002850c = 0;
    uRam00028508 = 0x30;
    uRam00028518 = 0x28518;
    uRam0002851c = 0x28518;
    uRam00028510 = 0x28510;
    uRam00028514 = 0x28510;
    iVar2 = 0x28520;
    iVar1 = 0;
    do {
      func_0x0000b8ac(iVar2);
      *(undefined1 *)(iVar2 + 8) = 0;
      *(char *)(iVar2 + 9) = (char)iVar1;
      *(undefined1 *)(iVar2 + 10) = 4;
      func_0x0000b284();
      iVar1 = iVar1 + 1;
      iVar2 = iVar2 + 0x2c;
    } while (iVar1 < 0x18);
    iVar1 = 0;
    do {
      func_0x0000b8ac(iVar2);
      *(undefined1 *)(iVar2 + 8) = 1;
      *(char *)(iVar2 + 9) = (char)iVar1;
      *(undefined1 *)(iVar2 + 10) = 4;
      func_0x0000b284();
      iVar1 = iVar1 + 1;
      iVar2 = iVar2 + 0x2c;
    } while (iVar1 < 0x18);
    auStack_10[0] = 0;
    uStack_8 = 0;
    uStack_4 = 0x20;
    uRam000104a4 = func_0x000001bc(auStack_10);
    auStack_10[0] = 0;
    uStack_8 = 1;
    uStack_4 = 1;
    uRam000104a8 = func_0x000001bc(auStack_10);
    uStack_24 = 0x2000000;
    uStack_1c = 0xb43c;
    uStack_14 = 0x32;
    uStack_18 = 0x1000;
    uStack_20 = 0;
    iVar2 = func_0x00000140(&uStack_24);
    if (0 < iVar2) {
      func_0x00000150(iVar2,0);
    }
    func_0x00000188(100000,auStack_2c);
    uRam000284f8 = auStack_2c[0];
    iRam000104ac = func_0x0000023c(1,0x20,1);
    if (((0 < iRam000104ac) &&
        (iVar2 = func_0x00000244(iRam000104ac,uRam000284f8,0xb410,0), iVar2 == 0)) &&
       (iVar2 = func_0x0000024c(iRam000104ac,1,0,1), iVar2 == 0)) {
      iRam000284f4 = 1;
    }
  }
  return;
}

