
void FUN_0000b3a0(void)

{
  int iVar1;
  
  iVar1 = func_0x0000b2b0(iRam00028500 * 0x2c + 0x28520);
  if (iVar1 != 0) {
    iRam00028500 = (iVar1 + -0x28520) / 0x2c;
  }
  return;
}

