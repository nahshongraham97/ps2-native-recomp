
undefined4 FUN_0037e4e0(undefined4 param_1,int param_2,int *param_3,int param_4)

{
  int iVar1;
  
  param_3[0x12] = param_2;
  if ((param_3[1] & 2U) == 0) {
    FUN_0037b590(param_1,param_2,param_3);
    param_3[0x19] =
         ((int)(uint)*(ushort *)(*param_3 + 0x12) >> 3) * param_4 * (uint)*(ushort *)(*param_3 + 6);
    FUN_0037e230(param_3,0);
    iVar1 = FUN_00376950(param_1,param_3,(*(uint *)(param_3[0x12] + 0x44) & 8) == 0);
    if (iVar1 != 0) {
      return 2;
    }
  }
  else {
    param_3[0x19] =
         ((int)(uint)*(ushort *)(*param_3 + 0x12) >> 3) * param_4 * (uint)*(ushort *)(*param_3 + 6);
    param_3[0x18] = 0;
    iVar1 = FUN_00377060(param_1,param_2,param_3,(*(uint *)(param_3[0x12] + 0x44) & 8) == 0);
    if (iVar1 != 0) {
      return 1;
    }
  }
  if ((param_2 != 0) && (param_3[0x14] == 0)) {
    FUN_00378cd0(param_2 + 0x2c,param_3);
  }
  return 0;
}

