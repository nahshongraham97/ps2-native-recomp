
undefined4 FUN_0037e600(undefined4 param_1,int param_2,int param_3)

{
  *(undefined4 *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x74) =
       *(undefined4 *)(*(int *)(param_2 + 4) + 0x20);
  *(undefined4 *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x78) =
       *(undefined4 *)(*(int *)(param_2 + 4) + 0x24);
  *(undefined4 *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x7c) =
       *(undefined4 *)(*(int *)(param_2 + 4) + 0x28);
  *(undefined4 *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x68) =
       *(undefined4 *)(*(int *)(param_2 + 4) + 0x10);
  *(int *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x58) =
       (int)*(short *)(*(int *)(param_2 + 4) + 10);
  if (*(short *)(*(int *)(param_2 + 4) + 10) != 1) {
    *(uint *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 4) =
         *(uint *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 4) | 1;
  }
  if ((*(byte *)(*(int *)(param_2 + 4) + 9) & 1) != 0) {
    *(uint *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 4) =
         *(uint *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 4) | 4;
  }
  if ((*(uint *)(param_3 + 4) & 2) == 0) {
    FUN_00377a90(param_1,param_3);
  }
  else {
    FUN_00377a30(param_1,param_3);
  }
  return 0;
}

