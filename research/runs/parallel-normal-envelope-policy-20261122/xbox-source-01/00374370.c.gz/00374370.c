
undefined4 __thiscall FUN_00374370(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = FUN_0037dad0(0,param_2,param_1);
  iVar2 = FUN_00374240(iVar1,*(uint *)(iVar1 + 0x44) & 0xfffffff7);
  if (iVar2 < 0) {
    uVar3 = 0;
  }
  else {
    FUN_00374410(iVar1);
    if ((*(uint *)(iVar1 + 0x44) & 8) == 0) {
      FUN_003742e0(param_2);
    }
    else {
      FUN_0037e4e0(*(undefined4 *)(iVar1 + 0x3c),iVar1,*(undefined4 *)(*(int *)(iVar1 + 4) + 0x14),0
                  );
    }
    if (*(int *)(*(int *)(iVar1 + 0x3c) + 0x514) == 1) {
      FUN_0037baf0(*(undefined4 *)(iVar1 + 0x3c));
    }
    uVar3 = 1;
  }
  return uVar3;
}

