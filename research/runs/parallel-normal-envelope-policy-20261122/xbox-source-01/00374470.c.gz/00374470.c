
void FUN_00374470(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if ((param_1 != 0) && (iVar1 = FUN_0037db00(&DAT_00707860,param_1), iVar1 != 0)) {
    piVar2 = (int *)FUN_0037dad0(0,iVar1);
    iVar3 = FUN_003749c0(piVar2);
    if ((iVar3 == 0) && (piVar2[3] != -1)) {
      FUN_003742e0(iVar1);
      FUN_0037e600(piVar2[0xf],piVar2,*(undefined4 *)(piVar2[1] + 0x14));
      piVar2[1] = piVar2[1] + 0x30;
      if ((uint)piVar2[1] < (uint)(*(int *)(*piVar2 + 8) * 0x30 + *(int *)(*piVar2 + 0xc))) {
        if (((int)*(char *)(piVar2[1] + 8) & 0x80U) == 0) {
          piVar2[2] = (int)((float)piVar2[2] + *(float *)(piVar2[1] + 0x18));
        }
      }
      else {
        piVar2[1] = 0;
      }
      if (*(int *)(piVar2[0xf] + 0x514) != 0) {
        FUN_0037baf0(piVar2[0xf]);
      }
    }
  }
  return;
}

