
void FUN_002811f0(int param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (param_1 == 1) {
    uGpffffa9a0 = 0;
    puVar5 = (undefined4 *)0x6b6420;
    puVar4 = (undefined4 *)0x6b6120;
    iVar3 = 0x6aba40;
    piVar2 = (int *)&gp0xffffa824;
  }
  else {
    if (param_1 != 0) {
      return;
    }
    uGpffffa9a4 = 0;
    puVar5 = (undefined4 *)0x6b64e0;
    puVar4 = (undefined4 *)0x6b61e0;
    iVar3 = 0x6af670;
    piVar2 = (int *)&gp0xffffa830;
  }
  iVar6 = 0;
  puVar1 = &DAT_005be100;
  do {
    if ((*piVar2 == 1) && (param_2 == 1)) {
      *puVar5 = *(undefined4 *)(iVar3 + 0x7c);
      puVar5[1] = puVar1[1];
      puVar5[2] = puVar1[2];
      *puVar4 = *(undefined4 *)(iVar3 + 0xbc);
      puVar4[1] = puVar1[1];
      puVar4[2] = puVar1[2];
    }
    else {
      *puVar5 = *puVar1;
      puVar5[1] = puVar1[1];
      puVar5[2] = puVar1[2];
      *puVar4 = *puVar1;
      puVar4[1] = puVar1[1];
      puVar4[2] = puVar1[2];
    }
    iVar6 = iVar6 + 1;
    iVar3 = iVar3 + 4;
    puVar5 = puVar5 + 3;
    puVar1 = puVar1 + 3;
    puVar4 = puVar4 + 3;
  } while (iVar6 < 0x10);
  return;
}

