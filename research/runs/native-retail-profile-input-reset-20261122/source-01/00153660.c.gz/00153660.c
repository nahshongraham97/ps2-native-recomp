
void FUN_00153660(undefined8 param_1,long param_2)

{
  long lVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  long lVar6;
  int iVar7;
  
  iVar7 = 0x6af670;
  lVar6 = 0;
  lVar1 = FUN_0012ed10(0x2001);
  if (lVar1 != 0) {
    lVar6 = FUN_0012e930();
  }
  if (lVar6 != 0) {
    iVar5 = (int)lVar6;
    if (*(int *)(iVar5 + 0x10) == 1) {
      puVar3 = (undefined4 *)0x6b6420;
      puVar2 = (undefined4 *)0x6b6120;
      puVar4 = (undefined4 *)&gp0xffffa9a0;
    }
    else {
      if (*(int *)(iVar5 + 0x10) != 0) {
        return;
      }
      puVar3 = (undefined4 *)0x6b64e0;
      puVar2 = (undefined4 *)0x6b61e0;
      puVar4 = (undefined4 *)&gp0xffffa9a4;
    }
    *(int *)(iVar5 + 0x18) = (int)param_2;
    if (param_2 == 0) {
      *puVar4 = 1;
    }
    else {
      if (*(undefined4 **)(iVar5 + 0x1c) == (undefined4 *)0x0) {
        *puVar4 = 0;
      }
      else {
        uRam006af6e8 = **(undefined4 **)(iVar5 + 0x1c);
        *puVar4 = 0;
      }
      iVar5 = 0;
      do {
        iVar5 = iVar5 + 8;
        *(undefined4 *)(iVar7 + 0x7c) = *puVar3;
        *(undefined4 *)(iVar7 + 0xbc) = *puVar2;
        *(undefined4 *)(iVar7 + 0x80) = puVar3[3];
        *(undefined4 *)(iVar7 + 0xc0) = puVar2[3];
        *(undefined4 *)(iVar7 + 0x84) = puVar3[6];
        *(undefined4 *)(iVar7 + 0xc4) = puVar2[6];
        *(undefined4 *)(iVar7 + 0x88) = puVar3[9];
        *(undefined4 *)(iVar7 + 200) = puVar2[9];
        *(undefined4 *)(iVar7 + 0x8c) = puVar3[0xc];
        *(undefined4 *)(iVar7 + 0xcc) = puVar2[0xc];
        *(undefined4 *)(iVar7 + 0x90) = puVar3[0xf];
        *(undefined4 *)(iVar7 + 0xd0) = puVar2[0xf];
        *(undefined4 *)(iVar7 + 0x94) = puVar3[0x12];
        *(undefined4 *)(iVar7 + 0xd4) = puVar2[0x12];
        *(undefined4 *)(iVar7 + 0x98) = puVar3[0x15];
        puVar3 = puVar3 + 0x18;
        *(undefined4 *)(iVar7 + 0xd8) = puVar2[0x15];
        puVar2 = puVar2 + 0x18;
        iVar7 = iVar7 + 0x20;
      } while (iVar5 < 0x10);
    }
  }
  return;
}

