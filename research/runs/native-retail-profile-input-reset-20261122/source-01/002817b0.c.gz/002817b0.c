
void FUN_002817b0(long param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  if (param_1 != 0) {
    iVar1 = *(int *)((int)param_1 + 4);
    iVar2 = *(int *)(iVar1 * 0x48 + 0x66012c);
    puVar4 = (undefined4 *)0x0;
    if (-1 < iVar2) {
      puVar4 = (undefined4 *)(iVar2 * 0x20 + 0x660268);
    }
    if (iVar1 == 1) {
      puVar3 = (undefined4 *)&gp0xffffa9a0;
    }
    else {
      if (iVar1 != 0) {
        return;
      }
      puVar3 = (undefined4 *)&gp0xffffa9a4;
    }
    if (puVar4 != (undefined4 *)0x0) {
      *puVar4 = 0;
    }
    if (puVar3 != (undefined4 *)0x0) {
      *puVar3 = 0;
    }
  }
  return;
}

