
int FUN_00281830(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 * 0x48 + 0x66012c);
  iVar2 = 0;
  if (-1 < iVar1) {
    iVar2 = iVar1 * 0x20 + 0x660268;
  }
  return iVar2;
}

