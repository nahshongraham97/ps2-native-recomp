
void FUN_00281870(void)

{
  FUN_002811f0(0,0);
  FUN_002811f0(1,0);
  uRam00660268 = 0;
  uRam00660288 = 0;
  return;
}

