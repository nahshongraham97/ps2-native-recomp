
void FUN_00281550(long param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  
  piVar3 = (int *)param_1;
  if (piVar3[1] == 1) {
    if (iGpffff9db4 == 7) {
      uVar5 = 0x6b6120;
    }
    else {
      uVar5 = 0x6b6420;
    }
    piVar2 = (int *)&gp0xffffa9a0;
    piVar4 = (int *)&gp0xffffa824;
  }
  else {
    if (piVar3[1] != 0) {
      return;
    }
    if (iGpffff9db4 == 7) {
      uVar5 = 0x6b61e0;
    }
    else {
      uVar5 = 0x6b64e0;
    }
    piVar2 = (int *)&gp0xffffa9a4;
    piVar4 = (int *)&gp0xffffa830;
  }
  if (*piVar2 == 0) {
    if (*piVar4 == 0) {
      if (((param_1 != 0) && (piVar3[2] == 2)) && ((iVar1 = *piVar3, -1 < iVar1 && (iVar1 < 4)))) {
        *(undefined4 **)(iVar1 * 0x20 + 0x660250) = &DAT_005be100;
      }
    }
    else {
      FUN_00281310();
    }
  }
  else {
    *(undefined4 *)(*piVar3 * 0x20 + 0x660268) = *(undefined4 *)(&gp0xffffa988 + *piVar3 * 4);
    if ((((param_1 != 0) && (piVar3[2] == 2)) && (iVar1 = *piVar3, -1 < iVar1)) && (iVar1 < 4)) {
      *(undefined4 *)(iVar1 * 0x20 + 0x660250) = uVar5;
    }
  }
  return;
}

