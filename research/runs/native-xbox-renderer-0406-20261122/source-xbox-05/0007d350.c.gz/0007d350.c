
void FUN_0007d350(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  param_1[1] = param_2;
  iVar1 = FUN_00241a60(param_3,param_4);
  if (iVar1 == 0) {
    FUN_00398d3b(1);
  }
  iVar2 = FUN_002b9e50(*(undefined4 *)(iVar1 + 4),*(undefined4 *)(iVar1 + 8),
                       *(undefined4 *)(iVar1 + 0xc),4);
  if (iVar2 == 0) {
    FUN_00398d3b(1);
  }
  FUN_002c0e90(iVar2,iVar1);
  FUN_002bcfc0(iVar1);
  iVar1 = FUN_002b8610(iVar2);
  if (iVar1 == 0) {
    FUN_00398d3b(1);
  }
  *(uint *)(iVar1 + 0x50) = *(uint *)(iVar1 + 0x50) & 0xffffff00 | 1;
  *(uint *)(iVar1 + 0x50) = *(uint *)(iVar1 + 0x50) & 0xffff00ff | 0x3300;
  *param_1 = iVar1;
  return;
}

