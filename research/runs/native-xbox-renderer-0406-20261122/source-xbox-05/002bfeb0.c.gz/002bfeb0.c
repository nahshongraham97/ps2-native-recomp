
undefined4 FUN_002bfeb0(void)

{
  int iVar1;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  iVar1 = (*DAT_00835354)(2,0,0,0);
  if (iVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x18,2);
    FUN_002c2370(&uStack_8);
    return 0;
  }
  iVar1 = FUN_002c2b90(&DAT_005a6788,&DAT_00835340);
  if (iVar1 != 0) {
    FUN_002bcd60(DAT_00835350);
    (*DAT_00835354)(0x11,0,0,0);
    DAT_00835490 = 3;
    return 1;
  }
  iVar1 = (*DAT_00835354)(3,0,0,0);
  if (iVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x18,3);
    FUN_002c2370(&uStack_8);
  }
  return 0;
}

