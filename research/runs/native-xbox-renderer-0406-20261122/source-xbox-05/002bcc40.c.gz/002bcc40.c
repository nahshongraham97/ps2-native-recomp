
uint * FUN_002bcc40(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 local_8;
  undefined4 local_4;
  
  uVar3 = param_1[3];
  if ((uVar3 == 4) || (uVar3 == 8)) {
    uVar1 = param_1[6];
    if (uVar1 == 0) {
      local_8 = 1;
      local_4 = FUN_002c2400(0x80000016);
      FUN_002c2370(&local_8);
      return (uint *)0x0;
    }
    FUN_002bbdd0(uVar1,uVar1,1 << ((byte)uVar3 & 0x1f));
  }
  else {
    if (uVar3 != 0x20) {
      local_8 = 1;
      local_4 = FUN_002c2400(0x80000008);
      FUN_002c2370(&local_8);
      return (uint *)0x0;
    }
    uVar3 = param_1[5];
    uVar1 = param_1[1];
    uVar2 = param_1[2];
    if (uVar3 == 0) {
      local_8 = 1;
      local_4 = FUN_002c2400(0x80000016);
      FUN_002c2370(&local_8);
      return (uint *)0x0;
    }
    if (0 < (int)uVar2) {
      do {
        FUN_002bbdd0(uVar3,uVar3,uVar1);
        uVar3 = uVar3 + param_1[4];
        uVar2 = uVar2 - 1;
      } while (uVar2 != 0);
      *param_1 = *param_1 | 2;
      return param_1;
    }
  }
  *param_1 = *param_1 | 2;
  return param_1;
}

