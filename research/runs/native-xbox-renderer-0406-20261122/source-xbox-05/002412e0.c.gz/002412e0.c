
/* WARNING: Removing unreachable block (ram,0x00241397) */

int FUN_002412e0(void)

{
  int iVar1;
  int iVar2;
  int in_stack_00000024;
  int in_stack_00000028;
  undefined4 in_stack_00000034;
  int local_20;
  byte local_14;
  undefined2 local_13;
  undefined1 local_11;
  int local_10;
  int local_c;
  int local_8;
  
  local_10 = in_stack_00000024 * in_stack_00000028;
  local_8 = FUN_002bbe30(in_stack_00000024,in_stack_00000028,0x20);
  FUN_002bbe90(local_8);
  iVar1 = *(int *)(local_8 + 0x14);
  iVar2 = (*DAT_00835474)(local_10 * 3,0x30000);
  local_c = 0;
  while (local_c < local_10 * 3) {
    FUN_002b90b0(in_stack_00000034,&local_14,1);
    if ((local_14 & 0x80) == 0) {
      FUN_002b90b0(in_stack_00000034,iVar2 + local_c,(local_14 + 1) * 3);
      local_c = (local_14 + 1) * 3 + local_c;
    }
    else {
      FUN_002b90b0(in_stack_00000034,&local_13,3);
      for (local_20 = 0; local_20 < (int)((local_14 & 0x8000007f) + 1); local_20 = local_20 + 1) {
        *(undefined2 *)(iVar2 + local_c) = local_13;
        *(undefined1 *)((undefined2 *)(iVar2 + local_c) + 1) = local_11;
        local_c = local_c + 3;
      }
    }
  }
  for (local_c = 0; local_c < local_10; local_c = local_c + 1) {
    *(undefined1 *)(iVar1 + local_c * 4) = *(undefined1 *)(iVar2 + 2 + local_c * 3);
    *(undefined1 *)(iVar1 + 1 + local_c * 4) = *(undefined1 *)(iVar2 + 1 + local_c * 3);
    *(undefined1 *)(iVar1 + 2 + local_c * 4) = *(undefined1 *)(iVar2 + local_c * 3);
    *(undefined1 *)(iVar1 + 3 + local_c * 4) = 0xff;
  }
  (*DAT_00835478)(iVar2);
  return local_8;
}

