
undefined4 FUN_00028990(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int local_10;
  int local_8;
  
  if ((DAT_008292f8 == 7) && (iVar1 = FUN_0007d6a0(), 1 < iVar1)) {
    if ((param_1 < 0x2b) || (0x2f < param_1)) {
      return 0;
    }
    param_1 = param_1 + 5;
  }
  FUN_002bcd60(0x3f800000);
  FUN_00028fd0(param_1);
  DAT_00831aa4 = 0;
  DAT_00831aa0 = 0;
  DAT_00831ad4 = 0;
  DAT_00833ae4 = 0;
  FUN_0002ca10();
  FUN_00031b80();
  if ((DAT_00831a4c == (int *)0x0) || ((DAT_00831a4c[0x22] & 1U) == 0)) {
    iVar1 = FUN_000287f0(param_1);
    if (iVar1 < 0) {
      uVar2 = 0;
    }
    else {
      local_10 = *DAT_00831a4c;
      if ((DAT_00831a4c != (int *)0x0) && (*DAT_00831a4c != 0)) {
        if ((DAT_008292f8 == 9) && (DAT_0082bd64 == 6)) {
          FUN_001b20e0(DAT_0082bde4);
        }
        if ((DAT_008292f8 == 10) || (DAT_008292f8 == 6)) {
          FUN_00232920(iVar1,local_10,1);
        }
        else if (param_1 == 0x17) {
          iVar3 = FUN_0027c790();
          if ((iVar3 != 0) && (iVar3 = FUN_003986b0(local_10,&DAT_004d85a4), iVar3 != 0)) {
            *(undefined1 *)(iVar3 + -1) = 0x77;
          }
          FUN_00232920(iVar1,local_10,1);
        }
        else {
          if (DAT_008292f8 == 7) {
            iVar3 = FUN_0007d6a0();
            if (iVar3 < 2) {
              local_10 = *(int *)(DAT_00831a4c[0x2b] + 4);
            }
            else {
              local_10 = *(int *)(DAT_00831a4c[0x2b] + 8);
            }
          }
          FUN_00233020(iVar1,local_10,1);
        }
        FUN_00232b70(iVar1);
        FUN_001b20e0((&PTR_PTR_00548a48)[param_1 * 6]);
      }
      FUN_000288a0();
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
      FUN_0025d9a0(0x4b);
      DAT_00831a6c = FUN_00026870(iVar1,"BACKGROUND",0x1004,0,1);
      FUN_0025d9b0();
      if (DAT_00831a4c != (int *)0x0) {
        if (DAT_00831a4c[0x26] == 0) {
          puVar4 = &DAT_008335c0;
          for (iVar3 = 0x23; iVar3 != 0; iVar3 = iVar3 + -1) {
            *puVar4 = 0;
            puVar4 = puVar4 + 1;
          }
        }
        else {
          FUN_00025ff0(DAT_00831a4c[0x26],param_1);
        }
      }
      FUN_001ba550();
      if (*(int *)(DAT_00831a50 + 0x48) == 0) {
        *(undefined4 *)(DAT_00831a6c + 0x30) = 0;
      }
      else {
        FUN_0019a250(*(undefined4 *)(DAT_00831a50 + 0x48),&DAT_00735134);
      }
      if (DAT_00831a6c == 0) {
        uVar2 = 0;
      }
      else {
        FUN_001b6e40(DAT_00831a6c);
        if (*(int *)(DAT_00831a50 + 0x48) == 0) {
          *(undefined4 *)(DAT_00831a6c + 0x30) = 0x1000;
        }
        else {
          *(undefined4 *)(DAT_00831a6c + 0x30) = 0x1009;
        }
        uVar2 = FUN_00398614();
        uVar2 = FUN_00398614(uVar2);
        uVar2 = FUN_00398614(uVar2);
        uVar2 = FUN_00398614(uVar2);
        FUN_0007d430(uVar2);
        DAT_00831a74 = 0;
        if ((DAT_00831a4c[0x23] != 0) && (*(char *)DAT_00831a4c[0x23] != '\0')) {
          DAT_00831a70 = FUN_00026340(iVar1,DAT_00831a4c[0x23],0x201f,0);
        }
        if (DAT_00831a70 != 0) {
          FUN_001c7180(DAT_00831a70,DAT_00831a6c + 0x2c);
        }
        FUN_001c77e0(FUN_00029110,&DAT_0073511c);
        FUN_001c77e0(FUN_00029110,&DAT_00735134);
        FUN_001c77e0(FUN_00029110,&DAT_0073512c);
        FUN_001c77e0(FUN_00029110,&DAT_00735118);
        if ((DAT_00831a4c[0x1c] & 1U) != 0) {
          FUN_00237860(DAT_00831a50 + 0x58);
        }
        DAT_00723b80 = *(undefined4 *)(DAT_00831a50 + 0x54);
        FUN_0002b3b0();
        if ((DAT_008292f8 != 7) && (DAT_008292f8 != 6)) {
          FUN_00079fe0(DAT_00831a4c);
        }
        for (local_8 = 0; iVar3 = FUN_0007d6a0(), local_8 < iVar3; local_8 = local_8 + 1) {
          iVar3 = FUN_00057320(local_8);
          if (iVar3 != 0) {
            FUN_002bb5b0(iVar3,DAT_00831a4c[1]);
            FUN_002bb670(iVar3,DAT_00831a4c[2]);
          }
        }
        DAT_00831a54 = param_1;
        FUN_00028ed0(iVar1);
        FUN_0003aa70();
        FUN_000287b0();
        FUN_00050b80();
        DAT_00831aa8 = 0;
        if (*(int *)(DAT_00831a50 + 100) != 0) {
          FUN_001af290(DAT_00831a60,*(undefined4 *)(DAT_00831a50 + 100));
          FUN_001af370(DAT_00831a60);
        }
        DAT_00831a48 = 1;
        DAT_00831ab4 = 0;
        uVar2 = 1;
      }
    }
  }
  else {
    uVar2 = 1;
  }
  return uVar2;
}

