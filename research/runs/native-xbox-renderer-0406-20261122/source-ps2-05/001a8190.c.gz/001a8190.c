
long FUN_001a8190(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  long lVar1;
  undefined4 *puVar2;
  
  lVar1 = (*pcRam0069f3d4)(*(undefined4 *)(iRam0064e4d8 + 0x69f290),0x30018);
  if (lVar1 == 0) {
    lVar1 = 0;
  }
  else {
    puVar2 = (undefined4 *)lVar1;
    puVar2[1] = param_1;
    puVar2[2] = param_2;
    puVar2[3] = param_3;
    puVar2[5] = 0;
    puVar2[6] = 0;
    *puVar2 = 0;
    FUN_001a3480(0x5a36e0,lVar1);
  }
  return lVar1;
}

