
undefined4 * FUN_002bc1d0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  iVar1 = (*DAT_00835460)(param_1);
  uVar4 = iVar1 + 1;
  iVar1 = DAT_005c735c;
  if (*(int *)((int)&DAT_00835348 + DAT_005c735c) < (int)uVar4) {
    iVar2 = (*DAT_0083547c)(*(undefined4 *)((int)&DAT_00835344 + DAT_005c735c),uVar4,0x1040406);
    iVar1 = DAT_005c735c;
    if (iVar2 == 0) {
      uStack_8 = 1;
      uStack_4 = FUN_002c2400(0x80000013,uVar4);
      FUN_002c2370(&uStack_8);
      return (undefined4 *)0x0;
    }
    *(int *)((int)&DAT_00835344 + DAT_005c735c) = iVar2;
    *(uint *)((int)&DAT_00835348 + iVar1) = uVar4;
  }
  puVar5 = param_1;
  puVar6 = *(undefined4 **)((int)&DAT_00835344 + iVar1);
  for (uVar3 = uVar4 >> 2; uVar3 != 0; uVar3 = uVar3 - 1) {
    *puVar6 = *puVar5;
    puVar5 = puVar5 + 1;
    puVar6 = puVar6 + 1;
  }
  for (uVar4 = uVar4 & 3; uVar4 != 0; uVar4 = uVar4 - 1) {
    *(undefined1 *)puVar6 = *(undefined1 *)puVar5;
    puVar5 = (undefined4 *)((int)puVar5 + 1);
    puVar6 = (undefined4 *)((int)puVar6 + 1);
  }
  return param_1;
}

