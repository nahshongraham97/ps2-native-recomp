
void FUN_002bbdd0(undefined1 *param_1,byte *param_2,int param_3)

{
  int iVar1;
  
  iVar1 = DAT_005c735c;
  for (; param_3 != 0; param_3 = param_3 + -1) {
    *param_1 = (&DAT_0083534c)[iVar1 + (uint)*param_2];
    param_1[1] = (&DAT_0083534c)[iVar1 + (uint)param_2[1]];
    param_1[2] = (&DAT_0083534c)[iVar1 + (uint)param_2[2]];
    param_1[3] = param_2[3];
    param_1 = param_1 + 4;
    param_2 = param_2 + 4;
  }
  return;
}

