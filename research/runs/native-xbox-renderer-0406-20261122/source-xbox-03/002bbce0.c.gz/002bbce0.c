
undefined4 FUN_002bbce0(void)

{
  int iVar1;
  int iVar2;
  int unaff_ESI;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  iVar2 = DAT_005c735c;
  if (*(int *)(&DAT_00835554 + DAT_005c735c) < unaff_ESI) {
    if (*(int *)(&DAT_00835550 + DAT_005c735c) == 0) {
      iVar1 = (*DAT_00835474)();
    }
    else {
      iVar1 = (*DAT_0083547c)(*(int *)(&DAT_00835550 + DAT_005c735c));
    }
    iVar2 = DAT_005c735c;
    if (iVar1 == 0) {
      uStack_8 = 1;
      uStack_4 = FUN_002c2400(0x80000013);
      FUN_002c2370(&uStack_8);
      return 0;
    }
    *(int *)(&DAT_00835550 + DAT_005c735c) = iVar1;
    *(int *)(&DAT_00835554 + iVar2) = unaff_ESI;
  }
  return *(undefined4 *)(&DAT_00835550 + iVar2);
}

