
undefined4 * FUN_002bbe30(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(*DAT_00835484)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c735c),0x30018)
  ;
  if (puVar1 == (undefined4 *)0x0) {
    return (undefined4 *)0x0;
  }
  puVar1[1] = param_1;
  puVar1[2] = param_2;
  puVar1[3] = param_3;
  puVar1[5] = 0;
  puVar1[6] = 0;
  *puVar1 = 0;
  FUN_002c2b90(&DAT_005a6738,puVar1);
  return puVar1;
}

