
undefined4 FUN_002bc410(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iStack_8;
  undefined4 uStack_4;
  
  iVar1 = (*DAT_00835448)(param_1,0x3a);
  iVar2 = param_1;
  if (iVar1 != 0) {
    iVar2 = iVar1;
  }
  iVar1 = (*DAT_00835448)(iVar2,0x2f);
  if (iVar1 != 0) {
    iVar2 = iVar1;
  }
  iVar1 = (*DAT_00835448)(iVar2,0x5c);
  if (iVar1 != 0) {
    iVar2 = iVar1;
  }
  iVar2 = (*DAT_00835448)(iVar2,0x2e);
  if (iVar2 != 0) {
    for (iVar1 = *(int *)(&DAT_0083555c + DAT_005c735c); iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x30))
    {
      iVar3 = (*DAT_00835454)(iVar1,iVar2);
      if ((iVar3 == 0) || (iVar3 = (*DAT_00835454)(iVar1 + 0x14,iVar2), iVar3 == 0)) {
        iStack_8 = *(int *)(iVar1 + 0x28);
        if (iStack_8 == 0) {
          return 0;
        }
        uStack_4 = 0;
        FUN_002bc2b0(param_1,5,FUN_002bc3e0,&iStack_8);
        return uStack_4;
      }
    }
  }
  return 0;
}

