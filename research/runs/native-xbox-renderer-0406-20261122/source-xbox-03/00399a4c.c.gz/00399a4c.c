
void thunk_FUN_00399a4e(void)

{
  float10 in_ST0;
  float10 in_ST1;
  
  FUN_00399a70((double)in_ST1,(double)in_ST0);
  return;
}

