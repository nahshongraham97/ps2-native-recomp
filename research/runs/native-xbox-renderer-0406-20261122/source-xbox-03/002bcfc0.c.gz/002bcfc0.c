
undefined4 FUN_002bcfc0(uint *param_1)

{
  if ((*param_1 & 1) != 0) {
    (*DAT_00835478)(param_1[5]);
    param_1[5] = 0;
    param_1[6] = 0;
    *param_1 = *param_1 & 0xfffffffe;
  }
  FUN_002c2bf0(&DAT_005a6738,param_1);
  (*DAT_00835488)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c735c),param_1);
  return 1;
}

