
undefined4 FUN_002bc590(undefined4 param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 local_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  uint uStack_4;
  
  local_14 = CONCAT31(local_14._1_3_,0x2e);
  (*DAT_0083543c)((int)&local_14 + 1,param_1,0x12);
  uStack_4 = uStack_4 & 0xffffff;
  (*DAT_00835468)(&local_14);
  puVar3 = (undefined4 *)0x0;
  puVar5 = *(undefined4 **)(&DAT_0083555c + DAT_005c735c);
  if (*(undefined4 **)(&DAT_0083555c + DAT_005c735c) != (undefined4 *)0x0) {
    do {
      puVar4 = puVar5;
      if (puVar3 != (undefined4 *)0x0) goto LAB_002bc68b;
      iVar2 = (*DAT_00835454)(puVar4,&local_14);
      puVar5 = puVar4;
      if (iVar2 != 0) {
        piVar1 = puVar4 + 0xc;
        puVar4 = puVar3;
        puVar5 = (undefined4 *)*piVar1;
      }
      puVar3 = puVar4;
    } while (puVar5 != (undefined4 *)0x0);
    if (puVar4 != (undefined4 *)0x0) goto LAB_002bc68b;
  }
  puVar3 = (undefined4 *)(*DAT_00835484)(*(undefined4 *)(&DAT_00835558 + DAT_005c735c),0x30406);
  if (puVar3 == (undefined4 *)0x0) {
    return 0;
  }
  *puVar3 = local_14;
  puVar3[1] = uStack_10;
  puVar3[2] = uStack_c;
  puVar3[3] = uStack_8;
  puVar3[4] = uStack_4;
  *(undefined1 *)(puVar3 + 5) = 0x2e;
  (*DAT_0083543c)((int)puVar3 + 0x15,param_1,0x12);
  *(undefined1 *)((int)puVar3 + 0x27) = 0;
  (*DAT_00835464)(puVar3 + 5);
  iVar2 = DAT_005c735c;
  puVar3[10] = 0;
  puVar3[0xb] = 0;
  puVar3[0xc] = *(undefined4 *)(&DAT_0083555c + iVar2);
  *(undefined4 **)(&DAT_0083555c + iVar2) = puVar3;
LAB_002bc68b:
  if (param_2 != 0) {
    puVar3[10] = param_2;
  }
  if (param_3 != 0) {
    puVar3[0xb] = param_3;
  }
  return 1;
}

