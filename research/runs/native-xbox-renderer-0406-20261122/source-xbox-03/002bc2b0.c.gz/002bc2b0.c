
undefined4 FUN_002bc2b0(undefined4 param_1,undefined4 param_2,code *param_3,undefined4 param_4)

{
  int iVar1;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcStack_4;
  
  pcVar5 = *(char **)((int)&DAT_00835344 + DAT_005c735c);
  iVar1 = FUN_002cd750(param_1);
  if (((iVar1 == 0) && (pcVar5 != (char *)0x0)) && (*pcVar5 != '\0')) {
    while (*pcVar5 != '\0') {
      (*DAT_0083544c)(pcVar5,0x3b);
      iVar1 = (*DAT_0083544c)(pcVar5,0x3b);
      if (iVar1 == 0) {
        uVar4 = (*DAT_00835460)(pcVar5);
        pcStack_4 = (char *)0x0;
      }
      else {
        uVar4 = iVar1 - (int)pcVar5;
        pcStack_4 = (char *)(iVar1 + 1);
      }
      (*DAT_00835460)(param_1);
      pcVar2 = (char *)FUN_002bbce0();
      if (pcVar2 == (char *)0x0) {
        return 0;
      }
      pcVar6 = pcVar2;
      for (uVar3 = uVar4 >> 2; uVar3 != 0; uVar3 = uVar3 - 1) {
        *(undefined4 *)pcVar6 = *(undefined4 *)pcVar5;
        pcVar5 = pcVar5 + 4;
        pcVar6 = pcVar6 + 4;
      }
      for (uVar3 = uVar4 & 3; uVar3 != 0; uVar3 = uVar3 - 1) {
        *pcVar6 = *pcVar5;
        pcVar5 = pcVar5 + 1;
        pcVar6 = pcVar6 + 1;
      }
      (*DAT_00835438)(pcVar2 + uVar4,param_1);
      iVar1 = (*param_3)(pcVar2,param_4);
      if (iVar1 == 0) {
        return param_1;
      }
      pcVar5 = pcStack_4;
      if (pcStack_4 == (char *)0x0) {
        return param_1;
      }
    }
  }
  else {
    (*DAT_00835460)(param_1);
    iVar1 = FUN_002bbce0();
    if (iVar1 == 0) {
      return 0;
    }
    (*DAT_00835438)(iVar1,param_1);
    (*param_3)(iVar1,param_4);
  }
  return param_1;
}

