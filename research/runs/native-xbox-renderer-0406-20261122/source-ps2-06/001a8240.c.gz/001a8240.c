
undefined4 FUN_001a8240(undefined8 param_1)

{
  if ((*(uint *)param_1 & 1) != 0) {
    FUN_001a82b0();
  }
  FUN_001a3520(0x5a36e0,param_1);
  (*pcRam0069f3d8)(*(undefined4 *)(iRam0064e4d8 + 0x69f290),param_1);
  return 1;
}

