
undefined4 FUN_002df860(void)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  long lVar4;
  char cVar5;
  char cVar6;
  char cVar7;
  char cVar8;
  char cVar9;
  char cVar10;
  char *pcVar11;
  int *piVar12;
  uint uVar13;
  undefined4 *puVar14;
  
  lVar4 = FUN_001a8190(0x80,0x80,8);
  iRam0064eacc = (int)lVar4;
  if (lVar4 == 0) {
    uVar3 = 0;
  }
  else {
    *(undefined4 *)(iRam0064eacc + 0x10) = 0x80;
    uVar13 = 0;
    piVar12 = (int *)0x6d03f8;
    *(undefined4 *)(iRam0064eacc + 0x14) = 0x6a64b0;
    do {
      lVar4 = FUN_001a87f0(0x80,0x80,8,0x2504);
      if (lVar4 == 0) {
        return 0;
      }
      lVar4 = FUN_001a9720(lVar4);
      iVar2 = (int)lVar4;
      *piVar12 = iVar2;
      if (lVar4 == 0) {
        return 0;
      }
      uVar13 = uVar13 + 1;
      *(uint *)(iVar2 + 0x50) = *(uint *)(iVar2 + 0x50) & 0xffffff00 | 2;
      iVar2 = *piVar12;
      piVar12 = piVar12 + 1;
      *(uint *)(iVar2 + 0x50) = *(uint *)(iVar2 + 0x50) & 0xffff00ff | 0x3300;
    } while (uVar13 < 3);
    uVar13 = 0;
    pcVar11 = (char *)0x6d0410;
    do {
      cVar5 = (char)uVar13;
      *pcVar11 = cVar5;
      cVar1 = cVar5 + '\x01';
      pcVar11[1] = cVar5;
      cVar10 = cVar5 + '\x02';
      pcVar11[2] = cVar5;
      cVar9 = cVar5 + '\x03';
      pcVar11[3] = -1;
      cVar8 = cVar5 + '\x04';
      pcVar11[4] = cVar1;
      cVar7 = cVar5 + '\x05';
      pcVar11[5] = cVar1;
      cVar6 = cVar5 + '\x06';
      pcVar11[6] = cVar1;
      cVar5 = cVar5 + '\a';
      pcVar11[7] = -1;
      uVar13 = uVar13 + 8;
      pcVar11[8] = cVar10;
      pcVar11[9] = cVar10;
      pcVar11[10] = cVar10;
      pcVar11[0xb] = -1;
      pcVar11[0xc] = cVar9;
      pcVar11[0xd] = cVar9;
      pcVar11[0xe] = cVar9;
      pcVar11[0xf] = -1;
      pcVar11[0x10] = cVar8;
      pcVar11[0x11] = cVar8;
      pcVar11[0x12] = cVar8;
      pcVar11[0x13] = -1;
      pcVar11[0x14] = cVar7;
      pcVar11[0x15] = cVar7;
      pcVar11[0x16] = cVar7;
      pcVar11[0x17] = -1;
      pcVar11[0x18] = cVar6;
      pcVar11[0x19] = cVar6;
      pcVar11[0x1a] = cVar6;
      pcVar11[0x1b] = -1;
      pcVar11[0x1c] = cVar5;
      pcVar11[0x1d] = cVar5;
      pcVar11[0x1e] = cVar5;
      pcVar11[0x1f] = -1;
      pcVar11 = pcVar11 + 0x20;
    } while (uVar13 < 0x100);
    uVar13 = 0;
    puVar14 = &DAT_005ca9c0;
    *(undefined4 *)(iRam0064eacc + 0x18) = 0x6d0410;
    do {
      FUN_002df680(*puVar14,uVar13);
      uVar13 = uVar13 + 1;
      puVar14 = puVar14 + 1;
    } while (uVar13 < 3);
    uVar3 = 1;
  }
  return uVar3;
}

