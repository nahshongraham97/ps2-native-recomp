
undefined4 FUN_001a8380(float param_1)

{
  int iVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  
  iVar1 = iRam0064e4d8;
  iVar2 = 1;
  fVar4 = 1.0 / param_1;
  *(float *)(iRam0064e4d8 + 0x69f49c) = param_1;
  *(undefined1 *)(iVar1 + 0x69f29c) = 0;
  *(undefined1 *)(iVar1 + 0x69f39c) = 0;
  do {
    fVar3 = (float)FUN_00122580((float)iVar2 / 255.0,fVar4);
    *(char *)(iVar2 + iRam0064e4d8 + 0x69f29c) = (char)(int)(fVar3 * 255.0 + 0.5);
    fVar3 = (float)FUN_00122580((float)iVar2 / 255.0,param_1);
    iVar1 = iVar2 + iRam0064e4d8;
    iVar2 = iVar2 + 1;
    *(char *)(iVar1 + 0x69f39c) = (char)(int)(fVar3 * 255.0 + 0.5);
  } while (iVar2 < 0x100);
  return 1;
}

