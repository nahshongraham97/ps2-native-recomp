
void FUN_00122580(void)

{
  FUN_0011ea20();
  return;
}

