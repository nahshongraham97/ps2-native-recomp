
float FUN_0011ea20(float param_1,float param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  float *pfVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  
  fVar8 = ABS(param_2);
  fVar13 = ABS(param_1);
  if ((uint)fVar8 < 0x800000) {
    return DAT_005f46c0;
  }
  iVar2 = 0;
  if ((int)param_1 < 0) {
    if ((uint)fVar8 < 0x4b800000) {
      if ((0x3f7fffff < (uint)fVar8) &&
         (uVar4 = 0x96 - ((int)fVar8 >> 0x17), uVar1 = (int)fVar8 >> (uVar4 & 0x1f),
         (float)(uVar1 << (uVar4 & 0x1f)) == fVar8)) {
        iVar2 = 2 - (uVar1 & 1);
      }
    }
    else {
      iVar2 = 2;
    }
  }
  if (fVar8 == 1.0) {
    if ((int)param_2 < 0) {
      return DAT_005f46c0 / param_1;
    }
    return param_1;
  }
  if (param_2 == 2.0) {
    return param_1 * param_1;
  }
  if ((param_2 == 0.5) && (-1 < (int)param_1)) {
    fVar8 = (float)FUN_0011f5b8(param_1);
    return fVar8;
  }
  fVar10 = param_2;
  fVar9 = (float)FUN_00121e08(param_1);
  if (((uint)fVar13 < 0x800000) || (fVar13 == 1.0)) {
    if ((int)param_2 < 0) {
      fVar9 = DAT_005f46c0 / fVar9;
    }
    if (-1 < (int)param_1) {
      return fVar9;
    }
    if (fVar13 == 1.0 && iVar2 == 0) {
      return (fVar9 - fVar9) / (fVar9 - fVar9);
    }
    if (iVar2 == 1) {
      return -fVar9;
    }
    return fVar9;
  }
  if ((int)param_1 < 0 && iVar2 == 0) {
    return (param_1 - param_1) / (param_1 - param_1);
  }
  if ((uint)fVar8 < 0x4d000001) {
    uVar1 = (uint)param_1 & 0x7fffff;
    fVar8 = (float)(uVar1 | 0x3f800000);
    iVar3 = ((int)fVar13 >> 0x17) + -0x7f;
    iVar5 = 0;
    if ((0x1cc471 < uVar1) && (iVar5 = 1, 0x5db3d6 < uVar1)) {
      iVar3 = ((int)fVar13 >> 0x17) + -0x7e;
      fVar8 = (float)((int)fVar8 - 0x800000);
      iVar5 = 0;
    }
    iVar6 = iVar5 * 4;
    fVar9 = *(float *)(&DAT_005f4638 + iVar6);
    fVar14 = DAT_005f46c0 / (fVar8 + fVar9);
    fVar13 = (float)(((int)fVar8 >> 1 | 0x20000000U) + iVar5 * 0x200000 + 0x40000);
    fVar15 = (fVar8 - fVar9) * fVar14;
    fVar12 = fVar15 * fVar15;
    fVar11 = (float)((uint)fVar15 & 0xfffff000);
    fVar14 = fVar14 * (((fVar8 - fVar9) - fVar11 * fVar13) - fVar11 * (fVar8 - (fVar13 - fVar9)));
    fVar13 = fVar14 * (fVar11 + fVar15) +
             fVar12 * fVar12 *
             (fVar12 * (fVar12 * (fVar12 * (fVar12 * (fVar12 * DAT_005f46e0 + DAT_005f46e4) +
                                           DAT_005f46e8) + DAT_005f46ec) + DAT_005f46f0) +
             DAT_005f46f4);
    fVar8 = (float)((uint)(fVar11 * fVar11 + DAT_005f46dc + fVar13) & 0xfffff000);
    fVar13 = (fVar13 - ((fVar8 - DAT_005f46dc) - fVar11 * fVar11)) * fVar15 + fVar14 * fVar8;
    fVar9 = (float)((uint)(fVar11 * fVar8 + fVar13) & 0xfffff000);
    fVar13 = (fVar13 - (fVar9 - fVar11 * fVar8)) * DAT_005f4700 + fVar9 * DAT_005f46f8 +
             *(float *)(&DAT_005f4648 + iVar6);
    fVar8 = (float)((uint)(fVar9 * DAT_005f46fc + fVar13 + *(float *)(&DAT_005f4640 + iVar6) +
                          (float)iVar3) & 0xfffff000);
    fVar13 = fVar13 - (((fVar8 - (float)iVar3) - *(float *)(&DAT_005f4640 + iVar6)) -
                      fVar9 * DAT_005f46fc);
  }
  else {
    if ((uint)fVar13 < 0x3f7ffff8) {
      if (-1 < (int)param_2) {
        return 0.0;
      }
      return DAT_005f46bc;
    }
    if (0x3f800007 < (uint)fVar13) {
      if ((int)param_2 < 1) {
        return 0.0;
      }
      return DAT_005f46bc;
    }
    fVar9 = param_1 - DAT_005f46c0;
    fVar13 = fVar9 * DAT_005f46c8 -
             fVar9 * fVar9 * (DAT_005f46d4 - fVar9 * (DAT_005f46d0 - fVar9 * DAT_005f46c4)) *
             DAT_005f46d8;
    fVar8 = (float)((uint)(fVar9 * DAT_005f46cc + fVar13) & 0xfffff000);
    fVar13 = fVar13 - (fVar8 - fVar9 * DAT_005f46cc);
  }
  fVar9 = DAT_005f46c0;
  if ((int)param_1 < 0 && iVar2 == 1) {
    fVar9 = DAT_005f4704;
  }
  fVar11 = (float)((uint)fVar10 & 0xfffff000) * fVar8;
  fVar10 = fVar10 * fVar13 + (fVar10 - (float)((uint)fVar10 & 0xfffff000)) * fVar8;
  fVar8 = fVar10 + fVar11;
  fVar13 = ABS(fVar8);
  if ((int)fVar8 < 1) {
    fVar14 = DAT_005f4710;
    if (0x42fc0000 < (uint)fVar13) goto LAB_0011ed8c;
    if ((fVar13 != 126.0) || (fVar8 - fVar11 < fVar10)) goto LAB_0011ed9c;
    pfVar7 = &DAT_005f4710;
  }
  else {
    if (((uint)fVar13 < 0x43010001) &&
       ((fVar13 != 129.0 || (fVar10 + DAT_005f470c <= fVar8 - fVar11)))) {
LAB_0011ed9c:
      iVar2 = 0;
      if (0x3f000000 < (uint)fVar13) {
        uVar1 = (int)fVar8 + (0x800000 >> (((int)fVar13 >> 0x17) - 0x7eU & 0x1f));
        uVar4 = (uVar1 >> 0x17 & 0xff) - 0x7f;
        iVar2 = (int)(uVar1 & 0x7fffff | 0x800000) >> (0x17 - uVar4 & 0x1f);
        fVar11 = fVar11 - (float)(uVar1 & ~(0x7fffff >> (uVar4 & 0x1f)));
        if ((int)fVar8 < 0) {
          iVar2 = -iVar2;
        }
        fVar8 = fVar10 + fVar11;
      }
      fVar8 = (float)((uint)fVar8 & 0xfffff000);
      fVar10 = fVar8 * DAT_005f471c + (fVar10 - (fVar8 - fVar11)) * DAT_005f4718;
      fVar11 = fVar8 * DAT_005f4714 + fVar10;
      fVar13 = fVar11 * fVar11;
      fVar10 = fVar10 - (fVar11 - fVar8 * DAT_005f4714);
      fVar8 = fVar11 - fVar13 * (fVar13 * (fVar13 * (fVar13 * (fVar13 * DAT_005f4720 + DAT_005f4724)
                                                    + DAT_005f4728) + DAT_005f472c) + DAT_005f4730);
      fVar8 = (float)((int)(DAT_005f46c0 -
                           (((fVar11 * fVar8) / (fVar8 - DAT_005f4734) - (fVar10 + fVar11 * fVar10))
                           - fVar11)) + iVar2 * 0x800000);
      if ((int)fVar8 >> 0x17 < 1) {
        fVar8 = (float)FUN_001220d8();
      }
      return fVar9 * fVar8;
    }
    pfVar7 = (float *)&DAT_005f4708;
  }
  fVar14 = *pfVar7;
LAB_0011ed8c:
  return fVar9 * fVar14 * fVar14;
}

