
undefined8 FUN_001a84a0(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  
  lVar1 = (*pcRam0069f2f4)(param_1,param_2,0);
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else if ((*(uint *)param_2 & 2) != 0) {
    *(byte *)((int)param_1 + 0x22) = *(byte *)((int)param_1 + 0x22) | 1;
  }
  return param_1;
}

