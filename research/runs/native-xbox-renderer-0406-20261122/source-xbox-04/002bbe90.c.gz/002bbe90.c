
uint * FUN_002bbe90(uint *param_1)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uVar2 = param_1[3];
  if ((uVar2 == 4) || (uVar2 == 8)) {
    bVar1 = true;
    iVar3 = (1 << ((byte)uVar2 & 0x1f)) << 2;
  }
  else {
    bVar1 = false;
    iVar3 = 0;
  }
  uVar2 = ((int)(uVar2 + 7) >> 3) * param_1[1] + 3 & 0xfffffffc;
  iVar4 = param_1[2] * uVar2;
  iVar3 = iVar4 + iVar3;
  param_1[4] = uVar2;
  uVar2 = (*DAT_00835474)(iVar3,0x30018);
  param_1[5] = uVar2;
  if (uVar2 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x80000013,iVar3);
    FUN_002c2370(&uStack_8);
    return (uint *)0x0;
  }
  if (bVar1) {
    param_1[6] = uVar2 + iVar4;
    *param_1 = *param_1 | 1;
    return param_1;
  }
  param_1[6] = 0;
  *param_1 = *param_1 | 1;
  return param_1;
}

