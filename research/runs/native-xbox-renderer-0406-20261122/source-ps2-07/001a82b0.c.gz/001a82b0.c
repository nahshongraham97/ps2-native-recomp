
undefined8 FUN_001a82b0(undefined8 param_1)

{
  uint *puVar1;
  
  puVar1 = (uint *)param_1;
  (*pcRam0069f3c8)(puVar1[5]);
  puVar1[5] = 0;
  puVar1[6] = 0;
  *puVar1 = *puVar1 & 0xfffffffe;
  return param_1;
}

