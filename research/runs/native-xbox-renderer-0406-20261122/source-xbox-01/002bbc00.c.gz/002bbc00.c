
undefined4 recovery0406_002bbc00(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = DAT_005c735c;
  if (*(int *)(&DAT_00835550 + DAT_005c735c) != 0) {
    (*DAT_00835478)(*(int *)(&DAT_00835550 + DAT_005c735c));
    iVar2 = DAT_005c735c;
    *(undefined4 *)(&DAT_00835550 + DAT_005c735c) = 0;
    *(undefined4 *)(&DAT_00835554 + iVar2) = 0;
  }
  if (*(int *)((int)&DAT_00835344 + iVar2) != 0) {
    (*DAT_00835478)(*(int *)((int)&DAT_00835344 + iVar2));
    iVar2 = DAT_005c735c;
    *(undefined4 *)((int)&DAT_00835344 + DAT_005c735c) = 0;
    *(undefined4 *)((int)&DAT_00835348 + iVar2) = 0;
  }
  iVar1 = *(int *)(&DAT_0083555c + iVar2);
  while (iVar1 != 0) {
    iVar1 = *(int *)(&DAT_0083555c + iVar2);
    *(undefined4 *)(&DAT_0083555c + iVar2) = *(undefined4 *)(iVar1 + 0x30);
    (*DAT_00835488)(*(undefined4 *)(&DAT_00835558 + iVar2),iVar1);
    iVar2 = DAT_005c735c;
    iVar1 = *(int *)(&DAT_0083555c + DAT_005c735c);
  }
  if (*(int *)(&DAT_00835558 + iVar2) != 0) {
    FUN_002c3fc0(*(int *)(&DAT_00835558 + iVar2));
    iVar2 = DAT_005c735c;
    *(undefined4 *)(&DAT_00835558 + DAT_005c735c) = 0;
  }
  if (*(int *)((int)&DAT_00835340 + iVar2) != 0) {
    FUN_002c3fc0(*(int *)((int)&DAT_00835340 + iVar2));
    *(undefined4 *)((int)&DAT_00835340 + DAT_005c735c) = 0;
  }
  DAT_005c7360 = DAT_005c7360 + -1;
  return param_1;
}

