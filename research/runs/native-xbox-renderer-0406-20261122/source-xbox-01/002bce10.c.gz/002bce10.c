
undefined4 recovery0406_002bce10(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined1 *puVar3;
  
  DAT_005c735c = param_2;
  iVar1 = FUN_002c4620(DAT_005a6738,DAT_005a6750,4,DAT_005a6754,&DAT_005c7364,0x40018);
  *(int *)((int)&DAT_00835340 + DAT_005c735c) = iVar1;
  if (iVar1 != 0) {
    iVar2 = FUN_002c4620(0x34,DAT_005a6750,4,DAT_005a675c,&DAT_005c7388,0x40406);
    iVar1 = DAT_005c735c;
    *(int *)(&DAT_00835558 + DAT_005c735c) = iVar2;
    if (iVar2 != 0) {
      *(undefined4 *)((int)&DAT_00835348 + iVar1) = 0x100;
      puVar3 = (undefined1 *)(*DAT_00835474)(0x100,0x1040406);
      iVar1 = DAT_005c735c;
      *(undefined1 **)((int)&DAT_00835344 + DAT_005c735c) = puVar3;
      if (puVar3 == (undefined1 *)0x0) {
        FUN_002c3fc0(*(undefined4 *)(&DAT_00835558 + iVar1));
        iVar1 = DAT_005c735c;
        *(undefined4 *)(&DAT_00835558 + DAT_005c735c) = 0;
        FUN_002c3fc0(*(undefined4 *)((int)&DAT_00835340 + iVar1));
        *(undefined4 *)((int)&DAT_00835340 + DAT_005c735c) = 0;
        return 0;
      }
      DAT_005c7360 = DAT_005c7360 + 1;
      *puVar3 = 0;
      FUN_002bcd60(0x3f800000);
      *(undefined4 *)(&DAT_0083555c + iVar1) = 0;
      *(undefined4 *)(&DAT_00835554 + iVar1) = 0x100;
      iVar2 = (*DAT_00835474)(0x100,0x1040018);
      iVar1 = DAT_005c735c;
      *(int *)(&DAT_00835550 + DAT_005c735c) = iVar2;
      if (iVar2 == 0) {
        (*DAT_00835478)(*(undefined4 *)((int)&DAT_00835344 + iVar1));
        iVar1 = DAT_005c735c;
        *(undefined4 *)((int)&DAT_00835344 + DAT_005c735c) = 0;
        *(undefined4 *)((int)&DAT_00835348 + iVar1) = 0;
        FUN_002c3fc0(*(undefined4 *)(&DAT_00835558 + iVar1));
        iVar1 = DAT_005c735c;
        *(undefined4 *)(&DAT_00835558 + DAT_005c735c) = 0;
        FUN_002c3fc0(*(undefined4 *)((int)&DAT_00835340 + iVar1));
        *(undefined4 *)((int)&DAT_00835340 + DAT_005c735c) = 0;
        return 0;
      }
      return param_1;
    }
    FUN_002c3fc0(*(undefined4 *)((int)&DAT_00835340 + iVar1));
    *(undefined4 *)((int)&DAT_00835340 + DAT_005c735c) = 0;
  }
  return 0;
}

