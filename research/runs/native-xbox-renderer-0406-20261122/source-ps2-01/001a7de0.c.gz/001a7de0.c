
undefined8 recovery0406_001a7de0(undefined8 param_1,int param_2)

{
  long lVar1;
  
  iGpffffa3e8 = param_2;
  lVar1 = thunk_FUN_001a0e00(DAT_005a36e0,uGpffff83a4,4,uGpffff83a8,0x6a32f0,0x40018);
  *(int *)(iGpffffa3e8 + 0x69f290) = (int)lVar1;
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else {
    lVar1 = thunk_FUN_001a0e00(0x34,uGpffff83a4,4,uGpffff83ac,0x6a32c0,0x40406);
    *(int *)(iGpffffa3e8 + 0x69f4a8) = (int)lVar1;
    if (lVar1 == 0) {
      FUN_001a10a0(*(undefined4 *)(iGpffffa3e8 + 0x69f290));
      param_1 = 0;
      *(undefined4 *)(iGpffffa3e8 + 0x69f290) = 0;
    }
    else {
      *(undefined4 *)(iGpffffa3e8 + 0x69f298) = 0x100;
      lVar1 = (*pcRam0069f3c4)(0x100,0x1040406);
      *(undefined1 **)(iGpffffa3e8 + 0x69f294) = (undefined1 *)lVar1;
      if (lVar1 == 0) {
        FUN_001a10a0(*(undefined4 *)(iGpffffa3e8 + 0x69f4a8));
        *(undefined4 *)(iGpffffa3e8 + 0x69f4a8) = 0;
        FUN_001a10a0(*(undefined4 *)(iGpffffa3e8 + 0x69f290));
        param_1 = 0;
        *(undefined4 *)(iGpffffa3e8 + 0x69f290) = 0;
      }
      else {
        *(undefined1 *)lVar1 = 0;
        iGpffffa3ec = iGpffffa3ec + 1;
        FUN_001a8380(0x3f800000);
        *(undefined4 *)(iGpffffa3e8 + 0x69f4ac) = 0;
        *(undefined4 *)(iGpffffa3e8 + 0x69f4a4) = 0x100;
        lVar1 = (*pcRam0069f3c4)(0x100,0x1040018);
        *(int *)(iGpffffa3e8 + 0x69f4a0) = (int)lVar1;
        if (lVar1 == 0) {
          (*pcRam0069f3c8)(*(undefined4 *)(iGpffffa3e8 + 0x69f294));
          *(undefined4 *)(iGpffffa3e8 + 0x69f294) = 0;
          *(undefined4 *)(iGpffffa3e8 + 0x69f298) = 0;
          FUN_001a10a0(*(undefined4 *)(iGpffffa3e8 + 0x69f4a8));
          *(undefined4 *)(iGpffffa3e8 + 0x69f4a8) = 0;
          FUN_001a10a0(*(undefined4 *)(iGpffffa3e8 + 0x69f290));
          param_1 = 0;
          *(undefined4 *)(iGpffffa3e8 + 0x69f290) = 0;
        }
      }
    }
  }
  return param_1;
}

