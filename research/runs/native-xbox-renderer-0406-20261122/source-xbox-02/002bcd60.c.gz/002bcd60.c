
undefined4 FUN_002bcd60(undefined4 param_1)

{
  int iVar1;
  undefined1 uVar2;
  int iVar3;
  
  iVar1 = DAT_005c735c;
  *(undefined4 *)(&DAT_0083554c + DAT_005c735c) = param_1;
  iVar3 = 1;
  (&DAT_0083534c)[iVar1] = 0;
  *(undefined1 *)((int)&DAT_0083544c + iVar1) = 0;
  do {
    thunk_FUN_00399a4e();
    uVar2 = FUN_00398614();
    (&DAT_0083534c)[iVar3 + iVar1] = uVar2;
    thunk_FUN_00399a4e();
    uVar2 = FUN_00398614();
    *(undefined1 *)((int)&DAT_0083544c + iVar3 + iVar1) = uVar2;
    iVar3 = iVar3 + 1;
  } while (iVar3 < 0x100);
  return 1;
}

