
undefined4 FUN_00007f00(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 auStackX_0 [4];
  
  auStackX_0[0] = param_1;
  iVar1 = func_0x0000f278(0,param_1);
  iVar3 = *(int *)(*(int *)(iVar1 + 4) + 0x18);
  iVar2 = FUN_0000a8c4();
  *(int *)(iVar1 + 8) = iVar3 + iVar2;
  *(undefined4 *)(iVar1 + 0x24) = 0;
  auStackX_0[0] = func_0x0000f3d8(auStackX_0);
  func_0x0000f474(*(int *)(iVar1 + 0x3c) + 0x274,auStackX_0[0]);
  *(int *)(*(int *)(*(int *)(iVar1 + 0x3c) + 0x268) + *(short *)(iVar1 + 0xc) * 8) = iVar1;
  *(ushort *)(iVar1 + 0x1e) = *(ushort *)(iVar1 + 0x1e) | 0x8000;
  return 1;
}

