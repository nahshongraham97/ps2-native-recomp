
void FUN_000080a8(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  if ((param_1 != 0) && (iVar1 = func_0x0000f298(0x248b4,param_1), iVar1 != 0)) {
    piVar2 = (int *)func_0x0000f278(0,iVar1);
    iVar3 = FUN_00008bc8(piVar2);
    if (iVar3 == 0) {
      iVar3 = piVar2[0xf];
      func_0x0000a7d8(iVar3 + 0x3ac);
      do {
        iVar4 = func_0x00008fc8(piVar2,10000,1,0x1022c);
        if (iVar4 != 0) {
          if (iVar4 < 1) {
            if (iVar4 == -2) {
              func_0x0000a7e4(iVar3 + 0x3ac);
              return;
            }
            iVar5 = (int)piVar2 - iRam000248bc;
            if (iVar5 < 0) {
              iVar5 = iVar5 + 0x3f;
            }
            func_0x0000f318(0,iRam000248c0 + (iVar5 >> 6) * 0x10);
          }
          else {
            iVar5 = (int)piVar2 - iRam000248bc;
            if (iVar5 < 0) {
              iVar5 = iVar5 + 0x3f;
            }
            func_0x0000f318(0,iRam000248c0 + (iVar5 >> 6) * 0x10);
          }
        }
      } while (iVar4 < 0);
      if ((short)piVar2[3] == -1) {
        func_0x0000a7e4(iVar3 + 0x3ac);
      }
      else {
        iVar4 = FUN_00007c70(piVar2);
        if (iVar4 < 0) {
          func_0x0000a7e4(iVar3 + 0x3ac);
        }
        else {
          *(ushort *)((int)piVar2 + 0x1e) = *(ushort *)((int)piVar2 + 0x1e) & 0xfff7;
          func_0x00007f00(iVar1);
          func_0x0000a598(iVar3,piVar2,*(undefined4 *)(piVar2[1] + 0x14));
          piVar2[1] = piVar2[1] + 0x28;
          uVar6 = piVar2[1];
          if (uVar6 < (uint)(*(int *)(*piVar2 + 0xc) + *(int *)(*piVar2 + 8) * 0x28)) {
            if (((int)*(char *)(uVar6 + 8) & 0x80U) == 0) {
              if (*(uint *)(uVar6 + 0x18) < -piVar2[2] - 1U) {
                piVar2[2] = piVar2[2] + *(uint *)(uVar6 + 0x18);
              }
            }
          }
          else {
            piVar2[1] = 0;
          }
          if (*(int *)(iVar3 + 0x2a8) != 0) {
            FUN_000046f8(iVar3);
          }
          func_0x0000a7e4(iVar3 + 0x3ac);
        }
      }
    }
  }
  return;
}

