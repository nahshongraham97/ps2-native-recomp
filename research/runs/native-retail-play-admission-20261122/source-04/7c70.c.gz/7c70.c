
undefined4 FUN_00007c70(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = *(int *)(*(int *)(*(int *)(param_1 + 0x3c) + 0x268) + *(short *)(param_1 + 0xc) * 8);
  if ((iVar2 == 0) || (iVar2 == param_1)) {
    uVar1 = 0;
  }
  else if ((*(short *)(param_1 + 0x10) < *(short *)(iVar2 + 0x10)) ||
          (((*(ushort *)(param_1 + 0x1e) & 0x80) != 0 &&
           (*(short *)(param_1 + 0x10) <= *(short *)(iVar2 + 0x10))))) {
    uVar1 = 0xffffffff;
  }
  else {
    func_0x00008b54();
    uVar1 = 1;
    *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x3c) + 0x268) + *(short *)(param_1 + 0xc) * 8) = 0;
  }
  return uVar1;
}

