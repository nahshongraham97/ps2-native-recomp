
void FUN_00007ea0(int *param_1)

{
  char cVar1;
  
  param_1[1] = *(int *)(*param_1 + 0xc);
  while( true ) {
    cVar1 = *(char *)(param_1[1] + 8);
    if (cVar1 == '\a') break;
    if (cVar1 == '\x06') {
      *(undefined4 *)(param_1[1] + 0x10) = 0;
    }
    param_1[1] = param_1[1] + 0x28;
  }
  param_1[1] = *(int *)(*param_1 + 0xc);
  return;
}

