
undefined4 FUN_0000a598(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  func_0x0000a7d8(param_1 + 0x3ac);
  *(undefined2 *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x44) =
       *(undefined2 *)(*(int *)(param_2 + 4) + 0x20);
  *(undefined2 *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x46) =
       *(undefined2 *)(*(int *)(param_2 + 4) + 0x22);
  *(undefined2 *)(*(int *)(*(int *)(param_2 + 4) + 0x14) + 0x48) =
       *(undefined2 *)(*(int *)(param_2 + 4) + 0x24);
  if (*(short *)(*(int *)(param_2 + 4) + 10) != 1) {
    iVar1 = *(int *)(*(int *)(param_2 + 4) + 0x14);
    *(ushort *)(iVar1 + 0xc) = *(ushort *)(iVar1 + 0xc) | 1;
  }
  if ((*(byte *)(*(int *)(param_2 + 4) + 9) & 1) != 0) {
    iVar1 = *(int *)(*(int *)(param_2 + 4) + 0x14);
    *(ushort *)(iVar1 + 0xc) = *(ushort *)(iVar1 + 0xc) | 4;
  }
  if ((*(ushort *)(param_3 + 0xc) & 2) == 0) {
    func_0x00006468(param_1,param_3);
  }
  else {
    func_0x000068ac(param_1,param_3);
  }
  func_0x0000a7e4(param_1 + 0x3ac);
  return 0;
}

