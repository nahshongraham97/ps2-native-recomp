
int FUN_0000265c(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  func_0x0000a7d8(iRam000248e0 + 0x3ac);
  iVar2 = *(int *)(param_1 + 0x10);
  if (iVar2 == 0) {
    func_0x0000a7e4(iRam000248e0 + 0x3ac);
  }
  else {
    for (iVar3 = 0; iVar3 < *(short *)(param_1 + 8); iVar3 = iVar3 + 1) {
      if ((*(uint *)(param_1 + 4) & 0x10) == 0) {
        iVar1 = FUN_0000a7f0(*(undefined4 *)(iVar2 + 8),param_2);
        if (iVar1 == 0) {
          func_0x0000a7e4(iRam000248e0 + 0x3ac);
          return iVar2;
        }
      }
      else if (*(int *)(iVar2 + 8) == param_2) {
        func_0x0000a7e4(iRam000248e0 + 0x3ac);
        return iVar2;
      }
      iVar2 = iVar2 + 0x24;
    }
    func_0x0000a7e4(iRam000248e0 + 0x3ac);
  }
  return 0;
}

