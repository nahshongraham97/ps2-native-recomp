
undefined4 FUN_00003a38(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  if (*(int *)(param_2 + 0x14) == 0) {
    uVar1 = 0;
  }
  else {
    *(undefined2 *)(*(int *)(param_2 + 0x14) + 0x44) = *(undefined2 *)(param_2 + 0x20);
    *(undefined2 *)(*(int *)(param_2 + 0x14) + 0x46) = *(undefined2 *)(param_2 + 0x22);
    *(undefined2 *)(*(int *)(param_2 + 0x14) + 0x48) = *(undefined2 *)(param_2 + 0x24);
    *(undefined4 *)(*(int *)(param_2 + 0x14) + 0x28) = *(undefined4 *)(param_2 + 0x10);
    *(undefined2 *)(*(int *)(param_2 + 0x14) + 0xe) = *(undefined2 *)(param_2 + 10);
    if (*(short *)(param_2 + 10) != 1) {
      *(ushort *)(*(int *)(param_2 + 0x14) + 0xc) = *(ushort *)(*(int *)(param_2 + 0x14) + 0xc) | 1;
    }
    if ((*(byte *)(param_2 + 9) & 1) != 0) {
      *(ushort *)(*(int *)(param_2 + 0x14) + 0xc) = *(ushort *)(*(int *)(param_2 + 0x14) + 0xc) | 4;
    }
    iVar2 = func_0x0000a49c(*(undefined4 *)(param_1 + 0x3c),param_1,*(undefined4 *)(param_2 + 0x14),
                            *(undefined4 *)(param_2 + 0xc));
    if (iVar2 == 0) {
      uVar1 = 0;
    }
    else {
      uVar1 = 1;
    }
  }
  return uVar1;
}

