
int FUN_00008fc8(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  iVar3 = param_1 - iRam000248bc;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x3f;
  }
  iVar3 = iRam000248c0 + (iVar3 >> 6) * 0x10;
  uVar1 = func_0x0000f318(0x248b4,iVar3);
  if (*(short *)(param_1 + 0x22) != 0) {
    func_0x0000f980(param_1);
  }
  while( true ) {
    if (*(short *)(param_1 + 0x22) == 0) {
      return iVar4;
    }
    iVar4 = iVar4 + 1;
    if (1000 < iVar4) break;
    func_0x0000a7e4(iRam000248e0 + 0x3ac);
    FUN_0000aa88(1000,0x1029c,0x747);
    func_0x0000a7d8(iRam000248e0 + 0x3ac);
    iVar2 = func_0x0000f298(0x248b4,uVar1);
    if (iVar3 != iVar2) {
      return -2;
    }
  }
  return -1;
}

