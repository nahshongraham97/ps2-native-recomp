
undefined4 FUN_00006468(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  func_0x0000a7d8(param_1 + 0x3ac);
  if (*(short *)(param_2 + 0x4a) == 2) {
    func_0x0000bdbc(*(undefined4 *)(param_2 + 0x2c),1);
    func_0x0000bdbc(*(undefined4 *)(param_2 + 0x30),1);
    iVar2 = *(int *)(*(int *)(param_2 + 0x14) + 4);
    func_0x0000bdfc(*(undefined4 *)(param_2 + 0x2c),iVar2,
                    iVar2 + *(int *)(*(int *)(param_2 + 0x14) + 8));
    iVar2 = *(int *)(*(int *)(param_2 + 0x18) + 4);
    func_0x0000bdfc(*(undefined4 *)(param_2 + 0x30),iVar2,
                    iVar2 + *(int *)(*(int *)(param_2 + 0x18) + 8));
    func_0x0000bfbc(*(undefined4 *)(param_2 + 0x2c),*(undefined4 *)(param_2 + 0x30));
  }
  else {
    func_0x0000bdbc(*(undefined4 *)(param_2 + 0x2c),1);
    iVar2 = *(int *)(*(int *)(param_2 + 0x14) + 4);
    func_0x0000bdfc(*(undefined4 *)(param_2 + 0x2c),iVar2,
                    iVar2 + *(int *)(*(int *)(param_2 + 0x14) + 8));
    func_0x0000beb8(*(undefined4 *)(param_2 + 0x2c));
  }
  uVar1 = FUN_0000a8c4();
  *(undefined4 *)(param_2 + 0x3c) = uVar1;
  func_0x0000a7e4(param_1 + 0x3ac);
  return 0;
}

