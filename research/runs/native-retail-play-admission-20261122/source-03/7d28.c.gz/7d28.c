
int FUN_00007d28(int param_1,uint param_2)

{
  short sVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = (int)*(short *)(param_1 + 0xc);
  iVar5 = *(int *)(param_1 + 0x3c);
  if (iVar4 == -1) {
    for (uVar3 = (uint)*(ushort *)(iVar5 + 0x264); (int)uVar3 < 0x30; uVar3 = uVar3 + 1) {
      piVar2 = (int *)(*(int *)(iVar5 + 0x268) + uVar3 * 8);
      iVar4 = *piVar2;
      if ((iVar4 == 0) || (iVar4 == param_1)) {
        *piVar2 = param_1;
        *(short *)(param_1 + 0xc) = (short)uVar3;
        break;
      }
    }
    sVar1 = *(short *)(param_1 + 0xc);
  }
  else {
    if (iVar4 != -2) {
      if ((int)(uint)*(ushort *)(iVar5 + 0x264) <= iVar4) {
        return -1;
      }
      if (((param_2 & 8) == 0) && (iVar4 = func_0x00007c70(), iVar4 < 0)) {
        return -1;
      }
      goto LAB_00007e88;
    }
    iVar4 = 0;
    *(undefined2 *)(param_1 + 0xc) = 0xffff;
    if (*(short *)(iVar5 + 0x264) != 0) {
      return -1;
    }
    if (0x30 < *(ushort *)(param_1 + 0xe)) {
      return -1;
    }
    for (; iVar4 < (int)(uint)*(ushort *)(param_1 + 0xe); iVar4 = iVar4 + 1) {
      if (*(int *)(*(int *)(iVar5 + 0x268) + iVar4 * 8) == 0) {
        *(short *)(param_1 + 0xc) = (short)iVar4;
        break;
      }
    }
    sVar1 = *(short *)(param_1 + 0xc);
  }
  if (sVar1 == -1) {
    return -1;
  }
LAB_00007e88:
  return (int)*(short *)(param_1 + 0xc);
}

