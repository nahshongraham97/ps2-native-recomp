
undefined4 FUN_0000638c(void)

{
  undefined4 uVar1;
  int iVar2;
  int unaff_s0;
  int unaff_s1;
  int unaff_s2;
  
  if (unaff_s2 == 1) {
    if (*(short *)(unaff_s0 + 0x4a) == 2) {
      func_0x0000bdbc(*(undefined4 *)(unaff_s0 + 0x2c));
      func_0x0000bdbc(*(undefined4 *)(unaff_s0 + 0x30),1);
      iVar2 = *(int *)(*(int *)(unaff_s0 + 0x14) + 4);
      func_0x0000bdfc(*(undefined4 *)(unaff_s0 + 0x2c),iVar2,
                      iVar2 + *(int *)(*(int *)(unaff_s0 + 0x14) + 8));
      iVar2 = *(int *)(*(int *)(unaff_s0 + 0x18) + 4);
      func_0x0000bdfc(*(undefined4 *)(unaff_s0 + 0x30),iVar2,
                      iVar2 + *(int *)(*(int *)(unaff_s0 + 0x18) + 8));
      func_0x0000bfbc(*(undefined4 *)(unaff_s0 + 0x2c),*(undefined4 *)(unaff_s0 + 0x30));
    }
    else {
      func_0x0000bdbc(*(undefined4 *)(unaff_s0 + 0x2c));
      iVar2 = *(int *)(*(int *)(unaff_s0 + 0x14) + 4);
      func_0x0000bdfc(*(undefined4 *)(unaff_s0 + 0x2c),iVar2,
                      iVar2 + *(int *)(*(int *)(unaff_s0 + 0x14) + 8));
      func_0x0000beb8(*(undefined4 *)(unaff_s0 + 0x2c));
    }
  }
  uVar1 = FUN_0000a8c4();
  *(undefined4 *)(unaff_s0 + 0x3c) = uVar1;
  func_0x0000a7e4(unaff_s1 + 0x3ac);
  return 0;
}

