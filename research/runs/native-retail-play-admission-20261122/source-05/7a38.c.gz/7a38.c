
undefined4 FUN_00007a38(int *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  
  piVar6 = *(int **)(param_2 + 4);
  param_1[0xd] = param_2;
  param_1[0xe] = 0;
  param_1[10] = 0;
  param_1[9] = 0;
  iVar1 = func_0x00006b4c(0x10);
  *param_1 = iVar1;
  if (*param_1 == 0) {
    uVar2 = 1;
  }
  else {
    *(undefined4 *)(*param_1 + 8) = *(undefined4 *)(*piVar6 + 8);
    uVar2 = func_0x00006b4c(*(int *)(*param_1 + 8) * 0x28);
    *(undefined4 *)(*param_1 + 0xc) = uVar2;
    piVar5 = *(int **)(*param_1 + 0xc);
    if (piVar5 == (int *)0x0) {
      func_0x00006bc8();
      uVar2 = 1;
    }
    else {
      piVar6 = *(int **)(*piVar6 + 0xc);
      for (iVar1 = 0; iVar1 < *(int *)(*param_1 + 8); iVar1 = iVar1 + 1) {
        iVar7 = 5;
        piVar3 = piVar5;
        piVar4 = piVar6;
        do {
          iVar8 = piVar4[1];
          iVar7 = iVar7 + -1;
          *piVar3 = *piVar4;
          piVar3[1] = iVar8;
          piVar4 = piVar4 + 2;
          piVar3 = piVar3 + 2;
        } while (0 < iVar7);
        if (*piVar5 != 0) {
          *piVar5 = *piVar6;
        }
        piVar5 = piVar5 + 10;
        piVar6 = piVar6 + 10;
      }
      param_1[1] = *(int *)(*param_1 + 0xc);
      iVar1 = param_1[1];
      for (iVar7 = 0; iVar7 < *(int *)(*param_1 + 8); iVar7 = iVar7 + 1) {
        if (*(char *)(iVar1 + 8) == '\x01') {
          uVar2 = func_0x0000a1fc(param_1[0xf],*(undefined4 *)(iVar1 + 0x14));
          *(undefined4 *)(iVar1 + 0x14) = uVar2;
          if (*(int *)(iVar1 + 0x14) == 0) {
            iVar1 = param_1[1];
            for (iVar8 = 0; iVar8 < iVar7; iVar8 = iVar8 + 1) {
              if (*(char *)(iVar1 + 8) == '\x01') {
                func_0x0000a254(param_1[0xf],*(undefined4 *)(iVar1 + 0x14));
              }
              iVar1 = iVar1 + 0x28;
            }
            func_0x00006bc8(*(undefined4 *)(*param_1 + 0xc));
            func_0x00006bc8(*param_1);
            return 1;
          }
        }
        iVar1 = iVar1 + 0x28;
      }
      uVar2 = 0;
    }
  }
  return uVar2;
}

