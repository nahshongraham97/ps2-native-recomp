
undefined4 FUN_00008b54(int *param_1)

{
  ushort uVar1;
  int iVar2;
  
  uVar1 = *(ushort *)((int)param_1 + 0x1e);
  iVar2 = param_1[0xf];
  func_0x0000a7d8(iVar2 + 0x3ac);
  if ((param_1 != (int *)0x0) && (*param_1 != 0)) {
    func_0x000087ec(param_1,uVar1 & 1);
  }
  func_0x0000a7e4(iVar2 + 0x3ac);
  return 0;
}

