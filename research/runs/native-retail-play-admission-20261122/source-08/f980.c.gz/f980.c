
int FUN_0000f980(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  iVar3 = 0;
  func_0x0000a7d8(0x4904c);
  if ((iRam00048e60 != 0) &&
     (iVar2 = func_0x0000f278(0,*(undefined4 *)(iRam00048e60 + 0x14)), iVar2 == param_1)) {
    iVar3 = 2;
  }
  if (iVar3 == 0) {
    piVar1 = piRam00048e58;
    piVar5 = (int *)0x48e58;
    while (piVar4 = piVar1, piVar4 != (int *)0x0) {
      iVar2 = func_0x0000f278(0,piVar4[5]);
      if (iVar2 == param_1) {
        iVar3 = 1;
        if (piVar4 != piRam00048e58) {
          iVar2 = *piVar4;
          *piVar5 = iVar2;
          if (iVar2 == 0) {
            piRam00048e5c = piVar5;
          }
          *piVar4 = (int)piRam00048e58;
          piRam00048e58 = piVar4;
          func_0x0000f278(0,piVar4[5]);
          func_0x0000f318(0x248b4,piVar4[5]);
          piVar4 = piVar5;
        }
        piVar1 = (int *)0x0;
        piVar5 = piVar4;
      }
      else {
        piVar1 = (int *)*piVar4;
        piVar5 = piVar4;
      }
    }
  }
  func_0x0000a7e4(0x4904c);
  return iVar3;
}

