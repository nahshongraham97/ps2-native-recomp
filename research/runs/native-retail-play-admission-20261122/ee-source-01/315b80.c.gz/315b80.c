
void FUN_00315b80(long param_1)

{
  long lVar1;
  
  if (param_1 != 0) {
    lVar1 = FUN_00316620(2,0,0);
    if (lVar1 != 0) {
      *(undefined4 *)lVar1 = 0x32;
      ((undefined4 *)lVar1)[1] = (int)param_1;
      FUN_003165e0();
    }
  }
  return;
}

