
undefined4 FUN_00007fa0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  func_0x0000a7d8(iRam000248e0 + 0x3ac);
  iVar1 = func_0x0000f278(0,param_1);
  iVar2 = func_0x00007d28(iVar1,*(undefined2 *)(iVar1 + 0x1e));
  if (iVar2 < 0) {
    func_0x0000a7e4(iRam000248e0 + 0x3ac);
    uVar3 = 0;
  }
  else {
    func_0x00007ea0(iVar1);
    if ((*(ushort *)(iVar1 + 0x1e) & 8) == 0) {
      func_0x00007f00(param_1);
    }
    else {
      func_0x0000f344(*(int *)(iVar1 + 0x3c) + 0x278,param_1);
      FUN_00003a38(iVar1,*(undefined4 *)(iVar1 + 4));
    }
    if ((*(int *)(*(int *)(iVar1 + 0x3c) + 0x2a8) != 0) && ((*(ushort *)(iVar1 + 0x1e) & 8) == 0)) {
      FUN_000046f8();
    }
    func_0x0000a7e4(iRam000248e0 + 0x3ac);
    uVar3 = 1;
  }
  return uVar3;
}

