
undefined4 FUN_00000e28(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  iVar1 = *param_2;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    puVar4 = *(undefined4 **)(iVar1 + 0xc);
    for (iVar1 = *(int *)(iVar1 + 8); iVar1 != 0; iVar1 = iVar1 + -1) {
      if (*(char *)(puVar4 + 2) == '\x01') {
        piVar3 = (int *)func_0x0000265c(param_1,*puVar4);
        if (piVar3 == (int *)0x0) {
          return 0;
        }
        if ((*piVar3 == 0) && ((piVar3[8] & 1U) == 0)) {
          return 0;
        }
      }
      puVar4 = puVar4 + 10;
    }
    uVar2 = 1;
  }
  return uVar2;
}

