
void FUN_002209a0(undefined8 param_1)

{
  thunk_FUN_004293f0(param_1,0,0);
  return;
}

