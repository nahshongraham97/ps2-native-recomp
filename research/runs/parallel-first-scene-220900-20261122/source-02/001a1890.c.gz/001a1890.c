
undefined4 FUN_001a1890(long param_1)

{
  undefined4 uVar1;
  long lVar2;
  undefined4 *puVar3;
  
  puGpffffa398 = (undefined1 *)&puGpffffa398;
  uGpffffa390 = 1;
  puGpffffa39c = puGpffffa398;
  lVar2 = FUN_001a0e00(0x24,0x10,0x10,0,0x69f1a0,0x40000);
  iGpffffa394 = (int)lVar2;
  if (lVar2 == 0) {
    uGpffffa390 = 0;
    uVar1 = 0;
  }
  else {
    **(undefined4 **)(iGpffffa394 + 0x20) = *(undefined4 *)(iGpffffa394 + 0x1c);
    *(undefined4 *)(*(int *)(iGpffffa394 + 0x1c) + 4) = *(undefined4 *)(iGpffffa394 + 0x20);
    if (param_1 == 0) {
      puRam0069f3c4 = &LAB_001a1860;
      pcRam0069f3c8 = FUN_001dada0;
      puRam0069f3cc = &LAB_001a1870;
      puRam0069f3d0 = &LAB_001a1880;
    }
    else {
      puVar3 = (undefined4 *)param_1;
      puRam0069f3c4 = (undefined1 *)*puVar3;
      pcRam0069f3c8 = (code *)puVar3[1];
      puRam0069f3cc = (undefined1 *)puVar3[2];
      puRam0069f3d0 = (undefined1 *)puVar3[3];
    }
    uVar1 = 1;
  }
  return uVar1;
}

