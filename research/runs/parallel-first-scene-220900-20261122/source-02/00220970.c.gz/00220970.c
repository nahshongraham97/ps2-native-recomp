
void FUN_00220970(undefined8 param_1,undefined8 param_2)

{
  FUN_00429c50(uGpffffab50,param_1,param_2,3,0,0,0);
  return;
}

