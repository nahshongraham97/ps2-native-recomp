
void FUN_002209b0(undefined8 param_1)

{
  FUN_00429d20(uGpffffab50,param_1,3,0,0,0);
  return;
}

