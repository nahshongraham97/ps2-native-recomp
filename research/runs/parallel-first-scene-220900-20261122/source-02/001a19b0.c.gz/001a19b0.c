
void FUN_001a19b0(void)

{
  int iVar1;
  
  if ((int **)piGpffffa398 != &piGpffffa398) {
    iVar1 = *piGpffffa398;
    while( true ) {
      *(int *)piGpffffa398[1] = iVar1;
      *(int *)(*piGpffffa398 + 4) = piGpffffa398[1];
      FUN_001a0fe0(piGpffffa398 + -7);
      if ((int **)piGpffffa398 == &piGpffffa398) break;
      iVar1 = *piGpffffa398;
    }
  }
  **(undefined4 **)(iGpffffa394 + 0x20) = *(undefined4 *)(iGpffffa394 + 0x1c);
  *(undefined4 *)(*(int *)(iGpffffa394 + 0x1c) + 4) = *(undefined4 *)(iGpffffa394 + 0x20);
  FUN_001a0fe0();
  iGpffffa394 = 0;
  uGpffffa390 = 0;
  return;
}

