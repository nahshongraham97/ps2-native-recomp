
void FUN_00220950(undefined8 param_1,undefined8 param_2)

{
  FUN_00429a90(param_1,uGpffffab50,param_2,3,0,0,0);
  return;
}

