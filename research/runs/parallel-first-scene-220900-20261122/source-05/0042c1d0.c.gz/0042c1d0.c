
int FUN_0042c1d0(long param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = (int)param_1;
  iVar1 = 0;
  if (param_1 != 0) {
    iVar1 = (*(int *)(iVar2 + 8) - (uint)*(byte *)(iVar2 + 0xc)) - (uint)*(byte *)(iVar2 + 0xf);
  }
  return iVar1;
}

