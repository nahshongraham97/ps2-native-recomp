
long FUN_004295b0(undefined8 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uVar4;
  undefined4 *puVar5;
  long lVar6;
  
  puVar5 = (undefined4 *)param_1;
  iVar1 = puVar5[5];
  if (*(int *)(iVar1 + 0x1c) != -0x41544155) {
    return 0;
  }
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined1 *)(puVar5 + 3) = 0;
  puVar5[2] = 0;
  puVar5[4] = 0;
  puVar5[6] = 0;
  if (*(code **)(iVar1 + 0x18) == (code *)0x0) {
    iVar3 = *(int *)(iVar1 + 0x14);
    if (iVar3 == 0x7fffffff) {
      lVar6 = 0;
    }
    else {
      if (iVar3 == 4) {
        uVar2 = puVar5[7];
      }
      else {
        if (((iVar3 != 3) && (iVar3 != 1)) && (iVar3 != 0)) {
          if (iVar3 == 5) {
            lVar6 = FUN_0042b140(puVar5[7],iVar1,puVar5[0xb],param_1);
          }
          else if (iVar3 == 2) {
            lVar6 = FUN_0042a750(puVar5[7],iVar1,puVar5[0xb],param_1);
          }
          else {
            lVar6 = 0;
          }
          goto LAB_004296dc;
        }
        uVar2 = puVar5[7];
      }
      lVar6 = FUN_0042bb00(uVar2,iVar1,puVar5[0xb],param_1);
    }
  }
  else {
    uGpffffb138 = 1;
    lVar6 = (**(code **)(iVar1 + 0x18))(puVar5[7],iVar1,puVar5[0xb],param_1);
    uGpffffb138 = 0;
  }
LAB_004296dc:
  if ((lVar6 == 0) && (*(char *)(iVar1 + 0x6c) != '\0')) {
    FUN_00428870(param_1,0);
    *(undefined1 *)(iVar1 + 0x2d) = 1;
    if (*(int *)(iGpffffb12c + 0x1c) == -0x41544155) {
      lVar6 = FUN_0042bb00(puVar5[7],iGpffffb12c,puVar5[0xb],param_1);
    }
  }
  if (lVar6 != 0) {
    iVar1 = puVar5[4];
    iVar3 = *(int *)(iVar1 + 0x14);
    if (iVar3 == 0x7fffffff) {
      iVar3 = 0;
    }
    else if (((iVar3 == 4) || (iVar3 == 3)) || ((iVar3 == 1 || (iVar3 == 0)))) {
      uVar4 = FUN_0042c1a0(lVar6);
      iVar3 = FUN_0042c1b0(uVar4);
    }
    else if (iVar3 == 2) {
      iVar3 = *(int *)(iVar1 + 100) + (uint)*(byte *)(iVar1 + 0x79) + 0x10;
    }
    else if (iVar3 == 5) {
      iVar3 = *(int *)(iVar1 + 100) + (uint)*(byte *)(iVar1 + 0x79);
    }
    else {
      iVar3 = 0;
    }
    FUN_0042c2c0(iVar1,iVar3);
  }
  return lVar6;
}

