
void FUN_004293f0(uint param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined8 uVar4;
  int iVar5;
  
  if (param_1 == 0) {
    return;
  }
  iVar5 = 0;
  iVar3 = *DAT_005ed160;
  uVar2 = *(uint *)(iVar3 + 0x38);
  do {
    if ((param_1 < uVar2) || (*(uint *)(iVar3 + 0x3c) <= param_1)) {
      iVar3 = *(int *)(iVar3 + 0x28);
    }
    else {
      piVar1 = (int *)(iVar3 + 0x24);
      iVar5 = iVar3;
      iVar3 = *piVar1;
      if (*piVar1 == 0) {
LAB_00429460:
        iVar3 = *(int *)(iVar5 + 0x14);
        if (iVar3 == 0x7fffffff) {
          iVar3 = 0;
        }
        else if ((((iVar3 == 4) || (iVar3 == 3)) || (iVar3 == 1)) || (iVar3 == 0)) {
          uVar4 = FUN_0042c1a0(param_1);
          iVar3 = FUN_0042c1b0(uVar4);
        }
        else if (iVar3 == 2) {
          iVar3 = *(int *)(iVar5 + 100) + (uint)*(byte *)(iVar5 + 0x79) + 0x10;
        }
        else if (iVar3 == 5) {
          iVar3 = *(int *)(iVar5 + 100) + (uint)*(byte *)(iVar5 + 0x79);
        }
        else {
          iVar3 = 0;
        }
        FUN_0042c270(iVar5,iVar3);
        iVar3 = *(int *)(iVar5 + 0x14);
        if (iVar3 == 0x7fffffff) {
          return;
        }
        if (((iVar3 == 4) || (iVar3 == 3)) || ((iVar3 == 1 || (iVar3 == 0)))) {
          FUN_0042ba50(param_1);
          return;
        }
        if (iVar3 == 2) {
          FUN_0042a6a0(iVar5,param_1);
          return;
        }
        if (iVar3 != 5) {
          return;
        }
        FUN_0042b090(iVar5,param_1);
        return;
      }
    }
    if (iVar3 == 0) goto LAB_00429460;
    uVar2 = *(uint *)(iVar3 + 0x38);
  } while( true );
}

