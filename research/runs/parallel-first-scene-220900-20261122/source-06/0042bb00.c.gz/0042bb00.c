
uint FUN_0042bb00(int param_1,undefined8 param_2,undefined8 param_3,undefined4 *param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  long lVar7;
  long lVar8;
  int iVar9;
  undefined4 *puVar10;
  int iVar11;
  
  bVar3 = false;
  if (param_1 == 0) {
    param_1 = 0x10;
  }
  lVar7 = FUN_0042c080(param_3);
  lVar8 = FUN_0042c220(lVar7);
  if (lVar8 == 0) {
    lVar7 = 4;
  }
  uVar2 = param_1 + 0xfU & 0xfffffff0;
  uVar6 = uVar2;
  if ((lVar7 != 4) && (lVar7 != 0)) {
    uVar6 = param_1 + (1 << ((uint)lVar7 & 0x1f)) + 0xfU & 0xfffffff0;
  }
  iVar11 = (int)param_2;
  if (*(int *)(iVar11 + 0xc) == 0) {
    return 0;
  }
  if (*(int *)(iVar11 + 0x14) == 3) {
    puVar5 = (undefined4 *)FUN_0042b9f0(param_2,uVar6);
  }
  else {
    lVar8 = FUN_0042c070(param_3);
    if (lVar8 == 0) {
      puVar10 = *(undefined4 **)(iVar11 + 0x10);
      puVar5 = (undefined4 *)0x0;
      if (puVar10 != (undefined4 *)0x0) {
        uVar1 = puVar10[2];
        puVar5 = puVar10;
        while ((uVar1 < uVar6 &&
               (puVar10 = (undefined4 *)*puVar5, puVar5 = (undefined4 *)0x0,
               puVar10 != (undefined4 *)0x0))) {
          uVar1 = puVar10[2];
          puVar5 = puVar10;
        }
      }
    }
    else {
      puVar10 = *(undefined4 **)(iVar11 + 0xc);
      puVar5 = (undefined4 *)0x0;
      if (puVar10 != (undefined4 *)0x0) {
        uVar1 = puVar10[2];
        puVar5 = puVar10;
        while ((uVar1 < uVar6 &&
               (puVar10 = (undefined4 *)puVar5[1], puVar5 = (undefined4 *)0x0,
               puVar10 != (undefined4 *)0x0))) {
          uVar1 = puVar10[2];
          puVar5 = puVar10;
        }
      }
      bVar3 = true;
    }
  }
  if (puVar5 == (undefined4 *)0x0) {
    return 0;
  }
  uVar1 = puVar5[2];
  cVar4 = (char)uVar6;
  if (uVar6 + 0x20 < uVar1) {
    if (bVar3) {
      iVar9 = (int)puVar5 + uVar6 + 0x10;
      FUN_0042b800(param_2,puVar5,iVar9);
      *(undefined1 *)(iVar9 + 0xc) = 0;
      *(uint *)(iVar9 + 8) = puVar5[2] - (uVar6 + 0x10);
      *(undefined1 *)(iVar9 + 0xd) = *(undefined1 *)((int)puVar5 + 0xd);
      *(undefined1 *)(iVar9 + 0xe) = *(undefined1 *)((int)puVar5 + 0xe);
      *(undefined1 *)(iVar9 + 0xf) = *(undefined1 *)((int)puVar5 + 0xf);
      FUN_0042c060(iVar9 + 0xe);
      FUN_0042bfe0(iVar9 + 0xe,4);
      FUN_0042c200(iVar9);
      FUN_0042c060((int)puVar5 + 0xe);
      FUN_0042bfe0((int)puVar5 + 0xe,4);
      FUN_0042bfe0((int)puVar5 + 0xe,5);
    }
    else {
      puVar10 = (undefined4 *)((int)puVar5 + (uVar1 - uVar6));
      puVar5[2] = uVar1 - (uVar6 + 0x10);
      FUN_0042bfe0((int)puVar5 + 0xe,4);
      FUN_0042c200(puVar5);
      FUN_0042c060((int)puVar10 + 0xe);
      FUN_0042c010((int)puVar10 + 0xe,4);
      FUN_0042bfe0((int)puVar10 + 0xe,5);
      puVar5 = puVar10;
      if ((int)puVar10 + uVar6 + 0x10 != *(int *)(iVar11 + 0x3c)) {
        FUN_0042bfe0((int)puVar10 + uVar6 + 0x1e,4);
      }
    }
  }
  else {
    FUN_0042b7a0(param_2,puVar5);
    uVar6 = puVar5[2];
    FUN_0042c060((int)puVar5 + 0xe);
    FUN_0042bfe0((int)puVar5 + 0xe,4);
    FUN_0042bfe0((int)puVar5 + 0xe,5);
    if (*(int *)(iVar11 + 0x3c) == (int)puVar5 + uVar6 + 0x10) {
      cVar4 = (char)uVar6 - cVar4;
      goto LAB_0042bdd0;
    }
    FUN_0042bfe0((int)puVar5 + uVar6 + 0x1e,4);
  }
  cVar4 = (char)uVar6 - cVar4;
LAB_0042bdd0:
  puVar5[2] = uVar6;
  *(char *)(puVar5 + 3) = cVar4;
  FUN_0042c040((int)puVar5 + 0xe,lVar7);
  *(undefined1 *)((int)puVar5 + 0xd) = *(undefined1 *)(param_4[5] + 0x2c);
  if (*(int *)(iVar11 + 8) == 0) {
    puVar5[1] = 0;
    *puVar5 = 0;
    *(undefined4 **)(iVar11 + 8) = puVar5;
  }
  else {
    puVar5[1] = *(int *)(iVar11 + 8);
    *puVar5 = 0;
    **(undefined4 **)(iVar11 + 8) = puVar5;
    *(undefined4 **)(iVar11 + 8) = puVar5;
  }
  uVar6 = (1 << ((uint)lVar7 & 0x1f)) - 1;
  uVar6 = ~uVar6 & (int)(puVar5 + 4) + uVar6;
  cVar4 = (char)uVar6 - (char)(puVar5 + 4);
  *(char *)((int)puVar5 + 0xf) = cVar4;
  *param_4 = puVar5[2];
  *(undefined1 *)(param_4 + 3) = *(undefined1 *)((int)puVar5 + 0xf);
  param_4[2] = (int)param_3;
  param_4[4] = iVar11;
  param_4[6] = (uint)*(byte *)(puVar5 + 3);
  param_4[1] = uVar2;
  *(char *)(uVar6 - 1) = cVar4;
  return uVar6;
}

