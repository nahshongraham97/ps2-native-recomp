
long FUN_001a6dd0(undefined8 param_1,ulong param_2,undefined4 param_3)

{
  long lVar1;
  
  if ((param_2 & 1) == 0) {
    pcRam0069f3d4 = FUN_001a1180;
    pcRam0069f3d8 = FUN_001a1340;
    FUN_001a0df0(1);
  }
  else {
    pcRam0069f3d4 = (code *)&LAB_001a6890;
    pcRam0069f3d8 = (code *)&LAB_001a68b0;
    FUN_001a0df0(0);
  }
  uRam0069f3e4 = param_3;
  if ((iRam0069f3e0 == 0) && (lVar1 = FUN_001a40b0(), lVar1 != 0)) {
    lVar1 = FUN_001a1890(param_1);
    if (lVar1 != 0) {
      lVar1 = FUN_0019f5b0();
      if (lVar1 != 0) {
        lVar1 = FUN_001a2f40();
        if (lVar1 != 0) {
          lVar1 = FUN_001a66a0();
          if ((lVar1 != 0) && (lVar1 = FUN_001b72b0(), lVar1 != 0)) {
            iRam0069f3e0 = 1;
            return lVar1;
          }
          FUN_001a2fd0();
        }
        FUN_0019f670();
      }
      FUN_001a19b0();
    }
    FUN_001a41d0();
  }
  return 0;
}

