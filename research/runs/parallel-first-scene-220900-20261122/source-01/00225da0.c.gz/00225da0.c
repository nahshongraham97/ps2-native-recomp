
void FUN_00225da0(void)

{
  uRam0064e0dc = 1;
  return;
}

