
void FUN_00225d40(void)

{
  puRam0064e4fc = &LAB_00225d50;
  return;
}

