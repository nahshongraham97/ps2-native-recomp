
undefined4 FUN_00220900(void)

{
  puRam006aa750 = &LAB_002209b0;
  puRam006aa754 = &LAB_002209a0;
  puRam006aa758 = &LAB_00220950;
  puRam006aa75c = &LAB_00220970;
  return 0x6aa750;
}

