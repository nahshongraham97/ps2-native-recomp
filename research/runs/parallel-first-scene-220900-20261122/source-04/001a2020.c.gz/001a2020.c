
undefined4 FUN_001a2020(undefined8 param_1)

{
  int iVar1;
  undefined4 uVar2;
  long lVar3;
  undefined4 *puVar4;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  iVar1 = iGpffffa3a0;
  if (iGpffffa3a4 == 0) {
    uVar2 = 1;
    uRam0069f3e4 = (int)param_1;
  }
  else {
    puVar4 = (undefined4 *)(iGpffffa3a0 + 0x69f290);
    *puVar4 = (int)param_1;
    FUN_001a2130();
    FUN_001a3c40(*(undefined4 *)(iVar1 + 0x69f29c));
    (*pcRam0069f3c8)(*(undefined4 *)(iVar1 + 0x69f29c));
    lVar3 = (*pcRam0069f3c4)(param_1,0x3040b);
    *(int *)(iVar1 + 0x69f29c) = (int)lVar3;
    if (lVar3 == 0) {
      uStack_8 = 1;
      *puVar4 = 0;
      uStack_4 = FUN_0019f510(0xffffffff80000013,param_1);
      FUN_0019f460(&uStack_8);
      uVar2 = 0;
    }
    else {
      lVar3 = FUN_001a3be0(lVar3,param_1);
      if (lVar3 == 0) {
        (*pcRam0069f3c8)(*(undefined4 *)(iVar1 + 0x69f29c));
        uStack_10 = 1;
        uStack_c = FUN_0019f510(0xc,0);
        FUN_0019f460(&uStack_10);
        uVar2 = 0;
      }
      else {
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

