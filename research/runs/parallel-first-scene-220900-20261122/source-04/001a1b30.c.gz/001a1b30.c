
undefined8 FUN_001a1b30(undefined8 param_1,int param_2)

{
  long lVar1;
  
  iGpffffa3a0 = param_2;
  lVar1 = FUN_001a1a30(param_2 + 0x69f290,uRam0069f3e4);
  if (lVar1 == 0) {
    param_1 = 0;
  }
  else {
    iGpffffa3a4 = iGpffffa3a4 + 1;
  }
  return param_1;
}

