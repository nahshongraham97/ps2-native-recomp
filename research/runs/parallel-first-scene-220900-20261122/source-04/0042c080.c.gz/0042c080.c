
undefined4 FUN_0042c080(uint param_1)

{
  param_1 = param_1 & 0xffffff8f;
  if (param_1 == 0x10) {
    return 4;
  }
  if ((((param_1 != 0x7fffffff) && (param_1 != 0x40)) && (param_1 != 0x20)) &&
     ((param_1 != 3 && (param_1 != 0)))) {
    if (param_1 == 0x80) {
      return 0;
    }
    if (param_1 == 2) {
      return 8;
    }
    if (param_1 == 8) {
      return 8;
    }
    if (param_1 == 7) {
      return 7;
    }
    if (param_1 == 6) {
      return 6;
    }
    if (param_1 == 5) {
      return 5;
    }
    if (param_1 == 4) {
      return 4;
    }
    if (param_1 == 1) {
      return 4;
    }
  }
  return 4;
}

