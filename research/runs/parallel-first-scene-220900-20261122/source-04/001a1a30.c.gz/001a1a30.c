
undefined8 FUN_001a1a30(undefined8 param_1,long param_2)

{
  long lVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  puVar4 = (undefined4 *)param_1;
  if (param_2 == 0) {
    puVar4[3] = 0;
  }
  else {
    lVar1 = (*pcRam0069f3c4)(param_2,0x4040b);
    puVar4[3] = (int)lVar1;
    if (lVar1 == 0) {
      uStack_8 = 1;
      uStack_4 = FUN_0019f510(0xffffffff80000013,param_2);
      FUN_0019f460(&uStack_8);
      return 0;
    }
    lVar1 = FUN_001a3be0(lVar1,param_2);
    if (lVar1 == 0) {
      (*pcRam0069f3c8)(puVar4[3]);
      uStack_10 = 1;
      uStack_c = FUN_0019f510(0xc,0);
      FUN_0019f460(&uStack_10);
      return 0;
    }
  }
  puVar3 = puVar4 + 4;
  puVar2 = puVar4 + 6;
  puVar4[4] = puVar3;
  puVar4[5] = puVar3;
  puVar4[6] = puVar2;
  puVar4[7] = puVar2;
  puVar4[9] = puVar3;
  puVar4[8] = puVar2;
  *puVar4 = (int)param_2;
  puVar4[1] = 0;
  puVar4[2] = 0;
  return param_1;
}

