
long FUN_00429a90(uint param_1,undefined4 param_2,uint param_3,undefined8 param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  uint uVar2;
  long lVar3;
  undefined8 uVar4;
  int iVar5;
  int iVar6;
  undefined1 auStack_30 [20];
  undefined4 uStack_1c;
  uint uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uStack_4 = (undefined4)param_4;
  uStack_1c = param_2;
  uStack_14 = param_3;
  uStack_10 = param_5;
  uStack_c = param_6;
  uStack_8 = param_7;
  FUN_0042c080(param_4);
  if (param_1 == 0) {
    lVar3 = FUN_004295b0(auStack_30);
    if (lVar3 == 0) {
      FUN_004288f0(auStack_30,3,0);
    }
  }
  else {
    if (param_3 != 0) {
      iVar6 = 0;
      iVar5 = *DAT_005ed160;
      uVar2 = *(uint *)(iVar5 + 0x38);
      do {
        if ((param_1 < uVar2) || (*(uint *)(iVar5 + 0x3c) <= param_1)) {
          iVar5 = *(int *)(iVar5 + 0x28);
        }
        else {
          piVar1 = (int *)(iVar5 + 0x24);
          iVar6 = iVar5;
          iVar5 = *piVar1;
          if (*piVar1 == 0) {
LAB_00429b68:
            if (*(int *)(iVar6 + 0x14) == 5) {
              uVar2 = *(uint *)(iVar6 + 100);
            }
            else if (*(int *)(iVar6 + 0x14) == 2) {
              uVar2 = *(uint *)(iVar6 + 100);
            }
            else {
              uVar4 = FUN_0042c1a0(param_1);
              uVar2 = FUN_0042c1d0(uVar4);
            }
            lVar3 = FUN_004295b0(auStack_30);
            if (lVar3 == 0) {
              FUN_004288f0(auStack_30,3,param_1);
              return 0;
            }
            if (param_3 <= uVar2) {
              uVar2 = param_3;
            }
            lVar3 = FUN_001db8a8(lVar3,param_1,uVar2);
            FUN_004293f0(param_1,0x63ffc8,0x87f);
            return lVar3;
          }
        }
        if (iVar5 == 0) goto LAB_00429b68;
        uVar2 = *(uint *)(iVar5 + 0x38);
      } while( true );
    }
    lVar3 = 0;
    FUN_004293f0(param_1,0x63ffc8,0x890);
  }
  return lVar3;
}

