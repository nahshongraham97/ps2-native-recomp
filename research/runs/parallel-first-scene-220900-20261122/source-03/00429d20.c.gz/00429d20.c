
long FUN_00429d20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  long lVar1;
  undefined1 auStack_30 [20];
  undefined4 uStack_1c;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uStack_1c = param_1;
  uStack_14 = param_2;
  uStack_10 = param_4;
  uStack_c = param_5;
  uStack_8 = param_6;
  uStack_4 = param_3;
  lVar1 = FUN_004295b0(auStack_30);
  if (lVar1 == 0) {
    FUN_004288f0(auStack_30,1,0);
  }
  return lVar1;
}

