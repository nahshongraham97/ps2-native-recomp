
undefined8
FUN_00429c50(undefined4 param_1,int param_2,int param_3,undefined8 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  long lVar1;
  undefined8 uVar2;
  uint uVar3;
  undefined1 auStack_30 [20];
  undefined4 uStack_1c;
  uint uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uStack_4 = (undefined4)param_4;
  param_2 = param_2 * param_3;
  uStack_1c = param_1;
  uStack_14 = param_2;
  uStack_10 = param_5;
  uStack_c = param_6;
  uStack_8 = param_7;
  lVar1 = FUN_0042c080(param_4);
  if (lVar1 != 4) {
    param_2 = param_2 + (1 << ((uint)lVar1 & 0x1f));
  }
  uVar3 = param_2 + 0xfU & 0xfffffff0;
  uStack_14 = uVar3;
  lVar1 = FUN_004295b0(auStack_30);
  if (lVar1 == 0) {
    FUN_004288f0(auStack_30,2,0);
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_001dba60(lVar1,0,uVar3);
  }
  return uVar2;
}

