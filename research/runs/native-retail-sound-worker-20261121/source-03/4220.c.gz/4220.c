
int FUN_00004220(int param_1,int param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int aiStackX_4 [3];
  
  uVar5 = 0;
  aiStackX_4[0] = param_2;
  if ((*(byte *)(param_2 + 0xc) & 3) == 0) {
    func_0x0000f424(aiStackX_4);
  }
  else {
    piVar1 = (int *)func_0x0000f278(0);
    func_0x0000f424(aiStackX_4);
    piRam00010c50 = piVar1;
    if (piVar1[9] == 0) {
      while ((iVar4 = piVar1[1], iVar4 != 0 &&
             (((uint)piVar1[2] <= param_3 || (((int)*(char *)(iVar4 + 8) & 0x80U) != 0))))) {
        switch(*(undefined1 *)(iVar4 + 8)) {
        case 1:
          iVar4 = func_0x00003a38(piVar1);
          if (iVar4 != 0) {
            uVar7 = *(undefined4 *)(param_1 + 0x2a8);
            *(undefined4 *)(param_1 + 0x2a8) = 0;
            func_0x00008b54(piVar1);
            *(undefined4 *)(param_1 + 0x2a8) = uVar7;
          }
          break;
        case 2:
          func_0x00003bc4(piVar1,iVar4,param_3);
          break;
        case 6:
          if ((*(short *)(iVar4 + 10) == 0) ||
             (iVar2 = *(int *)(iVar4 + 0x10) + 1, *(int *)(iVar4 + 0x10) = iVar2,
             iVar2 < *(short *)(iVar4 + 10))) {
            iVar4 = (piVar1[1] - *(int *)(*piVar1 + 0xc)) / 0x28;
            while (iVar4 = func_0x00004c50(*piVar1,iVar4 + -1,5), -1 < iVar4) {
              puVar6 = (undefined4 *)(*(int *)(*piVar1 + 0xc) + iVar4 * 0x28);
              iVar2 = func_0x0000a7f0(*puVar6,*(undefined4 *)piVar1[1]);
              if (iVar2 == 0) {
                if (((int)((undefined4 *)piVar1[1])[6] < 1) && ((int)puVar6[6] < 1)) {
                  uVar5 = 1;
                  for (puVar3 = puVar6; puVar3 != (undefined4 *)piVar1[1]; puVar3 = puVar3 + 10) {
                    if (0 < (int)puVar3[6]) {
                      uVar5 = 0;
                      break;
                    }
                  }
                }
                piVar1[1] = (int)puVar6;
              }
            }
            if (iVar4 < 0) {
              *(undefined4 *)(piVar1[1] + 0x10) = 0;
            }
          }
          else {
            *(undefined4 *)(piVar1[1] + 0x10) = 0;
          }
          break;
        case 7:
          uVar7 = *(undefined4 *)(param_1 + 0x2a8);
          *(undefined4 *)(param_1 + 0x2a8) = 0;
          piVar1[1] = 0;
          func_0x00008b54(piVar1);
          *(undefined4 *)(param_1 + 0x2a8) = uVar7;
          piVar1 = (int *)0x0;
          break;
        case 8:
          func_0x00003b38(piVar1);
        }
        if (piVar1 == (int *)0x0) {
          return aiStackX_4[0];
        }
        if (piRam00010c50 == (int *)0x0) {
          return aiStackX_4[0];
        }
        iVar4 = func_0x00004180(piVar1,uVar5);
        if (iVar4 != 0) {
          return aiStackX_4[0];
        }
      }
    }
    else {
      iVar4 = piVar1[1];
      if (((((iVar4 != 0) && (iVar4 == *(int *)(*piVar1 + 0xc))) && (*(char *)(iVar4 + 8) == '\x01')
           ) && ((*(int *)(iVar4 + 0x18) < 1 && (*(int *)(iVar4 + 0x14) != 0)))) &&
         ((*(ushort *)(*(int *)(iVar4 + 0x14) + 0xc) & 2) != 0)) {
        iVar4 = func_0x00003a38(piVar1);
        if (iVar4 == 0) {
          func_0x0000a3e4(param_1,*(undefined4 *)(piVar1[1] + 0x14));
          func_0x00004180(piVar1,0);
        }
        else {
          uVar5 = *(undefined4 *)(param_1 + 0x2a8);
          *(undefined4 *)(param_1 + 0x2a8) = 0;
          func_0x00008b54(piVar1);
          *(undefined4 *)(param_1 + 0x2a8) = uVar5;
        }
      }
    }
  }
  return aiStackX_4[0];
}

