
void FUN_00008cf0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined2 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  
  uVar7 = *(undefined4 *)(param_1 + 0x2a8);
  uVar4 = 0;
  iVar6 = 0;
  *(undefined4 *)(param_1 + 0x2a8) = 0;
  do {
    if ((int)(uint)*(ushort *)(param_1 + 0x264) <= iVar6) {
      *(undefined4 *)(param_1 + 0x2a8) = uVar7;
      return;
    }
    iVar3 = iVar6 * 8;
    iVar5 = *(int *)(*(int *)(param_1 + 0x268) + iVar3);
    if (iVar5 == 0) {
LAB_00008d64:
      iVar5 = func_0x0000f61c(*(undefined4 *)(*(int *)(param_1 + 0x268) + iVar3 + 4));
      if ((iVar5 != 0) && (iVar1 = func_0x000013ac(iVar5,param_1,0), iVar1 != 0)) {
        iVar2 = func_0x0000f278(0,iVar1);
        *(ushort *)(iVar2 + 0x1e) = *(ushort *)(iVar2 + 0x1e) | 1;
        *(ushort *)(iVar2 + 0x1e) = *(ushort *)(iVar2 + 0x1e) | 0x8000;
        *(undefined2 *)(iVar2 + 0x10) = uVar4;
        *(short *)(iVar2 + 0xc) = (short)iVar6;
        *(int *)(*(int *)(param_1 + 0x268) + iVar3) = iVar2;
        func_0x00000ee8(param_1,*(undefined4 *)(iVar5 + 8),iVar5,0x1090,iVar1);
      }
    }
    else {
      iVar1 = func_0x00008bc8(iVar5);
      if (iVar1 == 0) {
        uVar4 = *(undefined2 *)(iVar5 + 0x10);
        func_0x00008b54(iVar5);
        goto LAB_00008d64;
      }
    }
    iVar6 = iVar6 + 1;
  } while( true );
}

