
undefined4 FUN_00002450(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int in_t1;
  int in_t2;
  int *piVar6;
  int unaff_s0;
  int iStack00000024;
  
  *(int *)(param_1 + 0x20) = unaff_s0 + *(int *)(param_1 + 0x20);
  *(int *)(param_1 + 0x24) = unaff_s0 + *(int *)(param_1 + 0x24);
  *(int *)(param_1 + 0x28) = unaff_s0 + *(int *)(param_1 + 0x28);
  iStack00000024 = *(int *)(param_1 + 0x28);
  iVar3 = *(int *)(param_1 + 0x18);
  iVar1 = *(int *)(param_1 + 0x1c);
  piVar4 = *(int **)(param_1 + 0x14);
  for (; param_3 < *(short *)(unaff_s0 + 10); param_3 = param_3 + 1) {
    *piVar4 = iVar3;
    iVar3 = iVar3 + 0x10;
    *(int *)(*piVar4 + 0xc) = iVar1;
    piVar6 = *(int **)(*piVar4 + 0xc);
    iVar1 = iVar1 + *(int *)(*piVar4 + 8) * 0x28;
    for (iVar5 = 0; iVar5 < *(int *)(*piVar4 + 8); iVar5 = iVar5 + 1) {
      if (*piVar6 == in_t2) {
        *piVar6 = 0;
      }
      else if ((((*(uint *)(unaff_s0 + 4) & 0x10) == 0) || ((char)piVar6[2] == in_t1)) ||
              ((char)piVar6[2] == 6)) {
        *piVar6 = iStack00000024 + *piVar6;
      }
      piVar6 = piVar6 + 10;
    }
    piVar4 = piVar4 + 4;
  }
  if ((*(uint *)(unaff_s0 + 4) & 0x10) == 0) {
    iVar3 = *(int *)(unaff_s0 + 0x10);
    for (iVar1 = 0; iVar1 < *(short *)(unaff_s0 + 8); iVar1 = iVar1 + 1) {
      uVar2 = func_0x000025d8(&stack0x00000024,*(undefined4 *)(iVar3 + 8),
                              *(undefined4 *)(unaff_s0 + 4));
      *(undefined4 *)(iVar3 + 8) = uVar2;
      iVar3 = iVar3 + 0x24;
    }
  }
  return 0;
}

