
void FUN_000046c8(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = (int *)param_1[1];
  iVar2 = *param_1;
  if (piVar1 != (int *)0x0) {
    *piVar1 = iVar2;
    param_1[1] = 0;
  }
  if (iVar2 != 0) {
    *(int **)(iVar2 + 4) = piVar1;
    *param_1 = 0;
  }
  return;
}

