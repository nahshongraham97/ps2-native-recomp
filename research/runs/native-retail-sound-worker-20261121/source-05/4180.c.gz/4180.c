
undefined4 FUN_00004180(int *param_1,undefined4 param_2)

{
  uint uVar1;
  
  if (param_1[1] != 0) {
    param_1[1] = param_1[1] + 0x28;
    uVar1 = param_1[1];
    if (uVar1 < (uint)(*(int *)(*param_1 + 0xc) + *(int *)(*param_1 + 8) * 0x28)) {
      if (((int)*(char *)(uVar1 + 8) & 0x80U) != 0) {
        return param_2;
      }
      if (*(int *)(uVar1 + 0x18) < 0) {
        param_1[2] = -1;
        return param_2;
      }
      param_1[2] = param_1[2] + *(int *)(uVar1 + 0x18);
      return param_2;
    }
    param_1[1] = 0;
  }
  return 0;
}

