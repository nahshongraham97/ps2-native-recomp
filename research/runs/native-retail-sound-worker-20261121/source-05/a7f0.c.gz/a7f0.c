
int FUN_0000a7f0(char *param_1,char *param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  char cVar4;
  
  iVar3 = 0;
  while( true ) {
    cVar2 = (char)iVar3;
    cVar4 = *param_1;
    param_1 = param_1 + 1;
    if (cVar4 == '\0') break;
    cVar2 = *param_2;
    iVar3 = (int)cVar2;
    param_2 = param_2 + 1;
    if (iVar3 == 0) break;
    iVar1 = (int)cVar4;
    if ((0x60 < iVar1) && (iVar1 < 0x7b)) {
      cVar4 = (char)((uint)((iVar1 + -0x20) * 0x1000000) >> 0x18);
    }
    iVar1 = (int)cVar2;
    if ((0x60 < iVar1) && (iVar1 < 0x7b)) {
      iVar3 = (iVar1 + -0x20) * 0x1000000 >> 0x18;
    }
    if ((int)cVar4 != (int)(char)iVar3) {
      return (int)cVar4 - (int)(char)iVar3;
    }
  }
  if (cVar4 == 0) {
    cVar2 = *param_2;
  }
  return (int)cVar4 - (int)cVar2;
}

