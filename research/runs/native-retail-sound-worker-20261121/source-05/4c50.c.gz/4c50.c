
int FUN_00004c50(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc) + param_2 * 0x28;
  while( true ) {
    if (param_2 < 0) {
      return -1;
    }
    if (*(char *)(iVar1 + 8) == param_3) break;
    param_2 = param_2 + -1;
    iVar1 = iVar1 + -0x28;
  }
  return param_2;
}

