
void FUN_00005244(void)

{
  int iVar1;
  
  while (*(int *)(iRam000248e0 + 0x26c) == 0) {
    func_0x0000aa88(5000,0x1021c,0x192);
    iVar1 = func_0x00007168();
    if (iVar1 < 100000) {
      if (iRam00010c54 == 0) {
        func_0x00007168();
      }
      iRam00010c54 = 1;
    }
    else {
      iRam00010c54 = 0;
    }
    FUN_000046f8(iRam000248e0);
    func_0x000056f4();
  }
  *(int *)(iRam000248e0 + 0x26c) = *(int *)(iRam000248e0 + 0x26c) + 1;
  func_0x00000158();
  return;
}

