
void FUN_0000aa88(void)

{
  undefined4 uVar1;
  
  func_0x00000178();
  uVar1 = func_0x00000198();
  func_0x00000168(uVar1);
  return;
}

