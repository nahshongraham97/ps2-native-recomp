
undefined4 FUN_000046f8(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iStack_4;
  
  uVar1 = func_0x0000a8c4();
  func_0x0000a7d8(param_1 + 0x3ac);
  for (iStack_4 = *(int *)(param_1 + 0x274); iStack_4 != 0;
      iStack_4 = func_0x00004220(param_1,iStack_4,uVar1)) {
  }
  for (iStack_4 = *(int *)(param_1 + 0x27c); iStack_4 != 0;
      iStack_4 = func_0x00003db0(param_1,iStack_4,uVar1)) {
  }
  iStack_4 = *(int *)(param_1 + 0x274);
  while (iStack_4 != 0) {
    uVar2 = func_0x0000f278(0);
    func_0x000045b0(param_1,uVar2,uVar1);
    func_0x0000f424(&iStack_4);
  }
  func_0x0000a7e4(param_1 + 0x3ac);
  func_0x00008cf0(param_1);
  return 0;
}

