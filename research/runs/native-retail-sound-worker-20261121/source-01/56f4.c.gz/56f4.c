
undefined4 FUN_000056f4(void)

{
  return 0;
}

