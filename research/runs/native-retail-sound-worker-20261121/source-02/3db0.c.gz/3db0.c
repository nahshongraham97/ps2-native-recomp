
undefined4 FUN_00003db0(int param_1,undefined4 param_2,uint param_3)

{
  uint *puVar1;
  undefined4 uVar2;
  short sVar3;
  uint uVar4;
  uint uVar5;
  short sVar6;
  short sVar7;
  int iVar8;
  int iVar9;
  undefined4 auStackX_4 [3];
  
  auStackX_4[0] = param_2;
  puVar1 = (uint *)func_0x0000f278(0);
  uVar4 = puVar1[2];
  if ((int)uVar4 <= (int)param_3) {
    param_3 = uVar4;
  }
  if ((param_3 == uVar4) || (uVar5 = puVar1[1], (int)uVar4 <= (int)(uVar5 + 10))) {
    sVar3 = *(short *)((int)puVar1 + 0x12);
    sVar7 = (short)puVar1[5];
    sVar6 = *(short *)((int)puVar1 + 0x16);
  }
  else {
    iVar8 = uVar4 - uVar5;
    iVar9 = param_3 - uVar5;
    sVar3 = (short)((uint)(((int)(short)puVar1[3] +
                           (iVar9 * ((int)*(short *)((int)puVar1 + 0x12) - (int)(short)puVar1[3])) /
                           iVar8) * 0x10000) >> 0x10);
    sVar7 = (short)((uint)(((int)*(short *)((int)puVar1 + 0xe) +
                           (iVar9 * ((int)(short)puVar1[5] - (int)*(short *)((int)puVar1 + 0xe))) /
                           iVar8) * 0x10000) >> 0x10);
    sVar6 = (short)((uint)(((int)(short)puVar1[4] +
                           (iVar9 * ((int)*(short *)((int)puVar1 + 0x16) - (int)(short)puVar1[4])) /
                           iVar8) * 0x10000) >> 0x10);
  }
  if ((*puVar1 & 1) == 0) {
    if ((*puVar1 & 2) == 0) {
      if (puVar1[6] == 0) {
        *(short *)(puVar1[7] + 0x12) = sVar3;
        *(short *)(puVar1[7] + 0x14) = sVar7;
        *(short *)(puVar1[7] + 0x16) = sVar6;
      }
      else {
        *(short *)(puVar1[6] + 0x44) = sVar3;
        *(short *)(puVar1[6] + 0x46) = sVar7;
        *(short *)(puVar1[6] + 0x48) = sVar6;
      }
    }
    else {
      *(int *)(param_1 + 0x290) = (int)sVar3;
      *(int *)(param_1 + 0x294) = (int)sVar7;
      *(int *)(param_1 + 0x298) = (int)sVar6;
    }
  }
  else {
    *(int *)(param_1 + 0x29c) = (int)sVar3;
    *(int *)(param_1 + 0x2a0) = (int)sVar7;
    *(int *)(param_1 + 0x2a4) = (int)sVar6;
  }
  if ((int)param_3 < (int)puVar1[2]) {
    func_0x0000f424(auStackX_4);
  }
  else {
    uVar2 = func_0x0000f3d8(auStackX_4);
    func_0x0000f1a8(0x248a0,uVar2);
  }
  return auStackX_4[0];
}

