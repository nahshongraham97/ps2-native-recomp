
int FUN_0000a8c4(void)

{
  int iVar1;
  int iStack_10;
  int iStack_c;
  undefined1 auStack_8 [8];
  
  func_0x00000180(auStack_8);
  func_0x00000190(auStack_8,&iStack_c,&iStack_10);
  iVar1 = iStack_10 / 1000 + iStack_c * 1000;
  if (iVar1 == 0) {
    iVar1 = 1;
  }
  return iVar1;
}

