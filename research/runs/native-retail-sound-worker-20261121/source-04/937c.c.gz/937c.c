
undefined4 FUN_0000937c(int param_1)

{
  uint uVar1;
  int iVar2;
  ushort uVar3;
  
  *(ushort *)(param_1 + 0xc) = *(ushort *)(param_1 + 0xc) & 0xfec7;
  if (*(int *)(param_1 + 4) == 0) {
    *(ushort *)(param_1 + 0xc) = *(ushort *)(param_1 + 0xc) | 0x20;
  }
  else if ((*(ushort *)(param_1 + 0xc) & 0x100) == 0) {
    if ((*(int *)(*(int *)(param_1 + 8) + 0x2c) == 0) ||
       (uVar1 = FUN_0000a8c4(), uVar1 < *(uint *)(*(int *)(*(int *)(param_1 + 8) + 0x2c) + 0x40))) {
      if (((*(ushort *)(param_1 + 0xc) & 2) == 0) && (*(short *)(param_1 + 0xe) == 1)) {
        func_0x0000a7d8(iRam000248e0 + 0x3ac);
        iVar2 = *(int *)(param_1 + 0x3c);
        uVar1 = FUN_0000a8c4();
        if ((iVar2 + 2U < uVar1) &&
           (iVar2 = func_0x0000bb84(*(undefined4 *)(param_1 + 0x2c)), iVar2 != 0)) {
          func_0x0000a298(*(undefined4 *)(*(int *)(param_1 + 8) + 0x3c),param_1,0);
          *(ushort *)(param_1 + 0xc) = *(ushort *)(param_1 + 0xc) | 0x20;
          func_0x0000a7e4(iRam000248e0 + 0x3ac);
          return 0;
        }
        func_0x0000a7e4(iRam000248e0 + 0x3ac);
      }
      uVar3 = 8;
      if ((*(ushort *)(param_1 + 0xc) & 1) != 0) {
        uVar3 = 0x18;
      }
      *(ushort *)(param_1 + 0xc) = *(ushort *)(param_1 + 0xc) | uVar3;
    }
    else {
      *(ushort *)(param_1 + 0xc) = *(ushort *)(param_1 + 0xc) | 0x100;
    }
  }
  else {
    *(ushort *)(param_1 + 0xc) = *(ushort *)(param_1 + 0xc) | 0x20;
  }
  return 0;
}

