
bool FUN_00008bc8(int param_1)

{
  bool bVar1;
  
  if (param_1 == 0) {
    bVar1 = false;
  }
  else {
    bVar1 = (*(ushort *)(param_1 + 0x1e) & 0x8000) != 0;
  }
  return bVar1;
}

