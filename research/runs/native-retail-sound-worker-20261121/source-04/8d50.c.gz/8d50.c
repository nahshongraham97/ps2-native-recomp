
void FUN_00008d50(void)

{
  int in_v0;
  int iVar1;
  int unaff_s0;
  undefined2 unaff_s1;
  int unaff_s2;
  int unaff_s4;
  int unaff_s5;
  undefined4 unaff_s6;
  
  do {
    if (in_v0 != 0) goto LAB_00008e00;
    unaff_s1 = *(undefined2 *)(unaff_s2 + 0x10);
    func_0x00008b54(unaff_s2);
    do {
      iVar1 = func_0x0000f61c(*(undefined4 *)(*(int *)(unaff_s5 + 0x268) + unaff_s0 + 4));
      if ((iVar1 != 0) && (iVar1 = func_0x000013ac(iVar1), iVar1 != 0)) {
        iVar1 = func_0x0000f278(0,iVar1);
        *(ushort *)(iVar1 + 0x1e) = *(ushort *)(iVar1 + 0x1e) | 1;
        *(ushort *)(iVar1 + 0x1e) = *(ushort *)(iVar1 + 0x1e) | 0x8000;
        *(undefined2 *)(iVar1 + 0x10) = unaff_s1;
        *(short *)(iVar1 + 0xc) = (short)unaff_s4;
        *(int *)(*(int *)(unaff_s5 + 0x268) + unaff_s0) = iVar1;
        func_0x00000ee8();
      }
LAB_00008e00:
      unaff_s4 = unaff_s4 + 1;
      if ((int)(uint)*(ushort *)(unaff_s5 + 0x264) <= unaff_s4) {
        *(undefined4 *)(unaff_s5 + 0x2a8) = unaff_s6;
        return;
      }
      unaff_s0 = unaff_s4 * 8;
      unaff_s2 = *(int *)(*(int *)(unaff_s5 + 0x268) + unaff_s0);
    } while (unaff_s2 == 0);
    in_v0 = FUN_00008bc8(unaff_s2);
  } while( true );
}

