
void FUN_002164d0(int param_1)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 *in_v1_lo;
  int unaff_s0_lo;
  
  while( true ) {
    *(undefined4 *)(param_1 + 0x18) = *in_v1_lo;
    *(undefined4 *)(iGpffffa71c + 0x10) = *(undefined4 *)(*(int *)(iGpffffa71c + 0x1a8) + 8);
    *(int *)(iGpffffa71c + 0xc) =
         *(int *)(*(int *)(iGpffffa71c + 8) + 0x80) +
         **(int **)(*(int *)(*(int *)(iGpffffa71c + 8) + 0x7c) + *(int *)(iGpffffa71c + 0x10) * 4) +
         -1;
    if (*(int *)(*(int *)(iGpffffa71c + 0x1a8) + 4) == 0) break;
    while( true ) {
      if ((**(int **)(iGpffffa71c + 0x18) == 0) &&
         (*(int *)(iGpffffa71c + 0x1a8) != iGpffffa71c + 0x68)) break;
      if ((**(int **)(iGpffffa71c + 0x18) == 0) || (*(int *)(iGpffffa71c + 0x20) == 2))
      goto LAB_002165f0;
      puVar1 = *(undefined4 **)(iGpffffa71c + 0x18);
      *(undefined4 **)(iGpffffa71c + 0x18) = puVar1 + 1;
      pcVar2 = (code *)*puVar1;
      puGpffffa718 = *(uint **)(iGpffffa71c + 0x18);
      *(uint **)(iGpffffa71c + 0x18) = puGpffffa718 + 1;
      *(uint **)(iGpffffa71c + 0x1c) = puGpffffa718;
      uVar3 = *puGpffffa718;
      *(uint *)(iGpffffa71c + 0x14) = uVar3 >> 0x10;
      *(uint *)(iGpffffa71c + 0x18) = *(int *)(iGpffffa71c + 0x18) + (uVar3 & 0xffff) * 4;
      (*pcVar2)();
      if (*(int *)(iGpffffa71c + 0x18) == *(int *)(unaff_s0_lo + 0x90)) goto LAB_002165f0;
    }
    *(int *)(iGpffffa71c + 0x1ac) = *(int *)(iGpffffa71c + 0x1a8);
    *(int *)(iGpffffa71c + 0x1a8) = *(int *)(iGpffffa71c + 0x1a8) + -0x50;
    if (*(uint *)(iGpffffa71c + 0x1a8) < iGpffffa71c + 0x68U) {
      *(undefined4 *)(iGpffffa71c + 0x20) = 2;
    }
    in_v1_lo = *(undefined4 **)(iGpffffa71c + 0x1a8);
    param_1 = iGpffffa71c;
  }
LAB_002165f0:
  *(int *)(iGpffffa71c + 0x1a8) = iGpffffa71c + 0x68;
  *(int *)(iGpffffa71c + 0x1ac) = *(int *)(iGpffffa71c + 0x1a8) + 0x50;
  *(undefined4 *)(iGpffffa71c + 0x20) = 0;
  return;
}

