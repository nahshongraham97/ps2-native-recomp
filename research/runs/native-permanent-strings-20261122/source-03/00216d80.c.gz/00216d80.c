
void FUN_00216d80(int param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  byte *pbVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  uint *puVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  
  if (*(int *)(param_1 + 0x78) == 0) {
    uVar14 = 0;
    uVar5 = 0;
    if (*(int *)(param_1 + 0x68) != 0) {
      iVar12 = 0;
      do {
        piVar2 = *(int **)(*(int *)(param_1 + 0x70) + iVar12);
        if (piVar2[1] == 0) {
          iVar4 = FUN_00215ed0(*(int *)(param_1 + 0x80) + *piVar2 + -1,1);
          piVar2[2] = iVar4;
        }
        uVar5 = *(uint *)(param_1 + 0x68);
        uVar14 = uVar14 + 1;
        iVar12 = iVar12 + 4;
      } while (uVar14 < uVar5);
    }
    uVar14 = DAT_005fea20;
    uVar7 = 0;
    if (uVar5 != 0) {
      iVar12 = 0;
      do {
        iVar4 = *(int *)(*(int *)(param_1 + 0x70) + iVar12);
        if (*(int *)(iVar4 + 4) != 0) {
          iVar6 = *(int *)(param_1 + 0x88) + *(int *)(iVar4 + 4) + -1;
          uVar5 = (uint)*(byte *)(iVar6 + 4);
          puVar13 = (uint *)(*(int *)(param_1 + 0x74) + *(int *)(iVar4 + 8) * 4);
          for (iVar11 = *(int *)(iVar4 + 0xc); iVar11 != 0; iVar11 = iVar11 + -1) {
            uVar10 = 0;
            if (uVar5 != 0) {
              do {
                cVar1 = *(char *)(uVar10 + iVar6 + 5);
                if (cVar1 == '\x06') {
                  uVar9 = *puVar13;
                  if ((long)(int)uVar9 != 0) {
                    uVar15 = 0;
                    uVar16 = (uint)((ulong)((long)(int)uVar9 << 0x28) >> 0x28) - 1;
                    pbVar8 = &DAT_005acea0;
                    if (uVar14 != 0) {
                      do {
                        if ((uint)*pbVar8 == uVar9 >> 0x18) {
                          if (uVar16 < *(uint *)(pbVar8 + 8)) {
                            uVar9 = *(uint *)(*(int *)(pbVar8 + 4) + uVar16 * 4);
                          }
                          else {
                            uVar9 = 0;
                          }
                          goto LAB_00216fd0;
                        }
                        uVar15 = uVar15 + 1;
                        pbVar8 = pbVar8 + 0xc;
                      } while (uVar15 < uVar14);
                    }
                    uVar9 = 0;
LAB_00216fd0:
                    if (uVar9 != 0) {
                      *puVar13 = uVar9;
                    }
                  }
                }
                else if (cVar1 == -0x7b) {
                  if ((long)(int)*puVar13 != 0) {
                    iVar3 = *(int *)((uint)((ulong)((long)*(int *)(iVar4 + (uint)((ulong)((long)(int
                                                  )*puVar13 << 0x21) >> 0x21) * 4 + 0x14) << 0x21)
                                           >> 0x21) * 4 + *(int *)(param_1 + 0x70) + -4);
                    if (*(int *)(iVar3 + 4) == 0) {
                      *puVar13 = *(uint *)(iVar3 + 8);
                    }
                    else {
                      *puVar13 = *(int *)(param_1 + 0x74) + *(int *)(iVar3 + 8) * 4;
                    }
                  }
                }
                else if ((cVar1 == '\x04') && (*puVar13 != 0)) {
                  *puVar13 = *(int *)(param_1 + 0x84) + *(int *)(iVar4 + *puVar13 * 4 + 0x10);
                }
                uVar10 = uVar10 + 1;
                puVar13 = puVar13 + 1;
              } while (uVar10 < uVar5);
            }
          }
        }
        uVar7 = uVar7 + 1;
        iVar12 = iVar12 + 4;
      } while (uVar7 < *(uint *)(param_1 + 0x68));
    }
    *(undefined4 *)(param_1 + 0x78) = 1;
  }
  return;
}

