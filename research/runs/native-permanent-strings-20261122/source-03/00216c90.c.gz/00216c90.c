
void FUN_00216c90(int param_1)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  uint uVar6;
  
  uVar1 = DAT_005fea20;
  puVar2 = *(uint **)(param_1 + 0x8c);
  if (*(uint **)(param_1 + 0x90) <= puVar2) {
    return;
  }
  uVar3 = *puVar2;
  do {
    if ((long)(int)uVar3 == 0) {
      puVar2 = puVar2 + 1;
    }
    else {
      uVar6 = 0;
      uVar4 = (uint)((ulong)((long)(int)uVar3 << 0x28) >> 0x28) - 1;
      pbVar5 = &DAT_005acea0;
      if (uVar1 != 0) {
        do {
          if ((uint)*pbVar5 == uVar3 >> 0x18) {
            if (uVar4 < *(uint *)(pbVar5 + 8)) {
              uVar3 = *(uint *)(*(int *)(pbVar5 + 4) + uVar4 * 4);
            }
            else {
              uVar3 = 0;
            }
            goto LAB_00216d50;
          }
          uVar6 = uVar6 + 1;
          pbVar5 = pbVar5 + 0xc;
        } while (uVar6 < uVar1);
      }
      uVar3 = 0;
LAB_00216d50:
      *puVar2 = uVar3;
      puVar2 = puVar2 + (ushort)puVar2[1] + 2;
    }
    if (*(uint **)(param_1 + 0x90) <= puVar2) {
      return;
    }
    uVar3 = *puVar2;
  } while( true );
}

