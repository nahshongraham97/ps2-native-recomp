
void FUN_00216f70(uint param_1,ulong param_2,ulong param_3,ulong param_4,uint param_5,int param_6,
                 int param_7,uint param_8)

{
  int iVar1;
  byte *in_v1_lo;
  uint in_t4_lo;
  byte *pbVar2;
  uint uVar3;
  ulong uVar4;
  int in_t6_lo;
  uint in_t7_lo;
  int unaff_s0_lo;
  int unaff_s1_lo;
  uint *unaff_s2_lo;
  uint unaff_s4_lo;
  uint in_t8_lo;
  uint in_t9_lo;
  
  pbVar2 = in_v1_lo;
  do {
    while (*pbVar2 != in_t8_lo) {
      unaff_s4_lo = unaff_s4_lo + 1;
      pbVar2 = pbVar2 + 0xc;
      if (param_8 <= unaff_s4_lo) goto LAB_00216fc8;
    }
    if (in_t9_lo < *(uint *)(pbVar2 + 8)) {
      uVar3 = *(uint *)(*(int *)(pbVar2 + 4) + in_t9_lo * 4);
    }
    else {
      uVar3 = 0;
    }
    while( true ) {
      if (uVar3 != 0) {
        *unaff_s2_lo = uVar3;
      }
      do {
        while( true ) {
          in_t7_lo = in_t7_lo + 1;
          unaff_s2_lo = unaff_s2_lo + 1;
          if (param_5 <= in_t7_lo) {
            do {
              unaff_s1_lo = unaff_s1_lo + -1;
              while (unaff_s1_lo == 0) {
                do {
                  in_t4_lo = in_t4_lo + 1;
                  in_t6_lo = in_t6_lo + 4;
                  if (*(uint *)(unaff_s0_lo + 0x68) <= in_t4_lo) {
                    *(undefined4 *)(unaff_s0_lo + 0x78) = 1;
                    return;
                  }
                  param_7 = *(int *)(*(int *)(unaff_s0_lo + 0x70) + in_t6_lo);
                } while (*(int *)(param_7 + 4) == 0);
                param_6 = *(int *)(unaff_s0_lo + 0x88) + *(int *)(param_7 + 4) + -1;
                param_5 = (uint)*(byte *)(param_6 + 4);
                unaff_s2_lo = (uint *)(*(int *)(unaff_s0_lo + 0x74) + *(int *)(param_7 + 8) * 4);
                unaff_s1_lo = *(int *)(param_7 + 0xc);
              }
              in_t7_lo = 0;
            } while (param_5 == 0);
          }
          uVar4 = (ulong)*(byte *)(in_t7_lo + param_6 + 5);
          if (uVar4 == param_4) break;
          if (uVar4 == param_3) {
            if ((long)(int)*unaff_s2_lo != 0) {
              iVar1 = *(int *)((uint)((ulong)((long)*(int *)(param_7 + (uint)((ulong)((long)(int)*
                                                  unaff_s2_lo << 0x21) >> 0x21) * 4 + 0x14) << 0x21)
                                     >> 0x21) * 4 + *(int *)(unaff_s0_lo + 0x70) + -4);
              if (*(int *)(iVar1 + 4) == 0) {
                *unaff_s2_lo = *(uint *)(iVar1 + 8);
              }
              else {
                *unaff_s2_lo = *(int *)(unaff_s0_lo + 0x74) + *(int *)(iVar1 + 8) * 4;
              }
            }
          }
          else if ((uVar4 == param_2) && (*unaff_s2_lo != 0)) {
            *unaff_s2_lo = *(int *)(unaff_s0_lo + 0x84) +
                           *(int *)(param_7 + *unaff_s2_lo * 4 + 0x10);
          }
        }
        uVar3 = *unaff_s2_lo;
      } while ((long)(int)uVar3 == 0);
      unaff_s4_lo = 0;
      in_t8_lo = (uVar3 & param_1) >> 0x18;
      in_t9_lo = (uint)((ulong)((long)(int)uVar3 << 0x28) >> 0x28) - 1;
      pbVar2 = in_v1_lo;
      if (param_8 != 0) break;
LAB_00216fc8:
      uVar3 = 0;
    }
  } while( true );
}

