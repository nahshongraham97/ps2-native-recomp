
int FUN_00215ed0(undefined8 param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  long lVar4;
  uint uVar5;
  int iVar6;
  
  iVar2 = FUN_00240370(0x6a62c0,param_1);
  if (iVar2 == 0) {
    if (iRam0064e800 != 0) {
      iVar2 = *(int *)(iRam0064e800 + 0x68);
      iVar6 = iRam0064e800;
      while( true ) {
        uVar5 = 0;
        if (iVar2 != 0) {
          iVar2 = 0;
          do {
            piVar1 = *(int **)(*(int *)(iVar6 + 0x70) + iVar2);
            if (piVar1[1] == 0) {
              uVar3 = *(uint *)(iVar6 + 0x68);
            }
            else {
              lVar4 = FUN_001deb10(param_1,*(int *)(iVar6 + 0x80) + *piVar1 + -1);
              if (lVar4 == 0) {
                return *(int *)(iVar6 + 0x74) + piVar1[2] * 4;
              }
              uVar3 = *(uint *)(iVar6 + 0x68);
            }
            uVar5 = uVar5 + 1;
            iVar2 = iVar2 + 4;
          } while (uVar5 < uVar3);
        }
        iVar6 = *(int *)(iVar6 + 0x40);
        if (iVar6 == 0) break;
        iVar2 = *(int *)(iVar6 + 0x68);
      }
    }
    iVar2 = 0;
  }
  return iVar2;
}

