
void FUN_00215120(undefined8 param_1)

{
  int iVar1;
  undefined1 uVar2;
  
  iVar1 = (int)param_1;
  if (*(int *)(iVar1 + 0x2c) != 0) {
    uVar2 = *(undefined1 *)(iVar1 + 0x1d);
    if (iRam0064e7fc != 0) {
      iRam0064e7fc = 0;
      uVar2 = 1;
    }
    FUN_002170e0(*(int *)(iVar1 + 0x2c),uVar2);
  }
  FUN_003de190(param_1);
  *(undefined1 *)(iVar1 + 0x1c) = 1;
  return;
}

