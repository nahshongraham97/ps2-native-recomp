
void FUN_00215010(int param_1)

{
  undefined4 uVar1;
  bool bVar2;
  int iVar3;
  
  iVar3 = iRam0064e800;
  if (param_1 != 0) {
    for (; iVar3 != 0; iVar3 = *(int *)(iVar3 + 0x40)) {
      if (iVar3 == param_1) {
        bVar2 = true;
        goto LAB_00215054;
      }
    }
  }
  bVar2 = false;
LAB_00215054:
  if (bVar2) {
    iVar3 = *(int *)(param_1 + 0x4c);
    if (iVar3 == 0) {
      iVar3 = *(int *)(param_1 + 0x98);
    }
    else {
      *(undefined4 *)(param_1 + 0x4c) = 0;
      *(undefined4 *)(iVar3 + 0x2c) = 0;
      uVar1 = *(undefined4 *)(param_1 + 0x48);
      *(undefined4 *)(param_1 + 0x48) = 0;
      *(undefined4 *)(iVar3 + 8) = 0;
      FUN_003ddff0(iVar3,uVar1);
      iVar3 = *(int *)(param_1 + 0x98);
    }
    if (iVar3 != 0) {
      FUN_00130ac0(param_1 + 0x98);
    }
    FUN_00217fc0(param_1);
  }
  return;
}

