
int FUN_00214120(undefined8 param_1,undefined8 param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  
  iVar4 = (int)param_2;
  iVar7 = (*(int **)(iVar4 + 0x7c))[*(int *)(iVar4 + 0x50)] - **(int **)(iVar4 + 0x7c);
  iVar6 = (*(int **)(iVar4 + 0x70))[*(int *)(iVar4 + 0x68)] - **(int **)(iVar4 + 0x70);
  iVar1 = FUN_00199f60(param_1,*(int *)(iVar4 + 0x54) + 0x20 + *(int *)(iVar4 + 0x58) +
                               *(int *)(iVar4 + 0x5c) + *(int *)(iVar4 + 0x60) +
                               *(int *)(iVar4 + 0x6c) + *(int *)(iVar4 + 0x68) * 4 +
                               *(int *)(iVar4 + 0x50) * 4 + iVar6 + iVar7);
  iVar2 = iRam0064e804;
  if (iRam0064e804 == 0) {
    iVar2 = 0;
  }
  else {
    iRam0064e804 = *(int *)(iRam0064e804 + 0x40);
    FUN_001dba60(iVar2,0,0x9c);
    *(undefined4 *)(iVar2 + 0x44) = 0xffffffff;
    *(int *)(iVar2 + 0x40) = iRam0064e800;
    iRam0064e800 = iVar2;
    *(int *)(iVar2 + 0x48) = (int)param_1;
    *(int *)(iVar2 + 0x4c) = iVar1;
    uVar3 = 0;
    *(undefined4 *)(iVar2 + 0x44) = 0xfffffffe;
    *(int *)(iVar1 + 0x2c) = iVar2;
    puVar5 = *(undefined4 **)(iVar1 + 8);
    *puVar5 = *(undefined4 *)(iVar4 + 0x50);
    puVar5[1] = *(undefined4 *)(iVar4 + 0x60);
    puVar5[2] = *(undefined4 *)(iVar4 + 0x54);
    puVar5[3] = *(undefined4 *)(iVar4 + 0x58);
    puVar5[4] = *(undefined4 *)(iVar4 + 0x5c);
    puVar5[5] = *(undefined4 *)(iVar4 + 100);
    puVar5[6] = *(undefined4 *)(iVar4 + 0x68);
    puVar5[7] = *(undefined4 *)(iVar4 + 0x6c);
    puVar5 = puVar5 + 8;
    if (*(int *)(iVar4 + 0x50) != 0) {
      do {
        *puVar5 = 0;
        uVar3 = uVar3 + 1;
        puVar5 = puVar5 + 1;
      } while (uVar3 < *(uint *)(iVar4 + 0x50));
    }
    FUN_001db8a8(puVar5,**(undefined4 **)(iVar4 + 0x7c),iVar7);
    puVar5 = (undefined4 *)((int)puVar5 + iVar7);
    uVar3 = 0;
    if (*(int *)(iVar4 + 0x68) != 0) {
      do {
        *puVar5 = 0;
        uVar3 = uVar3 + 1;
        puVar5 = puVar5 + 1;
      } while (uVar3 < *(uint *)(iVar4 + 0x68));
    }
    FUN_001db8a8(puVar5,**(undefined4 **)(iVar4 + 0x70),iVar6);
    FUN_001db8a8((int)puVar5 + iVar6,*(undefined4 *)(iVar4 + 0x80),*(undefined4 *)(iVar4 + 0x54));
    iVar1 = (int)puVar5 + iVar6 + *(int *)(iVar4 + 0x54);
    FUN_001db8a8(iVar1,*(undefined4 *)(iVar4 + 0x84),*(undefined4 *)(iVar4 + 0x58));
    iVar1 = iVar1 + *(int *)(iVar4 + 0x58);
    FUN_001db8a8(iVar1,*(undefined4 *)(iVar4 + 0x88),*(undefined4 *)(iVar4 + 0x5c));
    iVar1 = iVar1 + *(int *)(iVar4 + 0x5c);
    FUN_001db8a8(iVar1,*(undefined4 *)(iVar4 + 0x74),*(undefined4 *)(iVar4 + 0x6c));
    FUN_001db8a8(iVar1 + *(int *)(iVar4 + 0x6c),*(undefined4 *)(iVar4 + 0x8c),
                 *(undefined4 *)(iVar4 + 0x60));
    FUN_002170e0(iVar2,0);
    FUN_0012da60(*(undefined4 *)(iVar4 + 0x8c));
    FUN_0012da60(*(undefined4 *)(iVar4 + 0x7c));
    FUN_0012da60(*(undefined4 *)(iVar4 + 0x74));
    FUN_0012da60(*(undefined4 *)(iVar4 + 0x88));
    FUN_0012da60(*(undefined4 *)(iVar4 + 0x84));
    FUN_0012da60(*(undefined4 *)(iVar4 + 0x80));
    FUN_0012da60(**(undefined4 **)(iVar4 + 0x70));
    FUN_0012da60(*(undefined4 *)(iVar4 + 0x70));
    FUN_0012da60(param_2);
  }
  return iVar2;
}

