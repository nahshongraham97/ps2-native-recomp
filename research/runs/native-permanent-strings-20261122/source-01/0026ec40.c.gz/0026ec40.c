
undefined4 * FUN_0026ec40(undefined8 param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  long lVar3;
  undefined4 *puVar4;
  
  puVar2 = *(undefined4 **)(iRam0064e998 + 0xc);
  puVar4 = (undefined4 *)(iRam0064e998 + 0xc);
  if (puVar2 == (undefined4 *)0x0) {
LAB_0026ec90:
    puVar2 = (undefined4 *)0x0;
  }
  else {
    uVar1 = *puVar2;
    while (lVar3 = FUN_001deb10(uVar1,param_1), lVar3 != 0) {
      puVar4 = puVar4 + 3;
      puVar2 = (undefined4 *)*puVar4;
      if (puVar2 == (undefined4 *)0x0) goto LAB_0026ec90;
      uVar1 = *puVar2;
    }
  }
  return puVar2;
}

