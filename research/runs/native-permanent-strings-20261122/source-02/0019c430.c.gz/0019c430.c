
uint * FUN_0019c430(uint param_1)

{
  int iVar1;
  uint *puVar2;
  int *piVar3;
  uint uVar4;
  
  if (piRam0069f10c == (int *)0x0) {
LAB_0019c468:
    piVar3 = (int *)0x0;
  }
  else {
    iVar1 = *piRam0069f10c;
    piVar3 = piRam0069f10c;
    while (iVar1 != (int)param_1 >> 0x10) {
      piVar3 = (int *)piVar3[6];
      if (piVar3 == (int *)0x0) goto LAB_0019c468;
      iVar1 = *piVar3;
    }
  }
  if (piVar3 != (int *)0x0) {
    puVar2 = (uint *)piVar3[5];
    uVar4 = 0;
    if (piVar3[2] != 0) {
      do {
        if (*puVar2 == (param_1 & 0xffff)) {
          return puVar2;
        }
        uVar4 = uVar4 + 1;
        puVar2 = puVar2 + 6;
      } while (uVar4 < (uint)piVar3[2]);
    }
  }
  return (uint *)0x0;
}

