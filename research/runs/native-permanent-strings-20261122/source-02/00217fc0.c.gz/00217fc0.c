
void FUN_00217fc0(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
  if (param_1 != 0) {
    puVar2 = (undefined4 *)0x64e800;
    for (iVar1 = iRam0064e800; iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x40)) {
      if (iVar1 == param_1) {
        *puVar2 = *(undefined4 *)(iVar1 + 0x40);
        FUN_001dba60(param_1,0,0x9c);
        *(undefined4 *)(param_1 + 0x44) = 0xffffffff;
        *(int *)(iVar1 + 0x40) = iRam0064e804;
        iRam0064e804 = iVar1;
        return;
      }
      puVar2 = (undefined4 *)(iVar1 + 0x40);
    }
  }
  return;
}

