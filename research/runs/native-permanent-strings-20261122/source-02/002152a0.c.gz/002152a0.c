
int FUN_002152a0(undefined8 param_1,undefined8 param_2,int param_3,undefined8 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  long lVar3;
  int iVar4;
  
  if (iRam0064e800 == 0) {
LAB_002152f0:
    iVar4 = 0;
  }
  else {
    iVar2 = *(int *)(iRam0064e800 + 0x44);
    iVar4 = iRam0064e800;
    while (param_3 != iVar2) {
      iVar4 = *(int *)(iVar4 + 0x40);
      if (iVar4 == 0) goto LAB_002152f0;
      iVar2 = *(int *)(iVar4 + 0x44);
    }
  }
  if ((iVar4 == 0) ||
     (((*(int **)(iVar4 + 0x4c) != (int *)0x0 &&
       (puVar1 = (undefined4 *)**(int **)(iVar4 + 0x4c), puVar1 != (undefined4 *)0x0)) &&
      (lVar3 = FUN_001deb10(*puVar1,param_2), lVar3 != 0)))) {
    lVar3 = FUN_0026ec40(param_2);
    if (lVar3 == 0) {
      lVar3 = 0;
    }
    else {
      lVar3 = FUN_00215180(param_1,lVar3,1,param_4);
    }
    iVar4 = 0;
    if (lVar3 != 0) {
      iVar2 = FUN_0019c140(param_1,lVar3);
      iVar4 = *(int *)(iVar2 + 0x2c);
      *(int *)(iVar4 + 0x44) = param_3;
    }
  }
  else {
    uRam0064e7fc = 0;
  }
  return iVar4;
}

