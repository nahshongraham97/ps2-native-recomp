
undefined8 FUN_0019bfa0(undefined8 param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_00429d20(uGpffffab88,0x34,3,0,0,0);
  FUN_001dba60(uVar1,0,0x34);
  FUN_0019c010(param_1,uVar1);
  return uVar1;
}

