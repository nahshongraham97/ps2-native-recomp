
void FUN_002170e0(long param_1,long param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  
  puVar4 = (undefined4 *)0x0;
  iVar5 = (int)param_1;
  if (param_1 != 0) {
    uVar2 = uRam00000000;
    if (*(int *)(iVar5 + 0x4c) == 0) goto LAB_0021710c;
    puVar4 = *(undefined4 **)(*(int *)(iVar5 + 0x4c) + 8);
  }
  uVar2 = *puVar4;
LAB_0021710c:
  uVar1 = 0;
  *(undefined4 *)(iVar5 + 0x50) = uVar2;
  *(undefined4 *)(iVar5 + 0x60) = puVar4[1];
  *(undefined4 *)(iVar5 + 0x54) = puVar4[2];
  *(undefined4 *)(iVar5 + 0x58) = puVar4[3];
  *(undefined4 *)(iVar5 + 0x5c) = puVar4[4];
  *(undefined4 *)(iVar5 + 100) = puVar4[5];
  *(undefined4 *)(iVar5 + 0x68) = puVar4[6];
  *(undefined4 *)(iVar5 + 0x6c) = puVar4[7];
  *(undefined4 **)(iVar5 + 0x7c) = puVar4 + 8;
  puVar4 = puVar4 + 8 + *(int *)(iVar5 + 0x50);
  if (*(int *)(iVar5 + 0x50) != 0) {
    iVar3 = 0;
    do {
      uVar1 = uVar1 + 1;
      *(undefined4 **)(*(int *)(iVar5 + 0x7c) + iVar3) = puVar4;
      iVar3 = iVar3 + 4;
      puVar4 = puVar4 + puVar4[4] + 5;
    } while (uVar1 < *(uint *)(iVar5 + 0x50));
  }
  *(undefined4 **)(iVar5 + 0x70) = puVar4;
  uVar1 = 0;
  puVar4 = puVar4 + *(int *)(iVar5 + 0x68);
  if (*(int *)(iVar5 + 0x68) != 0) {
    iVar3 = 0;
    do {
      uVar1 = uVar1 + 1;
      *(undefined4 **)(*(int *)(iVar5 + 0x70) + iVar3) = puVar4;
      iVar3 = iVar3 + 4;
      puVar4 = puVar4 + puVar4[4] + 5;
    } while (uVar1 < *(uint *)(iVar5 + 0x68));
  }
  *(undefined4 **)(iVar5 + 0x80) = puVar4;
  iVar3 = (int)puVar4 + *(int *)(iVar5 + 0x54);
  *(int *)(iVar5 + 0x84) = iVar3;
  iVar3 = iVar3 + *(int *)(iVar5 + 0x58);
  *(int *)(iVar5 + 0x88) = iVar3;
  iVar3 = iVar3 + *(int *)(iVar5 + 0x5c);
  *(int *)(iVar5 + 0x74) = iVar3;
  iVar3 = iVar3 + *(int *)(iVar5 + 0x6c);
  *(int *)(iVar5 + 0x8c) = iVar3;
  *(int *)(iVar5 + 0x90) = iVar3 + *(int *)(iVar5 + 0x60);
  if (param_2 == 0) {
    FUN_00216d80(param_1);
    FUN_00216c90(param_1);
  }
  else {
    *(undefined4 *)(iVar5 + 0x78) = 1;
  }
  return;
}

