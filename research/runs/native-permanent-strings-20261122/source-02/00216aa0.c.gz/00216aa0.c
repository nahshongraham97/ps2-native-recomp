
void FUN_00216aa0(void)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int unaff_s0_lo;
  
  *(byte *)(unaff_s0_lo + 0xd0) = *(byte *)(unaff_s0_lo + 0xd0) & 0xdf | 0x20;
  if (iGpffff9e64 == unaff_s0_lo) {
    if ((iGpffff9e64 != -0xe8) && (piVar2 = *(int **)(iGpffff9e64 + 0xe8), piVar2 != (int *)0x0)) {
      piVar3 = (int *)*piVar2;
      while( true ) {
        if (piVar2[4] == piVar3[1]) {
          if ((undefined **)*piVar3 != &PTR_LAB_0059fe20) {
            piVar3 = (int *)0x0;
          }
          if (piVar3 != (int *)0x0) {
            piGpffffa71c = piVar3;
            return;
          }
          piVar1 = (int *)piVar2[1];
        }
        else {
          piVar1 = (int *)piVar2[1];
          piVar2[4] = 1;
          FUN_0012fa00();
        }
        if (piVar1 == (int *)0x0) break;
        piVar3 = (int *)*piVar1;
        piVar2 = piVar1;
      }
    }
    piGpffffa71c = (int *)0x0;
  }
  return;
}

