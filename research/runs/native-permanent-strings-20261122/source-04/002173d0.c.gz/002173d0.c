
void FUN_002173d0(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  FUN_00240870(0x6a62c0,0x17,uRam0064ec40);
  uRam0064e800 = 0;
  iVar3 = 0x6a5690;
  iVar4 = 0;
  iVar2 = 0;
  do {
    iVar1 = iVar2;
    iVar2 = iVar1 + 6;
    *(int *)(iVar3 + 0x40) = iVar4 + 0x6a572c;
    *(int *)(iVar3 + 0xdc) = iVar4 + 0x6a57c8;
    *(int *)(iVar3 + 0x178) = iVar4 + 0x6a5864;
    *(int *)(iVar3 + 0x214) = iVar4 + 0x6a5900;
    *(int *)(iVar3 + 0x2b0) = iVar4 + 0x6a599c;
    *(int *)(iVar3 + 0x34c) = iVar4 + 0x6a5a38;
    iVar3 = iVar3 + 0x3a8;
    iVar4 = iVar4 + 0x3a8;
  } while (iVar2 < 0xd);
  uRam0064e804 = 0x6a5690;
  *(int *)(iVar2 * 0x9c + 0x6a56d0) = (iVar1 + 7) * 0x9c + 0x6a5690;
  uRam006a6264 = 0;
  return;
}

