
void FUN_0000cd08(int param_1,int param_2)

{
  undefined4 auStack_10 [2];
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  if (iRam000109ec == -1) {
    uStack_8 = 1;
    uStack_4 = 1;
    auStack_10[0] = 0;
    iRam000109ec = func_0x000001bc(auStack_10);
    iRam00028d70 = param_1 + param_2;
    uRam00028d78 = 0;
    iRam00028d6c = param_2;
    iRam00028d74 = param_1;
  }
  return;
}

