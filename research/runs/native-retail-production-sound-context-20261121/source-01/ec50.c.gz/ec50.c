
void FUN_0000ec50(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = func_0x0000cd88(0x20000);
  iVar1 = *(int *)(iVar1 + 4);
  iVar4 = 0;
  do {
    iVar2 = iVar4 * 0x68;
    *(undefined4 *)(iVar2 + 0x28d80) = 0;
    *(undefined4 *)(iVar2 + 0x28d84) = 0;
    *(undefined4 *)(iVar2 + 0x28d88) = 0;
    *(undefined4 *)(iVar2 + 0x28d8c) = 0;
    *(undefined4 *)(iVar2 + 0x28d90) = 0;
    *(undefined4 *)(iVar2 + 0x28d94) = 0;
    *(undefined4 *)(iVar2 + 0x28d98) = 0;
    *(undefined4 *)(iVar2 + 0x28d9c) = 0;
    *(undefined4 *)(iVar2 + 0x28da0) = 0;
    *(undefined4 *)(iVar2 + 0x28db4) = 0;
    *(undefined4 *)(iVar2 + 0x28db8) = 0;
    *(undefined4 *)(iVar2 + 0x28dbc) = 0;
    iVar3 = iVar4 * 0x10000;
    *(undefined4 *)(iVar2 + 0x28dc0) = 0;
    *(undefined4 *)(iVar2 + 0x28dc4) = 0;
    *(undefined4 *)(iVar2 + 0x28dc8) = 0;
    *(int *)(iVar2 + 0x28dd4) = iVar3 + 0x28e50;
    *(int *)(iVar2 + 0x28dd8) = iVar3 + 0x30e50;
    *(int *)(iVar2 + 0x28ddc) = iVar1 + iVar3;
    *(int *)(iVar2 + 0x28de0) = iVar1 + (iVar4 * 2 + 1) * 0x8000;
    iVar4 = iVar4 + 1;
  } while (iVar4 < 2);
  return;
}

