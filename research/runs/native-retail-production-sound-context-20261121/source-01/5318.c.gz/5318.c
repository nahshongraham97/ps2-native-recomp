
undefined4 FUN_00005318(int param_1)

{
  undefined4 uVar1;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uStack_14 = 0x2000000;
  uStack_c = 0x5244;
  uStack_4 = 0x32;
  uStack_8 = 0x800;
  uStack_10 = 0;
  uVar1 = func_0x00000140(&uStack_14);
  *(undefined4 *)(param_1 + 0x25c) = uVar1;
  func_0x00000150(*(undefined4 *)(param_1 + 0x25c),0);
  return *(undefined4 *)(param_1 + 0x25c);
}

