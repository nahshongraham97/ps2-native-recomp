
undefined4 FUN_00004708(void)

{
  int unaff_s1;
  int in_stack_00000024;
  
  func_0x0000a8c4();
  func_0x0000a7d8(unaff_s1 + 0x3ac);
  in_stack_00000024 = *(int *)(unaff_s1 + 0x274);
  while (in_stack_00000024 != 0) {
    in_stack_00000024 = func_0x00004220();
  }
  in_stack_00000024 = *(int *)(unaff_s1 + 0x27c);
  while (in_stack_00000024 != 0) {
    in_stack_00000024 = func_0x00003db0();
  }
  in_stack_00000024 = *(int *)(unaff_s1 + 0x274);
  while (in_stack_00000024 != 0) {
    func_0x0000f278(0);
    func_0x000045b0();
    func_0x0000f424(&stack0x00000024);
  }
  func_0x0000a7e4(unaff_s1 + 0x3ac);
  func_0x00008cf0();
  return 0;
}

