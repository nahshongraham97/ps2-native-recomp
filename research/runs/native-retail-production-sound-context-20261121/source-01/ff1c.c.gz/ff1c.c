
void FUN_0000ff1c(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uRam00048e54 = 0x48e6c;
  iVar3 = 0x12;
  do {
    iVar2 = iVar3 + 1;
    iVar1 = iVar3 * 0x18;
    iVar3 = iVar3 + -1;
    *(int *)(iVar1 + 0x48e6c) = iVar2 * 0x18 + 0x48e6c;
  } while (-1 < iVar3);
  uRam00049034 = 0;
  uRam00048e58 = 0;
  uRam00048e5c = 0x48e58;
  func_0x0000a7cc(0x4904c);
  uStack_4 = 0x14;
  uStack_10 = 0;
  uStack_8 = 0;
  uStack_c = 0;
  uRam000109f4 = func_0x000001bc(&uStack_10);
  uStack_24 = 0x2000000;
  uStack_1c = 0xf6e4;
  uStack_14 = 0x34;
  uStack_18 = 0x1000;
  uStack_20 = 0;
  iVar3 = func_0x00000140(&uStack_24);
  if (0 < iVar3) {
    func_0x00000150(iVar3,0);
  }
  return;
}

