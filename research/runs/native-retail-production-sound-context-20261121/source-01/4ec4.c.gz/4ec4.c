
void FUN_00004ec4(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uStack_8 = 1;
  uStack_4 = 1;
  uStack_10 = 0;
  uStack_c = 0;
  uRam00010214 = func_0x000001bc(&uStack_10);
  uRam00010218 = func_0x000001bc(&uStack_10);
  return;
}

