
undefined4 FUN_0000ca00(void)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uVar1 = 1;
  if (iRam000104b0 != 1) {
    iVar2 = func_0x0000c608(0x104bc,0x104ec,0x20,0x28);
    if (iVar2 == 0) {
      uVar1 = 0;
    }
    else {
      uStack_8 = 0;
      uStack_4 = 0;
      iRam000104b8 = func_0x00000200(&uStack_8);
      if (iRam000104b8 < 0) {
        uVar1 = 0;
      }
      else {
        func_0x0000a7cc(0x28d60);
        uStack_1c = 0x2000000;
        uStack_14 = 0xc924;
        uStack_c = 0x14;
        uStack_10 = 0x1000;
        uStack_18 = 0;
        iVar2 = func_0x00000140(&uStack_1c);
        if (iVar2 < 1) {
          uVar1 = 0;
        }
        else {
          func_0x00000150(iVar2,0);
          uVar1 = 1;
          iRam000104b0 = 1;
        }
      }
    }
  }
  return uVar1;
}

