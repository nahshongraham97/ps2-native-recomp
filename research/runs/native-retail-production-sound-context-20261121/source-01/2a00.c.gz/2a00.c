
undefined4 FUN_00002a00(void)

{
  int in_v0;
  int iVar1;
  int in_v1;
  int unaff_s0;
  int unaff_s1;
  undefined4 uVar2;
  int unaff_s2;
  undefined4 unaff_s3;
  int unaff_s4;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined2 uStack0000004c;
  undefined2 uStack0000004e;
  int in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  
  if (in_v0 == in_v1) {
    unaff_s3 = func_0x00004d14(*(undefined4 *)(unaff_s4 + 4),unaff_s4 + 0xc,
                               *(undefined4 *)(unaff_s4 + 8));
  }
  else if (in_v0 == 0x2b) {
    switch(*(undefined4 *)(unaff_s4 + 4)) {
    case 0:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        unaff_s3 = func_0x00008f80(iVar1);
      }
      break;
    case 1:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        unaff_s3 = func_0x00008f8c(iVar1);
      }
      break;
    case 2:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        unaff_s3 = func_0x00008f98(iVar1);
      }
      break;
    case 3:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        unaff_s3 = func_0x00008fa4(iVar1);
      }
      break;
    case 4:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        unaff_s3 = func_0x00008fb0(iVar1);
      }
      break;
    case 5:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        unaff_s3 = func_0x00008fbc(iVar1);
      }
      break;
    default:
      unaff_s1 = 1;
      break;
    case 7:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        unaff_s2 = func_0x00008f4c(iVar1);
      }
    }
  }
  else if (in_v0 == 0x2a) {
    switch(*(undefined4 *)(unaff_s4 + 4)) {
    case 0:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        func_0x00008e44(iVar1,*(undefined4 *)(unaff_s4 + 0xc));
      }
      break;
    case 1:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        func_0x00008e4c(iVar1,*(undefined4 *)(unaff_s4 + 0xc));
      }
      break;
    case 2:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        func_0x00008e94(iVar1,*(undefined4 *)(unaff_s4 + 0xc));
      }
      break;
    case 3:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        func_0x00008f34(iVar1,*(undefined4 *)(unaff_s4 + 0xc));
      }
      break;
    case 4:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        func_0x00008f3c(iVar1,*(undefined4 *)(unaff_s4 + 0xc));
      }
      break;
    case 5:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        func_0x00008f44(iVar1,*(undefined4 *)(unaff_s4 + 0xc));
      }
      break;
    case 6:
      iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
      if (iVar1 != 0) {
        func_0x00008edc(iVar1,*(undefined4 *)(unaff_s4 + 0xc),*(undefined4 *)(unaff_s4 + 0x10));
      }
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x2f) {
    iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 4));
    if (iVar1 != 0) {
      unaff_s3 = 1;
    }
  }
  else if (in_v0 == 0x35) {
    unaff_s3 = func_0x00002770(*(undefined4 *)(unaff_s4 + 4));
  }
  else if (in_v0 == 0x29) {
    iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 4));
    if (iVar1 != 0) {
      unaff_s3 = func_0x00008bc8(iVar1);
    }
  }
  else if (in_v0 == 0x32) {
    if (*(int *)(unaff_s4 + 4) != 0) {
      func_0x000080a8();
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x28) {
    iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 4));
    if (iVar1 != 0) {
      func_0x00008ac4(iVar1);
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x27) {
    if (*(int *)(unaff_s4 + 4) != 0) {
      func_0x0000846c();
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x34) {
    iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 4));
    if (iVar1 != 0) {
      func_0x00008690(iVar1);
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x33) {
    iVar1 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 4));
    if (iVar1 != 0) {
      func_0x00008598(iVar1);
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x26) {
    if (*(int *)(unaff_s4 + 4) != 0) {
      func_0x000082f8();
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x24) {
    func_0x00001dbc(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8),
                    *(undefined4 *)(unaff_s4 + 0xc),*(undefined4 *)(unaff_s4 + 0x10));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x23) {
    func_0x00008c64(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x22) {
    func_0x00001f08(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8),
                    *(undefined4 *)(unaff_s4 + 0xc));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x6a) {
    func_0x00001af4(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8),
                    *(undefined4 *)(unaff_s4 + 0xc),*(undefined4 *)(unaff_s4 + 0x10));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x36) {
    func_0x00001c64(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8),
                    *(undefined4 *)(unaff_s4 + 0xc),*(undefined4 *)(unaff_s4 + 0x10));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x21) {
    func_0x000019a8(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8),
                    *(undefined4 *)(unaff_s4 + 0xc),*(undefined4 *)(unaff_s4 + 0x10));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x519) {
    iVar1 = func_0x00003938();
    if (iVar1 != 0x10b30) {
      func_0x00001600(*(undefined4 *)(unaff_s4 + 4),iVar1);
    }
    unaff_s0 = 1;
  }
  else if (in_v0 == 0x518) {
    iVar1 = func_0x00003938();
    if (iVar1 != 0x10b30) {
      func_0x00001560(*(undefined4 *)(unaff_s4 + 4),iVar1);
    }
    unaff_s0 = 1;
  }
  else if (in_v0 == 0x517) {
    unaff_s3 = func_0x000016b4(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x516) {
    unaff_s3 = func_0x00001824(*(undefined4 *)(unaff_s4 + 4));
  }
  else if (in_v0 == 0x515) {
    unaff_s3 = func_0x0000176c(*(undefined4 *)(unaff_s4 + 4));
  }
  else if (in_v0 == 0x514) {
    unaff_s2 = func_0x00001750(*(undefined4 *)(unaff_s4 + 4));
  }
  else if (in_v0 == 0x4b2) {
    unaff_s3 = func_0x000018fc(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8));
  }
  else if (in_v0 == 0x4b1) {
    unaff_s3 = func_0x00001980(*(undefined4 *)(unaff_s4 + 4),unaff_s4 + 8);
  }
  else if (in_v0 == 0x2c) {
    unaff_s3 = func_0x00001988(*(undefined4 *)(unaff_s4 + 4));
  }
  else if (in_v0 == 6) {
    unaff_s3 = func_0x0000a8c4();
  }
  else if (in_v0 == 0x15) {
    unaff_s3 = func_0x00002618(*(undefined4 *)(unaff_s4 + 4));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x14) {
    if (iRam00010b1c == 0) {
      func_0x000000ec(0x10b40,0,0x110);
      unaff_s3 = func_0x0000236c(*(undefined4 *)(unaff_s4 + 4),unaff_s4 + 8);
    }
  }
  else if (in_v0 == 0x3c) {
    iVar1 = func_0x00003938();
    if (iVar1 != 0x10b30) {
      func_0x00002834(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8),unaff_s4 + 0x10,
                      iVar1);
    }
    unaff_s0 = 1;
  }
  else if (in_v0 == 0x38) {
    func_0x000003dc(*(undefined4 *)(unaff_s4 + 4));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x37) {
    func_0x000003ac(*(undefined4 *)(unaff_s4 + 4),unaff_s4 + 8);
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x2e) {
    unaff_s3 = func_0x00000334(unaff_s4 + 4);
    unaff_s1 = 1;
  }
  else if (in_v0 == 5) {
    unaff_s3 = func_0x00005cd4(*(undefined4 *)(unaff_s4 + 4),unaff_s4 + 8);
    unaff_s1 = 1;
  }
  else if (in_v0 == 3) {
    switch(*(undefined4 *)(unaff_s4 + 4)) {
    case 0:
      func_0x00004c9c(*(undefined4 *)(unaff_s4 + 8),*(undefined4 *)(unaff_s4 + 0xc));
      break;
    case 1:
      func_0x00004ca4(*(undefined4 *)(unaff_s4 + 8),*(undefined4 *)(unaff_s4 + 0xc));
      break;
    case 2:
      func_0x00004cac(*(undefined4 *)(unaff_s4 + 8),*(undefined4 *)(unaff_s4 + 0xc));
      break;
    case 3:
      func_0x00004cb4(*(undefined4 *)(unaff_s4 + 8),*(undefined4 *)(unaff_s4 + 0xc));
      break;
    case 4:
      func_0x00004cbc(*(undefined4 *)(unaff_s4 + 8),*(undefined4 *)(unaff_s4 + 0xc));
      break;
    case 5:
      func_0x00004cc4(*(undefined4 *)(unaff_s4 + 8),*(undefined4 *)(unaff_s4 + 0xc));
    }
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x40) {
    func_0x00006d4c();
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x3f) {
    func_0x00004fe8();
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x3e) {
    func_0x00006b04();
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x450) {
    func_0x00004b08(*(undefined4 *)(unaff_s4 + 4));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x44f) {
    func_0x000049c0(*(undefined4 *)(unaff_s4 + 4));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x44e) {
    uVar2 = func_0x000092d4(*(undefined4 *)(unaff_s4 + 8));
    func_0x00004854(*(undefined4 *)(unaff_s4 + 4),uVar2);
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x12) {
    func_0x0000484c(*(undefined4 *)(unaff_s4 + 4));
    unaff_s1 = 1;
  }
  else if (in_v0 == 7) {
    func_0x000047d8(*(undefined4 *)(unaff_s4 + 4));
    unaff_s1 = 1;
  }
  else if (in_v0 == 0x44d) {
    unaff_s3 = func_0x0000cce4();
  }
  else if (in_v0 == 0x44c) {
    unaff_s3 = func_0x0000cc58();
  }
  else if (in_v0 == 0x3e9) {
    func_0x00005cb4(*(undefined4 *)(unaff_s4 + 4),*(undefined4 *)(unaff_s4 + 8));
    unaff_s1 = 1;
  }
  else if (in_v0 == 2) {
    uVar2 = *(undefined4 *)(unaff_s4 + 4);
    func_0x00003784(uVar2);
    unaff_s3 = func_0x00005bc4(uVar2);
    unaff_s1 = 1;
  }
  else if (in_v0 == 1) {
    in_stack_00000054 = *(undefined4 *)(unaff_s4 + 4);
    in_stack_00000050 = unaff_s4 + 0x1c;
    in_stack_00000058 = *(undefined4 *)(unaff_s4 + 8);
    in_stack_0000005c = *(undefined4 *)(unaff_s4 + 0xc);
    in_stack_00000044 = *(undefined4 *)(unaff_s4 + 0x10);
    in_stack_00000048 = *(undefined4 *)(unaff_s4 + 0x14);
    uStack0000004c = (undefined2)*(undefined4 *)(unaff_s4 + 0x18);
    uStack0000004e = (undefined2)((uint)*(undefined4 *)(unaff_s4 + 0x18) >> 0x10);
    unaff_s3 = func_0x000056fc(&stack0x00000054,&stack0x00000044);
  }
  else if (in_v0 == 0x67) {
    unaff_s0 = 1;
    uRam00010b24 = in_stack_00000060;
  }
  else if (in_v0 == 100) {
    unaff_s0 = 1;
    uRam00010b28 = in_stack_00000060;
  }
  else if (in_v0 == 1000) {
    unaff_s0 = 1;
    uRam00010b2c = in_stack_00000060;
  }
  else if (in_v0 == 99) {
    func_0x00003784(uRam000248e0);
    unaff_s1 = 1;
  }
  else {
    unaff_s3 = 0xffffffff;
  }
  if (unaff_s2 == 0) {
    if (unaff_s1 == 0) {
      if (unaff_s0 == 0) {
        func_0x0000ac8c(in_stack_00000060,unaff_s3);
      }
    }
    else {
      func_0x0000ad24(in_stack_00000060);
    }
  }
  else {
    func_0x0000accc(in_stack_00000060,unaff_s2);
  }
  return 0;
}

