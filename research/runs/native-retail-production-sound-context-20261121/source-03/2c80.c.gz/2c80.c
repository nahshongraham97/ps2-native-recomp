
/* WARNING: Removing unreachable block (ram,0x00003670) */
/* WARNING: Removing unreachable block (ram,0x00003678) */

undefined4 FUN_00002c80(void)

{
  int unaff_s2;
  undefined4 in_stack_00000060;
  
  FUN_00003784(uRam000248e0);
  if (unaff_s2 == 0) {
    func_0x0000ad24(in_stack_00000060);
  }
  else {
    func_0x0000accc(in_stack_00000060);
  }
  return 0;
}

