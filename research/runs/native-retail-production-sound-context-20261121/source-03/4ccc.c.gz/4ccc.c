
undefined4 FUN_00004ccc(int param_1)

{
  return *(undefined4 *)(param_1 + 0x290);
}

