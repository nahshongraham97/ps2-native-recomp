
undefined4 FUN_00000334(undefined4 param_1)

{
  undefined1 auStack_100 [256];
  
  if (iRam00010b08 != 0) {
    func_0x00000da4();
  }
  func_0x0000011c(0x100b0,param_1,0xff);
  uRam000101af = 0;
  func_0x0000010c(auStack_100,0x100b0);
  func_0x0000a934(auStack_100,0x10a08);
  return 1;
}

