
void FUN_00003784(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = 0x40;
  puVar1 = (undefined4 *)func_0x0000ad2c(0x49,uRam00010b2c);
  if (puVar1 != (undefined4 *)0x0) {
    uVar2 = func_0x00004ccc(param_1);
    *puVar1 = uVar2;
    uVar2 = func_0x00004cd8(param_1);
    puVar1[1] = uVar2;
    uVar2 = func_0x00004ce4(param_1);
    puVar1[2] = uVar2;
    uVar2 = func_0x00004cf0(param_1);
    puVar1[3] = uVar2;
    uVar2 = func_0x00004cfc(param_1);
    puVar1[4] = uVar2;
    uVar2 = func_0x00004d08(param_1);
    puVar1[5] = uVar2;
    puVar1[6] = *(undefined4 *)(param_1 + 0x3b8);
    uVar2 = func_0x00007148();
    puVar1[7] = uVar2;
    uVar2 = func_0x00007158();
    puVar1[8] = uVar2;
    puVar1 = puVar1 + 9;
    iVar5 = 0;
    do {
      piVar3 = (int *)(iRam000248c0 + iVar5 * 0x10);
      if ((((*(byte *)(piVar3 + 3) & 3) != 0) && ((*(ushort *)(*piVar3 + 0x1e) & 0x8000) != 0)) &&
         (iVar4 != 0)) {
        iVar4 = iVar4 + -1;
        uVar2 = func_0x0000f318(0x248b4);
        *puVar1 = uVar2;
        puVar1 = puVar1 + 1;
      }
      if (iVar4 != 0) {
        *puVar1 = 0;
      }
      iVar5 = iVar5 + 1;
    } while (iVar5 < 0x234);
    func_0x0000ae00();
  }
  return;
}

