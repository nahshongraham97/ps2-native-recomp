
void FUN_000045b0(undefined4 param_1,int param_2,undefined4 param_3)

{
  ushort *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  if (*(int *)(param_2 + 0x24) == 0) {
    for (iVar2 = *(int *)(param_2 + 0x38); iVar2 != 0;
        iVar2 = func_0x00003db0(param_1,iVar2,param_3)) {
    }
    puVar4 = *(undefined4 **)(param_2 + 0x28);
    while (puVar4 != (undefined4 *)0x0) {
      puVar3 = (undefined4 *)*puVar4;
      func_0x0000937c(puVar4);
      if ((*(ushort *)(puVar4 + 3) & 8) == 0) {
        iVar2 = puVar4[1];
        func_0x000046c8(puVar4);
        puVar1 = (ushort *)(puVar4 + 3);
        puVar4 = puVar3;
        if ((*puVar1 & 0x100) != 0) {
          if (iVar2 != 0) {
            func_0x000046a8(iVar2,*(undefined4 *)(param_2 + 0x2c));
          }
          *(undefined4 *)(param_2 + 0x2c) = 0;
        }
      }
      else {
        func_0x00003fcc(param_1,param_2,puVar4);
        puVar4 = puVar3;
      }
    }
  }
  return;
}

