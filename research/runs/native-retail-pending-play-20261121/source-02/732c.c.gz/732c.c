
void FUN_0000732c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  iRam00024cd4 = iRam00024cd4 + 1;
  func_0x0000a7d8(0x248d4);
  func_0x00007178(param_1,param_2,param_3,param_4,param_5);
  func_0x0000a7e4(0x248d4);
  iRam00024cd4 = iRam00024cd4 + -1;
  return;
}

