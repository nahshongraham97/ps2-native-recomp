
undefined4 FUN_0000fed4(void)

{
  return uRam00048e64;
}

