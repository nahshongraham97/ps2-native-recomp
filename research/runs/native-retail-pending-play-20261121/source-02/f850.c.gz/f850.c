
bool FUN_0000f850(undefined4 param_1,int param_2,undefined4 param_3,code *param_4,undefined4 param_5
                 )

{
  undefined4 *puVar1;
  bool bVar2;
  undefined4 *puVar3;
  
  func_0x0000a7d8(iRam000248e0 + 0x3ac);
  func_0x0000a7d8(0x4904c);
  puVar3 = puRam00048e54;
  bVar2 = puRam00048e54 == (undefined4 *)0x0;
  if (bVar2) {
    (*param_4)(0,param_3,param_5);
  }
  else {
    puVar1 = puRam00048e54 + 1;
    puRam00048e54 = (undefined4 *)*puRam00048e54;
    *puVar1 = param_1;
    puVar3[2] = param_2;
    puVar3[3] = param_3;
    puVar3[4] = param_4;
    puVar3[5] = param_5;
    func_0x0000f278(0,param_5);
    *(int *)(param_2 + 0x2c) = *(int *)(param_2 + 0x2c) + 1;
    *puVar3 = 0;
    *puRam00048e5c = puVar3;
    puRam00048e5c = puVar3;
    func_0x000001cc(uRam000109f4);
  }
  func_0x0000a7e4(0x4904c);
  func_0x0000a7e4(iRam000248e0 + 0x3ac);
  return !bVar2;
}

