
void FUN_0000f6e4(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  
  do {
    func_0x000001dc(uRam000109f4);
    func_0x0000a7d8(0x4904c);
    piVar1 = piRam00048e58;
    piVar4 = (int *)0x48e58;
    piVar5 = (int *)0x0;
    while (piVar3 = piVar1, piVar3 != (int *)0x0) {
      if (*(int *)(piVar3[3] + 4) == 0) {
        piVar1 = (int *)*piVar3;
        piVar4 = piVar3;
      }
      else {
        iVar2 = *piVar3;
        *piVar4 = iVar2;
        if (iVar2 == 0) {
          piRam00048e5c = piVar4;
        }
        piVar1 = (int *)0x0;
        piVar5 = piVar3;
      }
    }
    if (((piVar5 == (int *)0x0) && (piVar5 = piRam00048e58, piRam00048e58 != (int *)0x0)) &&
       (piRam00048e58 = (int *)*piRam00048e58, piRam00048e58 == (int *)0x0)) {
      piRam00048e5c = (int *)0x48e58;
    }
    uRam00048e64 = 0;
    if (piVar5 != (int *)0x0) {
      uRam00048e68 = 1;
    }
    piRam00048e60 = piVar5;
    func_0x0000a7e4(0x4904c);
    if (piVar5 != (int *)0x0) {
      func_0x0000732c(piVar5[1],piVar5[2],piVar5[3],piVar5[4],piVar5[5]);
      func_0x0000a7d8(0x4904c);
      *piVar5 = (int)piRam00048e54;
      piRam00048e60 = (int *)0x0;
      uRam00048e64 = 0;
      uRam00048e68 = 0;
      piRam00048e54 = piVar5;
      func_0x0000a7e4(0x4904c);
    }
  } while( true );
}

