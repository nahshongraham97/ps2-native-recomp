
void FUN_00007178(int param_1,int param_2,undefined4 *param_3,code *param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0;
  func_0x0000a7d8(param_1 + 0x3ac);
  iVar2 = param_3[1];
  if (iVar2 == 0) {
    func_0x0000a7e4(param_1 + 0x3ac);
    iVar2 = func_0x000073d0(param_1,param_2,*param_3,param_3[3]);
    func_0x0000fee4();
    func_0x0000a7d8(param_1 + 0x3ac);
    iVar3 = func_0x0000fed4();
    if ((iVar3 != 0) && (iVar2 != 0)) {
      iVar1 = func_0x0000f278(0,param_5);
      *(int *)(iVar2 + 0x30) = param_2;
      func_0x0000f318(0x248b4,param_5);
      func_0x00000170();
      func_0x00007700(iVar2);
      *(int *)(iVar1 + 0x30) = param_2;
      iVar2 = 0;
      func_0x0000a7d8(param_1 + 0x3ac);
      func_0x000087ec(iVar1,1);
      func_0x0000a7e4(param_1 + 0x3ac);
    }
    if (iVar2 == 0) {
      func_0x0000f318(0x248b4,param_5);
      func_0x000091fc(param_5);
    }
    else {
      param_3[1] = iVar2;
      *(undefined2 *)(param_3[1] + 0x20) = 1;
      *(int *)(param_3[1] + 0x30) = param_2;
    }
  }
  else {
    *(short *)(iVar2 + 0x20) = *(short *)(iVar2 + 0x20) + 1;
    func_0x0000f318(0x248b4,param_5);
  }
  if (iVar3 == 0) {
    (*param_4)(param_3[1] != 0,param_3,param_5);
  }
  *(int *)(param_2 + 0x2c) = *(int *)(param_2 + 0x2c) + -1;
  func_0x0000a7e4(param_1 + 0x3ac);
  return;
}

