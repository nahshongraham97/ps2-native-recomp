
void FUN_00000ee8(int param_1,undefined4 param_2,undefined4 *param_3,code *param_4,
                 undefined4 param_5)

{
  int iVar1;
  
  if ((param_3[1] == 0) && (iVar1 = func_0x00000e28(param_2,param_3), iVar1 != 0)) {
    func_0x0000a7d8(param_1 + 0x3ac);
    iVar1 = func_0x000073d0(param_1,param_2,*param_3,param_3[3]);
    if (iVar1 != 0) {
      param_3[1] = iVar1;
      *(undefined2 *)(iVar1 + 0x20) = 1;
      *(undefined4 *)(iVar1 + 0x30) = param_2;
    }
    func_0x0000a7e4(param_1 + 0x3ac);
  }
  if (param_3[1] == 0) {
    func_0x0000f850(param_1,param_2,param_3,param_4,param_5);
  }
  else {
    (*param_4)(1,param_3,param_5);
  }
  return;
}

