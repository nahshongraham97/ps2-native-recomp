
void FUN_00001090(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = func_0x0000f278(0,param_3);
  func_0x0000f318(0x248b4,param_3);
  if (param_1 == 0) {
    func_0x00007918(param_3);
  }
  else {
    func_0x0000a7d8(iRam000248e0 + 0x3ac);
    uVar3 = *(undefined4 *)(iRam000248e0 + 0x2a8);
    *(undefined4 *)(iRam000248e0 + 0x2a8) = 0;
    func_0x0000a7e4(iRam000248e0 + 0x3ac);
    iVar2 = func_0x00007a38(iVar1,param_2);
    if (iVar2 == 0) {
      *(undefined4 *)(iVar1 + 0x30) = *(undefined4 *)(*(int *)(param_2 + 4) + 0x30);
      iVar2 = func_0x00007fa0(param_3);
      *(undefined2 *)(iVar1 + 0x22) = 0;
      if (iVar2 != 0) {
        return;
      }
    }
    func_0x00007918(param_3);
    func_0x000014c8(param_2);
    func_0x0000a7d8(iRam000248e0 + 0x3ac);
    *(undefined4 *)(iRam000248e0 + 0x2a8) = uVar3;
    func_0x0000a7e4(iRam000248e0 + 0x3ac);
  }
  return;
}

