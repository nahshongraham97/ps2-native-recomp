
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_002ccec0(void)

{
  DAT_00835430 = _sprintf;
  _DAT_00835434 = _vsprintf;
  DAT_00835438 = FUN_0039b890;
  DAT_0083543c = _strncpy;
  DAT_00835440 = FUN_0039b8a0;
  DAT_00835444 = _strncat;
  DAT_00835448 = &UNK_002ccea0;
  DAT_0083544c = &UNK_002cce80;
  _DAT_00835450 = FUN_003986b0;
  DAT_00835454 = _strcmp;
  _DAT_00835458 = _strncmp;
  _DAT_0083545c = &UNK_002ccdd0;
  DAT_00835460 = _strlen;
  DAT_00835464 = &UNK_002cce20;
  DAT_00835468 = &UNK_002cce50;
  _DAT_0083546c = FUN_003994a5;
  _DAT_00835470 = FUN_00398d6b;
  return 1;
}

