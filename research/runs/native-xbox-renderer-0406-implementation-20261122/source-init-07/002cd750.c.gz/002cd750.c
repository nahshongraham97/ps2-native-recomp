
undefined4 FUN_002cd750(char *param_1)

{
  char cVar1;
  
  cVar1 = *param_1;
  if ((cVar1 != '\\') &&
     ((((cVar1 < 'A' || ('Z' < cVar1)) && ((cVar1 < 'a' || ('z' < cVar1)))) || (param_1[1] != ':')))
     ) {
    return 0;
  }
  return 1;
}

