
undefined4 * FUN_002c7670(void)

{
  return &DAT_005a6938;
}

