
undefined4 FUN_002c0250(undefined4 param_1)

{
  int iVar1;
  int unaff_ESI;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  iVar1 = (**(code **)(unaff_ESI + 4))(4,&DAT_00835350,&DAT_00835474,0);
  if (iVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x18,4);
    FUN_002c2370(&uStack_8);
  }
  iVar1 = (**(code **)(unaff_ESI + 4))(0,0,param_1,0);
  if (iVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x18,0);
    FUN_002c2370(&uStack_8);
    return 0;
  }
  iVar1 = (**(code **)(unaff_ESI + 4))(0xb,&DAT_00835388,0,0x1d);
  if (iVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x18,0xb);
    FUN_002c2370(&uStack_8);
  }
  DAT_005c7404 = DAT_005c7404 + 1;
  return 1;
}

