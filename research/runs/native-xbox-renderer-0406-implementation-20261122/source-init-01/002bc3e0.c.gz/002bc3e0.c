
undefined4 FUN_002bc3e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = (*DAT_00835404)(param_1);
  if (iVar1 != 0) {
    iVar1 = (*(code *)*param_2)(param_1);
    param_2[1] = iVar1;
    if (iVar1 != 0) {
      return 0;
    }
  }
  return param_1;
}

