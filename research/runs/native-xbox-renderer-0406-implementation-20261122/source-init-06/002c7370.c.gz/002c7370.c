
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint recovery0406_002c7370(undefined4 param_1,int *param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  uint uVar2;
  int extraout_ECX;
  int extraout_ECX_00;
  int iVar3;
  int *piVar4;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  int iStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  undefined4 uStack_4;
  
  switch(param_1) {
  case 0:
    uVar2 = FUN_002c6410();
    return uVar2;
  case 1:
  case 8:
    break;
  case 2:
    uVar2 = FUN_002c65a0();
    return uVar2;
  case 3:
    FUN_002ce970();
    FUN_002c8560();
    FUN_002c7d50();
    D3D8::D3DDevice_Release();
    DAT_00834444 = 0;
    return 1;
  case 4:
    piVar4 = &DAT_005a6938;
    for (iVar3 = 0xe; iVar3 != 0; iVar3 = iVar3 + -1) {
      *param_2 = *piVar4;
      piVar4 = piVar4 + 1;
      param_2 = param_2 + 1;
    }
    _DAT_008344e4 = param_3;
    return 1;
  case 5:
    *param_2 = DAT_00834478;
    return 1;
  case 6:
    if (param_4 < 0) {
      return 0;
    }
    if (DAT_00834478 <= param_4) {
      return 0;
    }
    D3D8::D3D_EnumAdapterModes(0,param_4,&iStack_14);
    param_2[1] = iStack_10;
    *param_2 = iStack_14;
    uVar1 = FUN_002c62f0();
    *(undefined4 *)(extraout_ECX + 8) = uVar1;
    *(undefined4 *)(extraout_ECX + 0x10) = uStack_c;
    *(undefined4 *)(extraout_ECX + 0xc) = 1;
    uVar1 = FUN_002c6340();
    *(undefined4 *)(extraout_ECX_00 + 0x14) = uVar1;
    if ((uStack_8 & 0x20) != 0) {
      *(undefined4 *)(extraout_ECX_00 + 0xc) = 3;
    }
    if ((uStack_8 & 0x40) != 0) {
      *(uint *)(extraout_ECX_00 + 0xc) = *(uint *)(extraout_ECX_00 + 0xc) | 0x200;
    }
    if ((uStack_8 & 0x10) != 0) {
      *(uint *)(extraout_ECX_00 + 0xc) = *(uint *)(extraout_ECX_00 + 0xc) | 0x100;
    }
    if ((char)uStack_8 < '\0') {
      *(uint *)(extraout_ECX_00 + 0xc) = *(uint *)(extraout_ECX_00 + 0xc) | 0x400;
    }
    if ((uStack_8 & 0x100) != 0) {
      *(uint *)(extraout_ECX_00 + 0xc) = *(uint *)(extraout_ECX_00 + 0xc) | 0x800;
      return 1;
    }
    break;
  case 7:
    if ((-1 < param_4) && (param_4 < DAT_00834478)) {
      D3D8::D3D_EnumAdapterModes(0,param_4,&iStack_14);
      DAT_00834450 = iStack_14;
      DAT_00834454 = iStack_10;
      DAT_00834458 = uStack_4;
      DAT_0083446c = uStack_8;
      DAT_00834470 = uStack_c;
      DAT_0083447c = FUN_002c62f0();
      DAT_00834484 = param_4;
      return 1;
    }
  default:
    return 0;
  case 10:
    *param_2 = DAT_00834484;
    return 1;
  case 0xb:
    uVar2 = FUN_002c7140();
    return uVar2;
  case 0xd:
    *param_2 = 1;
    return 1;
  case 0xe:
    if (param_4 != 0) {
      uStack_1c = 1;
      uStack_18 = FUN_002c2400(2,"Invalid subsystem number");
      FUN_002c2370(&uStack_1c);
      return 0;
    }
    (*DAT_00835438)(param_2,&DAT_0083448c);
    return 1;
  case 0xf:
    *param_2 = 0;
    return 1;
  case 0x10:
    return (uint)(param_4 == 0);
  case 0x12:
    D3D8::D3DDevice_SetVertexShader(0);
    D3D8::D3DDevice_SetPixelShader(0);
    return 0;
  case 0x13:
    *param_2 = 0x1000;
    return 1;
  case 0x16:
    *(undefined2 *)param_2 = 8;
  }
  return 1;
}

