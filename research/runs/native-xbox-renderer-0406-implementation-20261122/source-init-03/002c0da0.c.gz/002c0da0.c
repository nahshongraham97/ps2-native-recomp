
bool recovery0406_002c0da0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = (*DAT_00835408)(param_1,&DAT_004e1458);
  if (iVar1 != 0) {
    (*DAT_0083540c)(iVar1);
  }
  return iVar1 != 0;
}

