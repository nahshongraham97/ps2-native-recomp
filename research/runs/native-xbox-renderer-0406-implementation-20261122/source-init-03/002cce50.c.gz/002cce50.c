
void recovery0406_002cce50(char *param_1)

{
  char *pcVar1;
  char cVar2;
  
  if (param_1 != (char *)0x0) {
    cVar2 = *param_1;
    while (cVar2 != '\0') {
      cVar2 = *param_1;
      if (('@' < cVar2) && (cVar2 < '[')) {
        *param_1 = cVar2 + ' ';
      }
      pcVar1 = param_1 + 1;
      param_1 = param_1 + 1;
      cVar2 = *pcVar1;
    }
  }
  return;
}

