
undefined4 FUN_002c04f0(undefined4 param_1,uint param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  undefined4 local_8;
  undefined4 local_4;
  
  iVar1 = DAT_00835320;
  if (param_2 < 0x10001) {
    *(short *)(&DAT_00835378 + DAT_00835320) = (short)param_2;
    *(undefined4 *)(&DAT_0083537c + iVar1) = param_1;
    *(undefined4 *)(&DAT_00835380 + iVar1) = 0x24;
    *(undefined4 *)(&DAT_00835388 + iVar1) = param_3;
    *(uint *)(&DAT_00835384 + iVar1) = param_4 | 0x18;
    iVar1 = FUN_002c9fe0(*(undefined4 *)((int)&DAT_00835340 + iVar1),&DAT_00835378 + iVar1,1);
    if (iVar1 != 0) {
      return param_1;
    }
  }
  else {
    local_8 = 1;
    local_4 = FUN_002c2400(0x32);
    FUN_002c2370(&local_8);
  }
  return 0;
}

