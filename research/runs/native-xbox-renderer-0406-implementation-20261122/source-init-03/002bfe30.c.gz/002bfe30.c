
int FUN_002bfe30(void)

{
  int iVar1;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  (*DAT_00835354)(0x12,0,0,0);
  FUN_002c2bf0(&DAT_005a6788,&DAT_00835340);
  iVar1 = (*DAT_00835354)(3,0,0,0);
  if (iVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_002c2400(0x18,3);
    FUN_002c2370(&uStack_8);
    return 0;
  }
  DAT_00835490 = 2;
  return iVar1;
}

