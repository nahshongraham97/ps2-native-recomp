
long FUN_00300e20(long param_1,undefined8 param_2)

{
  int iVar1;
  long lVar2;
  long lVar3;
  int iVar4;
  undefined8 unaff_s0;
  int iVar5;
  undefined8 unaff_s1;
  int iVar6;
  undefined8 unaff_s2;
  undefined8 unaff_s3;
  undefined4 uStack00000000;
  undefined4 uStack00000004;
  undefined4 uStack00000010;
  undefined4 uStack00000014;
  undefined4 uStack00000020;
  undefined4 uStack00000024;
  undefined4 uStack00000030;
  undefined4 uStack00000034;
  
  uStack00000030 = (undefined4)unaff_s3;
  uStack00000034 = (undefined4)((ulong)unaff_s3 >> 0x20);
  uStack00000020 = (undefined4)unaff_s2;
  uStack00000024 = (undefined4)((ulong)unaff_s2 >> 0x20);
  uStack00000010 = (undefined4)unaff_s1;
  uStack00000014 = (undefined4)((ulong)unaff_s1 >> 0x20);
  uStack00000000 = (undefined4)unaff_s0;
  uStack00000004 = (undefined4)((ulong)unaff_s0 >> 0x20);
  iVar1 = FUN_0019c320();
  do {
    if (iVar1 < 1) {
      return 0;
    }
    if (param_1 == -1) {
      lVar2 = 0;
    }
    else {
      lVar2 = FUN_0019c140(param_1,iVar1);
      if (lVar2 == 0) {
        lVar2 = 0;
      }
      else {
        lVar3 = FUN_00199480(lVar2);
        if (lVar3 == 1) {
          lVar3 = FUN_00199480(lVar2);
          iVar6 = (int)lVar2;
          if ((lVar3 == 2) || (lVar3 == 1)) {
            iVar5 = 0;
            if (0 < *(int *)(iVar6 + 0x14)) {
              iVar4 = 0;
              do {
                lVar3 = FUN_001deb10(*(undefined4 *)(*(int *)(iVar6 + 0x20) + iVar4 + 0xc),param_2);
                if (lVar3 == 0) goto LAB_00300f20;
                iVar5 = iVar5 + 1;
                iVar4 = iVar4 + 0x10;
              } while (iVar5 < *(int *)(iVar6 + 0x14));
            }
            iVar5 = -1;
          }
          else {
            iVar5 = -1;
          }
LAB_00300f20:
          if (iVar5 == -1) {
            lVar2 = 0;
          }
          else {
            lVar2 = FUN_00300f90(lVar2,*(undefined4 *)(*(int *)(iVar6 + 0x20) + iVar5 * 0x10 + 4));
          }
        }
        else {
          lVar2 = 0;
        }
      }
    }
    if (lVar2 != 0) {
      return lVar2;
    }
    iVar1 = iVar1 + -1;
  } while( true );
}

