
void FUN_0019cfa0(undefined8 param_1,int param_2)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  long lVar6;
  
  piVar2 = (int *)param_1;
  lVar6 = 0;
  if ((char)piVar2[7] == '\0') {
    FUN_003de060();
    if ((*piVar2 != 0) && (*(int *)(*piVar2 + 8) == 3)) {
      FUN_00215010(piVar2[0xb]);
    }
    *piVar2 = 0;
    goto LAB_0019d15c;
  }
  if (*piVar2 == 0) {
    uVar5 = (uint)*(byte *)((int)piVar2 + 0x1f);
  }
  else {
    uVar5 = *(uint *)(*piVar2 + 8);
  }
  if (piVar2[2] != 0) {
    if (uVar5 == 1) {
      bVar1 = true;
    }
    else if (uVar5 == 2) {
      bVar1 = true;
    }
    else {
      bVar1 = false;
    }
    if (bVar1) {
      lVar6 = FUN_00429d20(uRam0064ec78,0x34,3,0,0,0);
      FUN_001db8a8(lVar6,param_1,0x34);
      iVar3 = (int)lVar6;
      *(undefined4 *)(iVar3 + 0x18) = *(undefined4 *)(param_2 + 0x14);
      *(int *)(param_2 + 0x14) = iVar3;
      *(undefined1 *)(iVar3 + 0x1d) = 0;
    }
  }
  if (uVar5 == 3) {
    iVar3 = piVar2[0xb];
    if (iVar3 != 0) {
      piVar2[0xb] = 0;
      *(undefined4 *)(iVar3 + 0x4c) = 0;
      if (lVar6 == 0) {
        FUN_00215010();
      }
      else {
        *(undefined4 *)(iVar3 + 0x44) = 0xfffffffe;
      }
    }
LAB_0019d100:
    *(undefined1 *)(piVar2 + 7) = 0;
  }
  else {
    if (uVar5 == 2) {
      if (*(char *)((int)piVar2 + 0x1e) != '\0') {
        puVar4 = (undefined4 *)piVar2[9];
        iVar3 = 0;
        if (0 < piVar2[5]) {
          do {
            *puVar4 = 0;
            iVar3 = iVar3 + 1;
            puVar4 = puVar4 + 1;
          } while (iVar3 < piVar2[5]);
        }
      }
      *(undefined1 *)((int)piVar2 + 0x1e) = 0;
      piVar2[9] = 0;
      piVar2[10] = 0;
      goto LAB_0019d100;
    }
    if (uVar5 == 1) {
      FUN_002ffd60(param_1);
      goto LAB_0019d100;
    }
    *(undefined1 *)(piVar2 + 7) = 0;
  }
  *piVar2 = 0;
LAB_0019d15c:
  piVar2[5] = 0;
  piVar2[4] = 0;
  return;
}

