
long FUN_00300e60(void)

{
  long lVar1;
  long lVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int unaff_s3_lo;
  undefined4 unaff_s5_lo;
  undefined4 unaff_s5_hi;
  
  do {
    lVar1 = FUN_0019c140();
    if (lVar1 == 0) {
      lVar1 = 0;
    }
    else {
      lVar2 = FUN_00199480(lVar1);
      if (lVar2 == 1) {
        lVar2 = FUN_00199480(lVar1);
        iVar5 = (int)lVar1;
        if ((lVar2 == 2) || (lVar2 == 1)) {
          iVar4 = 0;
          if (0 < *(int *)(iVar5 + 0x14)) {
            iVar3 = 0;
            do {
              lVar2 = FUN_001deb10(*(undefined4 *)(*(int *)(iVar5 + 0x20) + iVar3 + 0xc));
              if (lVar2 == 0) goto LAB_00300f20;
              iVar4 = iVar4 + 1;
              iVar3 = iVar3 + 0x10;
            } while (iVar4 < *(int *)(iVar5 + 0x14));
          }
          iVar4 = -1;
        }
        else {
          iVar4 = -1;
        }
LAB_00300f20:
        if (iVar4 == -1) {
          lVar1 = 0;
        }
        else {
          lVar1 = FUN_00300f90(lVar1,*(undefined4 *)(*(int *)(iVar5 + 0x20) + iVar4 * 0x10 + 4));
        }
      }
      else {
        lVar1 = 0;
      }
    }
    while( true ) {
      if (lVar1 != 0) {
        return lVar1;
      }
      unaff_s3_lo = unaff_s3_lo + -1;
      if (unaff_s3_lo < 1) {
        return 0;
      }
      if (CONCAT44(unaff_s5_hi,unaff_s5_lo) != -1) break;
      lVar1 = 0;
    }
  } while( true );
}

