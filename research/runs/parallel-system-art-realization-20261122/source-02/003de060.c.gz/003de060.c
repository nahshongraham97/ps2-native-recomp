
void FUN_003de060(int param_1)

{
  int *piVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 8) != 0) {
    iVar2 = *(int *)(param_1 + 0x18);
    if (iVar2 == 0) {
      piVar1 = *(int **)(param_1 + 4);
      goto LAB_003de0a4;
    }
    if (*(int *)(iVar2 + 8) == 0) {
      *(int *)(iVar2 + 8) = *(int *)(param_1 + 8) + *(int *)(param_1 + 0xc);
    }
  }
  piVar1 = *(int **)(param_1 + 4);
LAB_003de0a4:
  if (piVar1 != (int *)0x0) {
    if (*(char *)((int)piVar1 + 0xd) == '\0') {
      if (piVar1 == (int *)iRam0064f1b4) {
        *(undefined1 *)((int)piVar1 + 0xe) = 1;
        piVar1[5] = 0;
        *(undefined4 *)(param_1 + 4) = 0;
      }
      else if ((piVar1[1] != 0) && (piVar1 != (int *)0x0)) {
        if (piVar1[1] == 0) {
          iVar2 = piVar1[2];
        }
        else {
          uRam0064e434 = uRam0064df54;
          uRam0064df54 = 0;
          FUN_002dff50(piVar1 + 1);
          uRam0064df54 = uRam0064e434;
          FUN_002dfe50(piVar1[1]);
          piVar1[1] = 0;
          iVar2 = piVar1[2];
        }
        if (iVar2 == 0) {
          *(undefined4 *)(param_1 + 4) = 0;
          FUN_001dba60(piVar1,0,0x2c);
          *piVar1 = (int)piRam0064f1b0;
          piRam0064f1b0 = piVar1;
        }
      }
    }
    else {
      FUN_003de890(piVar1);
      *(undefined4 *)(param_1 + 4) = 0;
      piVar1[5] = 0;
      FUN_001dba60(piVar1,0,0x2c);
      *piVar1 = (int)piRam0064f1b0;
      piRam0064f1b0 = piVar1;
    }
  }
  return;
}

