
undefined4 FUN_001a8680(undefined8 param_1)

{
  long lVar1;
  undefined4 uStack_4;
  
  if ((*(byte *)((int)param_1 + 0x23) & 0x80) == 0) {
    uStack_4 = 1;
  }
  else {
    lVar1 = (*pcRam0069f348)(&uStack_4,param_1,0);
    if (lVar1 == 0) {
      uStack_4 = 0xffffffff;
    }
  }
  return uStack_4;
}

