
void FUN_002ffd60(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  
  uVar4 = 0;
  if (*(int *)(param_1 + 0x14) != 0) {
    iVar3 = 0;
    do {
      if ((uint)((ulong)((long)*(int *)(*(int *)(param_1 + 0x20) + iVar3) << 0x22) >> 0x22) - 2 < 2)
      {
        puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x20) + uVar4 * 0x10 + 4);
        piVar2 = (int *)0x0;
        if (puVar1 != (undefined4 *)0x0) {
          piVar2 = (int *)*puVar1;
        }
        if (piVar2 != (int *)0x0) {
          if (*piVar2 != 0) {
            *(undefined4 *)(*piVar2 + 0x24) = 0;
          }
          piVar2[0x15] = 1;
          FUN_001a97e0();
          puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x20) + uVar4 * 0x10 + 4);
          if (puVar1 != (undefined4 *)0x0) {
            *puVar1 = 0;
          }
        }
      }
      uVar4 = uVar4 + 1;
      iVar3 = iVar3 + 0x10;
    } while (uVar4 < *(uint *)(param_1 + 0x14));
  }
  return;
}

