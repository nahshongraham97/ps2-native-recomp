
void FUN_002dfe50(long param_1)

{
  if (param_1 != 0) {
    FUN_00327120();
  }
  return;
}

