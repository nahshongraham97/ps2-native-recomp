
bool FUN_001ab4f0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 *param_4)

{
  byte bVar1;
  bool bVar2;
  float *pfVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  byte abStack_20 [16];
  float afStack_10 [4];
  
  afStack_10[0] = (float)FUN_001ab320(param_1,param_3,0,abStack_20,param_2);
  afStack_10[1] = (float)FUN_001ab320(param_1,param_3,1,abStack_20,param_2);
  afStack_10[2] = (float)FUN_001ab320(param_1,param_3,2,abStack_20,param_2);
  afStack_10[3] = (float)FUN_001ab320(param_1,param_3,3,abStack_20,param_2);
  iVar6 = 0;
  pfVar3 = afStack_10;
  iVar4 = 0;
  do {
    iVar5 = iVar6;
    if (afStack_10[iVar4] <= *pfVar3) {
      iVar5 = iVar4;
    }
    iVar6 = iVar6 + 1;
    pfVar3 = pfVar3 + 1;
    iVar4 = iVar5;
  } while (iVar6 < 4);
  bVar2 = afStack_10[iVar5] < *(float *)((int)param_2 + 0x14);
  if (bVar2) {
    puVar7 = (undefined4 *)param_3;
    uVar10 = puVar7[1];
    uVar8 = puVar7[2];
    uVar9 = puVar7[3];
    *param_4 = *puVar7;
    param_4[1] = uVar10;
    param_4[2] = uVar8;
    param_4[3] = uVar9;
    uVar10 = puVar7[5];
    uVar8 = puVar7[6];
    uVar9 = puVar7[7];
    param_4[4] = puVar7[4];
    param_4[5] = uVar10;
    param_4[6] = uVar8;
    param_4[7] = uVar9;
    bVar1 = abStack_20[iVar5 * 4];
    param_4[iVar5] = (uint)bVar1;
    puVar7[iVar5 + 4] = (uint)bVar1;
  }
  return bVar2;
}

