
undefined8 FUN_001d3490(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  bool bVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined4 in_zero_lo;
  undefined4 in_zero_hi;
  undefined4 in_zero_udw;
  undefined4 in_register_0000000c;
  int iVar12;
  undefined4 uVar13;
  ulong uVar14;
  undefined8 extraout_v0_udw;
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined8 extraout_v0_udw_00;
  undefined1 auVar19 [16];
  undefined8 extraout_v0_udw_01;
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  byte bVar23;
  int iVar24;
  ulong in_v1_udw;
  undefined8 uVar34;
  undefined1 auVar25 [16];
  undefined1 auVar26 [16];
  undefined1 auVar27 [16];
  undefined1 auVar28 [16];
  undefined1 auVar29 [16];
  undefined1 auVar30 [16];
  undefined1 auVar31 [16];
  undefined1 auVar32 [16];
  undefined1 auVar33 [16];
  ulong uVar35;
  ulong in_a0_udw;
  undefined1 auVar36 [16];
  undefined1 auVar37 [16];
  undefined1 auVar38 [16];
  undefined1 auVar39 [16];
  undefined1 auVar40 [16];
  undefined1 auVar41 [16];
  undefined1 auVar42 [16];
  ulong uVar47;
  undefined1 auVar43 [16];
  undefined1 auVar44 [16];
  undefined1 auVar45 [16];
  undefined1 auVar46 [16];
  undefined8 in_a2_udw;
  undefined1 auVar48 [16];
  int *piVar49;
  
  iVar12 = *(int *)(*(int *)(param_1 + 0x2c) + 8) + iGpffff870c;
  if (iVar12 == 0) {
    puVar1 = *(undefined4 **)(param_1 + 0x40);
  }
  else {
    if ((long)*(char *)(iVar12 + 0x2c) << 0x3f < 0) {
      return 1;
    }
    puVar1 = *(undefined4 **)(param_1 + 0x40);
  }
  if (puVar1 == (undefined4 *)0x0) {
    piVar49 = *(int **)(param_1 + 0x40);
  }
  else {
    FUN_001c3250(*puVar1);
    piVar49 = *(int **)(param_1 + 0x40);
  }
  iVar12 = 0;
  if (piVar49 != (int *)0x0) {
    iVar12 = *piVar49;
  }
  uGpffffa570 = 0;
  if (iVar12 != 0) {
    bVar23 = *(byte *)(iVar12 + 0x23) & 0xf;
    uGpffffa570 = (uint)(bVar23 == 1 || bVar23 == 5);
  }
  if (iVar12 != iGpffffa574) {
    if (iVar12 == 0) {
      uGpffff83e8 = uGpffff83e8 & 0xffffffffffffffef;
    }
    else {
      uGpffff83e8 = uGpffff83e8 | 0x10;
      FUN_001c3330(iVar12,0);
    }
    iGpffffa574 = iVar12;
    if (piVar49 != (int *)0x0) {
      FUN_001cfca0((char)piVar49[0x14]);
      bVar3 = (piVar49[0x14] & 0xf00U) == 0x300;
      if (bVar3) {
        uVar2 = piVar49[0x14];
      }
      else {
        uVar2 = piVar49[0x14];
      }
      uGpffffa510 = (ulong)bVar3;
      if ((uVar2 & 0xf000) == 0x3000) {
        uGpffffa510 = uGpffffa510 | 4;
      }
    }
  }
  if (uGpffffa570 == 0) {
    uGpffffa4f8 = uGpffffa4f8 & 0xfffffffffffffffe;
  }
  else {
    uGpffffa4f8 = uGpffffa4f8 | 1;
  }
  FUN_001ae080(0,0x12);
  auVar16._8_8_ = 0;
  auVar16._0_8_ = in_v1_udw;
  auVar42._8_8_ = extraout_v0_udw;
  auVar42._0_8_ = 0x1000000f;
  auVar42 = _pcpyld(auVar16 << 0x40,auVar42);
  *puGpffffa4ac = auVar42._0_4_;
  puGpffffa4ac[1] = auVar42._4_4_;
  puGpffffa4ac[2] = auVar42._8_4_;
  puGpffffa4ac[3] = auVar42._12_4_;
  auVar15._8_8_ = extraout_v0_udw;
  auVar15._0_8_ = 0x6c0103fa01000404;
  auVar9._8_8_ = 0;
  auVar9._0_8_ = in_v1_udw;
  auVar16 = _pcpyld(auVar15,auVar9 << 0x40);
  puGpffffa4ac[4] = auVar16._0_4_;
  puGpffffa4ac[5] = auVar16._4_4_;
  puGpffffa4ac[6] = auVar16._8_4_;
  puGpffffa4ac[7] = auVar16._12_4_;
  auVar17._8_8_ = auVar16._8_8_;
  bVar3 = *(char *)(param_1 + 0x47) != -1;
  uGpffffa56c = (uint)bVar3;
  if (bVar3 || uGpffffa570 != 0) {
    uGpffff83e8 = uGpffff83e8 | 0x40;
  }
  else {
    uGpffff83e8 = uGpffff83e8 & 0xffffffffffffffbf;
  }
  uVar47 = auVar42._8_8_;
  auVar48._8_8_ = in_a2_udw;
  auVar48._0_8_ = 0xfc007fffffffffff;
  auVar4._4_4_ = in_zero_hi;
  auVar4._0_4_ = in_zero_lo;
  auVar4._8_4_ = in_zero_udw;
  auVar4._12_4_ = in_register_0000000c;
  auVar16 = _pcpyld(auVar4,auVar48);
  auVar17._4_4_ = uRam006a4a9c;
  auVar17._0_4_ = uRam006a4a98;
  auVar36._0_8_ =
       CONCAT44(uRam006a4a94,uRam006a4a90) & auVar16._0_8_ |
       ((long)(int)((uint)uGpffff83e8 | (uint)*(byte *)(param_1 + 0x29)) & 0x7ffU) << 0x2f;
  auVar36._8_8_ = in_a0_udw;
  auVar16 = _pcpyld(auVar17,auVar36);
  uRam006a4a90 = auVar16._0_4_;
  uRam006a4a94 = auVar16._4_4_;
  uRam006a4a98 = auVar16._8_4_;
  uRam006a4a9c = auVar16._12_4_;
  puGpffffa4ac[8] = uRam006a4a90;
  puGpffffa4ac[9] = auVar16._4_4_;
  puGpffffa4ac[10] = auVar16._8_4_;
  puGpffffa4ac[0xb] = auVar16._12_4_;
  auVar5._8_8_ = 0;
  auVar5._0_8_ = auVar16._8_8_;
  auVar18._8_8_ = auVar17._8_8_;
  auVar18._0_8_ = 0x6c0103fb01000404;
  auVar16 = _pcpyld(auVar18,auVar5 << 0x40);
  puGpffffa4ac[0xc] = auVar16._0_4_;
  puGpffffa4ac[0xd] = auVar16._4_4_;
  puGpffffa4ac[0xe] = auVar16._8_4_;
  puGpffffa4ac[0xf] = auVar16._12_4_;
  puGpffffa4ac = puGpffffa4ac + 0x10;
  if ((uGpffff83e8 & 0x10) == 0) {
    uVar13 = 0x3b808081;
  }
  else {
    uVar13 = 0x3b011b50;
  }
  FUN_001cfd00(uVar13,param_1 + 0x44);
  auVar10._8_8_ = 0;
  auVar10._0_8_ = in_a0_udw;
  auVar19._8_8_ = extraout_v0_udw_00;
  auVar19._0_8_ = 0x6c0103fc01000404;
  auVar16 = _pcpyld(auVar19,auVar10 << 0x40);
  *puGpffffa4ac = auVar16._0_4_;
  puGpffffa4ac[1] = auVar16._4_4_;
  puGpffffa4ac[2] = auVar16._8_4_;
  puGpffffa4ac[3] = auVar16._12_4_;
  puGpffffa4ac = puGpffffa4ac + 4;
  uVar34 = auVar16._8_8_;
  FUN_001cfe10(*(undefined4 *)(param_1 + 0x1c),*(undefined4 *)(param_1 + 0x3c));
  puVar1 = puGpffffa4ac;
  bVar23 = *(byte *)(param_1 + 0x28);
  auVar25._8_8_ = uVar34;
  auVar25._0_8_ = 0x6c0303fd01000404;
  uVar14 = (ulong)bVar23 & 7;
  auVar11._8_8_ = 0;
  auVar11._0_8_ = in_a0_udw;
  auVar16 = _pcpyld(auVar25,auVar11 << 0x40);
  *puGpffffa4ac = auVar16._0_4_;
  puGpffffa4ac[1] = auVar16._4_4_;
  puGpffffa4ac[2] = auVar16._8_4_;
  puGpffffa4ac[3] = auVar16._12_4_;
  auVar9 = auRam006a4b20;
  auVar16 = auRam006a4b00;
  if (((iGpffffa5bc == 0) || ((bVar23 & 4) != 0)) && ((iGpffff8404 == 0 || ((bVar23 & 4) == 0)))) {
    puGpffffa4ac[4] = auRam006a4b00._0_4_;
    puGpffffa4ac[5] = auVar16._4_4_;
    puGpffffa4ac[6] = auVar16._8_4_;
    puGpffffa4ac[7] = auVar16._12_4_;
    auVar9 = auRam006a4b10;
    puGpffffa4ac[8] = auRam006a4b10._0_4_;
    puGpffffa4ac[9] = auVar9._4_4_;
    puGpffffa4ac[10] = auVar9._8_4_;
    puGpffffa4ac[0xb] = auVar9._12_4_;
    uVar34 = auVar9._8_8_;
  }
  else {
    uVar14 = uVar14 | 8;
    puGpffffa4ac[4] = auRam006a4b20._0_4_;
    puGpffffa4ac[5] = auVar9._4_4_;
    puGpffffa4ac[6] = auVar9._8_4_;
    puGpffffa4ac[7] = auVar9._12_4_;
    auVar16 = auRam006a4b30;
    puGpffffa4ac[8] = auRam006a4b30._0_4_;
    puGpffffa4ac[9] = auVar16._4_4_;
    puGpffffa4ac[10] = auVar16._8_4_;
    puGpffffa4ac[0xb] = auVar16._12_4_;
    uVar34 = auVar16._8_8_;
    auVar16 = auVar9;
  }
  uGpffffa5b4 = 0;
  auVar37._8_8_ = auVar16._8_8_;
  uVar35 = 0;
  if (iGpffffa564 == 3) {
    uVar35 = 0x20;
    uGpffffa5b4 = 0x20;
  }
  auVar20._8_8_ = extraout_v0_udw_01;
  auVar20._0_8_ = uVar14;
  auVar37._0_8_ = (ulong)uGpffffa5b8 << 0x20 | uVar35;
  auVar16 = _pcpyld(auVar37,auVar20);
  puGpffffa4ac[0xc] = auVar16._0_4_;
  puGpffffa4ac[0xd] = auVar16._4_4_;
  puGpffffa4ac[0xe] = auVar16._8_4_;
  puGpffffa4ac[0xf] = auVar16._12_4_;
  auVar38._8_8_ = auVar16._8_8_;
  if (*(int *)(param_1 + 0x40) == 0) {
    puGpffffa4ac[0x10] = in_zero_lo;
    puGpffffa4ac[0x11] = in_zero_hi;
    puGpffffa4ac[0x12] = in_zero_udw;
    puGpffffa4ac[0x13] = in_register_0000000c;
    auVar7._8_8_ = 0;
    auVar7._0_8_ = auVar38._8_8_;
    auVar31._8_8_ = uVar34;
    auVar31._0_8_ = 0x5000000200000000;
    puGpffffa4ac[0x14] = in_zero_lo;
    puGpffffa4ac[0x15] = in_zero_hi;
    puGpffffa4ac[0x16] = in_zero_udw;
    puGpffffa4ac[0x17] = in_register_0000000c;
    auVar16 = _pcpyld(auVar31,auVar7 << 0x40);
    puGpffffa4ac[0x18] = auVar16._0_4_;
    puGpffffa4ac[0x19] = auVar16._4_4_;
    puGpffffa4ac[0x1a] = auVar16._8_4_;
    puGpffffa4ac[0x1b] = auVar16._12_4_;
    auVar32._8_8_ = auVar16._8_8_;
    auVar44._8_8_ = uVar47;
    auVar44._0_8_ = 0xe;
    auVar32._0_8_ = 0x1000000000008001;
    auVar16 = _pcpyld(auVar44,auVar32);
    puGpffffa4ac[0x1c] = auVar16._0_4_;
    puGpffffa4ac[0x1d] = auVar16._4_4_;
    puGpffffa4ac[0x1e] = auVar16._8_4_;
    puGpffffa4ac[0x1f] = auVar16._12_4_;
    auVar41._8_8_ = auVar38._8_8_;
    auVar41._0_8_ = uGpffffa4f8;
    auVar33._8_8_ = auVar16._8_8_;
    auVar33._0_8_ = 0x47;
    auVar16 = _pcpyld(auVar33,auVar41);
    puGpffffa4ac[0x20] = auVar16._0_4_;
    puGpffffa4ac[0x21] = auVar16._4_4_;
    puGpffffa4ac[0x22] = auVar16._8_4_;
    puGpffffa4ac[0x23] = auVar16._12_4_;
  }
  else {
    auVar6._8_8_ = 0;
    auVar6._0_8_ = auVar38._8_8_;
    auVar26._8_8_ = uVar34;
    auVar26._0_8_ = 0x5000000400000000;
    auVar16 = _pcpyld(auVar26,auVar6 << 0x40);
    puGpffffa4ac[0x10] = auVar16._0_4_;
    puGpffffa4ac[0x11] = auVar16._4_4_;
    puGpffffa4ac[0x12] = auVar16._8_4_;
    puGpffffa4ac[0x13] = auVar16._12_4_;
    auVar27._8_8_ = auVar16._8_8_;
    auVar43._8_8_ = uVar47;
    auVar43._0_8_ = 0xe;
    auVar27._0_8_ = 0x1000000000008003;
    auVar16 = _pcpyld(auVar43,auVar27);
    puGpffffa4ac[0x14] = auVar16._0_4_;
    puGpffffa4ac[0x15] = auVar16._4_4_;
    puGpffffa4ac[0x16] = auVar16._8_4_;
    puGpffffa4ac[0x17] = auVar16._12_4_;
    auVar38._0_8_ = uGpffffa4f8;
    auVar28._8_8_ = auVar16._8_8_;
    auVar28._0_8_ = 0x47;
    auVar16 = _pcpyld(auVar28,auVar38);
    puGpffffa4ac[0x18] = auVar16._0_4_;
    puGpffffa4ac[0x19] = auVar16._4_4_;
    puGpffffa4ac[0x1a] = auVar16._8_4_;
    puGpffffa4ac[0x1b] = auVar16._12_4_;
    auVar39._8_8_ = auVar38._8_8_;
    auVar39._0_8_ = uGpffffa518;
    auVar29._8_8_ = auVar16._8_8_;
    auVar29._0_8_ = 0x14;
    auVar16 = _pcpyld(auVar29,auVar39);
    puGpffffa4ac[0x1c] = auVar16._0_4_;
    puGpffffa4ac[0x1d] = auVar16._4_4_;
    puGpffffa4ac[0x1e] = auVar16._8_4_;
    puGpffffa4ac[0x1f] = auVar16._12_4_;
    auVar40._8_8_ = auVar38._8_8_;
    auVar40._0_8_ = uGpffffa510;
    auVar30._8_8_ = auVar16._8_8_;
    auVar30._0_8_ = 8;
    auVar16 = _pcpyld(auVar30,auVar40);
    puGpffffa4ac[0x20] = auVar16._0_4_;
    puGpffffa4ac[0x21] = auVar16._4_4_;
    puGpffffa4ac[0x22] = auVar16._8_4_;
    puGpffffa4ac[0x23] = auVar16._12_4_;
  }
  puGpffffa4ac = puGpffffa4ac + 0x24;
  auVar45._8_8_ = uVar47;
  auVar45._0_8_ = 0xe;
  *(byte *)(param_1 + 0x2b) =
       (byte)((int)(*(byte *)(param_1 + 0x28) & 0x20) >> 5) |
       (byte)((int)(*(byte *)(param_1 + 0x28) & 0x18) >> 2);
  uVar2 = *(uint *)(*(int *)(*(int *)(param_1 + 4) + 0x18) + (uint)*(byte *)(param_1 + 0x2b) * 4);
  if (uGpffffa5b0 == uVar2) {
    piVar49 = *(int **)(param_1 + 0x30);
  }
  else {
    auVar8._8_8_ = 0;
    auVar8._0_8_ = uVar47;
    auVar45 = auVar8 << 0x40;
    auVar21._0_8_ = (ulong)uVar2 << 0x20 | 0x50000000;
    auVar21._8_8_ = extraout_v0_udw_01;
    auVar16 = _pcpyld(auVar45,auVar21);
    *puGpffffa4ac = auVar16._0_4_;
    puVar1[0x25] = auVar16._4_4_;
    puVar1[0x26] = auVar16._8_4_;
    puVar1[0x27] = auVar16._12_4_;
    puGpffffa4ac = puVar1 + 0x28;
    piVar49 = *(int **)(param_1 + 0x30);
    uGpffffa5b0 = uVar2;
  }
  auVar46._8_8_ = auVar45._8_8_;
  iVar12 = *piVar49;
  auVar46._0_8_ = ((long)*(int *)(*(int *)(param_1 + 4) + 0x14) | 0x2000000U) << 0x20 | 0x3000000;
  auVar22._0_8_ = (ulong)*(uint *)(iVar12 + 0x20) << 0x20 | 0x50000000;
  auVar22._8_8_ = extraout_v0_udw_01;
  auVar16 = _pcpyld(auVar46,auVar22);
  *puGpffffa4ac = auVar16._0_4_;
  puGpffffa4ac[1] = auVar16._4_4_;
  puGpffffa4ac[2] = auVar16._8_4_;
  puGpffffa4ac[3] = auVar16._12_4_;
  puGpffffa4ac = puGpffffa4ac + 4;
  do {
    DI();
    SYNC(0x10);
  } while ((Status & 0x10000) != 0);
  *(int *)(iVar12 + 0x18) = *(int *)(iVar12 + 0x18) + 1;
  EI();
  iVar24 = *(int *)(iVar12 + 0x1c) + 1;
  *(int *)(iVar12 + 0x1c) = iVar24;
  if (iVar24 == 1) {
    FUN_001ad8c0();
  }
  return 1;
}

