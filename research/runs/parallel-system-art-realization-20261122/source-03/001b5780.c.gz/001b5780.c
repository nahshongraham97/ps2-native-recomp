
void FUN_001b5780(int param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  int iVar4;
  byte *pbVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  byte bVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  byte *pbVar13;
  uint uVar14;
  int iVar15;
  undefined8 *puVar16;
  uint uVar17;
  int iVar18;
  undefined4 uStack_840;
  undefined4 uStack_83c;
  undefined4 uStack_838;
  undefined4 uStack_834;
  undefined4 uStack_830;
  undefined4 uStack_82c;
  undefined4 uStack_828;
  undefined4 uStack_824;
  undefined4 uStack_820;
  undefined4 uStack_81c;
  undefined4 uStack_818;
  undefined4 uStack_814;
  undefined4 uStack_810;
  undefined4 uStack_80c;
  undefined4 uStack_808;
  undefined4 uStack_804;
  byte abStack_800 [8];
  undefined8 auStack_7f8 [63];
  undefined8 auStack_600 [64];
  undefined8 auStack_400 [64];
  undefined8 auStack_200 [64];
  
  uVar14 = 0;
  if ((0 < *(int *)(param_1 + 0x10)) && (0 < *(int *)(param_1 + 0x10))) {
    iVar18 = *(int *)(param_1 + 0xc);
    while( true ) {
      iVar15 = 0;
      if (0 < iVar18) {
        iVar11 = *(int *)(param_1 + 0x18);
        iVar1 = *(int *)(param_1 + 4);
        iVar12 = 0;
        do {
          puVar3 = (undefined8 *)(iVar1 + uVar14 * iVar11 + iVar15);
          puVar16 = (undefined8 *)(iVar1 + (uVar14 + 2) * iVar11 + iVar15);
          uStack_840 = (int)*puVar3;
          uStack_83c = (int)((ulong)*puVar3 >> 0x20);
          uStack_838 = *(undefined4 *)(puVar3 + 1);
          uStack_834 = *(undefined4 *)((int)puVar3 + 0xc);
          uStack_830 = *(undefined4 *)(puVar3 + 2);
          uStack_82c = *(undefined4 *)((int)puVar3 + 0x14);
          uStack_828 = *(undefined4 *)(puVar3 + 3);
          uStack_824 = *(undefined4 *)((int)puVar3 + 0x1c);
          *(undefined8 *)((int)auStack_7f8 + iVar12 + -8) = 0;
          uVar2 = *puVar16;
          uStack_818 = *(undefined4 *)(puVar16 + 1);
          uStack_814 = *(undefined4 *)((int)puVar16 + 0xc);
          *(undefined8 *)((int)auStack_7f8 + iVar12) = 0;
          uStack_810 = *(undefined4 *)(puVar16 + 2);
          uStack_80c = *(undefined4 *)((int)puVar16 + 0x14);
          uStack_808 = *(undefined4 *)(puVar16 + 3);
          uStack_804 = *(undefined4 *)((int)puVar16 + 0x1c);
          *(undefined8 *)((int)auStack_600 + iVar12) = 0;
          uStack_820 = (int)uVar2;
          uStack_81c = (int)((ulong)uVar2 >> 0x20);
          *(undefined8 *)((int)auStack_600 + iVar12 + 8) = 0;
          iVar18 = 0;
          *(undefined8 *)((int)auStack_400 + iVar12) = 0;
          *(undefined8 *)((int)auStack_400 + iVar12 + 8) = 0;
          *(undefined8 *)((int)auStack_200 + iVar12) = 0;
          *(undefined8 *)((int)auStack_200 + iVar12 + 8) = 0;
          do {
            uVar17 = 0;
            do {
              if ((uVar14 & 4) == 0) {
                uVar10 = iVar18 + uVar17;
                uVar10 = ((int)(uVar10 & 0x40) >> 1 |
                         (int)(uVar10 & 0x10) >> 2 |
                         (int)(uVar10 & 8) >> 2 |
                         (int)(uVar10 & 4) >> 2 | (uVar10 & 2) << 2 | (int)(uVar10 & 0x20) >> 1) ^
                         ((uVar10 & 1) << 6 | (uVar10 & 1) << 2);
              }
              else {
                uVar10 = iVar18 + uVar17;
                uVar10 = ((int)(uVar10 & 0x40) >> 1 |
                         (int)(uVar10 & 0x10) >> 2 |
                         (int)(uVar10 & 8) >> 2 |
                         (int)(uVar10 & 4) >> 2 | (uVar10 & 2) << 2 | (int)(uVar10 & 0x20) >> 1) ^
                         ((uVar10 & 1) << 6 | (~uVar10 & 1) << 2);
              }
              iVar4 = (int)(iVar18 + uVar17) >> 1;
              if ((uVar10 & 1) == 0) {
                if ((uVar17 & 1) == 0) {
                  bVar9 = *(byte *)((int)&uStack_840 + iVar4) & 0xf;
                }
                else {
                  bVar9 = (byte)((int)(*(byte *)((int)&uStack_840 + iVar4) & 0xf0) >> 4);
                }
                iVar4 = (int)(((int)uVar10 >> 5) * 0x400 + iVar15 + (uVar10 & 0x1f)) >> 1;
                *(byte *)((int)auStack_7f8 + iVar4 + -8) =
                     *(byte *)((int)auStack_7f8 + iVar4 + -8) | bVar9;
              }
              else {
                if ((uVar17 & 1) == 0) {
                  bVar9 = *(char *)((int)&uStack_840 + iVar4) << 4;
                }
                else {
                  bVar9 = *(byte *)((int)&uStack_840 + iVar4) & 0xf0;
                }
                iVar4 = (int)(((int)uVar10 >> 5) * 0x400 + iVar15 + (uVar10 & 0x1f)) >> 1;
                *(byte *)((int)auStack_7f8 + iVar4 + -8) =
                     *(byte *)((int)auStack_7f8 + iVar4 + -8) | bVar9;
              }
              uVar17 = uVar17 + 1;
            } while ((int)uVar17 < 0x20);
            iVar18 = iVar18 + 0x20;
          } while (iVar18 < 0x80);
          iVar18 = *(int *)(param_1 + 0xc);
          iVar15 = iVar15 + 0x20;
          iVar12 = iVar12 + 0x10;
        } while (iVar15 < iVar18);
      }
      iVar15 = 0;
      pbVar13 = abStack_800;
      do {
        iVar11 = 0;
        if (0 < iVar18 >> 1) {
          do {
            pbVar5 = pbVar13 + iVar11;
            uVar2 = *(undefined8 *)pbVar5;
            uVar7 = *(undefined4 *)(pbVar5 + 8);
            uVar8 = *(undefined4 *)(pbVar5 + 0xc);
            puVar6 = (undefined4 *)
                     (*(int *)(param_1 + 4) + *(int *)(param_1 + 0x18) * (uVar14 + iVar15) + iVar11)
            ;
            *puVar6 = (int)uVar2;
            puVar6[1] = (int)((ulong)uVar2 >> 0x20);
            puVar6[2] = uVar7;
            puVar6[3] = uVar8;
            iVar11 = iVar11 + 0x10;
            iVar18 = *(int *)(param_1 + 0xc);
          } while (iVar11 < iVar18 >> 1);
        }
        iVar15 = iVar15 + 1;
        pbVar13 = pbVar13 + 0x200;
      } while (iVar15 < 4);
      uVar14 = uVar14 + 4;
      if (*(int *)(param_1 + 0x10) <= (int)uVar14) break;
      iVar18 = *(int *)(param_1 + 0xc);
    }
  }
  return;
}

