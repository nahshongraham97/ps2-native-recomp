
undefined4 FUN_001a97e0(undefined8 param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1;
  iVar3 = piVar2[0x15];
  iVar1 = iVar3 + -1;
  piVar2[0x15] = iVar1;
  if (iVar1 < 1) {
    piVar2[0x15] = iVar3;
    FUN_001a3520(0x5a3720,param_1);
    if (piVar2[1] == 0) {
      iVar3 = *piVar2;
    }
    else {
      *(int *)piVar2[3] = piVar2[2];
      *(int *)(piVar2[2] + 4) = piVar2[3];
      iVar3 = *piVar2;
    }
    if (iVar3 == 0) {
      iVar3 = piVar2[0x15];
    }
    else {
      FUN_001a85a0();
      *piVar2 = 0;
      iVar3 = piVar2[0x15];
    }
    piVar2[0x15] = iVar3 + -1;
    (*pcRam0069f3d8)(*(undefined4 *)(iGpffffa400 + 0x69f298),param_1);
  }
  return 1;
}

