
undefined4 FUN_0000fd50(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  
  uVar6 = 0;
  func_0x0000a7d8(iRam000248e0 + 0x3ac);
  func_0x0000a7d8(0x4904c);
  piVar1 = piRam00048e58;
  piVar5 = (int *)0x48e58;
  while (piVar4 = piVar1, iVar2 = iRam00048e60, piVar4 != (int *)0x0) {
    iVar2 = func_0x0000f278(0,piVar4[5]);
    if (iVar2 == param_1) {
      iVar2 = *piVar4;
      *piVar5 = iVar2;
      if (iVar2 == 0) {
        piRam00048e5c = piVar5;
      }
      *piVar4 = (int)piRam00048e54;
      piRam00048e54 = piVar4;
      *(int *)(piVar4[2] + 0x2c) = *(int *)(piVar4[2] + 0x2c) + -1;
      *(undefined2 *)(param_1 + 0x22) = 0;
      uVar6 = 1;
      func_0x0000f318(0x248b4,piVar4[5]);
      piVar1 = (int *)0x0;
    }
    else {
      piVar1 = (int *)*piVar4;
      piVar5 = piVar4;
    }
  }
  if (((iRam00048e60 != 0) &&
      (iVar3 = func_0x0000f278(0,*(undefined4 *)(iRam00048e60 + 0x14)), iVar3 == param_1)) &&
     (iRam00048e68 != 0)) {
    uRam00048e64 = 1;
    *(undefined2 *)(param_1 + 0x22) = 0;
    uVar6 = 2;
    func_0x0000f318(0x248b4,*(undefined4 *)(iVar2 + 0x14));
  }
  func_0x0000a7e4(0x4904c);
  func_0x0000a7e4(iRam000248e0 + 0x3ac);
  return uVar6;
}

