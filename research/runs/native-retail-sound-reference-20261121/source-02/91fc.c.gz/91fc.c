
void FUN_000091fc(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  undefined4 auStackX_0 [4];
  undefined2 uStack_4;
  
  auStackX_0[0] = param_1;
  func_0x0000a7d8(iRam000248e0 + 0x3ac);
  uVar1 = func_0x0000f318(0x248b4,auStackX_0[0]);
  uStack_4 = (ushort)uVar1;
  if (uStack_4 < 0x40) {
    func_0x000036d4(uVar1);
  }
  iVar2 = func_0x0000f278(0,auStackX_0[0]);
  if (-1 < *(short *)(iVar2 + 0xc)) {
    piVar3 = (int *)(*(int *)(iRam000248e0 + 0x268) + *(short *)(iVar2 + 0xc) * 8);
    if (iVar2 == *piVar3) {
      *piVar3 = 0;
    }
    *(undefined2 *)(iVar2 + 0xc) = 0xffff;
  }
  uVar1 = func_0x0000f3d8(auStackX_0);
  func_0x0000f1a8(0x248b4,uVar1);
  func_0x0000a7e4(iRam000248e0 + 0x3ac);
  return;
}

