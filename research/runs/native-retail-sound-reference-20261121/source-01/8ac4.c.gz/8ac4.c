
void FUN_00008ac4(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = -1;
  if (param_1 != (int *)0x0) {
    if (*(short *)((int)param_1 + 0x22) != 0) {
      iVar2 = func_0x0000fd50();
    }
    iVar1 = param_1[0xf];
    func_0x0000a7d8(iVar1 + 0x3ac);
    if ((*param_1 != 0) || (iVar2 == 1)) {
      func_0x000087ec(param_1,1);
    }
    func_0x0000a7e4(iVar1 + 0x3ac);
  }
  return;
}

