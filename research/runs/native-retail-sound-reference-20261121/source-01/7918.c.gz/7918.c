
void FUN_00007918(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  piVar1 = (int *)func_0x0000f278(0,param_1);
  iVar2 = piVar1[0xf];
  func_0x0000a7d8(iVar2 + 0x3ac);
  if (piVar1 == piRam00010c50) {
    piRam00010c50 = (int *)0x0;
  }
  if (*piVar1 != 0) {
    iVar3 = *(int *)(*piVar1 + 0xc);
    if (iVar3 != 0) {
      for (iVar4 = 0; iVar4 < *(int *)(*piVar1 + 8); iVar4 = iVar4 + 1) {
        if ((*(char *)(iVar3 + 8) == '\x01') && (*(int *)(iVar3 + 0x14) != 0)) {
          func_0x0000a254(piVar1[0xf]);
          *(undefined4 *)(iVar3 + 0x14) = 0;
        }
        iVar3 = iVar3 + 0x28;
      }
      func_0x00006bc8(*(undefined4 *)(*piVar1 + 0xc));
    }
    func_0x00006bc8(*piVar1);
  }
  *piVar1 = 0;
  func_0x000091fc(param_1);
  func_0x0000a7e4(iVar2 + 0x3ac);
  return;
}

