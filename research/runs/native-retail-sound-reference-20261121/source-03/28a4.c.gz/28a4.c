
void FUN_000028a4(void)

{
  int iVar1;
  undefined4 unaff_s0;
  undefined4 unaff_s2;
  undefined4 unaff_s3;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  
  if (iRam00010b20 != 0) {
    func_0x00000148();
    iRam00010b20 = 0;
  }
  func_0x0000011c(0x10b4c);
  in_stack_0000002c = 0x2000000;
  in_stack_00000034 = 0x27dc;
  in_stack_0000003c = 0x32;
  uRam00010c4b = 0;
  in_stack_00000038 = 0x800;
  in_stack_00000030 = 0;
  uRam00010b40 = unaff_s3;
  uRam00010b48 = unaff_s2;
  uRam00010c4c = unaff_s0;
  iVar1 = func_0x00000140(&stack0x0000002c);
  if (iVar1 < 1) {
    uRam00010b1c = 0;
    func_0x000038e4();
  }
  else {
    iRam00010b20 = iVar1;
    func_0x0000002c();
    func_0x00007158();
    func_0x00000150(iVar1,0);
  }
  return;
}

