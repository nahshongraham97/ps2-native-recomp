
void FUN_000036d4(undefined4 param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)func_0x0000ad2c(1,uRam00010b24);
  if (puVar1 != (undefined4 *)0x0) {
    *puVar1 = param_1;
    func_0x0000ae00();
  }
  return;
}

