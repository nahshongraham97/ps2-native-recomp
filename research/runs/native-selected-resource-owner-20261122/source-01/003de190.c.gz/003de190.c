
void FUN_003de190(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 4);
  if (piVar1 != (int *)0x0) {
    if (piVar1[1] == 0) {
      iVar2 = piVar1[2];
    }
    else {
      FUN_002dfe50();
      piVar1[1] = 0;
      iVar2 = piVar1[2];
    }
    if (iVar2 == 0) {
      *(undefined4 *)(param_1 + 4) = 0;
      FUN_001dba60(piVar1,0,0x2c);
      *piVar1 = (int)piRam0064f1b0;
      piRam0064f1b0 = piVar1;
    }
  }
  return;
}

