
void FUN_00334700(void)

{
  uint uVar1;
  
  uRam0064ed90 = 0xffffffff;
  uRam006602e8 = 0;
  uRam0064ed8c = 0;
  uVar1 = FUN_00185c30(0x13);
  DAT_0064cc84 = uVar1 & 0xffff;
  puRam0064ed94 = (&PTR_DAT_005e5630)[uVar1 & 0xffff];
  return;
}

