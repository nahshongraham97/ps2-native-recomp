
void FUN_0018da30(void)

{
  uGpffffa258 = 0;
  uGpffffa25c = 0;
  uGpffffa250 = 0;
  uGpffffa254 = 0;
  FUN_0016fc70();
  FUN_00163a50();
  uRam006602d0 = 0;
  return;
}

