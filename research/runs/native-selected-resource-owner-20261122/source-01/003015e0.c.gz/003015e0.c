
int * FUN_003015e0(undefined8 param_1)

{
  long lVar1;
  undefined1 auStack_110 [256];
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  byte bStack_1;
  
  piStack_8 = (int *)0x0;
  FUN_001a27b0(param_1,4);
  FUN_001a2610(param_1,&bStack_1,1);
  if (bStack_1 != 0) {
    FUN_001a2610(param_1,auStack_110,bStack_1);
  }
  auStack_110[bStack_1] = 0;
  FUN_001a2610(param_1,&uStack_c,4);
  FUN_001a2610(param_1,&uStack_10,4);
  thunk_FUN_00229180(param_1,&piStack_8);
  if (piStack_8 != (int *)0x0) {
    if ((*piStack_8 == 0) || (lVar1 = FUN_001a8680(), lVar1 < 2)) {
      piStack_8[0x14] = piStack_8[0x14] & 0xffffff00U | 2;
    }
    else {
      piStack_8[0x14] = piStack_8[0x14] & 0xffffff00U | 4;
    }
    FUN_001a98a0(piStack_8,auStack_110);
    *(undefined4 *)(*piStack_8 + 0x2c) = uStack_10;
    *(undefined4 *)(*piStack_8 + 0x28) = uStack_c;
  }
  return piStack_8;
}

