
undefined4 * FUN_0016fc70(long param_1)

{
  undefined *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  long lVar5;
  int iVar6;
  int iVar7;
  undefined4 uStack_4;
  
  iVar6 = (int)param_1;
  puVar1 = (&PTR_s_EDDMONDGRAY14_MET_005a1af8)[iVar6 * 6];
  uVar3 = *(undefined4 *)(&DAT_005a1afc + iVar6 * 0x18);
  if (param_1 < 0x1f) {
    if ((&DAT_005a1b00)[iVar6 * 6] == 0) {
      uStack_4 = 0;
      lVar5 = FUN_00300b60(uVar3,(&PTR_s_EDDMONDGRAY14_005a1af4)[iVar6 * 6]);
      if (lVar5 != 0) {
        uVar3 = FUN_00300440(uVar3,puVar1,&uStack_4);
        iVar7 = (int)lVar5;
        uVar2 = *(uint *)(iVar7 + 0x50);
        *(uint *)(iVar7 + 0x50) = uVar2 & 0xffffff00 | 1;
        *(uint *)(iVar7 + 0x50) = uVar2 & 0xffff0000 | 0x3301;
        (&DAT_005a1b00)[iVar6 * 6] = iVar7;
        (&DAT_005a1b04)[iVar6 * 6] = uVar3;
      }
    }
    puVar4 = &DAT_005a1b00 + iVar6 * 6;
  }
  else {
    puVar4 = (undefined4 *)0x0;
  }
  return puVar4;
}

