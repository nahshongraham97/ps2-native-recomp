
int FUN_00229180(undefined8 param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  long lVar3;
  long lVar4;
  uint uVar5;
  int iVar6;
  undefined1 auStack_120 [128];
  undefined1 auStack_a0 [128];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  char cStack_10;
  char cStack_f;
  char cStack_e;
  char cStack_d;
  uint uStack_c;
  uint uStack_8;
  int iStack_4;
  
  *param_2 = 0;
  lVar3 = FUN_0019f1e0(param_1,1,&iStack_4,&uStack_8);
  if (lVar3 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = 0;
    if ((0x33fff < uStack_8) && (uStack_8 < 0x36004)) {
      iVar6 = 1;
    }
    if (iVar6 == 0) {
      uStack_20 = 0x116;
      uStack_1c = FUN_0019f510(0xffffffff80000004);
      FUN_0019f460(&uStack_20);
    }
    else {
      FUN_001dba60(&cStack_10,0,8);
      iVar1 = FUN_001a2610(param_1,&cStack_10,iStack_4);
      if (iStack_4 == iVar1) {
        if (cStack_10 == 'P') {
          if (((cStack_f == 'S') && (cStack_e == '2')) && (cStack_d == '\0')) {
            lVar3 = FUN_001a4580(auStack_a0,param_1);
            if (lVar3 == 0) {
              iVar6 = 0;
            }
            else {
              lVar3 = FUN_001a4580(auStack_120,param_1);
              if (lVar3 == 0) {
                iVar6 = 0;
              }
              else {
                lVar3 = FUN_0019f1e0(param_1,1,&iStack_4,&uStack_8);
                if (lVar3 == 0) {
                  iVar6 = 0;
                }
                else if ((uStack_8 < 0x34000) || (0x36003 < uStack_8)) {
                  uStack_18 = 0x116;
                  uStack_14 = FUN_0019f510(0xffffffff80000004);
                  FUN_0019f460(&uStack_18);
                  iVar6 = 0;
                }
                else {
                  lVar3 = FUN_00229420(param_1);
                  if (lVar3 == 0) {
                    iVar6 = 0;
                  }
                  else {
                    lVar4 = FUN_001a9720(lVar3);
                    *param_2 = (int)lVar4;
                    if (lVar4 == 0) {
                      FUN_001a85a0(lVar3);
                      iVar6 = 0;
                    }
                    else {
                      FUN_001a98a0(lVar4,auStack_a0);
                      FUN_001a9940(*param_2,auStack_120);
                      *(uint *)(*param_2 + 0x50) =
                           *(uint *)(*param_2 + 0x50) & 0xffffff00 | uStack_c & 0xff;
                      uVar2 = (int)uStack_c >> 0xc & 0xf;
                      uVar5 = (int)uStack_c >> 8 & 0xf;
                      if (uVar2 == 0) {
                        uVar2 = uVar5;
                      }
                      *(uint *)(*param_2 + 0x50) =
                           *(uint *)(*param_2 + 0x50) & 0xfffff0ff | uVar5 << 8;
                      *(uint *)(*param_2 + 0x50) =
                           *(uint *)(*param_2 + 0x50) & 0xffff0fff | uVar2 << 0xc;
                    }
                  }
                }
              }
            }
          }
          else {
            iVar6 = 0;
          }
        }
        else {
          iVar6 = 0;
        }
      }
      else {
        iVar6 = 0;
      }
    }
  }
  return iVar6;
}

