
int FUN_00300440(long param_1,undefined8 param_2,undefined4 *param_3)

{
  int iVar1;
  long lVar2;
  long lVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar1 = FUN_0019c320();
  do {
    if (iVar1 < 1) {
      return 0;
    }
    if (param_1 == -1) {
      iVar6 = 0;
    }
    else {
      lVar2 = FUN_0019c140(param_1,iVar1);
      if (lVar2 == 0) {
        iVar6 = 0;
      }
      else {
        lVar3 = FUN_00199480(lVar2);
        if (lVar3 == 1) {
          lVar3 = FUN_00199480(lVar2);
          iVar6 = (int)lVar2;
          if ((lVar3 == 2) || (lVar3 == 1)) {
            iVar4 = 0;
            if (0 < *(int *)(iVar6 + 0x14)) {
              iVar5 = 0;
              do {
                lVar2 = FUN_001deb10(*(undefined4 *)(*(int *)(iVar6 + 0x20) + iVar5 + 0xc),param_2);
                if (lVar2 == 0) goto LAB_00300558;
                iVar4 = iVar4 + 1;
                iVar5 = iVar5 + 0x10;
              } while (iVar4 < *(int *)(iVar6 + 0x14));
            }
            iVar4 = -1;
          }
          else {
            iVar4 = -1;
          }
LAB_00300558:
          if (iVar4 == -1) {
            iVar6 = 0;
          }
          else {
            iVar4 = *(int *)(iVar6 + 0x20) + iVar4 * 0x10;
            iVar6 = *(int *)(iVar4 + 4);
            *param_3 = *(undefined4 *)(iVar4 + 8);
          }
        }
        else {
          iVar6 = 0;
        }
      }
    }
    if (iVar6 != 0) {
      return iVar6;
    }
    iVar1 = iVar1 + -1;
  } while( true );
}

