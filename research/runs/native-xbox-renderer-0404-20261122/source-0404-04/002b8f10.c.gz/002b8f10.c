
int __fastcall FUN_002b8f10(int param_1,undefined4 *param_2)

{
  int in_EAX;
  undefined4 local_8;
  undefined4 local_4;
  
  if (param_1 == 1) {
    *(undefined4 *)(in_EAX + 0xc) = 0;
    *(undefined4 *)(in_EAX + 0x10) = param_2[1];
    *(undefined4 *)(in_EAX + 0x14) = *param_2;
    return in_EAX;
  }
  if (param_1 != 2) {
    if (param_1 != 3) {
      local_8 = 1;
      local_4 = FUN_002c2400(0xd);
      FUN_002c2370(&local_8);
      return 0;
    }
    *(undefined4 *)(in_EAX + 0xc) = param_2[1];
    *(undefined4 *)(in_EAX + 0x10) = param_2[1];
    *(undefined4 *)(in_EAX + 0x14) = *param_2;
    return in_EAX;
  }
  *(undefined4 *)(in_EAX + 0xc) = 0;
  *(undefined4 *)(in_EAX + 0x10) = 0;
  *(undefined4 *)(in_EAX + 0x14) = 0;
  return in_EAX;
}

