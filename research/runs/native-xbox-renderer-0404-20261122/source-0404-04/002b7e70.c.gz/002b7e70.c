
undefined4 * FUN_002b7e70(undefined4 param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  
  if (*(int *)((int)&DAT_00835348 + DAT_005c71ac) == 0) {
    puVar7 = (undefined4 *)((int)&DAT_00835340 + DAT_005c71ac);
    for (puVar1 = *(undefined4 **)((int)&DAT_00835340 + DAT_005c71ac); puVar1 != puVar7;
        puVar1 = (undefined4 *)*puVar1) {
      for (puVar2 = (undefined4 *)puVar1[-2]; puVar2 != puVar1 + -2; puVar2 = (undefined4 *)*puVar2)
      {
        puVar4 = puVar2 + -10;
        iVar5 = (*DAT_00835454)(puVar2 + -8,param_1);
        if (iVar5 == 0) {
          if (puVar4 != (undefined4 *)0x0) goto LAB_002b7e97;
          break;
        }
      }
    }
  }
  else {
    puVar4 = (undefined4 *)FUN_002b7970(*(int *)((int)&DAT_00835348 + DAT_005c71ac),param_1);
    if (puVar4 != (undefined4 *)0x0) {
LAB_002b7e97:
      puVar4[1] = puVar4[1] + 1;
      return puVar4;
    }
  }
  uVar3 = *(undefined4 *)((int)&DAT_00835354 + DAT_005c71ac);
  (*DAT_00835438)(uVar3,*(undefined4 *)((int)&DAT_00835350 + DAT_005c71ac));
  (*DAT_00835444)(uVar3,param_1,0x1f);
  iVar5 = FUN_002b95a0(2,1,uVar3);
  if (iVar5 != 0) {
    iVar6 = FUN_002b97a0(iVar5,0x20,0,0);
    if (iVar6 != 0) {
      puVar7 = (undefined4 *)FUN_002b7db0(iVar5);
      FUN_002b94d0(iVar5,0);
      return puVar7;
    }
    FUN_002b94d0(iVar5,0);
  }
  return (undefined4 *)0x0;
}

