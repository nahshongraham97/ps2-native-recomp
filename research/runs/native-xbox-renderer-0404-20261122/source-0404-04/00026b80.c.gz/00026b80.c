
void FUN_00026b80(int param_1)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  int *local_28;
  undefined4 local_24;
  uint local_20;
  int local_1c;
  int *local_18;
  uint local_14;
  uint local_10;
  undefined4 local_c;
  int local_8;
  
  local_8 = *(int *)(param_1 + 8);
  local_28 = *(int **)(param_1 + 8);
  local_24 = *(undefined4 *)(param_1 + 0xc);
  if (*local_28 == 0x53454320) {
    *(int *)(param_1 + 0x14) = local_28[4];
    *(int *)(param_1 + 0x10) = local_28[3];
    *(int **)(param_1 + 0x20) = local_28 + 7;
    iVar1 = *(int *)(param_1 + 0x14);
    iVar2 = *(int *)(param_1 + 0x20);
    local_20 = 0;
    for (local_14 = 0; local_14 < *(uint *)(param_1 + 0x14); local_14 = local_14 + 1) {
      local_10 = *(uint *)(local_14 * 0x10 + *(int *)(param_1 + 0x20)) & 0x3fffffff;
      if (local_10 == 3) {
        local_20 = local_14;
        break;
      }
    }
    local_18 = local_28;
    if (*(char *)(param_1 + 0x1d) == '\0') {
      for (local_14 = 0; local_14 < *(uint *)(param_1 + 0x14); local_14 = local_14 + 1) {
        puVar3 = (uint *)(local_14 * 0x10 + *(int *)(param_1 + 0x20));
        local_10 = *puVar3 & 0x3fffffff;
        puVar3[3] = iVar1 * 0x10 + iVar2 + puVar3[3];
        if ((puVar3[1] != 0) && (puVar3[1] = puVar3[1] + local_8, local_10 == 9)) {
          FUN_00026de0(puVar3[1]);
        }
        if ((local_10 == 4) && (puVar3 = (uint *)puVar3[1], *puVar3 <= puVar3[1])) {
          *puVar3 = *puVar3 + local_20;
          puVar3[1] = puVar3[1] + local_20;
        }
      }
    }
    local_1c = FUN_002b95a0(3,1,&local_28);
    if (local_1c != 0) {
      for (local_14 = 0; local_14 < *(uint *)(param_1 + 0x14); local_14 = local_14 + 1) {
        puVar3 = (uint *)(local_14 * 0x10 + *(int *)(param_1 + 0x20));
        local_10 = *puVar3 & 0x3fffffff;
        if ((local_10 == 2) || (local_10 == 3)) {
          FUN_00026760(local_1c,puVar3[1]);
          local_c = FUN_00026a40(local_1c);
          FUN_00026a10(param_1,local_14,local_c);
        }
      }
      FUN_002b94d0(local_1c,0);
    }
    FUN_00284e40();
    FUN_00235400(param_1);
    *(undefined1 *)(param_1 + 0x1c) = 1;
  }
  return;
}

