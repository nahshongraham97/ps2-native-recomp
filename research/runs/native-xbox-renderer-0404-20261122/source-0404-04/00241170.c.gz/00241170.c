
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_00241170(int param_1)

{
  int iVar1;
  uint *puVar2;
  uint *puVar3;
  uint auStack_90 [9];
  undefined4 uStack_6c;
  int iStack_68;
  byte *pbStack_64;
  int iStack_60;
  undefined4 local_50;
  byte local_4c;
  byte local_4b;
  byte local_4a;
  ushort local_49;
  ushort local_47;
  byte local_45;
  ushort local_44;
  ushort local_42;
  ushort local_40;
  ushort local_3e;
  byte local_3c;
  byte local_3b;
  undefined4 local_38;
  uint local_34 [4];
  uint local_24;
  uint local_20;
  uint local_1c;
  uint local_18;
  uint local_14;
  uint local_10;
  uint local_c;
  uint local_8;
  
  local_38 = DAT_005af7d0;
  if (param_1 == 0) {
    local_50 = 0;
  }
  else {
    iStack_60 = 0x12;
    pbStack_64 = &local_4c;
    iStack_68 = param_1;
    uStack_6c = 0x241199;
    FUN_002b90b0();
    local_34[0] = (uint)local_4c;
    local_34[1] = (uint)local_4b;
    local_34[2] = (uint)local_4a;
    local_34[3] = (uint)local_49;
    local_24 = (uint)local_47;
    local_20 = (uint)local_45;
    local_1c = (uint)local_44;
    local_18 = (uint)local_42;
    local_14 = (uint)local_40;
    local_10 = (uint)local_3e;
    local_c = (uint)local_3c;
    local_8 = (uint)local_3b;
    if (local_34[2] == 1) {
      iStack_60 = param_1;
      puVar2 = local_34;
      puVar3 = auStack_90;
      for (iVar1 = 0xc; iVar1 != 0; iVar1 = iVar1 + -1) {
        *puVar3 = *puVar2;
        puVar2 = puVar2 + 1;
        puVar3 = puVar3 + 1;
      }
      local_50 = FUN_00241780();
    }
    else if (local_34[2] == 2) {
      iStack_60 = param_1;
      puVar2 = local_34;
      puVar3 = auStack_90;
      for (iVar1 = 0xc; iVar1 != 0; iVar1 = iVar1 + -1) {
        *puVar3 = *puVar2;
        puVar2 = puVar2 + 1;
        puVar3 = puVar3 + 1;
      }
      local_50 = FUN_00241480();
    }
    else if (local_34[2] == 10) {
      iStack_60 = param_1;
      puVar2 = local_34;
      puVar3 = auStack_90;
      for (iVar1 = 0xc; iVar1 != 0; iVar1 = iVar1 + -1) {
        *puVar3 = *puVar2;
        puVar2 = puVar2 + 1;
        puVar3 = puVar3 + 1;
      }
      local_50 = FUN_002412e0();
    }
    else {
      local_50 = 0;
    }
    iStack_60 = 0;
    pbStack_64 = (byte *)param_1;
    iStack_68 = 0x2412bb;
    FUN_002b94d0();
  }
  return local_50;
}

