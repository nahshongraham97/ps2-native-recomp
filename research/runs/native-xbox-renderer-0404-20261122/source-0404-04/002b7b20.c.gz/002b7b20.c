
undefined4 FUN_002b7b20(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_002b95a0(2,2,param_1 + 8);
  if (iVar1 != 0) {
    uVar2 = FUN_002b7a70(param_1,iVar1);
    FUN_002b94d0(iVar1,0);
    return uVar2;
  }
  return 0;
}

