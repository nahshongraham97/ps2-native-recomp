
void __thiscall FUN_00241140(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_002b95a0(2,1,param_2,param_1);
  FUN_00241170(uVar1);
  return;
}

