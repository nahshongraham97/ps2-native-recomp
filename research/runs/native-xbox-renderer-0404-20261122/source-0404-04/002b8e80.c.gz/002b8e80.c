
int FUN_002b8e80(void)

{
  int in_EAX;
  int iVar1;
  int unaff_EBX;
  undefined4 local_8;
  undefined4 local_4;
  
  if (((in_EAX == 1) || (in_EAX == 2)) || (in_EAX == 3)) {
    iVar1 = (*DAT_00835408)();
    if (iVar1 != 0) {
      *(int *)(unaff_EBX + 0xc) = iVar1;
      return unaff_EBX;
    }
  }
  else {
    local_8 = 1;
    local_4 = FUN_002c2400(0xd);
    FUN_002c2370(&local_8);
  }
  local_8 = 1;
  local_4 = FUN_002c2400(0x80000002);
  FUN_002c2370(&local_8);
  return 0;
}

