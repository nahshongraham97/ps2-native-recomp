
uint FUN_002b90b0(undefined4 *param_1,undefined4 *param_2,uint param_3)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 local_8;
  undefined4 local_4;
  
  switch(*param_1) {
  case 1:
  case 2:
    break;
  case 3:
    iVar3 = param_1[4];
    iVar2 = param_1[3];
    if ((uint)(iVar3 - iVar2) < param_3) {
      local_8 = 1;
      local_4 = FUN_002c2400(5);
      FUN_002c2370(&local_8);
      param_3 = iVar3 - iVar2;
    }
    puVar5 = (undefined4 *)(param_1[5] + param_1[3]);
    for (uVar4 = param_3 >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
      *param_2 = *puVar5;
      puVar5 = puVar5 + 1;
      param_2 = param_2 + 1;
    }
    for (uVar4 = param_3 & 3; uVar4 != 0; uVar4 = uVar4 - 1) {
      *(undefined1 *)param_2 = *(undefined1 *)puVar5;
      puVar5 = (undefined4 *)((int)puVar5 + 1);
      param_2 = (undefined4 *)((int)param_2 + 1);
    }
    param_1[3] = param_1[3] + param_3;
    return param_3;
  case 4:
    uVar4 = (*(code *)param_1[4])(param_1[7],param_2,param_3);
    return uVar4;
  default:
    local_8 = 1;
    local_4 = FUN_002c2400(0xe);
    FUN_002c2370(&local_8);
    return 0;
  }
  uVar1 = param_1[3];
  uVar4 = (*DAT_00835410)(param_2,1,param_3,uVar1);
  if (uVar4 != param_3) {
    iVar3 = (*DAT_00835420)(uVar1);
    local_8 = 1;
    if (iVar3 != 0) {
      local_4 = FUN_002c2400(5);
      FUN_002c2370(&local_8);
      return uVar4;
    }
    local_4 = FUN_002c2400(0x8000001a);
    FUN_002c2370(&local_8);
  }
  return uVar4;
}

