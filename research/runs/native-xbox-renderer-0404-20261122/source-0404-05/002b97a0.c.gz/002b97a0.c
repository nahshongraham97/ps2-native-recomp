
undefined4 FUN_002b97a0(undefined4 param_1,int param_2,undefined4 *param_3,uint *param_4)

{
  int iVar1;
  undefined4 local_10;
  int local_c;
  uint local_8;
  undefined4 local_4;
  
  iVar1 = FUN_002b9680(param_1,&local_c,&local_10,&local_8,0);
  if (iVar1 != 0) {
    while (local_c != param_2) {
      iVar1 = FUN_002b93c0(param_1,local_10);
      if (iVar1 == 0) {
        return 0;
      }
      iVar1 = FUN_002b9680(param_1,&local_c,&local_10,&local_8,0);
      if (iVar1 == 0) {
        return 0;
      }
    }
    if (0x33fff < local_8) {
      if (0x36003 < local_8) {
        local_8 = 1;
        local_4 = FUN_002c2400(0x80000004);
        FUN_002c2370(&local_8);
        return 0;
      }
      if (param_3 != (undefined4 *)0x0) {
        *param_3 = local_10;
      }
      if (param_4 != (uint *)0x0) {
        *param_4 = local_8;
      }
      return 1;
    }
    local_8 = 1;
    local_4 = FUN_002c2400(0x80000004);
    FUN_002c2370(&local_8);
  }
  return 0;
}

