
uint module0403_0039b16e(int param_1)

{
  return *(uint *)(param_1 + 0xc) & 0x10;
}

