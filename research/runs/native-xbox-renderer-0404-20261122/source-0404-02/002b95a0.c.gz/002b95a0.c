
undefined4 FUN_002b95a0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = (*DAT_00835484)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c72d8),0x30404);
  iVar2 = FUN_002b8fb0(uVar1,1,param_1,param_2,param_3);
  if (iVar2 == 0) {
    (*DAT_00835488)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c72d8),uVar1);
    return 0;
  }
  return uVar1;
}

