
bool FUN_002b94d0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  bool bVar2;
  undefined4 local_8;
  undefined4 local_4;
  
  switch(*param_1) {
  case 2:
    iVar1 = (*DAT_0083540c)(param_1[3]);
    bVar2 = iVar1 == 0;
    break;
  case 3:
    bVar2 = true;
    if ((param_1[1] != 1) && (param_2 != (undefined4 *)0x0)) {
      *param_2 = param_1[5];
      param_2[1] = param_1[3];
    }
    break;
  case 4:
    if ((code *)param_1[3] != (code *)0x0) {
      (*(code *)param_1[3])(param_1[7]);
    }
  case 1:
    bVar2 = true;
    break;
  default:
    local_8 = 1;
    local_4 = FUN_002c2400(0xe);
    FUN_002c2370(&local_8);
    return false;
  }
  if (param_1[8] != 0) {
    (*DAT_00835488)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c72d8),param_1);
  }
  return bVar2;
}

