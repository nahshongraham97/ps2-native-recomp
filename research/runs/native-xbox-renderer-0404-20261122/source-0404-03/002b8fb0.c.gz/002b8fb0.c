
undefined4 *
FUN_002b8fb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 local_8;
  undefined4 local_4;
  
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = param_3;
    param_1[1] = param_4;
    param_1[8] = param_2;
    switch(param_3) {
    case 1:
      goto switchD_002b8fe5_caseD_1;
    case 2:
      puVar2 = (undefined4 *)FUN_002b8e80();
      return puVar2;
    case 3:
      puVar2 = (undefined4 *)FUN_002b8f10();
      return puVar2;
    case 4:
      param_1[3] = *param_5;
      param_1[4] = param_5[1];
      param_1[5] = param_5[2];
      param_1[6] = param_5[3];
      param_1[7] = param_5[4];
      return param_1;
    default:
      local_8 = 1;
      local_4 = FUN_002c2400(0xe);
      FUN_002c2370(&local_8);
      return (undefined4 *)0x0;
    }
  }
  return (undefined4 *)0x0;
switchD_002b8fe5_caseD_1:
  iVar1 = (*DAT_0083542c)(param_5);
  if (iVar1 != -1) {
    param_1[3] = param_5;
    return param_1;
  }
  return (undefined4 *)0x0;
}

