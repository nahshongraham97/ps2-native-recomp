
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_002c0dd0(void)

{
  DAT_00835404 = &UNK_002c0da0;
  DAT_00835408 = &UNK_0039b621;
  DAT_0083540c = _fclose;
  DAT_00835410 = &UNK_0039b4dc;
  DAT_00835414 = &UNK_0039b398;
  _DAT_00835418 = &UNK_0039b1fb;
  _DAT_0083541c = &UNK_0039b184;
  DAT_00835420 = &UNK_0039b16e;
  DAT_00835424 = &UNK_0039b125;
  _DAT_00835428 = &UNK_0039b03d;
  DAT_0083542c = &UNK_0039ae9c;
  return 1;
}

