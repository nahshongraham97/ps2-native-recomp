
undefined4 * FUN_002b93c0(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 local_8;
  undefined4 local_4;
  
  if (param_2 == 0) {
    return param_1;
  }
  switch(*param_1) {
  case 1:
  case 2:
    break;
  case 3:
    if ((uint)(param_2 + param_1[3]) <= (uint)param_1[4]) {
      param_1[3] = param_2 + param_1[3];
      return param_1;
    }
    param_1[3] = param_1[4];
    local_8 = 1;
    local_4 = FUN_002c2400(5);
    FUN_002c2370(&local_8);
    return (undefined4 *)0x0;
  case 4:
    iVar2 = (*(code *)param_1[6])(param_1[7],param_2);
    return (undefined4 *)(-(uint)(iVar2 != 0) & (uint)param_1);
  default:
    local_8 = 1;
    local_4 = FUN_002c2400(0xe);
    FUN_002c2370(&local_8);
    return (undefined4 *)0x0;
  }
  uVar1 = param_1[3];
  iVar2 = (*DAT_00835424)(uVar1,param_2,1);
  if (iVar2 == 0) {
    return param_1;
  }
  iVar2 = (*DAT_00835420)(uVar1);
  if (iVar2 != 0) {
    local_8 = 1;
    local_4 = FUN_002c2400(5);
    FUN_002c2370(&local_8);
  }
  return (undefined4 *)0x0;
}

