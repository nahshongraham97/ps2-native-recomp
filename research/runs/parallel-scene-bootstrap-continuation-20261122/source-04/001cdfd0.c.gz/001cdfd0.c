
undefined8 FUN_001cdfd0(undefined8 param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = (int)param_1;
  puVar2 = (undefined4 *)(iVar1 + iGpffffa658);
  *puVar2 = 0;
  puVar2[1] = 0;
  puVar2[2] = 0;
  puVar2[4] = *(undefined4 *)(iVar1 + 0x18);
  puVar2[5] = *(undefined4 *)(iVar1 + 0x1c);
  puVar2[6] = *(undefined4 *)(iVar1 + 0x10);
  *(undefined1 **)(iVar1 + 0x10) = &LAB_001cdf40;
  *(undefined1 **)(iVar1 + 0x18) = &LAB_001cdee0;
  *(undefined1 **)(iVar1 + 0x1c) = &LAB_001cdf20;
  puVar2[3] = 0;
  return param_1;
}

