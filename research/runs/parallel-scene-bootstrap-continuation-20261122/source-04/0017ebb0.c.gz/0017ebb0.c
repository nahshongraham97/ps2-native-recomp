
long FUN_0017ebb0(undefined8 param_1,undefined8 param_2,long param_3,long param_4)

{
  int iVar1;
  long lVar2;
  long lVar3;
  int iVar4;
  
  lVar2 = FUN_001a65a0();
  if (lVar2 == 0) {
    lVar2 = 0;
  }
  else {
    lVar3 = FUN_001a71d0();
    if (lVar3 != 0) {
      FUN_001aa0b0(lVar2,lVar3);
    }
    iVar4 = (int)lVar2;
    if ((param_4 != 0) && (lVar3 = FUN_001a87f0(param_1,param_2,0,2), lVar3 != 0)) {
      *(int *)(iVar4 + 0x60) = (int)lVar3;
    }
    if (param_3 == 0) {
      iVar1 = *(int *)(iVar4 + 4);
    }
    else {
      lVar3 = FUN_001a87f0(param_1,param_2,0,1);
      if (lVar3 != 0) {
        *(int *)(iVar4 + 100) = (int)lVar3;
      }
      iVar1 = *(int *)(iVar4 + 4);
    }
    if (((iVar1 == 0) ||
        ((param_4 != 0 &&
         ((*(int **)(iVar4 + 0x60) == (int *)0x0 || (**(int **)(iVar4 + 0x60) == 0)))))) ||
       ((param_3 != 0 && ((*(int **)(iVar4 + 100) == (int *)0x0 || (**(int **)(iVar4 + 100) == 0))))
       )) {
      lVar2 = 0;
    }
  }
  return lVar2;
}

