
int FUN_001a3190(int *param_1,int param_2,int param_3,long param_4,long param_5,long param_6)

{
  int *piVar1;
  int *piVar2;
  long lVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  if (iGpffffa3b8 == 0) {
    iVar6 = -1;
  }
  else {
    lVar3 = FUN_001a6a10();
    if (lVar3 == 0) {
      if (pcRam0069f3d4 == FUN_001a1180) {
        piVar1 = (int *)param_1[4];
      }
      else {
        uVar5 = 0;
        piVar1 = piGpffffa3b0;
        if (uGpffffa3b4 != 0) {
          do {
            if (param_1 == (int *)*piVar1) break;
            uVar5 = uVar5 + 1;
            piVar1 = piVar1 + 1;
          } while (uVar5 < uGpffffa3b4);
        }
        if (uGpffffa3b4 == uVar5) {
          piVar1 = (int *)(*pcRam0069f3c4)((uGpffffa3b4 + 1) * 4,0x40000);
          uVar5 = 0;
          if (piGpffffa3b0 != (int *)0x0) {
            if (uGpffffa3b4 != 0) {
              iVar6 = 0;
              piVar4 = piVar1;
              do {
                uVar5 = uVar5 + 1;
                piVar2 = (int *)((int)piGpffffa3b0 + iVar6);
                iVar6 = iVar6 + 4;
                *piVar4 = *piVar2;
                piVar4 = piVar4 + 1;
              } while (uVar5 < uGpffffa3b4);
            }
            (*pcRam0069f3c8)(piGpffffa3b0);
          }
          piVar1[uVar5] = (int)param_1;
          uGpffffa3b4 = uGpffffa3b4 + 1;
          piGpffffa3b0 = piVar1;
        }
        piVar1 = (int *)param_1[4];
      }
      if (piVar1 == (int *)0x0) {
LAB_001a3350:
        iVar6 = *param_1 + (param_2 + 3U & 0xfffffffc);
        if ((param_1[2] == 0) || (iVar6 <= param_1[2])) {
          lVar3 = (*pcRam0069f3d4)(iGpffffa3b8,0x40000);
          if (lVar3 == 0) {
            iVar6 = -1;
          }
          else {
            piVar1 = (int *)lVar3;
            *piVar1 = *param_1;
            *param_1 = iVar6;
            piVar1[1] = param_2;
            piVar1[2] = param_3;
            piVar1[3] = 0;
            piVar1[4] = 0;
            piVar1[5] = 0;
            piVar1[6] = 0;
            piVar1[7] = 0;
            if (param_4 == 0) {
              piVar1[8] = (int)&LAB_001a3120;
            }
            else {
              piVar1[8] = (int)param_4;
            }
            if (param_5 == 0) {
              piVar1[9] = (int)&LAB_001a3130;
            }
            else {
              piVar1[9] = (int)param_5;
            }
            if (param_6 == 0) {
              piVar1[10] = (int)&LAB_001a3140;
            }
            else {
              piVar1[10] = (int)param_6;
            }
            piVar1[0xb] = 0;
            piVar1[0xc] = 0;
            piVar1[0xd] = 0;
            piVar1[0xe] = (int)param_1;
            if (param_1[4] == 0) {
              param_1[4] = (int)piVar1;
              param_1[5] = (int)piVar1;
            }
            else {
              *(int **)(param_1[5] + 0x30) = piVar1;
              piVar1[0xd] = param_1[5];
              param_1[5] = (int)piVar1;
            }
            iVar6 = *piVar1;
          }
        }
        else {
          iVar6 = -1;
        }
      }
      else {
        iVar6 = piVar1[2];
        while (iVar6 != param_3) {
          piVar1 = (int *)piVar1[0xc];
          if (piVar1 == (int *)0x0) goto LAB_001a3350;
          iVar6 = piVar1[2];
        }
        uStack_10 = 1;
        uStack_c = FUN_0019f510(0xffffffff80000017);
        FUN_0019f460(&uStack_10);
        iVar6 = *piVar1;
      }
    }
    else {
      uStack_8 = 1;
      uStack_4 = FUN_0019f510(0xffffffff80000017);
      FUN_0019f460(&uStack_8);
      iVar6 = -1;
    }
  }
  return iVar6;
}

