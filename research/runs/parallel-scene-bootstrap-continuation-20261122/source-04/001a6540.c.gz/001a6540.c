
undefined4 FUN_001a6540(undefined8 param_1)

{
  FUN_001a3520(0x5a3630,param_1);
  FUN_001aa120(param_1);
  (*pcRam0069f3d8)(*(undefined4 *)(iRam0064e4c0 + 0x69f290),param_1);
  return 1;
}

