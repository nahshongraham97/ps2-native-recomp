
void FUN_0017ece0(void)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    FUN_0017ed40(iVar1);
    iVar1 = iVar1 + 1;
  } while (iVar1 < 4);
  if (iRam0064e200 != 0) {
    FUN_0017ee30(iRam0064e200,1,0);
    iRam0064e200 = 0;
  }
  return;
}

