
long FUN_001a65a0(void)

{
  long lVar1;
  undefined1 *puVar2;
  
  lVar1 = (*pcRam0069f3d4)(*(undefined4 *)(iRam0064e4c0 + 0x69f290),0x30005);
  if (lVar1 == 0) {
    lVar1 = 0;
  }
  else {
    puVar2 = (undefined1 *)lVar1;
    *puVar2 = 4;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    *(undefined4 *)(puVar2 + 4) = 0;
    *(code **)(puVar2 + 0x10) = FUN_001a6040;
    *(code **)(puVar2 + 0x18) = FUN_001a6100;
    *(code **)(puVar2 + 0x1c) = FUN_001a60b0;
    *(undefined4 *)(puVar2 + 0x6c) = 0x3f800000;
    *(undefined4 *)(puVar2 + 0x68) = 0x3f800000;
    *(undefined4 *)(puVar2 + 0x74) = 0x3f800000;
    *(undefined4 *)(puVar2 + 0x70) = 0x3f800000;
    *(undefined4 *)(puVar2 + 0x7c) = 0;
    *(undefined4 *)(puVar2 + 0x78) = 0;
    *(undefined4 *)(puVar2 + 0x80) = 0x3d4ccccd;
    *(undefined4 *)(puVar2 + 0x84) = 0x41200000;
    *(undefined4 *)(puVar2 + 0x88) = 0x40a00000;
    *(undefined4 *)(puVar2 + 0x60) = 0;
    *(undefined4 *)(puVar2 + 100) = 0;
    *(undefined4 *)(puVar2 + 0x14) = 1;
    FUN_001a4f00(lVar1);
    *(undefined4 *)(puVar2 + 0x2c) = 0;
    FUN_001a3480(0x5a3630,lVar1);
  }
  return lVar1;
}

