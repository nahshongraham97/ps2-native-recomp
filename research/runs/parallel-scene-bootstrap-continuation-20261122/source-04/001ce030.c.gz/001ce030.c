
undefined8 FUN_001ce030(undefined8 param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  param_2 = param_2 + iRam0064e748;
  puVar2 = (undefined4 *)((int)param_1 + iRam0064e748);
  *puVar2 = 0;
  puVar2[1] = 0;
  puVar2[2] = 0;
  iVar1 = *(int *)(param_2 + 0xc);
  if (iVar1 != 0) {
    FUN_001cf300(iVar1,param_1);
  }
  return param_1;
}

