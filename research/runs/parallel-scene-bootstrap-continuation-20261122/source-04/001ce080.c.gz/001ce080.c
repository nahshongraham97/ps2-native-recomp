
undefined8 FUN_001ce080(undefined8 param_1)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (int)param_1;
  piVar2 = (int *)(iVar1 + iRam0064e748);
  if (*piVar2 == 0) {
    *piVar2 = 0;
  }
  else {
    (*pcRam0069f3c8)();
    *piVar2 = 0;
  }
  piVar2[1] = 0;
  piVar2[2] = 0;
  *(int *)(iVar1 + 0x18) = piVar2[4];
  *(int *)(iVar1 + 0x1c) = piVar2[5];
  *(int *)(iVar1 + 0x10) = piVar2[6];
  return param_1;
}

