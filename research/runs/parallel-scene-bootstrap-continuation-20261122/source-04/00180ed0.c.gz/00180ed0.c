
undefined4 FUN_00180ed0(void)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  long lVar4;
  undefined8 uVar5;
  int *piVar6;
  int *piVar7;
  uint uVar8;
  undefined4 uVar9;
  
  FUN_001dba60(0x69eae0,0,0x390);
  uRam0069ead0 = 0;
  uRam0069ead4 = 1;
  uRam0069ead8 = 2;
  uRam0069eadc = 3;
  uGpffffa198 = 0;
  uGpffffa19c = 0;
  uGpffffa190 = 0;
  uGpffffa194 = 0;
  uVar3 = FUN_0017ebb0(uGpffff9e08,uGpffff9e04,1,1);
  uGpffffa110 = (undefined4)uVar3;
  FUN_001a6270(0x3e800000,uVar3);
  FUN_001a62b0(0x42fa0000,uVar3);
  uVar9 = FUN_0026dc20((fGpffff830c * 3.1415927) / 360.0);
  FUN_0017ef50(uVar9,uGpffff8308,uVar3,0);
  uVar8 = 0;
  lVar4 = FUN_00127100();
  if (0 < lVar4) {
    piVar7 = (int *)0x69eae0;
    piVar6 = piVar7;
    do {
      uVar3 = FUN_0017ebb0(uGpffff9e08,uGpffff9e04,0,0);
      iVar2 = (int)uVar3;
      if ((-1 < (int)uVar8) && ((int)uVar8 < 4)) {
        *piVar7 = iVar2;
      }
      *piVar6 = iVar2;
      lVar4 = FUN_0013f490(0x1003,*(undefined4 *)(iVar2 + 4));
      piVar6[1] = (int)lVar4;
      if (lVar4 != 0) {
        FUN_001a6270(0x3e800000,uVar3);
        FUN_001a62b0(0x42fa0000,uVar3);
        if (*piVar7 != 0) {
          uVar9 = FUN_0026dc20((fGpffff830c * 3.1415927) / 360.0);
          FUN_0017ef50(uVar9,uGpffff8308,*piVar7,0);
          FUN_001a6410(*piVar7,1);
        }
        iVar1 = piVar7[1];
        if (iVar1 != 0) {
          *(byte *)(iVar1 + 0xc) = *(byte *)(iVar1 + 0xc) & 0xdf | 0x20;
          *(byte *)(piVar7[1] + 0xc) = *(byte *)(piVar7[1] + 0xc) & 0xfb | 4;
        }
        if (piVar6[1] == 0) {
          piVar7[5] = 0;
          piVar7[6] = 0;
        }
        else {
          piVar7[5] = piVar6[1];
          piVar7[6] = *(int *)(piVar6[1] + 4);
        }
        piVar6[4] = *(int *)(piVar6[1] + 0x28);
        FUN_0013f6c0(piVar6[1]);
        *(byte *)(piVar6[1] + 0xc) = *(byte *)(piVar6[1] + 0xc) & 0xdf | 0x20;
        *(byte *)(piVar6[1] + 0xc) = *(byte *)(piVar6[1] + 0xc) & 0xfb | 4;
        FUN_0013c540(piVar6[1]);
        if ((iGpffff9db4 != 7) || (uVar8 == 0)) {
          uVar3 = FUN_0012ea90(2);
          uVar5 = FUN_00130d00(0x59fde0,0x1c0);
          piVar6[3] = (int)uVar5;
          lVar4 = FUN_0012f100(0x1d,uVar3,0x5005,0x1808d0,uVar5);
          piVar6[2] = (int)lVar4;
          if (lVar4 != 0) {
            FUN_0012dad0(0x1c0,piVar6[3]);
            *(code **)(piVar6[2] + 0xd8) = FUN_00180ac0;
            *(ushort *)(piVar6[2] + 0xd0) =
                 *(ushort *)(piVar6[2] + 0xd0) & 0xfc3f | (ushort)((uVar8 & 0xf) << 6);
            *(int *)(piVar6[3] + 8) = iVar2;
          }
        }
        piVar6[0x19] = 0x40266666;
        piVar6[0x17] = 0;
        piVar6[0x16] = 0;
        piVar6[0x15] = 0;
        piVar6[0xe] = 0;
        piVar6[0xd] = 0;
        piVar6[0xc] = 0;
        piVar6[0x11] = 0;
        piVar6[0x10] = 0;
        piVar6[0xf] = 0;
        piVar6[0xe] = 0;
        piVar6[0xd] = 0;
        piVar6[0xc] = 0;
        piVar6[7] = 1;
        piVar6[8] = 0;
        piVar6[9] = 0;
        iVar2 = piVar6[3];
        if ((iVar2 != 0) && (iVar1 = piVar6[2], iVar1 != 0)) {
          if (iVar1 == 0) {
            *(undefined4 *)(iVar2 + 0x68) = 0;
            *(undefined4 *)(piVar6[3] + 0x6c) = 0;
          }
          else {
            *(int *)(iVar2 + 0x68) = iVar1;
            *(undefined4 *)(piVar6[3] + 0x6c) = *(undefined4 *)(piVar6[2] + 4);
          }
        }
      }
      piVar7 = piVar7 + 0x39;
      piVar6 = piVar6 + 0x39;
      uVar8 = uVar8 + 1;
      iVar2 = FUN_00127100();
    } while ((int)uVar8 < iVar2);
  }
  FUN_001813c0();
  return 1;
}

