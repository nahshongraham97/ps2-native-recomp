
undefined4 FUN_00126420(void)

{
  undefined4 uVar1;
  long lVar2;
  undefined *puStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined *puStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined *puStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  
  lVar2 = FUN_0030e5b0(4);
  if (lVar2 == 0) {
    FUN_00163cb0(0x5f5270);
    uVar1 = 0;
  }
  else {
    uStack_1c = 0;
    puStack_20 = &DAT_005cbb60;
    uStack_10 = 0;
    uStack_18 = 2;
    uStack_14 = 2;
    FUN_0030e690(&puStack_20);
    uStack_3c = 0;
    puStack_40 = &DAT_005cbc40;
    uStack_30 = 0;
    uStack_38 = 0x10026;
    uStack_34 = 1;
    FUN_0030e690(&puStack_40);
    uStack_5c = 0;
    puStack_60 = &DAT_005cbb90;
    uStack_50 = 0;
    uStack_58 = 0x10006;
    uStack_54 = 1;
    FUN_0030e690(&puStack_60);
    uStack_7c = 0;
    puStack_80 = &DAT_005cbad0;
    uStack_70 = 0;
    uStack_78 = 0x1001;
    uStack_74 = 1;
    FUN_0030e690(&puStack_80);
    uStack_9c = 0;
    puStack_a0 = &DAT_005cbad0;
    uStack_90 = 0;
    uStack_98 = 1;
    uStack_94 = 1;
    FUN_0030e690(&puStack_a0);
    lVar2 = FUN_001cdbe0();
    if (lVar2 == 0) {
      FUN_00163cb0(0x5f5290);
      uVar1 = 0;
    }
    else {
      lVar2 = FUN_0021a630();
      if (lVar2 == 0) {
        FUN_00163cb0(0x5f52b0);
        uVar1 = 0;
      }
      else {
        FUN_003102f0();
        lVar2 = FUN_0021b640();
        if (lVar2 == 0) {
          FUN_00163cb0(0x5f52d0);
          uVar1 = 0;
        }
        else {
          lVar2 = FUN_002dfd70();
          if (lVar2 == 0) {
            FUN_00163cb0(0x5f52f0);
            uVar1 = 0;
          }
          else {
            lVar2 = FUN_00218fa0();
            if (lVar2 == 0) {
              FUN_00163cb0(0x5f5310);
              uVar1 = 0;
            }
            else {
              lVar2 = FUN_001d6ff0();
              if (lVar2 == 0) {
                FUN_00163cb0(0x5f5330);
                uVar1 = 0;
              }
              else {
                lVar2 = FUN_002762d0();
                if (lVar2 == 0) {
                  FUN_00163cb0(0x5f5350);
                  uVar1 = 0;
                }
                else {
                  lVar2 = FUN_002956a0();
                  if (lVar2 == 0) {
                    FUN_00163cb0(0x5f5370);
                    uVar1 = 0;
                  }
                  else {
                    lVar2 = FUN_002df460();
                    if (lVar2 == 0) {
                      FUN_00163cb0(0x5f5390);
                      uVar1 = 0;
                    }
                    else {
                      lVar2 = FUN_00213fc0();
                      if (lVar2 == 0) {
                        FUN_00163cb0(0x5f53b0);
                        uVar1 = 0;
                      }
                      else {
                        lVar2 = FUN_00213d50();
                        if (lVar2 == 0) {
                          FUN_00163cb0(0x5f53e0);
                          uVar1 = 0;
                        }
                        else {
                          lVar2 = FUN_00213620();
                          if (lVar2 == 0) {
                            FUN_00163cb0(0x5f5410);
                            uVar1 = 0;
                          }
                          else {
                            lVar2 = FUN_002132e0();
                            if (lVar2 == 0) {
                              FUN_00163cb0(0x5f5440);
                              uVar1 = 0;
                            }
                            else {
                              uVar1 = 1;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return uVar1;
}

