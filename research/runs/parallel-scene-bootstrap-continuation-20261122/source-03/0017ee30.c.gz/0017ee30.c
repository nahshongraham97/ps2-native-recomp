
void FUN_0017ee30(long param_1,long param_2,long param_3)

{
  int iVar1;
  int *piVar2;
  long lVar3;
  int iVar4;
  
  if (param_1 != 0) {
    lVar3 = FUN_001cf380();
    iVar4 = (int)param_1;
    if (lVar3 == 0) {
      iVar1 = *(int *)(iVar4 + 4);
    }
    else {
      FUN_001cf350(lVar3,param_1);
      iVar1 = *(int *)(iVar4 + 4);
    }
    if (iVar1 != 0) {
      FUN_001aa0b0(param_1,0);
      FUN_001a7240(iVar1);
    }
    if (param_2 != 0) {
      piVar2 = *(int **)(iVar4 + 0x60);
      if (piVar2 == (int *)0x0) {
        piVar2 = *(int **)(iVar4 + 100);
      }
      else {
        if (((param_3 != 0) && ((int *)*piVar2 != (int *)0x0)) && ((int *)*piVar2 != piVar2)) {
          FUN_001a85a0();
        }
        FUN_001a85a0(piVar2);
        *(undefined4 *)(iVar4 + 0x60) = 0;
        piVar2 = *(int **)(iVar4 + 100);
      }
      if (piVar2 != (int *)0x0) {
        if (((param_3 != 0) && ((int *)*piVar2 != (int *)0x0)) && ((int *)*piVar2 != piVar2)) {
          FUN_001a85a0();
        }
        FUN_001a85a0(piVar2);
        *(undefined4 *)(iVar4 + 100) = 0;
      }
    }
    FUN_001a6540(param_1);
  }
  return;
}

