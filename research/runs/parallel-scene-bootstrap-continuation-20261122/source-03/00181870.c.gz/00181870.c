
undefined4 FUN_00181870(int param_1)

{
  return *(undefined4 *)(param_1 * 0xe4 + 0x69eae0);
}

