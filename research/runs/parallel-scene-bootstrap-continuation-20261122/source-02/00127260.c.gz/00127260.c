
undefined4 FUN_00127260(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  long lVar3;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uRam0064defc = 1;
  uVar2 = FUN_00220900();
  lVar3 = FUN_001a6dd0(uVar2,0,0x100000);
  if (lVar3 == 0) {
    uVar1 = 0;
  }
  else {
    FUN_00225d40();
    FUN_00225da0();
    lVar3 = FUN_00126420();
    if (lVar3 == 0) {
      uVar1 = 0;
    }
    else {
      uStack_4 = 0;
      lVar3 = FUN_001a6c30(&uStack_4);
      if (lVar3 == 0) {
        FUN_001a6d70();
        uVar1 = 0;
      }
      else {
        lVar3 = FUN_00225d90();
        if (lVar3 == 0) {
          uVar1 = 0;
        }
        else {
          FUN_00225ca0();
          lVar3 = FUN_001a6b30();
          if (lVar3 == 0) {
            FUN_001a6be0();
            FUN_001a6d70();
            uVar1 = 0;
          }
          else {
            uRam0064dee4 = 1;
            uStack_8 = 7;
            FUN_001b03c0(5,&uStack_8);
            FUN_00225690();
            FUN_0026ebe0();
            FUN_0031cfd0();
            uVar1 = 1;
          }
        }
      }
    }
  }
  return uVar1;
}

