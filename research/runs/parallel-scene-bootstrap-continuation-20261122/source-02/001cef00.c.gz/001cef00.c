
undefined8 FUN_001cef00(undefined8 param_1,int param_2)

{
  int iVar1;
  
  iVar1 = (int)param_1 + iRam0064e748;
  if ((iVar1 != 0) && (param_2 == *(int *)(iVar1 + 0xc))) {
    FUN_001cf350(param_2,param_1);
  }
  return param_1;
}

