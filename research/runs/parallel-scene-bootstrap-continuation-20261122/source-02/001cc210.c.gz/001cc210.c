
undefined8 FUN_001cc210(undefined8 param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  
  puVar3 = (undefined4 *)param_1;
  puVar1 = (undefined4 *)*puVar3;
  if (puVar1 != (undefined4 *)0x0) {
    iVar2 = puVar3[1];
    iVar5 = 0;
    puVar4 = puVar1;
    if (0 < iVar2) {
      do {
        FUN_001cba10(*puVar4);
        iVar5 = iVar5 + 1;
        *puVar4 = 0;
        puVar4 = puVar4 + 1;
      } while (iVar5 < iVar2);
    }
    (*pcRam0069f3c8)(puVar1);
    *puVar3 = 0;
  }
  puVar3[1] = 0;
  puVar3[2] = 0;
  return param_1;
}

