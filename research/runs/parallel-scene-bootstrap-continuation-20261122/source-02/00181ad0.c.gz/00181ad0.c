
void FUN_00181ad0(void)

{
  int iVar1;
  long lVar2;
  int *piVar3;
  int iVar4;
  
  if (((iGpffffa110 != 0) && (iGpffff9de4 != 0)) && (lVar2 = FUN_001cf380(), lVar2 == 0)) {
    FUN_001cf300(iGpffff9de4,iGpffffa110);
  }
  iVar4 = 0;
  lVar2 = FUN_00127100();
  if (0 < lVar2) {
    piVar3 = (int *)0x69eae0;
    iVar1 = iRam0069eae0;
    while( true ) {
      if (iVar1 != 0) {
        if ((iGpffff9de4 != 0) && (lVar2 = FUN_001cf380(iVar1), lVar2 == 0)) {
          FUN_001cf300(iGpffff9de4,iVar1);
        }
        FUN_00126710();
      }
      piVar3 = piVar3 + 0x39;
      iVar4 = iVar4 + 1;
      iVar1 = FUN_00127100();
      if (iVar1 <= iVar4) break;
      iVar1 = *piVar3;
    }
  }
  return;
}

