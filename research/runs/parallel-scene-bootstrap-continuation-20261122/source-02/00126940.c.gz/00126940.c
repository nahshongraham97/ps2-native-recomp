
void FUN_00126940(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined1 auStack_50 [80];
  
  iVar6 = iRam0064e200;
  if ((iRam0064dec4 == 0) || (iRam0064def0 = iRam0064def0 + 1, iRam0064def0 < 6)) {
    if (iRam0064e0fc == 0) {
      iVar6 = 0;
      if (0 < iRam0064defc) {
        do {
          iVar3 = FUN_00181870(iVar6);
          FUN_001a7c90(*(undefined4 *)(iVar3 + 4));
          iVar6 = iVar6 + 1;
        } while (iVar6 < iRam0064defc);
      }
      FUN_0013f880();
      FUN_001c3e00();
      FUN_001adad0();
      FUN_002e99f0();
      uRam0064e7f8 = 0;
      uRam0064e7f4 = 0;
      uRam0064dfcc = 0;
      FUN_00126e60();
      iVar6 = 0;
      if (0 < iRam0064defc) {
        puVar7 = (undefined4 *)0x69ead0;
        do {
          uVar1 = *puVar7;
          if ((iVar6 != 0) && (-1 < (long)((ulong)bRam00660081 << 0x3e))) break;
          uVar4 = FUN_00181870(uVar1);
          uRam0064ded0 = (undefined4)uVar4;
          if ((bRam00660080 & 1) == 0) {
            uVar4 = FUN_001a6390(uVar4,0x64debc,7);
          }
          else {
            uVar4 = FUN_001a6390(uVar4,0x64ded8,7);
          }
          uVar2 = uRam0064deb8;
          if ((((bRam00660080 & 1) == 0) && (iRam006600b0 != 0)) &&
             (-1 < (long)((ulong)*(byte *)(iRam006600b0 + 0xe) << 0x3d))) {
            uVar8 = *(undefined4 *)((int)uVar4 + 0x84);
            if (iRam0066008c == 0) {
              FUN_001a62b0(0x44fa0000,uVar4);
            }
            else {
              FUN_001a62b0(*(undefined4 *)(iRam0066008c + 0x90),uVar4);
            }
            FUN_001a6260(uVar4);
            uRam0064deb8 = 0;
            FUN_00126fc0(0x14,1);
            FUN_00126fc0(8,1);
            FUN_00126fc0(6,1);
            FUN_00126fc0(7,2);
            FUN_00126fc0(10,5);
            FUN_00126fc0(0xb,6);
            FUN_00125ba0();
            uRam0064deb8 = uVar2;
            FUN_001c9880(*(undefined4 *)(iRam006600b0 + 0x1c));
            FUN_001a6250(uVar4);
            FUN_001a62b0(uVar8,uVar4);
          }
          uVar4 = FUN_001a6260(uVar4);
          FUN_00126fc0(0x14,1);
          FUN_00126fc0(8,1);
          FUN_00126fc0(6,1);
          FUN_00126fc0(7,2);
          FUN_00126fc0(10,5);
          FUN_00126fc0(0xb,6);
          FUN_00125ba0();
          FUN_0021f840();
          FUN_00210540(uVar4);
          if ((bRam00660080 & 1) == 0) {
            FUN_00172b20(1);
            if (iRam0064dea4 == 7) {
              FUN_0040fff0(uVar1);
            }
            FUN_0013f6d0();
            FUN_001816e0(uVar1);
            FUN_00210c60();
            if (((iRam0064dea4 != 10) && (iRam0064dea4 != 7)) && (iRam0065b96c == 0)) {
              FUN_0031cca0();
            }
            FUN_0031ce10();
            FUN_00126fc0(0x14,1);
            FUN_00126fc0(8,1);
            FUN_00126fc0(6,1);
            FUN_00126fc0(7,2);
            FUN_00126fc0(10,5);
            FUN_00126fc0(0xb,6);
            FUN_00125ba0();
          }
          FUN_00126fc0(0xe,0);
          FUN_00210520();
          FUN_001a6250(uVar4);
          iVar6 = iVar6 + 1;
          puVar7 = puVar7 + 1;
        } while (iVar6 < iRam0064defc);
      }
      if (iRam0064e0fc == 0) {
        uVar4 = FUN_001a6260(iRam0064e200);
        FUN_00210540(uVar4);
        FUN_0021f810();
        uVar1 = *(undefined4 *)((int)uVar4 + 4);
        iVar6 = FUN_00181870(0);
        uVar5 = FUN_001a7580(*(undefined4 *)(iVar6 + 4));
        FUN_001a7ac0(uVar1,uVar5,0);
        if ((((bRam00660080 & 1) == 0) && (iRam0065b96c == 0)) &&
           (FUN_00190700(), iRam0064dedc != 0)) {
          FUN_001de4b0(auStack_50,0x5f5260,uRam0064deb4);
        }
        FUN_00172b20(0);
        FUN_00210520();
        FUN_001a6250(uVar4);
        FUN_0021f800();
        if (iRam0065b96c == 0) {
          FUN_001a63d0(uVar4,0,1);
        }
      }
    }
    else {
      FUN_002e99f0();
      if ((iRam0064dec0 == 0) && (iVar6 != 0)) {
        FUN_001a6390(iVar6,0x64ded8,7);
        FUN_001a6260(iVar6);
        FUN_001a6250(iVar6);
        FUN_001a63d0(iVar6,0,1);
      }
    }
  }
  else {
    iRam0064def0 = 0;
    FUN_001adad0();
    FUN_002e99f0();
    thunk_FUN_002e8d50();
  }
  return;
}

