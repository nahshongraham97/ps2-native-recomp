
bool FUN_001cf020(void)

{
  bool bVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  ulong uVar9;
  ulong uVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  ulong uVar14;
  ulong uVar15;
  ulong uVar16;
  ulong uVar17;
  ulong uVar18;
  ulong uVar19;
  ulong uVar20;
  ulong uVar21;
  ulong uVar22;
  long lVar23;
  
  uVar2 = FUN_001a6a20(0xc,0x509,0x1cdd50,0x1cde40);
  uVar3 = FUN_001a6510(0x1c,0x509,0x1cdfd0,0x1ce080,0x1ce030);
  uRam0064e748 = (undefined4)uVar3;
  uVar4 = FUN_001ca1f0(8,0x509,0x1ce4c0,0x1ce510,0x1ce500);
  uRam0064e74c = (undefined4)uVar4;
  uVar5 = FUN_001ca220(8,0x509,0x1ce5f0,0x1ce660,0x1ce620);
  uRam0064e750 = (undefined4)uVar5;
  uVar6 = FUN_001cb5a0(8,0x509,0x1ce950,0x1ce9c0,0x1ce980);
  uRam0064e754 = (undefined4)uVar6;
  uVar7 = FUN_001cacd0(0,0x50e,0,0,0);
  uVar8 = FUN_001ccec0(0,0x50e,0,0,0);
  uVar9 = FUN_001cad00(0x50e,0x1cef50,0,0x1cefa0);
  uVar10 = FUN_001ccef0(0x50e,0,0,0x1cf010);
  uVar11 = FUN_001cacd0(0,0x510,0,0,0);
  uVar12 = FUN_001ccec0(0,0x510,0,0,0);
  uVar13 = FUN_001cad00(0x510,0x1cefb0,0,0x1ceff0);
  uVar14 = FUN_001ccef0(0x510,0,0,0x1cf000);
  uVar15 = FUN_001ca1f0(0,0x1f,0,0,0);
  uVar16 = FUN_001ca250(0x1f,0x1c9110,0,0x1c9190);
  uVar17 = FUN_001cdba0(0,0x1f,0,0,0);
  uVar18 = FUN_001cdbd0(0x1f,0,0,0x1c9050);
  uVar19 = FUN_001ccec0(0,0x1f,0,0,0);
  uVar20 = FUN_001ccef0(0x1f,0,0,0x1c9080);
  uVar21 = FUN_001cbda0(0,0x1f,0,0,0);
  uVar22 = FUN_001cbdd0(0x1f,0x1cb820,0,0x1cb8a0);
  if ((long)(uVar2 | uVar3 | uVar4 | uVar5 | uVar6 | uVar7 | uVar8 | uVar9 | uVar10 | uVar11 |
             uVar12 | uVar13 | uVar14 | uVar15 | uVar16 | uVar17 | uVar18 | uVar19 | uVar20 | uVar21
            | uVar22) < 0) {
    bVar1 = false;
  }
  else {
    lVar23 = FUN_001cfa00();
    bVar1 = lVar23 != 0;
  }
  return bVar1;
}

