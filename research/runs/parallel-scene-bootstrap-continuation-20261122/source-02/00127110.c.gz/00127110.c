
void FUN_00127110(undefined4 param_1)

{
  uRam0064defc = param_1;
  return;
}

