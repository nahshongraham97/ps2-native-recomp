
void FUN_00126000(long param_1)

{
  int iVar1;
  long lVar2;
  int iVar3;
  
  if (param_1 != 0) {
    iVar3 = (int)param_1;
    iVar1 = *(int *)(iVar3 + 4);
    if (iVar1 == 0) {
      iVar1 = *(int *)(iVar3 + 100);
    }
    else {
      FUN_001aa0b0(param_1,0);
      FUN_001a7240(iVar1);
      iVar1 = *(int *)(iVar3 + 100);
    }
    if (iVar1 == 0) {
      iVar1 = *(int *)(iVar3 + 0x60);
    }
    else {
      *(undefined4 *)(iVar3 + 100) = 0;
      FUN_001a85a0();
      iVar1 = *(int *)(iVar3 + 0x60);
    }
    if (iVar1 != 0) {
      *(undefined4 *)(iVar3 + 0x60) = 0;
    }
    lVar2 = FUN_001cf380(param_1);
    if (lVar2 != 0) {
      FUN_001cf350(lVar2,param_1);
    }
    FUN_001a6540(param_1);
  }
  return;
}

