
undefined8 FUN_001cf300(undefined8 param_1,int param_2)

{
  int iVar1;
  
  iVar1 = param_2 + iRam0064e748;
  if (*(int *)(param_2 + 4) != 0) {
    FUN_001a7510();
  }
  *(int *)(iVar1 + 0xc) = (int)param_1;
  return param_1;
}

