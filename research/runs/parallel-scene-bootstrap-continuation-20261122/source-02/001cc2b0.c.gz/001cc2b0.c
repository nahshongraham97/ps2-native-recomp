
undefined8 FUN_001cc2b0(undefined8 param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)param_1;
  puVar1[2] = 0;
  *puVar1 = 0;
  puVar1[1] = 0;
  return param_1;
}

