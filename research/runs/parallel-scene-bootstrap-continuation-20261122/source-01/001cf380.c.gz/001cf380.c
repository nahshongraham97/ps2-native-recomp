
undefined4 FUN_001cf380(int param_1)

{
  return *(undefined4 *)(param_1 + iRam0064e748 + 0xc);
}

