
undefined4 FUN_00127100(void)

{
  return uRam0064defc;
}

