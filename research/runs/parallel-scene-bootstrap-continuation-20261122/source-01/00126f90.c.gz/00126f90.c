
void FUN_00126f90(void)

{
  FUN_001ad520();
  FUN_001ad520();
  return;
}

