
void FUN_00125d60(void)

{
  DAT_0059b560 = 0;
  DAT_0059b564 = 0;
  uRam0064deb8 = 0;
  DAT_0059b568 = 0;
  DAT_0059b56c = 0;
  return;
}

