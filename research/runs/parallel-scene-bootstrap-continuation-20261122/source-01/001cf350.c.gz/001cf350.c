
undefined8 FUN_001cf350(undefined8 param_1,int param_2)

{
  param_2 = param_2 + iRam0064e748;
  if (*(int *)(param_2 + 0xc) == 0) {
    param_1 = 0;
  }
  else {
    *(undefined4 *)(param_2 + 0xc) = 0;
    *(undefined4 *)(param_2 + 8) = 0;
  }
  return param_1;
}

