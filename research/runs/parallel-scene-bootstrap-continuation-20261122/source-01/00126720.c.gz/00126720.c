
void FUN_00126720(void)

{
  uRam0064e0fc = 1;
  return;
}

