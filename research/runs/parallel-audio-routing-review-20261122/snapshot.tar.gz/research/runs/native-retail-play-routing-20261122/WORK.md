# Original direct/worker play admission

Start parent2c86de2626092cb1bb6c4d4c7313a4372bbbf9b1 and
fork915da5fd8dfdc108a3bb256fe2d142a331e74c32, main matching the published
checkpoints; fork tracked clean. The preceding turn made a source-derived
online-stage classification and connected compile correction. The protected
parent inventory retains SHA25626093151039b949348184f2e8a960b92d64e7f08408d43e58e1e0ed481a959f6.

Current dependency: every public native runtime request currently uses the
explicit queued fixture ingress. Original MSL EE8 first uses an existing
runtime, or E28's actual resource-readiness predicate to construct directly;
otherwise it queues real work through F850. Direct constructor failure also
queues a real retry, rather than invoking the ordinary ready consumer.

E28 checks only signed-byte kind1 commands and skips every other kind. For
each kind1, exact resource lookup must succeed and either the actual normal
resource cache pointer is present or source resource flags+20 bit0 is set.
An empty command list succeeds here; later constructor/consumer requirements
still apply. The earlier conversational claim that every command must be
kind1 was too strong; the original branch skips other kinds.

The existing saved MSL:LE:32 listing in the preceding admission record is
the actual decoder evidence. Join complete E28:EE8 and EE8:FC8 spans to the
original IRX PT_LOAD VMA0/file90, preserving branch/load delay slots and the
40-byte command step. These are IOP MIPS instructions, not R5900/EE words.
The EE12C030 caller separately proves actual f12 volume, semantic ID in a0,
and flags9 in t0; its full semantic parameter/envelope producers remain open.

Implementation decision: use actual native sample-cache owners for direct
construction, and acquire an actual semantic runtime reference atomically
when selecting the existing-runtime route. No pointer-presence simulation,
PS2 capacities, packet, compatibility token or guest module enters this path.
Retain selected samples until construction retires, so another native owner
cannot erase the resource between selection and construction. A fresh direct
constructor failure retires its actual work before queueing a fresh native
construction on the same public association. Consumer/copy failure is a
different completion and must never trigger that constructor retry.

Add automatic typed runtime/Main ingress while preserving explicit queued
primitives for their bounded existing clients. Reserve Main reference storage
before exposing playback; an actual Main admission guard must reject reentry
that could consume the reservation during direct native callbacks. Runtime
output failure must revoke direct publication just as queued publication.
Transient native consumer exclusion must fail by name without deadlocking a
reentrant cleanup. No guessed successful direct callback is permitted.

Status: source-derived decision; implementation and directly affected checks
pending. Production game parameters/envelopes, alternate sample classes,
remaining reset/mode/GPU integration and full native game acceptance OPEN.
No game/window/physical endpoint/frame/audio capture. Owner: no action.
Next: implement and verify real direct/queued construction and failure order.

Implemented/unbuilt: real direct sample/runtime selection, actual cached semantic-reference acquisition, same-association fresh constructor retry, automatic Runtime/Main admission, native reentry/shutdown exclusion and source-derived direct/cache/worker/failure checks. No source parameter/envelope policy inferred. User-delivered profile commit b986341 was separately rejected and locally reverted by5bc82da; it was never merged into main. Two user-requested6.1 Sol low agents now review that delivery and implement the verified1861B0 startup prefix in isolated worktrees; the user coordinates fonts/resources separately. Next compile/run the affected source.
