
void FUN_0023c700(undefined4 param_1)

{
  FUN_0023baf0(param_1);
  FUN_0037ad60(param_1);
  return;
}

