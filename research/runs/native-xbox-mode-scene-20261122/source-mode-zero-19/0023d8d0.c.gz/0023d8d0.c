
void FUN_0023d8d0(int param_1,int param_2)

{
  if (param_1 != -1) {
    if (*(int *)(&DAT_00568c18 + param_1 * 0x28) == 0) {
      FUN_0023d920(param_1);
    }
    *(int *)(&DAT_0056c1d8 + param_2 * 0x10) = param_1;
    (&DAT_0056c1dc)[param_2 * 0x10] = (&DAT_00568c20)[param_1 * 0x28];
  }
  return;
}

