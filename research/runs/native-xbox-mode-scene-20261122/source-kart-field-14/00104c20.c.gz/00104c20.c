
/* WARNING: Removing unreachable block (ram,0x00104cb9) */
/* WARNING: Removing unreachable block (ram,0x00104cbd) */

void FUN_00104c20(int param_1,int param_2,uint param_3)

{
  undefined *puVar1;
  int iVar2;
  undefined1 uVar3;
  uint uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  longlong lVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined4 *local_2c [4];
  uint local_1c;
  uint local_18;
  undefined *local_14 [4];
  
  iVar2 = DAT_005b8334;
  local_2c[0] = &DAT_00731448;
  local_2c[1] = &DAT_0072de48;
  local_2c[2] = &DAT_0072a848;
  local_2c[3] = &DAT_00727248;
  local_14[0] = &DAT_00731460;
  local_14[1] = &DAT_0072de60;
  local_14[2] = &DAT_0072a860;
  local_14[3] = &DAT_00727260;
  if ((0x2a < param_2) && (param_2 < 0x35)) {
    if ((0x2f < param_2) && (param_2 < 0x35)) {
      param_2 = param_2 + -5;
    }
    uVar6 = param_3 % *(uint *)(DAT_005b8334 + 0x30);
    uVar4 = (param_3 - uVar6) / *(uint *)(DAT_005b8334 + 0x30);
    uVar7 = uVar4 % *(uint *)(DAT_005b8334 + 0x30);
    uVar4 = (uVar4 - uVar7) / *(uint *)(DAT_005b8334 + 0x30);
    local_1c = uVar4 % 100;
    local_18 = (uVar4 - local_1c) / 100;
    if (((local_2c[param_1] != (undefined4 *)0x0) && (local_14[param_1] != (undefined *)0x0)) &&
       (*local_2c[param_1] == 1)) {
      uVar5 = __aullshr();
      uVar3 = __aullshr();
      lVar8 = __allmul(uVar5,0,uVar3,0);
      if (lVar8 != 0) {
        uVar9 = __allmul(uVar5,0,uVar3,0);
        if (((int)((ulonglong)uVar9 >> 0x20) == 0) &&
           ((uint)uVar9 <= param_3 * *(int *)(iVar2 + 0x30))) {
          return;
        }
      }
      uVar4 = local_1c << 0x10;
      uVar9 = __allshl();
      uVar10 = __allshl();
      puVar1 = local_14[param_1];
      *(uint *)(puVar1 + (param_2 + -0x2b) * 8 + 0x248) =
           (uint)uVar10 | (uint)uVar9 | uVar4 | uVar7 << 8 | uVar6;
      *(uint *)(puVar1 + (param_2 + -0x2b) * 8 + 0x24c) =
           (uint)((ulonglong)uVar10 >> 0x20) | (uint)((ulonglong)uVar9 >> 0x20);
    }
  }
  return;
}

