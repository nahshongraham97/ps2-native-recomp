
void FUN_00104ae0(undefined4 param_1)

{
  switch(param_1) {
  case 0:
    if (DAT_00731448 == 1) {
      DAT_007316a0 = DAT_007316a0 + 1;
    }
    break;
  case 1:
    if (DAT_0072de48 == 1) {
      DAT_0072e0a0 = DAT_0072e0a0 + 1;
    }
    break;
  case 2:
    if (DAT_0072a848 == 1) {
      DAT_0072aaa0 = DAT_0072aaa0 + 1;
    }
    break;
  case 3:
    if (DAT_00727248 == 1) {
      DAT_007274a0 = DAT_007274a0 + 1;
    }
  }
  return;
}

