
float10 FUN_0024fe50(void)

{
  uint *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  
  FUN_00231bf0(0xd);
  FUN_00258ff0(10);
  FUN_00258f20(0x17);
  FUN_001af010(DAT_007350c0);
  FUN_00097c30(0x6003e);
  FUN_000570a0();
  iVar2 = FUN_001c2680(0xc7c);
  if (iVar2 == 0) {
    FUN_0019ca30(0,FUN_00027be0);
  }
  FUN_001c2920(0xc7c,iVar2);
  FUN_001c7180(iVar2,DAT_007350c0 + 0xe);
  uVar3 = FUN_001b66c0(0x5d0);
  *(undefined4 *)(iVar2 + 100) = uVar3;
  if (*(int *)(iVar2 + 100) == 0) {
    FUN_0019ca30(0,FUN_00027be0);
  }
  uVar3 = FUN_001b66c0(0x574);
  *(undefined4 *)(iVar2 + 0x74) = uVar3;
  if (*(int *)(iVar2 + 0x74) == 0) {
    FUN_0019ca30(0,FUN_00027be0);
  }
  uVar3 = FUN_001b66c0(0x574);
  *(undefined4 *)(iVar2 + 0x78) = uVar3;
  if (*(int *)(iVar2 + 0x78) == 0) {
    FUN_0019ca30(0,FUN_00027be0);
  }
  uVar3 = FUN_001b66c0(0xc80);
  *(undefined4 *)(iVar2 + 0x68) = uVar3;
  if (*(int *)(iVar2 + 0x68) == 0) {
    FUN_0019ca30(0,FUN_00027be0);
  }
  *(undefined4 *)(iVar2 + 8) = (&DAT_00831aec)[DAT_005b895c * 0x12];
  if (*(int *)(iVar2 + 8) < 0) {
    *(undefined4 *)(iVar2 + 8) = 0;
  }
  FUN_000a0bc0(*(undefined4 *)(iVar2 + 8));
  FUN_0007b820(*(undefined4 *)(iVar2 + 8));
  FUN_001f8c00(&DAT_00831aec + DAT_005b895c * 0x12,2);
  *(undefined4 *)(iVar2 + 0x5c) = 7;
  FUN_00237050();
  puVar4 = (undefined4 *)FUN_00253420(0);
  puVar6 = *(undefined4 **)(iVar2 + 100);
  for (iVar5 = 0x174; iVar5 != 0; iVar5 = iVar5 + -1) {
    *puVar6 = *puVar4;
    puVar4 = puVar4 + 1;
    puVar6 = puVar6 + 1;
  }
  *(undefined4 *)(iVar2 + 0x60) = 0x6003d;
  FUN_0005b450(0,0x41900000);
  FUN_00232790(0x6003c);
  FUN_002503d0();
  FUN_001b20e0(PTR_PTR_0056149c);
  FUN_00232d10(0x6003c,"capui_shared_anims.sec",&DAT_00734a60,&DAT_00734ea0,0,0,1);
  FUN_00232d10(0x6003c,"f_ui_anims.sec",*(undefined4 *)(iVar2 + 0x74),*(int *)(iVar2 + 0x74) + 0x570
               ,0,0,1);
  FUN_00232d10(0x6003c,"m_ui_anims.sec",*(undefined4 *)(iVar2 + 0x78),*(int *)(iVar2 + 0x78) + 0x570
               ,0,0,1);
  FUN_00232920(0x6003c,"cap.sec",1);
  FUN_00232920(0x6003c,"cap_super_art.sec",1);
  FUN_001b0380(0x6003c,2,"cap_strings_eng.mko",1);
  uVar3 = FUN_001b05d0(0x6003c,PTR_s_cap_mko_005614a4,4,1);
  *(undefined4 *)(iVar2 + 0x7b4) = uVar3;
  uVar3 = FUN_001b05d0(0x6003c,"cap_parts.mko",0x16,1);
  *(undefined4 *)(iVar2 + 0x7b8) = uVar3;
  uVar3 = FUN_001b05d0(0x6003c,"cap_fx.mko",0x19,1);
  *(undefined4 *)(iVar2 + 0x7c4) = uVar3;
  uVar3 = FUN_001b05d0(0x6003c,"cap_movedata.mko",0x15,1);
  *(undefined4 *)(iVar2 + 2000) = uVar3;
  uVar3 = FUN_001b05d0(0x6003c,"cap_supers.mko",0x18,1);
  *(undefined4 *)(iVar2 + 0x7cc) = uVar3;
  uVar3 = FUN_001b05d0(0x6003c,"cap_hth_preview.mko",0x17,1);
  *(undefined4 *)(iVar2 + 0x7bc) = uVar3;
  uVar3 = FUN_001b05d0(0x6003c,"cap_wpn_preview.mko",0x17,1);
  *(undefined4 *)(iVar2 + 0x7c0) = uVar3;
  uVar3 = FUN_001b05d0(0x6003c,"cap_hth.mko",0x14,1);
  *(undefined4 *)(iVar2 + 0x7c8) = uVar3;
  FUN_00250660();
  FUN_001de2b0("common/create_a_player/cap_menu",0x6003c);
  FUN_001d64c0(6);
  FUN_00232b70(0x6003c);
  FUN_0024e680(0);
  FUN_00252310();
  FUN_002549d0(&DAT_00831aec,0x6003f);
  FUN_00245dd0(0);
  FUN_0023c8a0(8);
  FUN_0023c7c0();
  DAT_00831a40 = DAT_00831a40 | 0x40;
  while ((DAT_00831a40 & 1) != 0) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_001ddda0("common/create_a_player/cap_menu",0x6003c,0,0);
  FUN_0007bb90();
  FUN_001b20e0(PTR_PTR_0056149c);
  FUN_001f4de0(DAT_00831b1c,DAT_00831b20);
  FUN_001c26f0(0x900f,0x20,FUN_002503e0,0,0);
  puVar1 = *(uint **)(DAT_00831b1c + 0xcb4);
  if ((*puVar1 >> 3 & 1) == 0) {
    FUN_002563a0();
    *puVar1 = *puVar1 | 8;
  }
  FUN_001c26f0(0x9011,0x20,FUN_00250550,0,0);
  FUN_0023c150(0x3254f);
  FUN_000a0c30();
  FUN_000a0bc0(*(undefined4 *)(iVar2 + 8));
  FUN_0025a750(8,0);
  FUN_001de3a0();
  if ((*(int *)(iVar2 + 0x788) == 0) && (DAT_00731448 == 1)) {
    FUN_0025bde0(0,2);
  }
  FUN_00258f90();
  FUN_0019ca30(3,FUN_0019f3d0);
  return (float10)DAT_004d7b58;
}

