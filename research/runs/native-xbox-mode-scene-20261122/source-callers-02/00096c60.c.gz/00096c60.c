
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00096c60(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int local_10;
  
  if ((DAT_00831a44 >> 3 & 1) != 0) {
    DAT_00831a44 = DAT_00831a44 & 0xffffffef;
    FUN_0034a110();
    while ((DAT_00831a44 >> 4 & 1) == 0) {
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
  }
  FUN_000a0b60();
  _DAT_005b7d30 = FUN_0027c450();
  DAT_00831a40 = DAT_00831a40 & 0xfffffefd;
  DAT_00830928 = 0;
  DAT_005b7d44 = 0;
  if ((DAT_008292f8 == 9) && (DAT_0082bdd0 == 0)) {
    FUN_00231bf0(0xb);
  }
  else {
    FUN_00231bf0(0);
  }
  if ((DAT_00831a44 >> 2 & 1) == 0) {
    FUN_00258f20(6);
  }
  else {
    FUN_0025c530(FUN_000982a0,0x2070);
    FUN_00258f20(3);
  }
  FUN_000ae560();
  FUN_001f3b80();
  FUN_000982d0();
  if ((DAT_005bfa64 != 0) && (DAT_00831a54 == 0xc)) {
    DAT_0054cf24 = 0x3f19999a;
    DAT_0054cf28 = 0x3f666666;
  }
  FUN_00097c30(0x50011);
  FUN_000570a0();
  if ((DAT_00831a44 & 1) != 0) {
    FUN_0007bb90();
  }
  FUN_001b20e0(&PTR_PTR_004ea040);
  FUN_00232fa0(0x1000b,&PTR_s_fightingart_sec_0055893c,1);
  FUN_00093340(5);
  FUN_00093340(4);
  FUN_00093340(0);
  FUN_00093340(1);
  FUN_00093340(3);
  FUN_00093340(0x13);
  FUN_00093340(0x15);
  FUN_00093340(0x14);
  FUN_00093340(0x16);
  FUN_001af010(DAT_007350c0);
  DAT_00831ccc = 1;
  if ((DAT_00831a44 >> 3 & 1) == 0) {
    FUN_000ae780();
  }
  else {
    DAT_0054e9e8 = 0;
    FUN_000ae780();
    DAT_0054e9e8 = 1;
    FUN_000ae780();
    DAT_0054e9e8 = 5;
  }
  FUN_00028fd0(DAT_00831a54);
  FUN_000288a0();
  FUN_001f3a80();
  FUN_000540f0();
  iVar1 = FUN_00028990(DAT_00831a54);
  if (iVar1 == 0) {
    FUN_000570a0();
  }
  FUN_0023c8a0(2);
  FUN_0023c7c0();
  if ((DAT_00831a44 >> 3 & 1) == 0) {
    FUN_000add20(9);
  }
  DAT_00831a40 = DAT_00831a40 | 0x40;
  for (local_10 = 0x3c; ((DAT_00831a40 & 1) != 0 && (0 < local_10)); local_10 = local_10 + -1) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_0007f350();
  DAT_007350c4 = 0x40400000;
  (**(code **)(*DAT_007350c0 + 0x14))();
  FUN_0007f420();
  FUN_00057150();
  FUN_000983a0();
  if ((DAT_00831a44 >> 2 & 1) == 0) {
    uVar2 = FUN_0019ff60();
    uVar3 = FUN_001a0000();
    FUN_00232790(uVar2);
    FUN_001de2b0(uVar3,uVar2);
  }
  (**(code **)(*DAT_007350c0 + 0x20))(FUN_00096fc0,0);
  return (float10)_DAT_004d7c38;
}

