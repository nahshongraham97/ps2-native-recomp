
undefined4 FUN_0024bd30(int param_1,int param_2)

{
  char cVar1;
  bool bVar2;
  undefined4 uVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  uint *puVar11;
  uint *local_238;
  char *local_234;
  uint *local_228;
  char *local_224;
  uint *local_218;
  char *local_214;
  uint *local_208;
  char *local_204;
  uint *local_1f8;
  char *local_1f4;
  char *local_1e4;
  uint *local_1e0;
  char *local_1d4;
  uint *local_1d0;
  char *local_1c4;
  uint *local_1c0;
  char *local_1b4;
  uint *local_1b0;
  char *local_1a4;
  uint *local_1a0;
  uint local_168;
  undefined4 local_140;
  uint local_13c;
  uint local_12c;
  uint local_118;
  undefined4 local_f0;
  uint local_e4;
  uint local_e0;
  undefined4 local_cc;
  int local_bc;
  uint local_94;
  int local_90;
  int local_8c;
  int local_88;
  int local_84;
  int local_80;
  int local_7c;
  uint *local_78;
  uint local_74;
  undefined4 local_70;
  int local_6c;
  int local_68;
  int local_64;
  int local_60;
  undefined4 local_5c;
  undefined4 local_58;
  int local_54;
  int local_50;
  undefined4 local_4c;
  int local_38;
  int local_30;
  int local_2c;
  int *local_28;
  int local_24;
  int local_20;
  int local_1c;
  int local_18;
  uint *local_14;
  int local_10;
  uint *local_c;
  undefined4 local_8;
  
  local_c = (uint *)FUN_00242b60();
  local_14 = local_c + 1;
  local_20 = FUN_002421f0();
  local_10 = *(int *)(param_2 + 0x34);
  local_8 = 0;
  local_18 = *(int *)(param_2 + 0xc);
  if (local_10 == 0) {
    uVar3 = 0;
  }
  else if ((local_18 < 40000) || (47999 < local_18)) {
    uVar3 = 0;
  }
  else if (local_20 == 0) {
    uVar3 = 0;
  }
  else {
    switch(local_18) {
    case 40000:
      local_28 = (int *)FUN_001c4870(0x9004);
      if (local_28 != (int *)0x0) {
        if (((code *)local_28[0xc] == FUN_002494e0) &&
           (local_2c = FUN_001f9480(DAT_00831b1c), local_2c != 0)) {
          FUN_001c49a0(local_2c,FUN_001aad70);
        }
        if ((local_28 != (int *)0x0) && (local_28[1] != 0)) {
          (**(code **)(*local_28 + 0xc))(local_28);
        }
      }
      *(code **)(local_20 + 0x774) = FUN_002494e0;
      uVar3 = FUN_003394a0(0);
      *(undefined4 *)(local_20 + 0x24) = uVar3;
      FUN_001c27f0(0x9004,8,FUN_0024f1f0,0,0);
      uVar3 = 1;
      break;
    case 0x9c41:
      uVar3 = 1;
      break;
    case 0x9c42:
      local_30 = FUN_003394e0(0,&local_8);
      local_1c = local_30 + -0x9c55;
      iVar9 = FUN_003394a0(1);
      if (local_30 == 0x9c54) {
        uVar6 = local_14[0x7a];
        *(uint *)(local_20 + 0x14) = local_14[0x79];
        *(uint *)(local_20 + 0x18) = uVar6;
        uVar6 = local_14[0x7a];
        *(uint *)(local_20 + 0xc74) = local_14[0x79];
        *(uint *)(local_20 + 0xc78) = uVar6;
      }
      else {
        uVar6 = local_14[local_1c * 4 + iVar9 * 2 + 0x21];
        *(uint *)(local_20 + 0x14) = local_14[local_1c * 4 + iVar9 * 2 + 0x20];
        *(uint *)(local_20 + 0x18) = uVar6;
        uVar6 = local_14[local_1c * 4 + iVar9 * 2 + 0x21];
        *(uint *)(local_20 + 0xc74) = local_14[local_1c * 4 + iVar9 * 2 + 0x20];
        *(uint *)(local_20 + 0xc78) = uVar6;
      }
      *(int *)(local_20 + 0xc) = local_1c;
      *(int *)(local_20 + 0x10) = iVar9;
      uVar3 = 1;
      break;
    case 0x9c43:
      local_38 = FUN_003394a0(0);
      if (local_38 == 0) {
        if (*(int *)(local_20 + 0xc) < 0) {
          uVar6 = *(uint *)(local_20 + 0xc78);
          local_14[0x79] = *(uint *)(local_20 + 0xc74);
          local_14[0x7a] = uVar6;
          FUN_00243960(DAT_00831b1c,DAT_00831b20);
        }
        else {
          uVar6 = *(uint *)(local_20 + 0xc78);
          iVar9 = *(int *)(local_20 + 0xc);
          iVar7 = *(int *)(local_20 + 0x10);
          local_14[iVar9 * 4 + iVar7 * 2 + 0x20] = *(uint *)(local_20 + 0xc74);
          local_14[iVar9 * 4 + iVar7 * 2 + 0x21] = uVar6;
          FUN_002440e0(*(undefined4 *)(local_20 + 0xc));
          FUN_00243c50(DAT_00831b1c,DAT_00831b20);
        }
      }
      else if (*(int *)(local_20 + 0xc) < 0) {
        uVar6 = *(uint *)(local_20 + 0x18);
        local_14[0x79] = *(uint *)(local_20 + 0x14);
        local_14[0x7a] = uVar6;
      }
      else {
        uVar6 = *(uint *)(local_20 + 0x18);
        iVar9 = *(int *)(local_20 + 0xc);
        iVar7 = *(int *)(local_20 + 0x10);
        local_14[iVar9 * 4 + iVar7 * 2 + 0x20] = *(uint *)(local_20 + 0x14);
        local_14[iVar9 * 4 + iVar7 * 2 + 0x21] = uVar6;
        piVar4 = (int *)(*(int *)(local_20 + 0xc) * 0xc +
                        *(int *)(DAT_005bf198 + local_14[0x7d] * 4));
        uVar6 = local_14[*(int *)(local_20 + 0xc) * 2 + 1];
        if (*(int *)(local_20 + 0x10) == 0) {
          *(uint *)(*piVar4 + 0x18 + uVar6 * 0x3c) = (uint)*(ushort *)(local_20 + 0x14);
          *(uint *)(*piVar4 + 0x1c + uVar6 * 0x3c) = (uint)*(ushort *)(local_20 + 0x16);
        }
        else {
          *(uint *)(*piVar4 + 0x20 + uVar6 * 0x3c) = (uint)*(ushort *)(local_20 + 0x14);
          *(uint *)(*piVar4 + 0x24 + uVar6 * 0x3c) = (uint)*(ushort *)(local_20 + 0x16);
        }
      }
      uVar3 = 1;
      break;
    case 0x9c45:
      local_54 = FUN_003394e0(0,&local_8);
      local_54 = local_54 + -0x9c55;
      local_58 = FUN_003394e0(2,&local_8);
      local_50 = FUN_003394a0(1);
      if (local_54 < 0) {
        local_4c = FUN_00243b80(&DAT_00578fa0,(short)local_14[0x79],
                                *(undefined2 *)((int)local_14 + 0x1e6));
      }
      else {
        local_4c = FUN_00243b80(&DAT_005787a0,(short)local_14[local_54 * 4 + local_50 * 2 + 0x20],
                                *(undefined2 *)
                                 ((int)local_14 + local_50 * 8 + local_54 * 0x10 + 0x82));
      }
      FUN_0024e640(local_4c,local_58);
      uVar3 = 1;
      break;
    case 0x9c46:
      uVar3 = FUN_003394a0(0);
      FUN_0024e800(uVar3);
      uVar3 = 1;
      break;
    case 0x9c47:
      local_74 = (uint)*(ushort *)(local_20 + 0x2e);
      local_70 = 1;
      local_60 = 0;
      local_6c = FUN_00248bf0(*(undefined4 *)(local_20 + 0x7b4));
      if (*(int *)(local_20 + 0x5c) == 2) {
        local_70 = 1;
      }
      else if (*(int *)(local_20 + 0x5c) == 3) {
        local_60 = 1;
        local_70 = 2;
      }
      local_78 = local_c + local_60 * 0x1b + 0x80;
      if (-1 < *(int *)(local_20 + 0x1c)) {
        FUN_00255f20();
        local_78[*(int *)(local_20 + 0x1c)] = *(uint *)(local_20 + 0x2c);
        local_74 = local_74 - 1;
        local_68 = FUN_00232560(0x6003f,local_70);
        local_64 = FUN_00232560(0x60040,1);
        if (((local_64 != 0) && (local_68 != 0)) && (local_64 != 0)) {
          iVar9 = FUN_002428e0();
          if (iVar9 == 0) {
            local_7c = *(int *)(local_20 + 0x1c) + 0x17;
            if ((int)local_74 < 0) {
              FUN_00234010(local_68,local_7c);
            }
            else {
              FUN_002342c0(local_68,local_7c,local_64,local_74);
            }
            if (local_60 == 0) {
              *(int *)(local_6c + 4 + *(int *)(local_20 + 0x1c) * 8) = local_7c;
              *(undefined4 *)(local_6c + *(int *)(local_20 + 0x1c) * 8) =
                   *(undefined4 *)(local_20 + 0x1c);
            }
            else {
              *(int *)(local_6c + 0xa4 + *(int *)(local_20 + 0x1c) * 8) = local_7c;
              *(undefined4 *)(local_6c + 0xa0 + *(int *)(local_20 + 0x1c) * 8) =
                   *(undefined4 *)(local_20 + 0x1c);
            }
          }
          else {
            FUN_002546b0(DAT_00831b1c,local_68,*(undefined4 *)(local_20 + 0x68),0x60040,local_60);
          }
          FUN_0024f050(*(undefined4 *)(local_20 + 0x1c));
          FUN_001de7e0();
          FUN_002568b0(0);
        }
        return 1;
      }
    default:
      uVar3 = 0;
      break;
    case 0x9c48:
      local_80 = FUN_003394a0(0);
      if (*(int *)(local_20 + 0x778) != local_80) {
        if (*(int *)(local_20 + 0x778) == 1) {
          FUN_00255cc0();
        }
        else if ((local_80 == 1) && (iVar9 = FUN_001c4870(0x9004), iVar9 == 0)) {
          FUN_00255b10();
        }
        *(int *)(local_20 + 0x778) = local_80;
        iVar9 = FUN_001c4870(0x10000);
        if (iVar9 == 0) {
          FUN_00249120(0x2d);
        }
        else {
          FUN_00249120(0);
        }
      }
      uVar3 = 1;
      break;
    case 0x9c49:
      local_84 = FUN_003394a0(0);
      local_88 = *(int *)(local_20 + 0x5c);
      if ((local_84 != *(int *)(local_20 + 0x5c)) && (*(int *)(local_20 + 0x5c) != 7)) {
        FUN_001c4730(0x10000);
        FUN_001c26f0(0x10000,0x34,FUN_0024e610,0,0);
      }
      FUN_002568b0(0);
      local_8c = 0;
      while (iVar9 = FUN_001c4870(0x9004), iVar9 != 0) {
        local_8c = 1;
        FUN_00249480();
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
      }
      if ((local_8c == 0) && ((*(int *)(param_1 + 0x1ac) == 0 || (local_88 == 6)))) {
        FUN_00243890(0xffffffff);
      }
      *(int *)(local_20 + 0x5c) = local_84;
      while (iVar9 = FUN_001c4870(0x9013), iVar9 != 0) {
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
      }
      switch(local_84) {
      case 0:
        FUN_001c4730(0x902f);
        FUN_001c4730(0x9007);
        *(undefined4 *)(local_20 + 0x88) = 0;
        *(undefined4 *)(local_20 + 0x54) = 5;
        *(undefined4 *)(local_20 + 0x58) = 5;
        *(undefined4 *)(local_20 + 0x1c) = 0;
        *(undefined4 *)(local_20 + 0x2c) = 0;
        *(undefined4 *)(local_20 + 0x778) = 0;
        FUN_00247460(1);
        *(uint *)(DAT_00831b20 + 0xc) = *(uint *)(DAT_00831b20 + 0xc) & 0xdfffffff;
        FUN_0025f070(DAT_00831b1c,1,*(undefined4 *)(DAT_00831b1c + 0x450));
        FUN_00255cc0();
        FUN_001c4730(0x9003);
        FUN_00232790(0x60040);
        if (local_88 != 0) {
          FUN_00242650();
        }
        FUN_00249120(0);
        if ((0 < local_88) && ((local_88 < 4 || (local_88 == 6)))) {
          FUN_0023c150(0x32551);
          FUN_0023c150(0x3254f);
        }
        break;
      case 1:
        FUN_001c4730(0x902f);
        FUN_001c26f0(0x902f,0x20,FUN_0024fd50,0,0);
        FUN_001c4730(0x9010);
        FUN_001c26f0(0x9010,0x20,FUN_0024f520,0,0);
        *(undefined4 *)(DAT_00831b20 + 0xe8) = 0;
        *(undefined4 *)(DAT_00831b20 + 0xe4) = 0;
        *(undefined4 *)(DAT_00831b20 + 0xe0) = 0;
        FUN_0023c150(0x32550);
        break;
      case 2:
        *(undefined4 *)(local_20 + 0x88) = 1;
        FUN_001c4730(0x9004);
        FUN_0024e800(6);
        FUN_00247460(1);
        FUN_00249120(0);
        FUN_0024e780(0);
        *(undefined4 *)(DAT_00831b64 + 0x44c) = *(undefined4 *)(DAT_00831b1c + 0x440);
        *(undefined4 *)(DAT_00831b1c + 0x44c) = *(undefined4 *)(DAT_00831b64 + 0x44c);
        *(undefined4 *)(DAT_00831b64 + 0x448) = 0;
        *(undefined4 *)(DAT_00831b1c + 0x448) = 0;
        FUN_0023c150(0x32550);
        FUN_0023c7c0();
        break;
      case 3:
        *(undefined4 *)(local_20 + 0x88) = 1;
        *(undefined4 *)(DAT_00831b64 + 0x44c) = *(undefined4 *)(DAT_00831b1c + 0x444);
        *(undefined4 *)(DAT_00831b1c + 0x44c) = *(undefined4 *)(DAT_00831b64 + 0x44c);
        *(undefined4 *)(DAT_00831b64 + 0x448) = 1;
        *(undefined4 *)(DAT_00831b1c + 0x448) = 1;
        FUN_001c4730(0x9004);
        FUN_0024e800(6);
        FUN_00247460(1);
        FUN_00249120(0);
        FUN_0024e780(0);
        FUN_0024e860();
        FUN_0023c150(0x32550);
        FUN_0023c7c0();
        break;
      case 4:
      case 5:
        FUN_001c4730(0x9004);
        FUN_00247460(1);
        FUN_00249120(0);
        break;
      case 6:
        *(undefined4 *)(local_20 + 0x88) = 1;
        FUN_0024e800(7);
        FUN_00247460(1);
        FUN_00249120(0);
        FUN_0023c150(0x32550);
      }
      FUN_00242650();
      FUN_00242960();
      uVar3 = 1;
      break;
    case 0x9c4a:
      puVar5 = (uint *)FUN_001f9dc0(0,&local_94);
      if (local_94 < 0x5d0) {
        uVar3 = 1;
      }
      else if (*(int *)(local_20 + 0x788) == 0) {
        *(undefined4 *)(local_20 + 0x788) = 1;
        FUN_00252c80(local_c);
        *local_c = *local_c | 1;
        local_90 = param_2;
        *(undefined4 *)(param_2 + 0x10) = 1;
        *(undefined4 *)(param_2 + 0x18) = 1;
        FUN_001c4730(0x9013);
        FUN_001c4730(0x9003);
        FUN_001c4730(0x9004);
        FUN_001c4730(0x9014);
        FUN_001c4730(0x10000);
        FUN_001c4730(0x9010);
        FUN_001c4730(0x9011);
        iVar9 = FUN_001f9410(DAT_00831b1c);
        if ((iVar9 != 0) && (*(int *)(iVar9 + 0x34) != **(int **)(local_20 + 0x7c))) {
          FUN_001a4440(iVar9,**(undefined4 **)(local_20 + 0x7c),0);
        }
        iVar9 = FUN_001f9480(DAT_00831b1c);
        if (iVar9 != 0) {
          FUN_001c49a0(iVar9,FUN_001aad70);
        }
        iVar9 = FUN_001c4870(0x1001);
        if (iVar9 != 0) {
          FUN_001c49a0(iVar9,FUN_001c4170);
        }
        while (iVar9 = FUN_001c4870(0x10000), iVar9 != 0) {
          DAT_007350c4 = 0x3f800000;
          (**(code **)(*DAT_007350c0 + 0x14))();
        }
        iVar9 = FUN_001f9f90(0,0);
        if (iVar9 == 0) {
          *local_c = *local_c & 0xfffffffb;
        }
        else {
          FUN_00258090(local_c,iVar9,local_94);
        }
        puVar11 = local_c;
        for (iVar9 = 0x174; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar5 = *puVar11;
          puVar11 = puVar11 + 1;
          puVar5 = puVar5 + 1;
        }
        FUN_001c27f0(0x902a,0x20,FUN_0024f4c0,0,0);
        uVar3 = 1;
      }
      else {
        uVar3 = 1;
      }
      break;
    case 0x9c4b:
      uVar3 = FUN_003394a0(0);
      FUN_0024e680(uVar3);
      uVar3 = 1;
      break;
    case 0x9c4c:
      FUN_0024e780(1);
      uVar3 = 1;
      break;
    case 0x9c4d:
      iVar9 = FUN_003394a0(0);
      if (iVar9 == 0) {
        local_c[0xb6] = *(uint *)(local_20 + 0x7a4);
        local_c[0xb7] = *(uint *)(local_20 + 0x7a8);
        local_c[0xb4] = *(uint *)(local_20 + 0x7b0);
        FUN_00243890(0xffffffff);
        FUN_00248d90();
      }
      else if (local_c[0xb6] != *(uint *)(local_20 + 0x7a4)) {
        for (local_bc = 0; local_bc < 0x14; local_bc = local_bc + 1) {
          *(undefined1 *)(local_c + local_bc + 0x9b) = 0;
          *(undefined2 *)((int)local_c + local_bc * 4 + 0x26e) = 0;
        }
      }
      FUN_0024e780(1);
      FUN_001de7e0();
      uVar3 = 1;
      break;
    case 0x9c4e:
      FUN_001c4730(0x10000);
      FUN_001c26f0(0x10000,0x34,FUN_0024e610,0,0);
      uVar3 = 1;
      break;
    case 0x9c4f:
      bVar2 = false;
      if (*(int *)(local_20 + 0x5c) == 3) {
        bVar2 = local_c[0xb5] != *(uint *)(local_20 + 0x7ac) ||
                local_c[0xb6] != *(uint *)(local_20 + 0x7a4);
      }
      else if (local_c[0x9a] != *(uint *)(local_20 + 0x7ac)) {
        bVar2 = true;
      }
      if ((bVar2) && (*(int *)(param_2 + 0x30) != 0)) {
        FUN_0033afc0(param_2,0);
      }
      uVar3 = 1;
      break;
    case 0x9c50:
      local_5c = *(undefined4 *)(param_2 + 0x30);
      iVar9 = FUN_00255f20();
      if (iVar9 == 0) {
        FUN_0033afc0(param_2,0);
        uVar3 = 1;
      }
      else {
        uVar3 = 1;
      }
      break;
    case 0x9c51:
      iVar9 = FUN_003394e0(0,&local_8);
      FUN_002568b0(1);
      *(int *)(local_20 + 0x20) = iVar9 + -0x9cf9;
      FUN_00242650();
      FUN_00242960();
      FUN_00243890(1000);
      FUN_00247460(1);
      uVar3 = 1;
      break;
    case 0x9c52:
      iVar9 = FUN_003394a0(0);
      if (iVar9 != 0) {
        FUN_00248ce0();
      }
      FUN_00243890(0xffffffff);
      uVar3 = 1;
      break;
    case 0x9c53:
      switch(*(undefined4 *)(local_20 + 0x7e8)) {
      case 0x9c41:
      case 0x9c42:
      case 0x9c43:
      case 0x9c44:
      case 0x9c45:
      case 0x9c46:
      case 0x9c47:
      case 0x9c48:
      case 0x9c49:
      case 0x9c4a:
      case 0x9c4b:
      case 0x9c4c:
      case 0x9c4d:
        local_1c = *(int *)(local_20 + 0x7e8) + -0x9c41;
        local_14[local_1c * 2 + 1] = *(uint *)(local_20 + 0x9ec);
        local_14[local_1c * 2] = *(uint *)(local_20 + 0x9f0);
        FUN_00246ae0(local_c,local_1c);
        FUN_0033d050(0x92888,1,0);
        FUN_00246210(local_c);
        FUN_00243890(0xffffffff);
        break;
      case 0x9c50:
      case 0x9c51:
        local_14[0x7c] = *(uint *)(local_20 + 0x9ec);
        local_14[0x7d] = *(uint *)(local_20 + 0x9f0);
        local_c[0xb9] = *(uint *)(local_20 + 0x9f4);
        puVar5 = (uint *)(local_20 + 0x9f8);
        puVar11 = local_14;
        for (iVar9 = 0x7f; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar11 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar11 = puVar11 + 1;
        }
        DAT_005bebc0 = 1;
        FUN_00245dd0(0);
        *(undefined4 *)(local_20 + 0x784) = 1;
        FUN_00246210(local_c);
        FUN_00243890(0xffffffff);
        FUN_001df1c0(0x92888,0);
        break;
      case 0x9c52:
        local_14[0x7e] = *(uint *)(local_20 + 0x9ec);
        FUN_00243890(0xffffffff);
        FUN_001de7e0();
        break;
      case 0x9c9a:
        local_224 = (char *)(local_20 + 0xc60);
        local_228 = local_c + 0x16f;
        do {
          cVar1 = *local_224;
          *(char *)local_228 = cVar1;
          local_224 = local_224 + 1;
          local_228 = (uint *)((int)local_228 + 1);
        } while (cVar1 != '\0');
        break;
      case 0x9c9c:
      case 0x9d10:
        local_214 = (char *)(local_20 + 0xc60);
        local_218 = local_c + 0xba;
        do {
          cVar1 = *local_214;
          *(char *)local_218 = cVar1;
          local_214 = local_214 + 1;
          local_218 = (uint *)((int)local_218 + 1);
        } while (cVar1 != '\0');
        break;
      case 0x9c9d:
        local_234 = (char *)(local_20 + 0x7ec);
        local_238 = local_c + 0xef;
        do {
          cVar1 = *local_234;
          *(char *)local_238 = cVar1;
          local_234 = local_234 + 1;
          local_238 = (uint *)((int)local_238 + 1);
        } while (cVar1 != '\0');
        break;
      case 0x9cf9:
      case 0x9cfa:
      case 0x9cfb:
      case 0x9cfc:
      case 0x9cfd:
      case 0x9cfe:
        local_1c = *(int *)(local_20 + 0x7e8) + -0x9cf9;
        local_c[local_1c * 8 + 0xbf] = *(uint *)(local_20 + 0x9ec);
        local_c[local_1c * 8 + 0xc0] = *(uint *)(local_20 + 0x9f0);
        FUN_002568b0(1);
        FUN_00248ce0();
        FUN_00243890(0xffffffff);
        break;
      case 0x9d0c:
        local_1f4 = (char *)(local_20 + 0xc60);
        local_1f8 = local_c + 0x94;
        do {
          cVar1 = *local_1f4;
          *(char *)local_1f8 = cVar1;
          local_1f4 = local_1f4 + 1;
          local_1f8 = (uint *)((int)local_1f8 + 1);
        } while (cVar1 != '\0');
        break;
      case 0x9d0d:
        local_c[0xb7] = *(uint *)(local_20 + 0x9ec);
        *(undefined4 *)(local_20 + 0x7a8) = *(undefined4 *)(local_20 + 0x9ec);
        FUN_00243890(0xffffffff);
        break;
      case 0x9d0e:
        local_c[0xb9] = *(uint *)(local_20 + 0x9ec);
        FUN_00245dd0(1);
        FUN_0023c8a0(8);
        break;
      case 0x9d0f:
        local_c[0xb8] = *(uint *)(local_20 + 0x9ec);
        FUN_00247460(1);
        break;
      case 0x9d14:
        local_204 = (char *)(local_20 + 0xc60);
        local_208 = local_c + 0xaf;
        do {
          cVar1 = *local_204;
          *(char *)local_208 = cVar1;
          local_204 = local_204 + 1;
          local_208 = (uint *)((int)local_208 + 1);
        } while (cVar1 != '\0');
        break;
      case 0x9d15:
        local_c[0x99] = *(uint *)(local_20 + 0x9ec);
        FUN_00248d90();
        break;
      case 0x9d16:
        local_c[0xb4] = *(uint *)(local_20 + 0x9ec);
        FUN_00248d90();
        break;
      case 0x9d1b:
        local_c[0x9a] = *(uint *)(local_20 + 0x9ec);
        puVar5 = (uint *)(local_20 + 0xbf4);
        puVar11 = local_c + 0x80;
        for (iVar9 = 0x1b; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar11 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar11 = puVar11 + 1;
        }
        FUN_00248000();
        FUN_0024e780(0);
        FUN_001de7e0();
        break;
      case 0x9d1c:
        local_c[0xb5] = *(uint *)(local_20 + 0x9ec);
        puVar5 = (uint *)(local_20 + 0xbf4);
        puVar11 = local_c + 0x9b;
        for (iVar9 = 0x1b; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar11 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar11 = puVar11 + 1;
        }
        FUN_00243890(0x3e6);
        FUN_0024e780(1);
        FUN_001de7e0();
      }
      *(undefined4 *)(local_20 + 0x7e8) = 0xffffffff;
      *(undefined4 *)(local_20 + 0x9ec) = 0xffffffff;
      *(undefined4 *)(local_20 + 0x9f0) = 0xffffffff;
      *(undefined1 *)(local_20 + 0xc60) = 0;
      uVar3 = 1;
      break;
    case 0x9c54:
      local_24 = FUN_003394e0(0,&local_8);
      *(int *)(local_20 + 0x7e8) = local_24;
      switch(local_24) {
      case 0x9c41:
      case 0x9c42:
      case 0x9c43:
      case 0x9c44:
      case 0x9c45:
      case 0x9c46:
      case 0x9c47:
      case 0x9c48:
      case 0x9c49:
      case 0x9c4a:
      case 0x9c4b:
      case 0x9c4c:
      case 0x9c4d:
        *(uint *)(local_20 + 0x9ec) = local_14[(local_24 + -0x9c41) * 2 + 1];
        *(uint *)(local_20 + 0x9f0) = local_14[(local_24 + -0x9c41) * 2];
        break;
      default:
        break;
      case 0x9c50:
      case 0x9c51:
        puVar5 = local_14;
        puVar11 = (uint *)(local_20 + 0x9f8);
        for (iVar9 = 0x7f; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar11 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar11 = puVar11 + 1;
        }
        *(uint *)(local_20 + 0x9ec) = local_14[0x7c];
        *(uint *)(local_20 + 0x9f0) = local_14[0x7d];
        *(uint *)(local_20 + 0x9f4) = local_c[0xb9];
        break;
      case 0x9c52:
        *(uint *)(local_20 + 0x9ec) = local_14[0x7e];
        break;
      case 0x9c9a:
        local_1d0 = local_c + 0x16f;
        local_1d4 = (char *)(local_20 + 0xc60);
        do {
          uVar6 = *local_1d0;
          *local_1d4 = (char)uVar6;
          local_1d0 = (uint *)((int)local_1d0 + 1);
          local_1d4 = local_1d4 + 1;
        } while ((char)uVar6 != '\0');
        break;
      case 0x9c9c:
      case 0x9d10:
        local_1c0 = local_c + 0xba;
        local_1c4 = (char *)(local_20 + 0xc60);
        do {
          uVar6 = *local_1c0;
          *local_1c4 = (char)uVar6;
          local_1c0 = (uint *)((int)local_1c0 + 1);
          local_1c4 = local_1c4 + 1;
        } while ((char)uVar6 != '\0');
        break;
      case 0x9c9d:
        local_1e0 = local_c + 0xef;
        local_1e4 = (char *)(local_20 + 0x7ec);
        do {
          uVar6 = *local_1e0;
          *local_1e4 = (char)uVar6;
          local_1e0 = (uint *)((int)local_1e0 + 1);
          local_1e4 = local_1e4 + 1;
        } while ((char)uVar6 != '\0');
        break;
      case 0x9cf9:
      case 0x9cfa:
      case 0x9cfb:
      case 0x9cfc:
      case 0x9cfd:
      case 0x9cfe:
        FUN_00243890(1000);
        *(uint *)(local_20 + 0x9ec) = local_c[(local_24 + -0x9cf9) * 8 + 0xbf];
        *(uint *)(local_20 + 0x9f0) = local_c[(local_24 + -0x9cf9) * 8 + 0xc0];
        break;
      case 0x9d0c:
        local_1a0 = local_c + 0x94;
        local_1a4 = (char *)(local_20 + 0xc60);
        do {
          uVar6 = *local_1a0;
          *local_1a4 = (char)uVar6;
          local_1a0 = (uint *)((int)local_1a0 + 1);
          local_1a4 = local_1a4 + 1;
        } while ((char)uVar6 != '\0');
        break;
      case 0x9d0d:
        *(uint *)(local_20 + 0x9ec) = local_c[0xb7];
        break;
      case 0x9d0e:
        *(uint *)(local_20 + 0x9ec) = local_c[0xb9];
        break;
      case 0x9d0f:
        *(uint *)(local_20 + 0x9ec) = local_c[0xb8];
        break;
      case 0x9d14:
        local_1b0 = local_c + 0xaf;
        local_1b4 = (char *)(local_20 + 0xc60);
        do {
          uVar6 = *local_1b0;
          *local_1b4 = (char)uVar6;
          local_1b0 = (uint *)((int)local_1b0 + 1);
          local_1b4 = local_1b4 + 1;
        } while ((char)uVar6 != '\0');
        break;
      case 0x9d15:
        *(uint *)(local_20 + 0x9ec) = local_c[0x99];
        break;
      case 0x9d16:
        *(uint *)(local_20 + 0x9ec) = local_c[0xb4];
        break;
      case 0x9d1b:
        *(uint *)(local_20 + 0x9ec) = local_c[0x9a];
        puVar5 = local_c + 0x80;
        puVar11 = (uint *)(local_20 + 0xbf4);
        for (iVar9 = 0x1b; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar11 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar11 = puVar11 + 1;
        }
        FUN_0024e780(0);
        break;
      case 0x9d1c:
        *(uint *)(local_20 + 0x9ec) = local_c[0xb5];
        puVar5 = local_c + 0x9b;
        puVar11 = (uint *)(local_20 + 0xbf4);
        for (iVar9 = 0x1b; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar11 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar11 = puVar11 + 1;
        }
        FUN_0024e780(1);
      }
      uVar3 = 1;
      break;
    case 0x9c55:
      if ((*(uint *)(local_20 + 0x9f0) != local_14[0x7d]) ||
         (*(uint *)(local_20 + 0x9ec) != local_14[0x7c])) {
        FUN_0033afc0(param_2,0);
      }
      uVar3 = 1;
      break;
    case 0x9c56:
      uVar3 = FUN_003394e0(0,&local_8);
      *(undefined4 *)(local_20 + 0x7dc) = uVar3;
      local_cc = 0;
      switch(*(undefined4 *)(local_20 + 0x7dc)) {
      case 0x9c41:
      case 0x9c42:
      case 0x9c43:
      case 0x9c44:
      case 0x9c45:
      case 0x9c46:
      case 0x9c47:
      case 0x9c48:
      case 0x9c49:
      case 0x9c4a:
      case 0x9c4b:
      case 0x9c4c:
      case 0x9c4d:
        local_1c = *(int *)(local_20 + 0x7dc) + -0x9c41;
        piVar4 = (int *)(local_1c * 0xc + *(int *)(DAT_005bf198 + local_14[0x7d] * 4));
        if (*piVar4 != 0) {
          iVar7 = local_c[local_1c * 2 + 1] * 0x3c + *piVar4;
          iVar9 = FUN_0024b7e0(*(int *)(iVar7 + 4) + -0xd6);
          if (iVar9 != 0) {
            local_e0 = *(uint *)(iVar7 + 0x14);
            if (0xc < local_e0) {
              local_e0 = 1;
            }
            if (local_e0 == 0xc) {
              local_cc = 2;
            }
            else {
              uVar6 = FUN_0024e5e0((&PTR_s_<COLOR_0x00000000>0_005797a0)[local_e0]);
              if (DAT_007314a0 < uVar6) {
                local_cc = 2;
              }
              else {
                local_cc = 1;
              }
            }
          }
        }
        break;
      case 0x9cf9:
      case 0x9cfa:
      case 0x9cfb:
      case 0x9cfc:
      case 0x9cfd:
      case 0x9cfe:
        uVar6 = local_c[*(int *)(local_20 + 0x20) * 8 + 0xbf];
        iVar9 = DAT_005bf19c[7];
        iVar7 = FUN_0024b870(uVar6 + 0x44c);
        if (iVar7 != 0) {
          local_118 = *(uint *)(uVar6 * 0x28 + iVar9 + 4);
          if (0xc < local_118) {
            local_118 = 1;
          }
          uVar6 = FUN_0024e5e0((&PTR_s_<COLOR_0x00000000>0_005797a0)[local_118]);
          if (DAT_007314a0 < uVar6) {
            local_cc = 2;
          }
          else {
            local_cc = 1;
          }
        }
        break;
      case 0x9d0a:
        if (*(byte *)(local_20 + 0x2c) == 0) {
          iVar9 = *(int *)((uint)*(ushort *)(local_20 + 0x2e) * 0x30 + DAT_005bf19c[6]) * 0x34 +
                  DAT_005bf19c[5];
          local_f0 = *(undefined4 *)(iVar9 + 0x28);
          local_e4 = *(uint *)(iVar9 + 0x2c);
        }
        else {
          iVar9 = (uint)*(ushort *)(local_20 + 0x2e) * 0x24 +
                  *(int *)(*DAT_005bf19c + 0x14 + (uint)*(byte *)(local_20 + 0x2c) * 0x18);
          local_f0 = *(undefined4 *)(iVar9 + 0x18);
          local_e4 = *(uint *)(iVar9 + 0x1c);
        }
        if (0xc < local_e4) {
          local_e4 = 1;
        }
        uVar6 = FUN_0024e5e0((&PTR_s_<COLOR_0x00000000>0_005797a0)[local_e4]);
        iVar9 = FUN_0024b870(local_f0);
        if (iVar9 != 0) {
          if (DAT_007314a0 < uVar6) {
            local_cc = 2;
          }
          else {
            local_cc = 1;
          }
        }
      }
      *(undefined4 *)(local_20 + 0x7d8) = local_cc;
      uVar3 = 1;
      break;
    case 0x9c57:
      if (*(int *)(local_20 + 0x7dc) == 0) {
        uVar3 = 1;
      }
      else if (*(int *)(local_20 + 0x7d8) == 1) {
        switch(*(undefined4 *)(local_20 + 0x7dc)) {
        case 0x9c41:
        case 0x9c42:
        case 0x9c43:
        case 0x9c44:
        case 0x9c45:
        case 0x9c46:
        case 0x9c47:
        case 0x9c48:
        case 0x9c49:
        case 0x9c4a:
        case 0x9c4b:
        case 0x9c4c:
        case 0x9c4d:
          local_1c = *(int *)(local_20 + 0x7dc) + -0x9c41;
          piVar4 = (int *)(local_1c * 0xc + *(int *)(DAT_005bf198 + local_14[0x7d] * 4));
          if (*piVar4 != 0) {
            iVar9 = local_c[local_1c * 2 + 1] * 0x3c + *piVar4;
            FUN_00241d80(0,*(int *)(iVar9 + 4) + -0xd6,0);
            local_12c = *(uint *)(iVar9 + 0x14);
            if (0xc < local_12c) {
              local_12c = 1;
            }
            iVar9 = FUN_0024e5e0((&PTR_s_<COLOR_0x00000000>0_005797a0)[local_12c]);
            DAT_007314a0 = DAT_007314a0 - iVar9;
            DAT_007314a8 = DAT_007314a8 + iVar9;
            FUN_001de7e0();
          }
          break;
        case 0x9cf9:
        case 0x9cfa:
        case 0x9cfb:
        case 0x9cfc:
        case 0x9cfd:
        case 0x9cfe:
          uVar6 = local_c[*(int *)(local_20 + 0x20) * 8 + 0xbf];
          iVar9 = DAT_005bf19c[7];
          iVar10 = uVar6 + 0x44c;
          iVar7 = FUN_0024b870(iVar10);
          if (iVar7 != 0) {
            FUN_0024e570(0,iVar10,0);
            local_168 = *(uint *)(uVar6 * 0x28 + iVar9 + 4);
            if (0xc < local_168) {
              local_168 = 1;
            }
            iVar9 = FUN_0024e5e0((&PTR_s_<COLOR_0x00000000>0_005797a0)[local_168]);
            DAT_007314a0 = DAT_007314a0 - iVar9;
            DAT_007314a8 = DAT_007314a8 + iVar9;
          }
          break;
        case 0x9d0a:
          if (*(byte *)(local_20 + 0x2c) == 0) {
            iVar9 = *(int *)((uint)*(ushort *)(local_20 + 0x2e) * 0x30 + DAT_005bf19c[6]) * 0x34 +
                    DAT_005bf19c[5];
            local_140 = *(undefined4 *)(iVar9 + 0x28);
            local_13c = *(uint *)(iVar9 + 0x2c);
          }
          else {
            iVar9 = (uint)*(ushort *)(local_20 + 0x2e) * 0x24 +
                    *(int *)(*DAT_005bf19c + 0x14 + (uint)*(byte *)(local_20 + 0x2c) * 0x18);
            local_140 = *(undefined4 *)(iVar9 + 0x18);
            local_13c = *(uint *)(iVar9 + 0x1c);
          }
          FUN_0024e570(0,local_140,0);
          if (0xc < local_13c) {
            local_13c = 1;
          }
          iVar9 = FUN_0024e5e0((&PTR_s_<COLOR_0x00000000>0_005797a0)[local_13c]);
          DAT_007314a0 = DAT_007314a0 - iVar9;
          DAT_007314a8 = DAT_007314a8 + iVar9;
        }
        uVar3 = 1;
      }
      else {
        uVar3 = 1;
      }
      break;
    case 0x9c58:
      *(undefined4 *)(param_2 + 0x18) = 1;
      *(undefined4 *)(param_2 + 0x14) = 1;
      *(undefined4 *)(param_2 + 0x1c) = 1;
      *(undefined4 *)(param_2 + 0x10) = 1;
      FUN_001c4730(0x902f);
      FUN_001c4730(0x9007);
      FUN_001c4730(0x9010);
      iVar9 = FUN_001c4870(0x9004);
      if (iVar9 == 0) {
        iVar9 = FUN_001c4870(0x9003);
        if (iVar9 == 0) {
          iVar9 = FUN_001c4870(0x9013);
          if (iVar9 == 0) {
            *(undefined4 *)(param_2 + 0x10) = 0;
            uVar3 = 1;
          }
          else {
            uVar3 = 1;
          }
        }
        else {
          uVar3 = 1;
        }
      }
      else {
        FUN_00249480();
        uVar3 = 1;
      }
      break;
    case 0x9c59:
      uVar3 = *(undefined4 *)(*(int *)(param_2 + 0x30) + 0x1c);
      uVar8 = FUN_003394a0(0);
      iVar9 = FUN_0033d4a0(uVar8);
      if (((iVar9 == 0) || (iVar9 = FUN_0033bb00(), iVar9 != 1)) ||
         (iVar9 = FUN_0033c1d0(uVar3), iVar9 == -1)) {
        *(undefined4 *)(param_2 + 0x10) = 0;
        *(undefined4 *)(param_2 + 0x14) = 0;
        *(undefined4 *)(param_2 + 0x1c) = 0;
        *(undefined4 *)(param_2 + 0x18) = 0;
        FUN_0033afc0(param_2,0);
      }
      else {
        *(undefined4 *)(param_2 + 0x10) = 1;
        *(undefined4 *)(param_2 + 0x14) = 1;
        *(undefined4 *)(param_2 + 0x1c) = 1;
        *(undefined4 *)(param_2 + 0x18) = 1;
      }
      uVar3 = 1;
    }
  }
  return uVar3;
}

