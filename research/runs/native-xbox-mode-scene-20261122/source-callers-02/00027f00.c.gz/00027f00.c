
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00027f00(void)

{
  FUN_00231bf0(3);
  DAT_00831b18 = 0x40;
  DAT_00831b60 = 0x40;
  DAT_00831b00 = 0;
  DAT_00831b48 = 0;
  DAT_00831a44 = DAT_00831a44 & 0xfffffffb;
  FUN_00258ff0(0xc);
  DAT_005b4ee0 = 0;
  DAT_005b4edc = 0;
  FUN_00258f20(3);
  FUN_001f8c00(&DAT_00831aec,0);
  FUN_001f8c00(&DAT_00831b34,0);
  DAT_00831cd0 = 0;
  FUN_001f99e0();
  FUN_00199660();
  FUN_0009b580(0xffffffff);
  FUN_0023c8a0(1);
  FUN_0023c7c0();
  DAT_005b4ecc = 0;
  _DAT_005b4ed0 = 0;
  _DAT_005b4ec4 = 0;
  _DAT_005b4ec8 = 0;
  FUN_00093340(0);
  FUN_000a0c30();
  DAT_00831cd0 = 0;
  return;
}

