
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00198420(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  float local_3c;
  float local_34;
  float local_30;
  undefined4 *local_2c;
  float local_28;
  float local_20;
  undefined4 *local_18;
  float local_14;
  float local_c;
  float local_8;
  
  FUN_00231bf0(5);
  FUN_00258f20(5);
  FUN_000a0b60();
  iVar1 = FUN_001c2680(0x48);
  if (iVar1 != 0) {
    FUN_001c7180(iVar1,DAT_007350c0 + 0xe);
    FUN_001c2920(0x48,iVar1);
    *(undefined4 *)(iVar1 + 0x20) = 0;
    *(undefined4 *)(iVar1 + 0x24) = 0x41700000;
    *(undefined4 *)(iVar1 + 0x28) = 0;
    *(undefined4 *)(iVar1 + 0x2c) = 0;
    *(undefined4 *)(iVar1 + 0x30) = 0x41f00000;
    *(undefined4 *)(iVar1 + 0x34) = 0x42960000;
    *(undefined4 *)(iVar1 + 0x38) = 0x1f;
    if (DAT_008292f8 == 0x11) {
      FUN_001f8c00(&DAT_00831aec + DAT_005b895c * 0x12,2);
    }
    if (DAT_00831af4 == 0) {
      local_18 = &DAT_00831b34;
      local_2c = &DAT_00831aec;
      DAT_00831af0 = 0;
    }
    else if (DAT_00831b3c == 0) {
      local_18 = &DAT_00831aec;
      local_2c = &DAT_00831b34;
      DAT_00831b38 = 1;
    }
    else {
      local_18 = &DAT_00831aec;
      local_2c = &DAT_00831b34;
      DAT_00831b38 = 1;
      DAT_00831b3c = 0;
    }
    if (DAT_008292f8 == 0x11) {
      FUN_001996b0();
    }
    FUN_001b20e0(&PTR_PTR_004ea040);
    FUN_00232f60(0x1000b,&PTR_s_fightingart_sec_0055893c,1);
    FUN_00093340(0);
    FUN_00093340(1);
    FUN_00093340(3);
    FUN_00093340(9);
    FUN_0023c8a0(5);
    FUN_0023c7c0();
    FUN_001af010(DAT_007350c0);
    FUN_00028990(0x15);
    FUN_00198e70(local_2c);
    FUN_00198a40();
    iVar2 = FUN_00199870();
    if (DAT_008292f8 == 0x11) {
      local_18[0xb] = 0x3d;
      local_18[5] = local_18[5] | 1;
    }
    else if ((0 < iVar2) && (DAT_005b8824 != -1)) {
      local_18[0xb] = DAT_005b8824;
    }
    DAT_00831a54 = FUN_001996f0();
    if (DAT_008292f8 != 0x11) {
      FUN_001994a0();
    }
    FUN_000627b0(0);
    FUN_0002c8f0();
    local_8 = *(float *)(&DAT_005534b8 + iVar2 * 8);
    local_14 = *(float *)(&DAT_005534bc + iVar2 * 8);
    if (DAT_008292f8 == 0x11) {
      FUN_0023c150(0x42505);
      local_28 = 0.0;
      local_30 = -2.35;
      local_8 = 500.0;
      local_14 = 0.0;
      *(undefined4 *)(iVar1 + 0x34) = 0x41f00000;
    }
    else if (iVar2 == 0) {
      FUN_0023c150(0x42502);
      local_28 = *(float *)(iVar1 + 0x20);
      local_30 = 1.0;
    }
    else if (iVar2 == 7) {
      FUN_0023c150(0x42504);
      local_28 = *(float *)(iVar1 + 0x24);
      local_30 = -1.0;
    }
    else {
      FUN_0023c150(0x42503);
      local_28 = *(float *)(iVar1 + 0x24);
      local_30 = -1.0;
    }
    FUN_00062900(DAT_00833638,FUN_00062860);
    FUN_000629c0(0,1,local_8,local_14);
    if (local_14 - local_8 < _DAT_004d7c38) {
      local_3c = -(local_14 - local_8);
    }
    else {
      local_3c = local_14 - local_8;
    }
    local_20 = (DAT_004d7cd0 * *(float *)(iVar1 + 0x34)) / DAT_004d7c34 +
               (DAT_004d7cd0 * local_28) / DAT_004d7c34 + local_3c;
    uVar3 = FUN_00199760(iVar2);
    local_2c[0xb] = uVar3;
    local_2c[5] = 0;
    FUN_00207b90(local_18);
    FUN_001f6db0(local_2c[1],local_2c[0xb],local_2c[5]);
    iVar4 = FUN_000572e0(0);
    *(float *)(iVar4 + 100) = local_30 * _DAT_004e1530;
    FUN_000570a0();
    FUN_0025a750(8,0);
    if (DAT_008292f8 == 0x11) {
      DAT_007350c4 = DAT_004d7c64 * _DAT_008292e4;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    if (iVar2 == 0) {
      DAT_007350c4 = _DAT_004e152c * _DAT_008292e4;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    else {
      DAT_007350c4 = _DAT_004e1528 * _DAT_008292e4;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    local_c = local_28 * _DAT_008292e4 - DAT_004d7b54;
    while (_DAT_004d7c38 < local_c) {
      *(float *)(iVar4 + 100) = (local_28 - local_c) / local_28;
      *(float *)(iVar4 + 100) = *(float *)(iVar4 + 100) * *(float *)(iVar4 + 100);
      *(float *)(iVar4 + 100) = local_30 * *(float *)(iVar4 + 100);
      *(float *)(iVar4 + 100) = DAT_008292e8 * *(float *)(iVar4 + 100);
      local_c = local_c - DAT_004d7b54;
      local_20 = local_20 - DAT_008292e8;
      DAT_007350c4 = 1.0;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    *(float *)(iVar4 + 100) = local_30 * DAT_004d7b54;
    while (_DAT_004d7c38 < local_20) {
      local_34 = 1.0;
      if (local_20 < *(float *)(iVar1 + 0x34)) {
        local_34 = DAT_004d7b54 - (*(float *)(iVar1 + 0x34) - local_20) / *(float *)(iVar1 + 0x34);
        local_34 = local_34 * local_34;
      }
      *(float *)(iVar4 + 100) = local_34 * local_30;
      *(float *)(iVar4 + 100) = DAT_008292e8 * *(float *)(iVar4 + 100);
      local_20 = local_20 - DAT_008292e8;
      DAT_007350c4 = 1.0;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    FUN_0002c980();
    FUN_000627b0(0);
    if (DAT_008292f8 != 0x11) {
      DAT_007350c4 = *(float *)(iVar1 + 0x30);
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
  }
  FUN_0025a6f0(8,1);
  FUN_0019ca30(2,FUN_00096c60);
  return (float10)DAT_004d7b58;
}

