
void FUN_001166e0(void)

{
  FUN_0023c8a0(6);
  FUN_0023c7c0();
  return;
}

