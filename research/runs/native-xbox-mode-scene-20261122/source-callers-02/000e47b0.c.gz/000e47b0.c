
/* WARNING: Removing unreachable block (ram,0x000e47ba) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_000e47b0(void)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  FUN_000a0b60();
  DAT_00831a40 = DAT_00831a40 & 0xfffffefd;
  FUN_00258ff0(7);
  iVar2 = FUN_0007d6a0();
  if (iVar2 < 2) {
    FUN_00231bf0(6);
  }
  else {
    FUN_00231bf0(7);
  }
  FUN_00232790(0x1400d5);
  FUN_00232790(0x1500d6);
  FUN_00231a10(0x1500d6);
  if ((DAT_00831a44 >> 2 & 1) == 0) {
    FUN_00258f20(0x12);
  }
  else {
    FUN_00258f20(3);
  }
  if ((DAT_00831a44 & 1) != 0) {
    FUN_0034b790(DAT_0055361c,10);
  }
  FUN_000982d0();
  FUN_00097c30(0x50011);
  FUN_000570a0();
  if ((DAT_00831a44 & 1) != 0) {
    FUN_0007bb90();
  }
  FUN_001b20e0(&PTR_PTR_004ea040);
  FUN_00232fa0(0x1000b,&PTR_s_fightingart_sec_0055893c,1);
  FUN_001b20e0(&PTR_PTR_004ed6c8);
  FUN_00232fa0(0x1300d4,&PTR_s_kart_sec_0055abe0,1);
  FUN_00232920(0x1300d4,"kart_bgnd_shared_art.sec",1);
  FUN_00232b70(0x1300d4);
  FUN_00093340(10);
  FUN_00093340(0xb);
  FUN_00093340(0x10);
  FUN_00093340(0x11);
  iVar2 = FUN_0007d6a0();
  if (iVar2 == 1) {
    FUN_00093340(0xc);
    FUN_00093340(0xd);
  }
  else if (iVar2 == 2) {
    FUN_00093340(0xc);
    FUN_00093340(0xe);
  }
  else {
    FUN_00093340(0xf);
    FUN_00093340(0xe);
  }
  FUN_00232bd0(0x1400d5,&PTR_s_kart_anims_sec_0055abd4,&DAT_005b8178,&DAT_005b82d8,0,1,1);
  FUN_00232b70(0x1400d5);
  DAT_0082ecd8 = &DAT_005b8178;
  FUN_001af010(DAT_007350c0);
  if ((DAT_00831a44 & 1) != 0) {
    FUN_0034a4d0();
  }
  iVar2 = FUN_00028990(DAT_00831a54);
  if (iVar2 == 0) {
    FUN_000570a0();
    FUN_000f50a0(3);
  }
  FUN_000e4b70();
  puVar1 = DAT_005b8334;
  FUN_000e5f80();
  FUN_000c27a0();
  FUN_000e5bd0();
  FUN_000e66c0();
  *puVar1 = *puVar1 | 2;
  FUN_0023c8a0(7);
  FUN_0023c7c0();
  DAT_00831a40 = DAT_00831a40 | 0x40;
  while ((DAT_00831a40 & 1) != 0) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_0007f350();
  DAT_007350c4 = 0x40400000;
  (**(code **)(*DAT_007350c0 + 0x14))();
  FUN_0007f420();
  FUN_00057150();
  if ((DAT_00831a44 >> 2 & 1) == 0) {
    do {
      do {
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
        iVar2 = FUN_001c4870(0x6041);
        iVar3 = FUN_001c4870(0x6042);
      } while (iVar2 != 0);
    } while (iVar3 != 0);
    *puVar1 = *puVar1 | 8;
    uVar4 = FUN_0019ff60();
    FUN_00232790(uVar4);
    uVar5 = FUN_001a0000(uVar4);
    FUN_001de2b0(uVar5);
    FUN_00232b70(uVar4);
    *puVar1 = *puVar1 & 0xfffffff7;
  }
  (**(code **)(*DAT_007350c0 + 0x20))(FUN_000e9f60,0);
  return (float10)_DAT_004d7c38;
}

