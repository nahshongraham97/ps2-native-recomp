
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00192700(void)

{
  int iVar1;
  
  FUN_00097c30(0x50011);
  FUN_000570a0();
  FUN_0007bb90();
  FUN_000a0b60();
  FUN_00028990(0x16);
  FUN_001b20e0(&PTR_PTR_004e9510);
  FUN_00232f60(0xe002e,&PTR_s_krypt_screen_art_sec_00557f10,1);
  FUN_00093340(9);
  FUN_00093340(0x1b);
  FUN_00093340(0x1c);
  FUN_00093340(7);
  FUN_001b0350(0x170002,2,"krypt_strings_eng.mko",1);
  FUN_00193480(&PTR_s_kryptdata_bin_00557f70,&DAT_00829314,&DAT_00829310,&DAT_005b8804,300);
  *(undefined4 *)(DAT_00736354 + 8) = DAT_00831a60;
  DAT_00831a74 = 0x3e19999a;
  FUN_0023c8a0(3);
  FUN_0023c7c0();
  FUN_00193020();
  FUN_00193420();
  FUN_00057de0(0,FUN_00061a00,1);
  DAT_007350c4 = 0x40000000;
  (**(code **)(*DAT_007350c0 + 0x14))();
  DAT_00831a40 = DAT_00831a40 | 0x40;
  while ((DAT_00831a40 & 1) != 0) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_0023dd10();
  FUN_00197e50();
  FUN_001b03a0(DAT_00831a60,5,0);
  FUN_000570a0();
  FUN_0025a750(0x14,0);
  while (iVar1 = FUN_0005cb50(), iVar1 == 0) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_00196580();
  FUN_001de2b0("common/c_generic_popup",0xf0030);
  FUN_001929a0(3,1,1);
  FUN_000a0c30();
  (**(code **)(*DAT_007350c0 + 0x20))(FUN_001928f0,0);
  return (float10)_DAT_004d7c38;
}

