
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00105b30(void)

{
  undefined4 uVar1;
  int iVar2;
  float10 fVar3;
  int local_10;
  int local_c;
  
  if (DAT_00734ffc == 0) {
    fVar3 = (float10)_DAT_004d7c38;
  }
  else if ((DAT_005b834c & 1) == 0) {
    if (DAT_00734ff0 != 0) {
      if (*(int *)(DAT_00734ff0 + 0x78) == 0) {
        local_10 = 0;
      }
      else {
        if (*(int *)(*(int *)(DAT_00734ff0 + 0x78) + 4) == *(int *)(DAT_00734ff0 + 0x7c)) {
          local_c = *(int *)(DAT_00734ff0 + 0x78);
        }
        else {
          local_c = 0;
        }
        local_10 = local_c;
      }
      if (local_10 != 0) {
        FUN_001c49a0(local_10,FUN_001abd40);
      }
    }
    if (DAT_00734ff4 != 0) {
      *(undefined4 *)(DAT_00734ff4 + 0xc0) = 0;
      *(undefined4 *)(DAT_00734ff4 + 0xc4) = 0xc0c00000;
      *(undefined4 *)(DAT_00734ff4 + 200) = 0;
      *(uint *)(DAT_00734ff4 + 0xc) = *(uint *)(DAT_00734ff4 + 0xc) & 0xfffffdff;
    }
    _DAT_005b8348 = DAT_00734ffc;
    FUN_00087480(0x1200);
    FUN_0025a6f0(10,1);
    FUN_001f7660(DAT_00734ffc);
    if (DAT_00734ff0 != 0) {
      uVar1 = FUN_000139e0(DAT_00734ff4,FUN_001c4170);
      FUN_001f71f0(uVar1);
      FUN_001f7340(DAT_00734ff0,1);
    }
    FUN_0019b000();
    FUN_000a9c70();
    FUN_001b8720(&DAT_00831aec,1);
    FUN_001b8720(&DAT_00831b34,1);
    FUN_000874c0(0x3f800000);
    FUN_000828f0(0x3dcccccd);
    FUN_00081920();
    DAT_007350c4 = 0x41200000;
    (**(code **)(*DAT_007350c0 + 0x14))();
    FUN_00081940();
    FUN_001058f0(DAT_00734ffc);
    FUN_00105a50(DAT_00734ffc);
    FUN_00105df0();
    FUN_0023dde0();
    FUN_0023c8a0(4);
    FUN_00232b70(DAT_0054f04c);
    FUN_00232b70(DAT_0054f050);
    FUN_0023c7c0();
    iVar2 = FUN_0023c150(0x525b2);
    if ((iVar2 == 0) && (DAT_0054f04c == -1)) {
      fVar3 = (float10)_DAT_004d7c38;
    }
    else {
      DAT_005b834c = DAT_005b834c | 1;
      FUN_000a0c30();
      FUN_0008b4d0();
      FUN_00085cf0(*(undefined4 *)(DAT_00734ffc + 0x458),3);
      FUN_001b02b0();
      FUN_001af290(*(undefined4 *)(DAT_00734ffc + 0x9d4),0x89);
      FUN_001af100(*(undefined4 *)(DAT_00734ffc + 0x9d4));
      fVar3 = (float10)_DAT_004d7c38;
    }
  }
  else {
    fVar3 = (float10)_DAT_004d7c38;
  }
  return fVar3;
}

