
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_001ea970(void)

{
  int iVar1;
  int iVar2;
  uint local_8;
  
  DAT_007350c0[0xb] = (int)FUN_001eab00;
  FUN_001df270(DAT_005ac74c);
  FUN_0034ba20();
  FUN_0034b790(DAT_0055361c,10);
  FUN_000aa720();
  FUN_00231bf0(1);
  FUN_00258ff0(0xe);
  FUN_00359f10();
  FUN_00258f20(0x11);
  FUN_0023c8a0(1);
  FUN_0023c7c0();
  iVar1 = FUN_001c2680(0x44);
  if (iVar1 == 0) {
    FUN_0019ca30(0,FUN_00027be0);
  }
  FUN_001c2920(0x44,iVar1);
  FUN_001c7180(iVar1,DAT_007350c0 + 0xe);
  *(undefined4 *)(iVar1 + 8) = DAT_005017a4;
  *(undefined4 *)(iVar1 + 0xc) = DAT_005017a8;
  *(undefined **)(iVar1 + 0x10) = PTR_DAT_005017ac;
  *(undefined4 *)(iVar1 + 0x40) = 0;
  for (local_8 = 0; local_8 < 10; local_8 = local_8 + 1) {
    iVar2 = FUN_00104ab0(local_8);
    if (iVar2 != 0) {
      *(uint *)(iVar1 + 0x18 + *(int *)(iVar1 + 0x40) * 4) = local_8;
      *(int *)(iVar1 + 0x40) = *(int *)(iVar1 + 0x40) + 1;
    }
  }
  FUN_001de3a0();
  FUN_001ddda0("common/kart_online/kart_session",0x8002a,iVar1,1);
  FUN_001ea820();
  FUN_0023c150(0x1253b);
  FUN_000570a0();
  FUN_000a0c30();
  FUN_0007bb90();
  (**(code **)(*DAT_007350c0 + 0x20))(FUN_001eab40,0);
  return (float10)_DAT_004d7c38;
}

