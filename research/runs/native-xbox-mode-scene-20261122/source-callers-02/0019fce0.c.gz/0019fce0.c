
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_0019fce0(void)

{
  FUN_0019f140();
  FUN_00231bf0(1);
  FUN_00258ff0(0xc);
  FUN_00258f20(0x14);
  FUN_0023c8a0(1);
  FUN_0023c7c0();
  FUN_00349c60();
  FUN_001de3a0();
  FUN_001ddda0("common/xbox_online/xo_signed_in",0x8002a,0,1);
  (**(code **)(*DAT_007350c0 + 0x20))(FUN_0019fd60,0);
  return (float10)_DAT_004d7c38;
}

