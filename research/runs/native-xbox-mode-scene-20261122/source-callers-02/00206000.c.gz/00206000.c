
void __fastcall FUN_00206000(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_000573b0(0,param_1);
  FUN_00231bf0(4);
  FUN_001a12d0(0xffffffff);
  FUN_0023c8a0(1);
  FUN_0023c7c0();
  FUN_002051c0(&DAT_00831aec);
  FUN_002051c0(&DAT_00831b34);
  if (DAT_008292f8 == 4) {
    DAT_00831af0 = 0;
    DAT_00831b38 = 1;
  }
  FUN_0009b580(0xffffffff);
  DAT_005bd980 = 0;
  DAT_00831b00 = 0;
  DAT_00831b48 = 0;
  DAT_00831afc = 0x3f800000;
  DAT_00831b44 = 0x3f800000;
  DAT_00723c44 = 100;
  DAT_00723c40 = 100;
  *(undefined4 *)(iVar1 + 0xc0) = 0x3d75c28f;
  *(undefined4 *)(iVar1 + 0xc4) = 0x3fd9999a;
  *(undefined4 *)(iVar1 + 200) = 0x404851ec;
  *(undefined4 *)(iVar1 + 0xf4) = 0x40490fdb;
  DAT_00831a54 = 0x38;
  FUN_001997d0();
  return;
}

