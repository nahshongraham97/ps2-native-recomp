
float10 __fastcall FUN_00106080(undefined4 param_1)

{
  int iVar1;
  
  FUN_00258ff0(0x10,param_1);
  FUN_00231bf0(0);
  FUN_00258f20(3);
  FUN_001af010(DAT_007350c0);
  DAT_00831b18 = DAT_0054d0a8;
  DAT_00831a54 = 0xb;
  FUN_00097c30(0x50011);
  FUN_000570a0();
  FUN_00028fd0(DAT_00831a54);
  FUN_000288a0();
  FUN_001f3c80(0,&DAT_00831aec);
  iVar1 = FUN_00028990(DAT_00831a54);
  if (iVar1 == 0) {
    FUN_000570a0();
  }
  FUN_0023c8a0(2);
  FUN_0023c7c0();
  FUN_001c49a0(DAT_00831b28,FUN_001f5db0);
  DAT_00831a40 = DAT_00831a40 | 0x40;
  for (iVar1 = 0x3c; ((DAT_00831a40 & 1) != 0 && (0 < iVar1)); iVar1 = iVar1 + -1) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_00105fb0(&DAT_00831aec);
  FUN_00258f90();
  FUN_0019ca30(7,FUN_0008b550);
  return (float10)DAT_004d7b58;
}

