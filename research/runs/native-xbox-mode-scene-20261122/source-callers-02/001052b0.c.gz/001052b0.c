
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_001052b0(void)

{
  int iVar1;
  int iVar2;
  uint local_c;
  int local_8;
  
  FUN_0007d680(1);
  FUN_00258ff0(0xf);
  FUN_00231bf0(1);
  FUN_0023c8a0(1);
  FUN_0023c7c0();
  FUN_00232790(0x8002a);
  if (DAT_005b896c != 0) {
    DAT_005b896c = 0;
    for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
      FUN_0007b790(&DAT_00831aec + local_8 * 0x12);
      (&DAT_00831af0)[local_8 * 0x12] = 5;
      FUN_001f8c00(&DAT_00831aec + local_8 * 0x12,0);
      FUN_0007b820(local_8);
    }
    FUN_001f8c00(&DAT_00831aec + DAT_005b895c * 0x12,2);
    if ((DAT_00553618 != 0) && (DAT_00553618 != 5)) {
      FUN_001fa810(0,DAT_00553618);
    }
  }
  FUN_00258f20(0x1a);
  FUN_002051c0(&DAT_00831aec);
  FUN_002051c0(&DAT_00831b34);
  FUN_002051c0(&DAT_00831b7c);
  FUN_002051c0(&DAT_00831bc4);
  iVar1 = FUN_001c2680(0x48);
  if (iVar1 == 0) {
    FUN_0019ca30(0,FUN_00027be0);
  }
  FUN_001c2920(0x48,iVar1);
  FUN_001c7180(iVar1,DAT_007350c0 + 0xe);
  *(undefined4 *)(iVar1 + 0x30) = 0;
  for (local_c = 0; local_c < 10; local_c = local_c + 1) {
    iVar2 = FUN_00104ab0(local_c);
    if (iVar2 != 0) {
      *(uint *)(iVar1 + 8 + *(int *)(iVar1 + 0x30) * 4) = local_c;
      *(int *)(iVar1 + 0x30) = *(int *)(iVar1 + 0x30) + 1;
    }
  }
  *(undefined4 *)(iVar1 + 0x38) = 0;
  *(undefined4 *)(iVar1 + 0x3c) = 0xa8c;
  FUN_00105510();
  *(undefined **)(iVar1 + 0x34) = &DAT_0082eca0;
  FUN_0009b580(DAT_0082ecd0);
  DAT_0082ecd4 = 0;
  FUN_001ddda0("common/kart/kart_main",0x8002a,iVar1,0);
  FUN_000570a0();
  FUN_0023c150(0x1253b);
  FUN_000a0c30();
  (**(code **)(*DAT_007350c0 + 0x20))(FUN_00105590,0);
  return (float10)_DAT_004d7c38;
}

