
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_0024f1f0(void)

{
  float fVar1;
  int iVar2;
  int iVar3;
  undefined4 local_20;
  undefined4 local_1c;
  int local_18;
  undefined4 local_14;
  int local_10;
  undefined4 local_c;
  int local_8;
  
  iVar2 = FUN_002421f0();
  fVar1 = DAT_004d7b58;
  if (iVar2 != 0) {
    while (iVar3 = FUN_001c4870(0x9003), iVar3 != 0) {
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    while (iVar3 = FUN_001c4870(0x9013), iVar3 != 0) {
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    local_18 = *(int *)(iVar2 + 0x60);
    local_8 = (local_18 == 0x6003d) + 0x6003d;
    local_20 = 0x60040;
    local_1c = 0x6003c;
    local_14 = 0;
    local_10 = local_18;
    FUN_00251190(DAT_00831b1c,DAT_00831b20,&local_20,local_8);
    FUN_0024ead0(*(undefined4 *)(DAT_00831b1c + 0x450));
    FUN_001c69e0(DAT_00831b20 + 0x2c);
    *(int *)(iVar2 + 0x60) = local_8;
    FUN_00250690(DAT_00831b1c,DAT_00831b20,local_8,*(undefined4 *)(iVar2 + 100));
    *(undefined4 *)(iVar2 + 0x7e0) = DAT_005bea28;
    if (DAT_005bea34 != 0) {
      *(undefined4 *)(iVar2 + 0x7e0) = 4;
    }
    FUN_001b9c60(DAT_00831b20);
    local_c = FUN_001f9410(DAT_00831b1c);
    FUN_001a51f0(local_c,1);
    FUN_001bba60(DAT_00831b20);
    FUN_001b8580(DAT_00831b20);
    if (*(int *)(iVar2 + 0x5c) == 3) {
      FUN_0024e860();
    }
    if ((*(int *)(iVar2 + 0x778) == 1) && (*(int *)(iVar2 + 0x780) == 0)) {
      FUN_00255b10();
    }
    else {
      FUN_00255e10(1);
    }
    FUN_00256e70();
    FUN_0024f470();
    FUN_0024f440();
    FUN_00241ff0(DAT_00831b1c,DAT_00831b20);
    if (*(int *)(iVar2 + 0x784) != 0) {
      FUN_0023c8a0(8);
      *(undefined4 *)(iVar2 + 0x784) = 0;
    }
    (**(code **)(*DAT_007350c0 + 0x20))(*(undefined4 *)(iVar2 + 0x774),0);
    fVar1 = _DAT_004d7c38;
  }
  return (float10)fVar1;
}

