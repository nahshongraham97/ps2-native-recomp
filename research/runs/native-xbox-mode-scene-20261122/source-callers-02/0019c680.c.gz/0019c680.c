
/* WARNING: Removing unreachable block (ram,0x0019c916) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0019c680(void)

{
  undefined8 uVar1;
  int iVar2;
  uint uVar3;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  FUN_002a0e60();
  FUN_0025cb80();
  FUN_002588b0(3);
  iVar2 = FUN_002694f0();
  if ((iVar2 != 0) && (iVar2 = FUN_0007d460(), iVar2 != 0)) {
    FUN_00268b10();
    FUN_00096bf0();
    FUN_001d6390(0);
    FUN_001c0000();
    FUN_0025c4e0();
    FUN_0019c620();
    iVar2 = FUN_0027c7c0();
    _DAT_008292fc = _DAT_004d8764 / (float)iVar2;
    FUN_00258e20();
    FUN_00258f20(0);
    FUN_001c6e90();
    FUN_00232180();
    FUN_001b1fc0();
    FUN_000a1420();
    iVar2 = FUN_0019c930();
    if ((iVar2 != 0) &&
       ((iVar2 = FUN_0026a740(1), iVar2 != 0 && (iVar2 = FUN_0019d5f0(), iVar2 != 0)))) {
      local_18 = DAT_005c3bcc;
      local_14 = DAT_005c3bcc;
      local_10 = DAT_005c3bcc;
      local_c = DAT_005c3bcc;
      local_8 = DAT_005c3bcc;
      FUN_00349900(&local_18);
      FUN_0009cb40();
      FUN_0034be40();
      FUN_00349c60();
      FUN_0023ad80();
      FUN_001f98d0();
      FUN_00235a40();
      FUN_0023c8a0(0);
      FUN_002330c0();
      FUN_00258630();
      FUN_00233100();
      _DAT_005b8888 = 1;
      thunk_FUN_003728c0();
      uVar3 = FUN_00258ad0(3);
      uVar1 = rdtsc();
      FUN_001d6070((int)uVar1 << 0x10 | uVar3 & 0xffff);
      uVar3 = FUN_002591d0(0xe);
      DAT_00831a64 = uVar3 & 0xffff;
      FUN_001c27f0(0x2001,0x20,FUN_00027be0,0,0);
      DAT_00709e6c = 0;
      DAT_00829304 = 0;
      _DAT_008292f4 = __setjmp3(&DAT_005b8848,0);
      do {
        DAT_00709e6c = DAT_00709e6c + 1;
        if (((DAT_00831a40 >> 0xd & 1) == 0) && (DAT_007350b0 == 0)) {
          DAT_00829304 = DAT_00829304 + 1;
        }
        FUN_001b6750();
        FUN_0026a9c0();
        FUN_000a2760();
        FUN_0034bd50();
        FUN_0025c1e0();
        iVar2 = FUN_0007be10();
        if (iVar2 == 0) {
          iVar2 = FUN_0019cbb0();
          if (iVar2 != 0) {
            FUN_0019cc00();
          }
          iVar2 = FUN_0034a440();
          if (iVar2 != 0) {
            FUN_0034a460();
          }
        }
        if ((DAT_00831a40 >> 0xd & 1) == 0) {
          FUN_000a0dc0();
        }
        FUN_001c2330();
        FUN_001c4d70();
        FUN_0019c950();
        FUN_001c6de0();
      } while( true );
    }
  }
  return 0;
}

