
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_001fe3d0(void)

{
  int iVar1;
  bool bVar2;
  int local_8;
  
  DAT_005bd964 = 0;
  DAT_005bd968 = 0;
  _DAT_005bd96c = 0;
  DAT_00561778 = 0x3c;
  DAT_0056177c = 0xffffffff;
  DAT_00561780 = 0xffffffff;
  DAT_00734a40 = DAT_005b895c;
  for (local_8 = 0; local_8 < 5; local_8 = local_8 + 1) {
    if (local_8 == 4) goto LAB_001fe565;
    if (local_8 == DAT_005b895c) break;
  }
  DAT_00734a44 = (&DAT_00831aec)[DAT_005b895c * 0x12];
  FUN_00258ff0(3);
  FUN_00258f20(0xc);
  FUN_001f8c00(&DAT_00831aec + DAT_00734a40 * 0x12,2);
  FUN_0023c8a0(1);
  FUN_0023c7c0();
  FUN_001fe7e0(&DAT_0056177c,&DAT_00561780);
  FUN_001ddda0("common/player_profile/pp_view_profile",0x8002a,0,1);
  FUN_000570a0();
  FUN_000a0c30();
  FUN_001fe040(0);
  while (iVar1 = FUN_001fe030(), iVar1 != 2) {
    iVar1 = DAT_00561778 + -1;
    bVar2 = DAT_00561778 == 0;
    DAT_00561778 = iVar1;
    if (bVar2) {
      iVar1 = FUN_0026b540(0);
      if (iVar1 != 0) {
        FUN_001fe7e0(&DAT_0056177c,&DAT_00561780);
      }
      FUN_001df060(0x1fb7,0);
      DAT_00561778 = 5;
    }
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_0025a6f0(8,1);
LAB_001fe565:
  FUN_00258f90();
  FUN_00258ff0(0xc);
  FUN_001f8c00(&DAT_00831aec + DAT_00734a40 * 0x12,0);
  FUN_0019ca30(3,FUN_0019f3d0);
  return (float10)DAT_004d7b58;
}

