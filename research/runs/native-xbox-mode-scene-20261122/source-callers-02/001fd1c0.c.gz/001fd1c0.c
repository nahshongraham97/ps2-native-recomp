
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_001fd1c0(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  bool bVar5;
  int local_20;
  int local_1c;
  int local_18;
  int local_14;
  int local_8;
  
  FUN_00258ff0(3);
  FUN_000a0b60();
  DAT_005bd954 = 0;
  DAT_00734a40 = DAT_005b895c;
  if ((DAT_005b895c == 0) || (DAT_005b895c == 1)) {
    DAT_00734a44 = (&DAT_00831aec)[DAT_005b895c * 0x12];
    FUN_00258f20(0xc);
    FUN_001f8c00(&DAT_00831aec + DAT_00734a40 * 0x12,2);
    FUN_0023c8a0(1);
    FUN_0023c7c0();
    DAT_00561628 = 1;
    FUN_001f99e0();
    FUN_001fddb0(&DAT_005bd948,&DAT_005bd95c);
    FUN_000570a0();
    FUN_000a0c30();
    FUN_000a0bc0(DAT_00734a44);
    FUN_0007bb90();
    FUN_0026b540(0);
    iVar1 = FUN_0019e450();
    if (iVar1 != 0) {
      FUN_000a0b60();
      while (DAT_005b888c != 0) {
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
      }
      DAT_007350c4 = 0x40a00000;
      (**(code **)(*DAT_007350c0 + 0x14))();
      FUN_001ddda0("common/player_profile/pp_create_profile",0x8002a,0,1);
LAB_001fd30d:
      do {
        while( true ) {
          FUN_001d64a0(0);
          FUN_001df060(0x2fa9,0);
          DAT_005bd954 = 0;
          FUN_000a0c30();
          FUN_000a0bc0(DAT_00734a44);
          FUN_001fe040(0);
          while (DAT_005bd954 == 0) {
            DAT_007350c4 = 0x3f800000;
            (**(code **)(*DAT_007350c0 + 0x14))();
            iVar1 = FUN_001fe030();
            if (iVar1 == 2) {
              bVar5 = false;
              FUN_001df060(0x1fe3,0);
              FUN_001fe040(0);
              DAT_007350c4 = 0x42340000;
              (**(code **)(*DAT_007350c0 + 0x14))();
              while (!bVar5) {
                DAT_007350c4 = 0x3f800000;
                (**(code **)(*DAT_007350c0 + 0x14))();
                iVar1 = FUN_001fe030();
                if (iVar1 == 1) goto LAB_001fdd53;
                iVar1 = FUN_001fe030();
                if (iVar1 == 2) {
                  FUN_001df060(0x1fab,0);
                  bVar5 = true;
                }
              }
              DAT_005bd954 = 0;
              FUN_001fe040(0);
            }
          }
          FUN_0026b540(0);
          iVar1 = FUN_001f9fd0(&DAT_005bd948);
          if (iVar1 == 0) break;
          FUN_0026f150();
          FUN_0026f440();
          DAT_007350c4 = 0x41200000;
          (**(code **)(*DAT_007350c0 + 0x14))();
        }
        FUN_000a0b60();
        FUN_001df210();
        FUN_001d64a0(1);
        FUN_001df060(0x2fa9,0);
        FUN_001fe040(0);
        while (iVar1 = FUN_001fe030(), iVar1 == 0) {
          DAT_007350c4 = 0x3f800000;
          (**(code **)(*DAT_007350c0 + 0x14))();
        }
        iVar1 = FUN_001fe030();
      } while ((iVar1 != 1) && (iVar1 = FUN_001fe030(), iVar1 == 2));
      FUN_001fa060(&DAT_005bd948);
      FUN_001d64a0(2);
      FUN_001df060(0x2fa9,0);
      FUN_001fe040(0);
      while (iVar1 = FUN_001fe030(), iVar1 != 1) {
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
        iVar1 = FUN_001fe030();
        if (iVar1 == 2) {
          bVar5 = false;
          FUN_001df060(0x1fe3,0);
          FUN_001fe040(0);
          while (!bVar5) {
            DAT_007350c4 = 0x3f800000;
            (**(code **)(*DAT_007350c0 + 0x14))();
            iVar1 = FUN_001fe030();
            if (iVar1 == 1) goto LAB_001fdd53;
            iVar1 = FUN_001fe030();
            if (iVar1 == 2) {
              FUN_001df060(0x1fab,0);
              bVar5 = true;
            }
          }
          FUN_001fe040(0);
        }
      }
      do {
        FUN_001d64a0(3);
        FUN_001df060(0x2fa9,0);
        (&DAT_0056162c)[DAT_00734a40] = 0;
        FUN_001df060(0x1faa,DAT_00734a40 + 1);
        FUN_001fdf10(&DAT_005bd940);
        _DAT_005bd93c = 0;
        while (iVar1 = FUN_001fdf50(&DAT_005bd940,&DAT_005bd93c,DAT_00734a44,DAT_00734a40),
              iVar1 != 6) {
          DAT_007350c4 = 0x3f800000;
          (**(code **)(*DAT_007350c0 + 0x14))();
          iVar1 = FUN_000a1060(DAT_00734a44,0xb);
          if (iVar1 != 0) {
            for (local_14 = 0; local_14 < 6; local_14 = local_14 + 1) {
              (&DAT_005bd940)[local_14] = 0;
            }
            _DAT_005bd93c = 0;
            if (DAT_00734a40 == 0) {
              FUN_001df060(0x1fc4,1);
            }
            else {
              FUN_001df060(0x1fc5,DAT_00734a40 + 1);
            }
            FUN_001df060(0x1faa,DAT_00734a40 + 1);
          }
        }
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
        local_18 = 3;
        local_1c = 0;
        FUN_001d64a0(4);
        FUN_001df060(0x2fa9,0);
        while ((local_18 != 0 && (local_1c == 0))) {
          local_18 = local_18 + -1;
          (&DAT_0056162c)[DAT_00734a40] = 0;
          FUN_001df060(0x1faa,DAT_00734a40 + 1);
          FUN_001fdf10(&DAT_005bd934);
          _DAT_005bd930 = 0;
          while (iVar1 = FUN_001fdf50(&DAT_005bd934,&DAT_005bd930,DAT_00734a44,DAT_00734a40),
                iVar1 != 6) {
            DAT_007350c4 = 0x3f800000;
            (**(code **)(*DAT_007350c0 + 0x14))();
            iVar1 = FUN_000a1060(DAT_00734a44,0xb);
            if (iVar1 != 0) {
              for (local_20 = 0; local_20 < 6; local_20 = local_20 + 1) {
                (&DAT_005bd934)[local_20] = 0;
              }
              _DAT_005bd930 = 0;
              if (DAT_00734a40 == 0) {
                FUN_001df060(0x1fc4,1);
              }
              else {
                FUN_001df060(0x1fc5,DAT_00734a40 + 1);
              }
              FUN_001df060(0x1faa,DAT_00734a40 + 1);
            }
          }
          DAT_007350c4 = 0x3f800000;
          (**(code **)(*DAT_007350c0 + 0x14))();
          local_1c = FUN_001fb360(&DAT_005bd940,&DAT_005bd934);
        }
      } while (local_1c == 0);
      FUN_0019e650(8);
      local_8 = 1;
      FUN_001d64a0(5);
      FUN_001df060(0x2fa9,0);
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
      FUN_0019eef0();
      DAT_005bd960 = 0;
      FUN_001fe040(0);
LAB_001fd935:
      if (DAT_005bd960 != 0) {
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
        FUN_001df060(0x1fb7,0);
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
        FUN_001d64a0(6);
        FUN_001df060(0x2fa9,0);
        FUN_001fe040(0);
        while (iVar1 = FUN_001fe030(), iVar1 != 1) {
          DAT_007350c4 = 0x3f800000;
          (**(code **)(*DAT_007350c0 + 0x14))();
        }
        goto LAB_001fdd53;
      }
      bVar5 = local_8 == 0;
      local_8 = local_8 + -1;
      if (bVar5) {
        FUN_0019ef30(DAT_00734a40);
        iVar1 = FUN_0026b540(1);
        if (iVar1 != 0) {
          if ((DAT_0059c8a8 != -1) && (iVar1 = FUN_0019e680(), DAT_0059c8a8 != iVar1)) {
            FUN_0019e620(DAT_0059c8a8);
          }
          DAT_007350c4 = 0x40000000;
          (**(code **)(*DAT_007350c0 + 0x14))();
          FUN_001df060(0x1fb7,0);
        }
        local_8 = 1;
      }
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
      iVar1 = FUN_001fe030();
      if (iVar1 == 1) {
        iVar1 = FUN_0019e680();
        if ((iVar1 < 0) || (8 < iVar1)) {
          FUN_0023c150(0x250a);
        }
        else {
          FUN_0026b540(0);
          if (*(int *)(&DAT_00736520 + iVar1 * 0x1afc0) == 0) {
            iVar2 = FUN_001fde80(iVar1);
            iVar3 = FUN_001f9fd0(&DAT_005bd948);
            if (iVar3 != 0) goto code_r0x001fda78;
            if ((iVar2 < 0) || (7 < iVar2)) {
              FUN_0023c150(0x250a);
            }
            else {
              iVar2 = FUN_001fa540(iVar1);
              if (iVar2 == -1) goto LAB_001fdd53;
              FUN_0019e0a0(&DAT_00736520 + iVar1 * 0x1afc0,iVar2);
              *(undefined1 *)(iVar1 * 0x1afc0 + 0x7365e1 + iVar2 * 0x35e0) = DAT_005bd946;
              FUN_0019ddd0(&DAT_005bd948,iVar1 * 0x1afc0 + 0x7365d0 + iVar2 * 0x35e0);
              FUN_0019de10(&DAT_005bd940,iVar1 * 0x1afc0 + 0x7365db + iVar2 * 0x35e0);
              *(undefined4 *)(iVar1 * 0x1afc0 + 0x739b9c + iVar2 * 0x35e0) = 1;
              uVar4 = FUN_002591c0();
              *(undefined4 *)(iVar1 * 0x1afc0 + 0x739ba0 + iVar2 * 0x35e0) = uVar4;
              uVar4 = FUN_001df630(0x10,1,iVar1 * 0x1afc0 + 0x736560,0,
                                   &DAT_00736524 + iVar1 * 0x1afc0,&DAT_00736528 + iVar1 * 0x1afc0);
              DAT_005bd960 = FUN_0019d750(iVar1,6,uVar4);
              FUN_0023c150(0x2508);
            }
          }
        }
        FUN_001fe040(0);
      }
      iVar1 = FUN_001fe030();
      if (iVar1 == 2) {
        bVar5 = false;
        FUN_001df060(0x1fe3,0);
        FUN_001fe040(0);
        while (!bVar5) {
          DAT_007350c4 = 0x3f800000;
          (**(code **)(*DAT_007350c0 + 0x14))();
          iVar1 = FUN_001fe030();
          if (iVar1 == 1) goto LAB_001fdd53;
          iVar1 = FUN_001fe030();
          if (iVar1 == 2) {
            FUN_001df060(0x1fab,0);
            bVar5 = true;
          }
        }
        FUN_001fe040(0);
      }
      goto LAB_001fd935;
    }
    FUN_0026e670();
    FUN_0026f440();
  }
LAB_001fdd53:
  FUN_000a0c00();
  FUN_000a0c30();
  FUN_00258f90();
  FUN_00258ff0(0xc);
  FUN_0025a6f0(8,1);
  FUN_001f8c00(&DAT_00831aec + DAT_00734a40 * 0x12,0);
  FUN_0019ca30(3,FUN_0019f3d0);
  return (float10)DAT_004d7b58;
code_r0x001fda78:
  FUN_0026f150();
  FUN_0026f440();
  DAT_007350c4 = 0x3f800000;
  (**(code **)(*DAT_007350c0 + 0x14))();
  FUN_001fddb0(&DAT_005bd948,&DAT_005bd95c);
  goto LAB_001fd30d;
}

