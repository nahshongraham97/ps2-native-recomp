
/* WARNING: Removing unreachable block (ram,0x0019f99e) */
/* WARNING: Removing unreachable block (ram,0x0019f9a2) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0019f3d0(void)

{
  int iVar1;
  int iVar2;
  int local_14;
  int local_8;
  
  local_8 = 0;
  FUN_0035d600();
  DAT_005b7a58 = 0;
  DAT_0055361c = 0xffffffff;
  DAT_005ac74c = -1;
  DAT_00831a44 = DAT_00831a44 & 0xffffffdf;
  _DAT_005b8964 = 0;
  if (DAT_005b8954 == 0) {
    DAT_005b8954 = 1;
    FUN_0019ca30(3,FUN_001fa0c0);
  }
  FUN_00231bf0(1);
  FUN_0019f2f0();
  if (DAT_00731448 == 1) {
    if (DAT_0072de48 == 1) {
      FUN_001f9a10(1);
    }
    if (DAT_0072a848 == 1) {
      FUN_001f9a10(2);
    }
    if (DAT_00727248 == 1) {
      FUN_001f9a10(3);
    }
  }
  else if (DAT_0072de48 == 1) {
    FUN_001fa810(1,0);
    if (DAT_0072a848 == 1) {
      FUN_001f9a10(2);
    }
    if (DAT_00727248 == 1) {
      FUN_001f9a10(3);
    }
  }
  else if (DAT_0072a848 == 1) {
    FUN_001fa810(2,0);
    if (DAT_00727248 == 1) {
      FUN_001f9a10(3);
    }
  }
  else if (DAT_00727248 == 1) {
    FUN_001fa810(3,0);
  }
  FUN_00258ff0(0xc);
  FUN_00258f20(8);
  FUN_00199660();
  FUN_0007b790(&DAT_00831aec);
  FUN_0007b790(&DAT_00831b34);
  FUN_001f8c00(&DAT_00831aec,0);
  FUN_001f8c00(&DAT_00831b34,0);
  FUN_0007b790(&DAT_00831b7c);
  FUN_0007b790(&DAT_00831bc4);
  FUN_001f8c00(&DAT_00831b7c,0);
  FUN_001f8c00(&DAT_00831bc4,0);
  _DAT_005ea70c = 0;
  DAT_00831a44 = DAT_00831a44 & 0xfffffffe;
  FUN_001f1c10(&DAT_00831aec);
  FUN_001f1c10(&DAT_00831b34);
  FUN_001f1c10(&DAT_00831b7c);
  FUN_001f1c10(&DAT_00831bc4);
  FUN_0009ce80();
  FUN_0023c8a0(1);
  FUN_0023c7c0();
  FUN_00232790(0x8002a);
  FUN_0019fa30();
  FUN_0023c150(0x1253c);
  FUN_000570a0();
  FUN_000a0c30();
  FUN_0026c5a0();
  FUN_0019fbd0();
  DAT_005b8960 = 0x17;
  do {
    iVar1 = DAT_005b8960;
    if (DAT_005b8960 != 0x17) {
      local_14 = DAT_005b8960;
      DAT_005b896c = 1;
      FUN_00258f90();
      FUN_00258f20(0x17);
      FUN_001de3a0();
      iVar2 = FUN_0034a360();
      if ((iVar2 != 0) && (iVar1 == 0x13)) {
        local_14 = 3;
      }
      if (-1 < DAT_005ac74c) {
        DAT_005b895c = DAT_005ac74c;
      }
      if (-1 < (int)(&DAT_00831aec)[DAT_005b895c * 0x12]) {
        FUN_0019fb50((&DAT_00831aec)[DAT_005b895c * 0x12]);
      }
      FUN_001d9530(DAT_005b895c,local_14);
      switch(local_14) {
      case 1:
        FUN_0019fb20();
        FUN_00258ff0(8);
        FUN_001892d0();
        FUN_00136e60();
        FUN_0019ca30(0xb,FUN_00113430);
        break;
      default:
        FUN_0019ca30(0,FUN_00027be0);
        DAT_005b896c = 0;
        break;
      case 3:
        FUN_0019ca30(3,FUN_0019f3d0);
        break;
      case 4:
        FUN_0019ca30(3,FUN_0019f3d0);
        break;
      case 5:
        FUN_00258ff0(0);
        FUN_0019fa10();
        FUN_0019fb20();
        FUN_0019ca30(1,FUN_002057e0);
        break;
      case 6:
        FUN_00258ff0(1);
        FUN_0019fa10();
        FUN_0019fb20();
        FUN_0019ca30(1,FUN_002057e0);
        break;
      case 7:
        FUN_0019fb20();
        FUN_00258ff0(0xf);
        FUN_0019ca30(10,FUN_001052b0);
        break;
      case 9:
        FUN_00258ff0(4);
        FUN_0019fa10();
        FUN_0019fb20();
        FUN_0019ca30(1,FUN_002057e0);
        break;
      case 0xc:
        FUN_0019ca30(3,FUN_001a05c0);
        break;
      case 0xd:
        FUN_0019ca30(3,FUN_001a0360);
        break;
      case 0xe:
      case 0xf:
        FUN_0019fb20();
        FUN_0019ca30(4,FUN_00192570);
        break;
      case 0x10:
        FUN_0019ca30(3,FUN_001fd1c0);
        break;
      case 0x11:
        FUN_0019ca30(3,FUN_001fe3d0);
        break;
      case 0x12:
        FUN_0019ca30(3,FUN_001fee00);
        break;
      case 0x13:
        FUN_0019fb20();
        DAT_005ac74c = DAT_005b895c;
        DAT_0055361c = (&DAT_00831aec)[DAT_005b895c * 0x12];
        FUN_00349c60();
        FUN_00349d40(DAT_0055361c);
        FUN_0019ca30(5,FUN_0019f0d0);
      case 0x15:
        FUN_0019ca30(3,FUN_0008b550);
        break;
      case 0x16:
        FUN_0019fb20();
        FUN_0019ca30(0xc,FUN_0024fe50);
      }
    }
    if (DAT_005b7e64 != local_8) {
      DAT_005b894c = 0xe10;
      local_8 = DAT_005b7e64;
    }
    if ((DAT_005b8950 != 0) && (DAT_005b894c = DAT_005b894c + -1, DAT_005b894c < 1)) {
      FUN_00349d00(0);
      FUN_00028330(1);
      FUN_0019fb20();
      FUN_0019ca30(0,FUN_00027be0);
    }
    if (DAT_005b7a58 != 0) {
      FUN_001df1c0(0x23f2,1);
      DAT_005b7a58 = 0;
    }
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  } while( true );
}

