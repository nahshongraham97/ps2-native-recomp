
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0008a260(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int local_1c;
  int local_18;
  
  local_18 = 36000;
  FUN_0008a760();
  FUN_00232f60(0x20028,*(undefined4 *)(param_1 + 4),1);
  FUN_0023c8a0(4);
  DAT_007350c4 = 0x41f00000;
  (**(code **)(*DAT_007350c0 + 0x14))();
  FUN_0023c7c0();
  DAT_005b7b30 = FUN_0023c150(*(undefined4 *)(param_1 + 0x28));
  iVar1 = FUN_0027c790();
  if (iVar1 == 0) {
    local_1c = -0x40;
  }
  else {
    local_1c = (DAT_00831e1c + -0x280) / 2 + -0x40;
  }
  iVar1 = FUN_0009dfb0(0x20028,0x4002,*(undefined4 *)(param_1 + 0x10),0,local_1c,0x2a,0x1f);
  if (iVar1 != 0) {
    *(uint *)(iVar1 + 0xc) = *(uint *)(iVar1 + 0xc) | 8;
    if (iVar1 == 0) {
      DAT_00831df0 = 0;
      _DAT_00831df4 = 0;
    }
    else {
      _DAT_00831df4 = *(undefined4 *)(iVar1 + 4);
      DAT_00831df0 = iVar1;
    }
  }
  iVar1 = FUN_0009dfb0(0x20028,0x4003,*(undefined4 *)(param_1 + 0x14),0,local_1c + 0x200,0x2a,0x1f);
  if (iVar1 != 0) {
    *(uint *)(iVar1 + 0xc) = *(uint *)(iVar1 + 0xc) | 8;
    if (iVar1 == 0) {
      DAT_00831de8 = 0;
      _DAT_00831dec = 0;
    }
    else {
      _DAT_00831dec = *(undefined4 *)(iVar1 + 4);
      DAT_00831de8 = iVar1;
    }
  }
  if ((*(int *)(param_1 + 0x18) != 0) &&
     (iVar1 = FUN_0009dfb0(0x20028,0x4004,*(undefined4 *)(param_1 + 0x18),0,local_1c,0x2a,0x1f),
     iVar1 != 0)) {
    *(uint *)(iVar1 + 0xc) = *(uint *)(iVar1 + 0xc) | 8;
    if (iVar1 == 0) {
      DAT_00831de0 = 0;
      _DAT_00831de4 = 0;
    }
    else {
      _DAT_00831de4 = *(undefined4 *)(iVar1 + 4);
      DAT_00831de0 = iVar1;
    }
  }
  if ((*(int *)(param_1 + 0x1c) != 0) &&
     (iVar1 = FUN_0009dfb0(0x20028,0x4005,*(undefined4 *)(param_1 + 0x1c),0,local_1c + 0x200,0x2a,
                           0x1f), iVar1 != 0)) {
    *(uint *)(iVar1 + 0xc) = *(uint *)(iVar1 + 0xc) | 8;
    if (iVar1 == 0) {
      DAT_00831dd8 = 0;
      _DAT_00831ddc = 0;
    }
    else {
      _DAT_00831ddc = *(undefined4 *)(iVar1 + 4);
      DAT_00831dd8 = iVar1;
    }
  }
  if ((*(int *)(param_1 + 0x20) != 0) &&
     (iVar1 = FUN_0009dfb0(0x20028,0x4004,*(undefined4 *)(param_1 + 0x20),0,local_1c,0x2a,0x1f),
     iVar1 != 0)) {
    *(uint *)(iVar1 + 0xc) = *(uint *)(iVar1 + 0xc) | 8;
    if (iVar1 == 0) {
      DAT_00831dd0 = 0;
      _DAT_00831dd4 = 0;
    }
    else {
      _DAT_00831dd4 = *(undefined4 *)(iVar1 + 4);
      DAT_00831dd0 = iVar1;
    }
  }
  if ((*(int *)(param_1 + 0x24) != 0) &&
     (iVar1 = FUN_0009dfb0(0x20028,0x4005,*(undefined4 *)(param_1 + 0x24),0,local_1c + 0x200,0x2a,
                           0x1f), iVar1 != 0)) {
    *(uint *)(iVar1 + 0xc) = *(uint *)(iVar1 + 0xc) | 8;
    if (iVar1 == 0) {
      DAT_00831dc8 = 0;
      _DAT_00831dcc = 0;
    }
    else {
      _DAT_00831dcc = *(undefined4 *)(iVar1 + 4);
      DAT_00831dc8 = iVar1;
    }
  }
  uVar2 = FUN_001b05d0(0x170002,"endings.mko",0x10,1);
  FUN_00232b70(0x170002);
  uVar3 = FUN_001afa30(uVar2,*(undefined4 *)(param_1 + 8));
  FUN_0008b330(0x20a0,uVar2,uVar3);
  do {
    iVar1 = FUN_001c4870(0x20a0);
    if (iVar1 == 0) {
LAB_0008a6e5:
      FUN_0025a6f0(8,1);
      DAT_005b7b30 = 0;
      DAT_005b7b3c = 0;
      FUN_0009dc50(0x4002);
      FUN_0009dc50(0x4003);
      FUN_0009dc50(0x4004);
      FUN_0009dc50(0x4005);
      FUN_0009dc50(0x4004);
      FUN_0009dc50(0x4005);
      return;
    }
    iVar1 = FUN_0008b2f0();
    if ((iVar1 != 0) || (local_18 == 0)) {
      FUN_000a0b60();
      FUN_0025a6f0(8,1);
      if (DAT_008292f8 == 5) {
        FUN_000a0c30();
        FUN_001c4730(0x20a0);
        FUN_001c4730(0x9002);
        FUN_0023c5a0();
        goto LAB_0008a6e5;
      }
      if (param_2 == 0) {
        FUN_0019ca30(7,FUN_0008b550);
      }
      else {
        DAT_0082bd64 = 8;
        FUN_0019ca30(0xb,FUN_00113430);
      }
    }
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
    local_18 = local_18 + -1;
  } while( true );
}

