
void FUN_002455f0(int param_1,int param_2)

{
  undefined1 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int local_7c;
  int local_2c;
  
  puVar3 = (undefined4 *)FUN_00242b60();
  iVar4 = FUN_002421f0();
  switch(param_1) {
  case 0x9c41:
  case 0x9c42:
  case 0x9c43:
  case 0x9c44:
  case 0x9c45:
  case 0x9c46:
  case 0x9c47:
  case 0x9c48:
  case 0x9c49:
  case 0x9c4a:
  case 0x9c4b:
  case 0x9c4c:
  case 0x9c4d:
    param_1 = param_1 + -0x9c41;
    iVar4 = (&DAT_005bea00)[param_1 * 7];
    local_2c = 0;
    if (iVar4 != 0) {
      local_2c = *(int *)(iVar4 + *(int *)(param_2 + 0xc) * 4);
    }
    if (puVar3[param_1 * 2 + 2] != local_2c) {
      if (iVar4 != 0) {
        puVar3[param_1 * 2 + 1] = local_2c;
      }
      puVar3[param_1 * 2 + 2] = local_2c;
      FUN_00246ae0(puVar3,param_1);
      FUN_0033d050(0x92888,1,0);
      FUN_00243890(param_1);
    }
    FUN_00246210(puVar3);
    break;
  case 0x9c50:
    puVar3[0x7d] = (uint)*(byte *)(iVar4 + 0xa4 + *(int *)(param_2 + 0xc) * 2);
    FUN_00246c60(puVar3);
    iVar5 = FUN_00244910(*(undefined4 *)(iVar4 + 0x7b8));
    *(undefined4 *)(iVar4 + 0x7e4) = *(undefined4 *)(iVar5 + 0xc + puVar3[0x7d] * 0x10);
    FUN_00246210(puVar3);
    FUN_00243890(0xffffffff);
    DAT_005bebc0 = 1;
    FUN_001df1c0(0x92888,0);
    break;
  case 0x9c51:
    puVar3[0x7e] = *(undefined4 *)(param_2 + 0xc);
    if ((*(int *)(iVar4 + 0x7e8) == 0x9c51) && (*(int *)(iVar4 + 0x9f0) == puVar3[0x7e])) {
      puVar7 = (undefined4 *)(iVar4 + 0x9f8);
      puVar8 = puVar3;
      for (iVar5 = 0x7f; puVar8 = puVar8 + 1, iVar5 != 0; iVar5 = iVar5 + -1) {
        *puVar8 = *puVar7;
        puVar7 = puVar7 + 1;
      }
    }
    else {
      FUN_00247050();
      FUN_00246c60(puVar3);
      FUN_00245dd0(0);
      FUN_0023c8a0(8);
      iVar5 = FUN_00244910(*(undefined4 *)(iVar4 + 0x7b8));
      *(undefined4 *)(iVar4 + 0x7e4) = *(undefined4 *)(iVar5 + 0xc + puVar3[0x7d] * 0x10);
    }
    FUN_00246210(puVar3);
    FUN_00243890(0xffffffff);
    FUN_001df1c0(0x92888,0);
    break;
  case 0x9c52:
    puVar3[0x7f] = *(undefined4 *)(param_2 + 0xc);
    FUN_00245e30(DAT_00831b1c,DAT_00831b20);
    FUN_001de7e0();
    break;
  case 0x9cf9:
  case 0x9cfa:
  case 0x9cfb:
  case 0x9cfc:
  case 0x9cfd:
  case 0x9cfe:
    uVar6 = (uint)*(byte *)(iVar4 + *(int *)(param_2 + 0xc) + 0x55c);
    FUN_002568b0(1);
    FUN_00243890(1000);
    FUN_00248ce0();
    puVar3[*(int *)(iVar4 + 0x20) * 8 + 0xbf] = uVar6;
    if ((*(uint *)(uVar6 * 0x28 + *(int *)(DAT_005bf19c + 0x1c) + 0xc) & 1) == 0) {
      puVar3[*(int *)(iVar4 + 0x20) * 8 + 0xc0] = 0;
    }
    else {
      puVar3[*(int *)(iVar4 + 0x20) * 8 + 0xc0] = 1;
    }
    FUN_00246030(puVar3,*(undefined4 *)(iVar4 + 0x20));
    FUN_00242650();
    FUN_00242960();
    break;
  case 0x9d08:
    if (DAT_005bf19c != 0) {
      uVar1 = *(undefined1 *)(iVar4 + *(int *)(param_2 + 0xc) + 0x8c);
      FUN_002568b0(1);
      *(undefined1 *)(iVar4 + 0x2c) = uVar1;
      *(undefined2 *)(iVar4 + 0x2e) = 0;
      FUN_00248d90();
    }
    break;
  case 0x9d09:
    *(undefined4 *)(iVar4 + 0x1c) = *(undefined4 *)(param_2 + 0xc);
    *(undefined4 *)(iVar4 + 0x2c) = puVar3[*(int *)(iVar4 + 0x1c) + 0x80];
    FUN_00247460(1);
    break;
  case 0x9d0a:
    *(undefined2 *)(iVar4 + 0x2e) = *(undefined2 *)(iVar4 + 0xa4 + *(int *)(param_2 + 0xc) * 2);
    FUN_00247460(1);
    break;
  case 0x9d0d:
    uVar2 = *(undefined4 *)(iVar4 + 0x720 + *(int *)(param_2 + 0xc) * 4);
    *(undefined4 *)(iVar4 + 0x7a8) = uVar2;
    puVar3[0xb7] = uVar2;
    FUN_00243890(0xffffffff);
    break;
  case 0x9d0e:
    puVar3[0xb9] = (uint)*(byte *)(iVar4 + *(int *)(param_2 + 0xc) + 0x6f0);
    FUN_00245dd0(1);
    FUN_0023c8a0(8);
    iVar4 = puVar3[0xb9] * 3 + DAT_005bf230;
    FUN_0023c570(DAT_005bf1a0);
    DAT_005bf1a0 = FUN_0023c150(iVar4 + 0xb05aa);
    if (DAT_005bf230 < 2) {
      local_7c = DAT_005bf230 + 1;
    }
    else {
      local_7c = 0;
    }
    DAT_005bf230 = local_7c;
    break;
  case 0x9d0f:
    puVar3[0xb8] = *(undefined4 *)(param_2 + 0xc);
    FUN_00247460(1);
    break;
  case 0x9d11:
    *(undefined4 *)(iVar4 + 0x1c) = *(undefined4 *)(param_2 + 0xc);
    *(undefined4 *)(iVar4 + 0x2c) = puVar3[*(int *)(iVar4 + 0x1c) + 0x9b];
    FUN_00247460(1);
    break;
  case 0x9d15:
    puVar3[0x99] = (uint)*(byte *)(iVar4 + *(int *)(param_2 + 0xc) + 0x3c8);
    while (iVar4 = FUN_001c4870(0x9004), iVar4 != 0) {
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    FUN_00248d90();
    break;
  case 0x9d16:
    puVar3[0xb4] = (uint)*(byte *)(iVar4 + *(int *)(param_2 + 0xc) + 0x3c8);
    while (iVar4 = FUN_001c4870(0x9004), iVar4 != 0) {
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
    FUN_00248d90();
    break;
  case 0x9d1a:
    puVar3[0xb6] = *(undefined4 *)(param_2 + 0xc);
    FUN_00247290();
    FUN_00243890(0xffffffff);
    FUN_00248d90();
    break;
  case 0x9d1b:
    if (puVar3[0x9a] != *(int *)(param_2 + 0xc)) {
      puVar3[0x9a] = *(undefined4 *)(param_2 + 0xc);
      FUN_002470f0(puVar3,0);
      FUN_00248000();
    }
    break;
  case 0x9d1c:
    if (puVar3[0xb5] != (uint)*(byte *)(iVar4 + *(int *)(param_2 + 0xc) + 0x708)) {
      puVar3[0xb5] = (uint)*(byte *)(iVar4 + *(int *)(param_2 + 0xc) + 0x708);
      FUN_002470f0(puVar3,1);
      FUN_00243890(0x3e6);
    }
  }
  return;
}

