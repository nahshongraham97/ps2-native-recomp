
void FUN_0023bbc0(int param_1)

{
  int iVar1;
  
  iVar1 = DAT_005be3c4 + -1;
  DAT_005be3c4 = iVar1;
  if (iVar1 != param_1) {
    _memmove(&DAT_00723ac0 + param_1 * 3,&DAT_00723ac0 + (param_1 + 1) * 3,iVar1 - param_1);
  }
  (&DAT_00723ac0)[iVar1 * 3] = 0;
  (&DAT_00723ac4)[iVar1 * 3] = 0;
  *(undefined4 *)(&DAT_00723ac8 + iVar1 * 0xc) = 0;
  return;
}

