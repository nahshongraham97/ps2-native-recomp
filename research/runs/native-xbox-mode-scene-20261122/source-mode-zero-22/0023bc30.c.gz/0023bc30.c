
uint FUN_0023bc30(int param_1)

{
  return (param_1 - 0x723ac0U) / 0xc;
}

