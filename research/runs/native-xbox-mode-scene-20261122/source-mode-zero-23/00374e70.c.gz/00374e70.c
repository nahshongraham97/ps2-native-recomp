
void FUN_00374e70(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_0037db00(&DAT_00707860,param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_0037dad0(0,iVar1);
    FUN_00374820(uVar2);
  }
  return;
}

