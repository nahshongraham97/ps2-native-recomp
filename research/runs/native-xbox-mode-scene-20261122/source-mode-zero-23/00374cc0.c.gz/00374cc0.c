
undefined4 FUN_00374cc0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  
  iVar1 = FUN_0037db00(&DAT_00707860,param_1);
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    piVar3 = (int *)FUN_0037dad0(0,iVar1);
    if (((piVar3 == (int *)0x0) || (*piVar3 == 0)) || (*(int *)(*piVar3 + 8) == 0)) {
      uVar2 = 0;
    }
    else {
      uVar2 = 1;
    }
  }
  return uVar2;
}

