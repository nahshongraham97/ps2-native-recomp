
void FUN_000e66c0(void)

{
  int iVar1;
  uint *puVar2;
  uint local_3c;
  uint local_38;
  uint local_34;
  uint local_30;
  int local_1c [6];
  
  puVar2 = DAT_005b8334;
  local_1c[1] = 0;
  local_1c[2] = 1;
  local_1c[3] = 3;
  local_1c[4] = 6;
  local_1c[0] = 0;
  if (((*DAT_005b8334 >> 6 & 1) == 0) && ((DAT_00831a44 >> 2 & 1) == 0)) {
    if (DAT_005b8334[6] != 0) {
      if ((*DAT_005b8334 >> 0xc & 1) == 0) {
        iVar1 = local_1c[DAT_005b8334[0x1b]];
        for (local_1c[5] = 0; local_1c[5] < (int)puVar2[0x1b]; local_1c[5] = local_1c[5] + 1) {
          for (; local_1c[0] < 4; local_1c[0] = local_1c[0] + 1) {
            if ((&DAT_00831af4)[local_1c[0] * 0x12] == 2) {
              if (puVar2[local_1c[0] * 2 + 0x93] == 0) {
                local_3c = 0;
              }
              else {
                if (*(uint *)(puVar2[local_1c[0] * 2 + 0x93] + 4) == puVar2[local_1c[0] * 2 + 0x94])
                {
                  local_38 = puVar2[local_1c[0] * 2 + 0x93];
                }
                else {
                  local_38 = 0;
                }
                local_3c = local_38;
              }
              if (local_3c == 0) {
                return;
              }
              (*(code *)(&PTR_FUN_0054ed5c)[iVar1 + local_1c[5]])(local_3c);
              local_1c[0] = local_1c[0] + 1;
              break;
            }
          }
        }
      }
      else {
        if (DAT_005b8334[DAT_005ea35c * 2 + 0x93] == 0) {
          local_34 = 0;
        }
        else {
          if (*(uint *)(DAT_005b8334[DAT_005ea35c * 2 + 0x93] + 4) ==
              DAT_005b8334[DAT_005ea35c * 2 + 0x94]) {
            local_30 = DAT_005b8334[DAT_005ea35c * 2 + 0x93];
          }
          else {
            local_30 = 0;
          }
          local_34 = local_30;
        }
        if (local_34 == 0) {
          return;
        }
        FUN_000c4e70(local_34);
      }
      if (2 < (int)puVar2[0x1b]) {
        puVar2[0x65] = 0xffffffff;
      }
    }
  }
  else {
    *DAT_005b8334 = *DAT_005b8334 & 0xffffff7f;
  }
  return;
}

