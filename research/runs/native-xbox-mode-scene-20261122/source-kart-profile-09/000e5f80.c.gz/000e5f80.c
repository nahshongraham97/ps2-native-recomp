
void FUN_000e5f80(void)

{
  uint uVar1;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 *local_14;
  uint *local_10;
  uint local_c;
  int local_8;
  
  local_10 = DAT_005b8334;
  local_c = DAT_005b8334[5];
  local_8 = 0;
  FUN_001b0c90(DAT_005b8334[3]);
  if ((*local_10 >> 2 & 1) == 0) {
    FUN_001b0c90(local_10[4]);
  }
  FUN_001b20e0(&PTR_PTR_004ed6c8);
  uVar1 = FUN_001b04c0(0x1300d9,&PTR_s_kart_core_mko_0055ab68,0x10,1);
  local_10[3] = uVar1;
  FUN_00232b70(0x1300d9);
  if ((local_10[3] != 0) && (local_c = FUN_001af510(local_10[3],0x35), local_c != 0)) {
    local_10[5] = local_c;
    uVar1 = FUN_001af510(local_10[3],0x3d);
    local_10[6] = uVar1;
    if ((local_10[6] != 0) && ((*local_10 >> 2 & 1) == 0)) {
      uVar1 = FUN_001b04c0(0x1300d9,&PTR_s_kart_fx_mko_0055ab74,0x11,1);
      local_10[4] = uVar1;
      FUN_00232b70(0x1300d9);
      if ((local_10[4] != 0) &&
         (local_14 = *(undefined4 **)(local_c + 0xc), local_14 != (undefined4 *)0x0)) {
        local_1c = 0;
        local_24 = 0x1300d4;
        local_20 = 0x1300d9;
        local_18 = 0;
        FUN_001ebf20(*local_14,&local_24);
        local_8 = (1 < (int)local_10[0x1b]) + 1;
        FUN_001ebf20(local_14[local_8],&local_24);
        *local_10 = *local_10 | 4;
      }
    }
  }
  return;
}

