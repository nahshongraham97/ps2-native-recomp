
void FUN_000e4b70(void)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  int local_8;
  
  DAT_005b8334 = (uint *)FUN_001b66c0(0x107c);
  if (DAT_005b8334 == (uint *)0x0) {
    FUN_001c49a0(DAT_007350c0,FUN_000f50f0);
  }
  else {
    puVar3 = DAT_005b8334;
    for (iVar2 = 0x41f; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    if (DAT_007350c0 == 0) {
      DAT_005b8334[1] = 0;
      DAT_005b8334[2] = 0;
    }
    else {
      DAT_005b8334[1] = DAT_007350c0;
      DAT_005b8334[2] = *(uint *)(DAT_007350c0 + 4);
    }
    uVar1 = FUN_0027c7c0();
    DAT_005b8334[0xc] = uVar1;
    FUN_000e5280();
    FUN_000e56a0();
    FUN_000e4e70();
    FUN_001b20e0(&PTR_PTR_004ed6c8);
    FUN_001b0350(0x1300d9,2,"kart_strings_eng.mko",0);
    FUN_000e7150(1);
    FUN_000e9300();
    uVar1 = FUN_00027230(0x1300d4,"FROZEN");
    DAT_005b8334[0x3b7] = uVar1;
    if (DAT_005b8334[0x3b7] != 0) {
      for (local_8 = 0; local_8 < 2; local_8 = local_8 + 1) {
        uVar1 = FUN_001999f0(&DAT_0054df7c,&DAT_00735124,0);
        if (uVar1 != 0) {
          if (uVar1 == 0) {
            DAT_005b8334[local_8 * 2 + 0x3b8] = 0;
            DAT_005b8334[local_8 * 2 + 0x3b9] = 0;
          }
          else {
            DAT_005b8334[local_8 * 2 + 0x3b8] = uVar1;
            DAT_005b8334[local_8 * 2 + 0x3b9] = *(uint *)(uVar1 + 4);
          }
          if (local_8 != 0) {
            *(float *)(uVar1 + 0xf4) = *(float *)(uVar1 + 0xf4) + DAT_004d85ac;
          }
        }
      }
    }
    uVar1 = FUN_0007d6a0();
    DAT_005b8334[0x1b] = uVar1;
    if ((DAT_005b8334[0x1b] == 1) &&
       (uVar1 = FUN_001999f0(&DAT_0054ea84,&DAT_0073510c,0), uVar1 != 0)) {
      *(undefined4 *)(uVar1 + 0xc4) = 0xc61c4000;
      if (uVar1 == 0) {
        DAT_005b8334[0x3b0] = 0;
        DAT_005b8334[0x3b1] = 0;
      }
      else {
        DAT_005b8334[0x3b0] = uVar1;
        DAT_005b8334[0x3b1] = *(uint *)(uVar1 + 4);
      }
    }
    FUN_000e5a90();
    FUN_000e68e0();
    *DAT_005b8334 = *DAT_005b8334 & 0xffffefff | (DAT_00831a44 & 1) << 0xc;
    if ((1 < (int)DAT_005b8334[0x1b]) || ((*DAT_005b8334 >> 0xc & 1) != 0)) {
      *DAT_005b8334 = *DAT_005b8334 | 0x80;
    }
    *DAT_005b8334 = *DAT_005b8334 | 0x100000;
    *DAT_005b8334 = *DAT_005b8334 & 0xfff7ffff;
  }
  return;
}

