
void FUN_000e5a90(void)

{
  int iVar1;
  undefined4 uVar2;
  int local_14;
  int local_c;
  
  iVar1 = DAT_005b8334;
  for (local_14 = 0; local_14 < 4; local_14 = local_14 + 1) {
    (&DAT_00831af0)[local_14 * 0x12] = local_14;
  }
  *(undefined **)(iVar1 + 0x104c) = &DAT_00731460;
  *(undefined **)(iVar1 + 0x1050) = &DAT_0072de60;
  *(undefined4 **)(iVar1 + 0x105c) = &DAT_00731448;
  *(undefined4 **)(iVar1 + 0x1060) = &DAT_0072de48;
  *(undefined **)(iVar1 + 0x1054) = &DAT_0072a860;
  *(undefined **)(iVar1 + 0x1058) = &DAT_00727260;
  *(undefined4 **)(iVar1 + 0x1064) = &DAT_0072a848;
  *(undefined4 **)(iVar1 + 0x1068) = &DAT_00727248;
  local_c = 0;
  for (local_14 = 0; local_14 < 4; local_14 = local_14 + 1) {
    if (**(int **)(iVar1 + 0x105c + local_14 * 4) == 1) {
      *(int *)(iVar1 + 0x106c + local_c * 4) = local_14;
      local_c = local_c + 1;
    }
  }
  for (; local_c < 4; local_c = local_c + 1) {
    *(undefined4 *)(iVar1 + 0x106c + local_c * 4) = 0xffffffff;
  }
  uVar2 = FUN_0025d280();
  *(undefined4 *)(iVar1 + 0x3c) = uVar2;
  uVar2 = FUN_0025d2d0();
  *(undefined4 *)(iVar1 + 0x40) = uVar2;
  return;
}

