
void FUN_000e4e70(void)

{
  uint *puVar1;
  uint uVar2;
  undefined4 local_3c;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  int *local_10;
  int local_c;
  int local_8;
  
  puVar1 = DAT_005b8334;
  local_14 = *(int *)(DAT_00831a4c + 0xac);
  local_30 = 0;
  local_2c = 0;
  local_28 = 0;
  local_24 = 0x3f800000;
  local_20 = 0x3f800000;
  local_1c = 0x3f800000;
  local_c = FUN_0007d6a0();
  if (local_c < 2) {
    local_3c = *(undefined4 *)(local_14 + 4);
  }
  else {
    local_3c = *(undefined4 *)(local_14 + 8);
  }
  local_18 = local_3c;
  *(uint *)(DAT_00831a6c + 0x30) = *(uint *)(DAT_00831a6c + 0x30) ^ 8;
  uVar2 = FUN_000327f0(local_3c,&DAT_004dd8f0,0x6029,0,&local_30,&local_30,&local_24);
  if (uVar2 == 0) {
    *puVar1 = *puVar1 | 0x20;
  }
  else {
    if (uVar2 == 0) {
      puVar1[0xb0] = 0;
      puVar1[0xb1] = 0;
    }
    else {
      puVar1[0xb0] = uVar2;
      puVar1[0xb1] = *(uint *)(uVar2 + 4);
    }
    *(undefined4 *)(uVar2 + 0xc) = 0;
    *(undefined4 *)(uVar2 + 0x30) = *(undefined4 *)(DAT_00831a6c + 0x30);
    FUN_001bada0(uVar2);
    for (local_10 = (int *)FUN_001c6d00(uVar2 + 0x94); local_10 != (int *)0x0;
        local_10 = (int *)FUN_001c6d70(local_10)) {
      local_8 = *local_10;
      *(uint *)(local_8 + 8) = *(uint *)(local_8 + 8) | 0x800;
      *(uint *)(local_8 + 8) = *(uint *)(local_8 + 8) | 0x2000;
      if ((*(uint *)(local_8 + 0xc) & 0x80000000) == 0) {
        FUN_001b6ba0(local_8,0xc);
      }
      else {
        FUN_001b6ba0(local_8,0xd);
      }
    }
    FUN_001baf40(DAT_00831a6c,0);
    for (local_10 = (int *)FUN_001c6d00(DAT_00831a6c + 0x94); local_10 != (int *)0x0;
        local_10 = (int *)FUN_001c6d70(local_10)) {
      local_8 = *local_10;
      *(uint *)(local_8 + 8) = *(uint *)(local_8 + 8) & 0xffffdfff;
    }
    uVar2 = FUN_000327f0(local_18,"ROADLOD",0x602a,0,&local_30,&local_30,&local_24);
    if (uVar2 == 0) {
      *puVar1 = *puVar1 | 0x20;
    }
    else {
      if (uVar2 == 0) {
        puVar1[0xb2] = 0;
        puVar1[0xb3] = 0;
      }
      else {
        puVar1[0xb2] = uVar2;
        puVar1[0xb3] = *(uint *)(uVar2 + 4);
      }
      *(undefined4 *)(uVar2 + 0xc) = 0;
      *(undefined4 *)(uVar2 + 0x30) = *(undefined4 *)(DAT_00831a6c + 0x30);
      FUN_001bada0(uVar2);
      for (local_10 = (int *)FUN_001c6d00(uVar2 + 0x94); local_10 != (int *)0x0;
          local_10 = (int *)FUN_001c6d70(local_10)) {
        local_8 = *local_10;
        *(uint *)(local_8 + 8) = *(uint *)(local_8 + 8) & 0xffffdfff;
        FUN_001b6ba0(local_8,0xc);
      }
      uVar2 = FUN_000327f0(local_18,"ARENALOD",0x602b,0,&local_30,&local_30,&local_24);
      if (uVar2 == 0) {
        *puVar1 = *puVar1 | 0x20;
      }
      else {
        if (uVar2 == 0) {
          puVar1[0xb4] = 0;
          puVar1[0xb5] = 0;
        }
        else {
          puVar1[0xb4] = uVar2;
          puVar1[0xb5] = *(uint *)(uVar2 + 4);
        }
        *(undefined4 *)(uVar2 + 0xc) = 0;
        *(undefined4 *)(uVar2 + 0x30) = *(undefined4 *)(DAT_00831a6c + 0x30);
        FUN_001bada0(uVar2);
        for (local_10 = (int *)FUN_001c6d00(uVar2 + 0x94); local_10 != (int *)0x0;
            local_10 = (int *)FUN_001c6d70(local_10)) {
          local_8 = *local_10;
          *(uint *)(local_8 + 8) = *(uint *)(local_8 + 8) & 0xffffdfff;
          FUN_001b6ba0(local_8,4);
        }
      }
    }
  }
  return;
}

