
int FUN_001b04c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_001ada80(param_3);
  if (iVar1 == 0) {
    uVar2 = FUN_001b0710(param_1,param_2,1,param_4);
    iVar1 = FUN_001b0520(param_1,uVar2,param_3);
  }
  else {
    DAT_005b89c0 = 0;
  }
  return iVar1;
}

