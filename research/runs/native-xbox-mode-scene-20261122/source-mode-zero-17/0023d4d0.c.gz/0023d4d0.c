
void FUN_0023d4d0(undefined4 param_1)

{
  int iVar1;
  int local_8;
  
  for (local_8 = 0; local_8 < 0x158; local_8 = local_8 + 1) {
    if ((*(int *)(&DAT_00568c18 + local_8 * 0x28) != 0) ||
       (*(int *)(&DAT_00568c1c + local_8 * 0x28) == 1)) {
      iVar1 = FUN_0023d540(local_8,param_1);
      if (iVar1 == 0) {
        FUN_0023d230(local_8);
      }
    }
  }
  return;
}

