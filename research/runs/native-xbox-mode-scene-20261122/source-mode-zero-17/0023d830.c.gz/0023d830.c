
void FUN_0023d830(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined *puVar3;
  undefined4 uVar4;
  int local_8;
  
  uVar4 = 0xffffffff;
  puVar3 = (&PTR_DAT_0056c940)[param_1 * 9];
  iVar1 = *(int *)(&DAT_0056c944 + param_1 * 0x24);
  uVar2 = 0;
  for (local_8 = 0; local_8 < iVar1; local_8 = local_8 + 1) {
    uVar4 = FUN_0023ca10(*(undefined4 *)(puVar3 + local_8 * 0xc),
                         *(undefined4 *)(puVar3 + local_8 * 0xc),iVar1,uVar2,puVar3,uVar4);
    uVar2 = *(undefined4 *)(puVar3 + local_8 * 0xc + 4);
    FUN_0023d8d0(uVar4,uVar2);
  }
  return;
}

