
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_000f1330(void)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int local_198;
  int local_194;
  int local_190;
  int local_18c;
  int local_188;
  int local_184;
  int local_180;
  int local_17c;
  int local_178;
  int local_174;
  int local_170;
  int local_16c;
  int local_168;
  int local_164;
  int local_160;
  int local_15c;
  int local_150;
  char local_14c [84];
  undefined4 local_f8;
  int local_f4;
  byte local_ed;
  int local_ec;
  int local_e8;
  int local_e4;
  int local_e0;
  int local_dc;
  int local_d8;
  int local_d4;
  float local_d0;
  int local_cc;
  int local_c8;
  int local_c4;
  int local_c0;
  int local_bc;
  int local_b8 [8];
  undefined4 local_98 [8];
  int local_78;
  char *local_74;
  int local_70;
  float local_6c [8];
  int local_4c;
  undefined4 local_48;
  char *local_44;
  undefined1 local_40;
  undefined1 local_3f;
  undefined1 local_3e;
  undefined1 local_3d;
  int local_3c;
  int local_38;
  int local_34;
  uint local_30;
  uint local_2c;
  int *local_28;
  int local_24;
  int local_20;
  int local_1c;
  int local_18;
  int local_14;
  int local_10;
  int local_c;
  int local_8;
  
  local_f8 = DAT_005af7d0;
  local_cc = DAT_005b8334;
  local_c = *(int *)(DAT_005b8334 + 0x18);
  local_3c = *(int *)(DAT_00831a4c + 0xac);
  local_20 = DAT_00831e1c;
  local_18 = DAT_00831e18;
  local_d4 = 0;
  local_48 = 0;
  local_28 = *(int **)(DAT_005b8334 + 0x14);
  local_44 = (char *)FUN_001b02e0(2,2);
  local_74 = (char *)FUN_001b02e0(2,7);
  local_70 = -1;
  local_c0 = *(int *)(local_cc + 0xeb4);
  if ((local_44 == (char *)0x0) || (*local_44 == '\0')) {
    local_44 = "WINS!";
  }
  if ((local_74 == (char *)0x0) || (*local_74 == '\0')) {
    local_74 = "PLAYER %d";
  }
  if (DAT_005bfa64 != 0) {
    local_20 = 0x500;
    local_18 = 0x2d0;
  }
  for (local_24 = 0; local_24 < 8; local_24 = local_24 + 1) {
    if (*(int *)(local_cc + 0x24c + local_24 * 8) == 0) {
      local_160 = 0;
    }
    else {
      if (*(int *)(*(int *)(local_cc + 0x24c + local_24 * 8) + 4) ==
          *(int *)(local_cc + 0x250 + local_24 * 8)) {
        local_15c = *(int *)(local_cc + 0x24c + local_24 * 8);
      }
      else {
        local_15c = 0;
      }
      local_160 = local_15c;
    }
    local_38 = local_160;
    if (local_160 == 0) {
      local_b8[local_24] = -1;
    }
    else {
      local_b8[local_24] = local_24;
      if ((*(int *)(local_38 + 0xbc) < 0) || (local_c0 < 1)) {
        local_98[local_24] = 0;
        local_6c[local_24] = *(float *)(local_38 + 200) + _DAT_004dd92c;
      }
      else {
        uVar2 = FUN_000efd70(local_38);
        local_98[local_24] = uVar2;
        local_6c[local_24] = *(float *)(local_38 + 200);
      }
    }
  }
  if (*(int *)(local_3c + 0x40) == 1) {
    FUN_000efb90(local_b8,local_98,local_6c);
  }
  for (local_24 = 0; local_24 < 8; local_24 = local_24 + 1) {
    if (*(int *)(local_3c + 0x40) == 1) {
      *(int *)(local_cc + 0x29c + local_24 * 4) = local_b8[local_24];
    }
    else {
      *(int *)(local_cc + 0x29c + local_24 * 4) = local_24;
    }
  }
  for (local_24 = 0; local_24 < 8; local_24 = local_24 + 1) {
    local_e0 = *(int *)(local_cc + 0x29c + local_24 * 4);
    if (-1 < local_e0) {
      if (*(int *)(local_cc + 0x24c + local_e0 * 8) == 0) {
        local_168 = 0;
      }
      else {
        if (*(int *)(*(int *)(local_cc + 0x24c + local_e0 * 8) + 4) ==
            *(int *)(local_cc + 0x250 + local_e0 * 8)) {
          local_164 = *(int *)(local_cc + 0x24c + local_e0 * 8);
        }
        else {
          local_164 = 0;
        }
        local_168 = local_164;
      }
      local_38 = local_168;
      if (local_168 != 0) {
        if (*(int *)(local_168 + 0x254) == 0) {
          local_170 = 0;
        }
        else {
          if (*(int *)(*(int *)(local_168 + 0x254) + 4) == *(int *)(local_168 + 600)) {
            local_16c = *(int *)(local_168 + 0x254);
          }
          else {
            local_16c = 0;
          }
          local_170 = local_16c;
        }
        local_bc = local_170;
        if ((local_170 != 0) && (local_8 = FUN_001c4d20(local_170), local_8 != 0)) {
          if (*(int *)(local_cc + 0x29c) == *(int *)(local_38 + 0x20)) {
            FUN_00104ae0(*(undefined4 *)(local_38 + 0x1bc));
          }
          else {
            FUN_00104b80(*(undefined4 *)(local_38 + 0x1bc));
          }
          if (*(int *)(local_cc + 0x6c) < 2) {
            for (local_14 = 0; local_14 < 8; local_14 = local_14 + 1) {
              if (*(int *)(local_cc + 0x29c + local_14 * 4) == *(int *)(local_38 + 0x20)) {
                local_d4 = local_14;
                local_48 = *(undefined4 *)(local_38 + 0x20);
              }
            }
          }
        }
      }
    }
  }
  if (*(int *)(local_cc + 0x28c) == 0) {
    local_178 = 0;
  }
  else {
    if (*(int *)(*(int *)(local_cc + 0x28c) + 4) == *(int *)(local_cc + 0x290)) {
      local_174 = *(int *)(local_cc + 0x28c);
    }
    else {
      local_174 = 0;
    }
    local_178 = local_174;
  }
  local_38 = local_178;
  if (local_178 == 0) {
    FUN_0023de30();
    for (local_24 = 0; local_24 < 8; local_24 = local_24 + 1) {
      if (*(int *)(local_cc + 0x24c + local_24 * 8) == 0) {
        local_180 = 0;
      }
      else {
        if (*(int *)(*(int *)(local_cc + 0x24c + local_24 * 8) + 4) ==
            *(int *)(local_cc + 0x250 + local_24 * 8)) {
          local_17c = *(int *)(local_cc + 0x24c + local_24 * 8);
        }
        else {
          local_17c = 0;
        }
        local_180 = local_17c;
      }
      local_38 = local_180;
      if (local_180 == 0) {
        FUN_000f2370(0,6);
      }
    }
  }
  else {
    local_70 = *(int *)(*(int *)(local_178 + 0x2c) + 0x10);
    local_dc = DAT_00831e1c >> 1;
    iVar3 = FUN_0027c790();
    if (iVar3 != 0) {
      local_dc = local_dc + *(int *)(local_c + 0xa8);
    }
    local_30 = FUN_00398614();
    local_c8 = *(int *)(local_c + 4) + 0x71c;
    local_10 = DAT_00831e18 - *(int *)(*(int *)(local_c + 4) + 0x724);
    if (*(int *)(local_cc + 0x140 + *(int *)(local_38 + 0x20) * 4) == 0) {
      _sprintf(&DAT_005b82e0,local_74,*(int *)(local_38 + 0x20) + 1);
    }
    else {
      _sprintf(&DAT_005b82e0,"%s",*(undefined4 *)(local_cc + 0x140 + *(int *)(local_38 + 0x20) * 4))
      ;
    }
    local_c4 = FUN_000935c0(0x603d,0xb,&DAT_005b82e0,local_dc,local_10,0x36);
    _sprintf(&DAT_005b82e0,local_44);
    local_c8 = *(int *)(local_c + 4) + 0x738;
    local_10 = DAT_00831e18 - *(int *)(*(int *)(local_c + 4) + 0x740);
    local_34 = FUN_000935c0(0x603e,0xb,&DAT_005b82e0,local_dc,local_10,0x36);
    if ((local_c4 != 0) && (local_34 != 0)) {
      local_4c = FUN_000c5630(0x3f,0x1300d4,0x602e,0x3c);
      if ((local_4c != 0) &&
         (local_e8 = FUN_001c2770(0x20ac,0x20,FUN_000f34a0,0x30,&local_e4), local_e8 != 0)) {
        if ((local_34 != 0) && (local_c4 != 0)) {
          local_3e = DAT_0054ea7c;
          local_3f = DAT_0054ea7d;
          local_40 = DAT_0054ea7e;
          local_3d = 0;
          FUN_00369d80(local_34 + 0x3c,&local_40);
          FUN_00369d80(local_c4 + 0x3c,&local_40);
          if (local_c4 == 0) {
            *(undefined4 *)(local_e4 + 0x18) = 0;
            *(undefined4 *)(local_e4 + 0x1c) = 0;
          }
          else {
            *(int *)(local_e4 + 0x18) = local_c4;
            *(undefined4 *)(local_e4 + 0x1c) = *(undefined4 *)(local_c4 + 4);
          }
          if (local_34 == 0) {
            *(undefined4 *)(local_e4 + 0x10) = 0;
            *(undefined4 *)(local_e4 + 0x14) = 0;
          }
          else {
            *(int *)(local_e4 + 0x10) = local_34;
            *(undefined4 *)(local_e4 + 0x14) = *(undefined4 *)(local_34 + 4);
          }
        }
        *(undefined4 *)(local_4c + 0x28) = 0x3e800000;
        *(undefined4 *)(local_4c + 0x2c) = 0x3e800000;
        if (1 < *(int *)(local_cc + 0x6c)) {
          *(int *)(local_4c + 0x14) = local_20 / 2 - *(int *)(*(int *)(local_4c + 0x34) + 0x54) / 2;
          *(int *)(local_4c + 0x18) = local_18 / 2 - *(int *)(*(int *)(local_4c + 0x34) + 0x58) / 2;
          if ((local_34 != 0) && (local_c4 != 0)) {
            *(int *)(local_c4 + 0x2c) = *(int *)(local_4c + 0x18) + 0x5f;
            *(int *)(local_34 + 0x2c) = *(int *)(local_4c + 0x18) + -5;
          }
        }
        *(undefined4 *)(local_e4 + 0x20) = *(undefined4 *)(local_4c + 0x14);
        *(undefined4 *)(local_e4 + 0x24) = *(undefined4 *)(local_4c + 0x18);
        *(int *)(local_e4 + 0x28) = local_d4;
        *(undefined4 *)(local_e4 + 0x2c) = local_48;
        if (local_4c == 0) {
          *(undefined4 *)(local_e4 + 8) = 0;
          *(undefined4 *)(local_e4 + 0xc) = 0;
        }
        else {
          *(int *)(local_e4 + 8) = local_4c;
          *(undefined4 *)(local_e4 + 0xc) = *(undefined4 *)(local_4c + 4);
        }
      }
      local_14 = -1;
      if (*(int *)(local_38 + 0x254) == 0) {
        local_188 = 0;
      }
      else {
        if (*(int *)(*(int *)(local_38 + 0x254) + 4) == *(int *)(local_38 + 600)) {
          local_184 = *(int *)(local_38 + 0x254);
        }
        else {
          local_184 = 0;
        }
        local_188 = local_184;
      }
      local_bc = local_188;
      if (((local_188 != 0) && (local_8 = FUN_001c4d20(local_188), local_8 != 0)) &&
         (local_d8 = FUN_00057320(*(undefined4 *)(local_8 + 0x90)), local_d8 != 0)) {
        local_14 = *(int *)(local_38 + 0x20);
      }
      if (local_14 < 0) {
        FUN_0023de30();
      }
      else {
        FUN_0023dec0();
      }
      for (local_24 = 0; local_24 < 8; local_24 = local_24 + 1) {
        if (*(int *)(local_cc + 0x24c + local_24 * 8) == 0) {
          local_190 = 0;
        }
        else {
          if (*(int *)(*(int *)(local_cc + 0x24c + local_24 * 8) + 4) ==
              *(int *)(local_cc + 0x250 + local_24 * 8)) {
            local_18c = *(int *)(local_cc + 0x24c + local_24 * 8);
          }
          else {
            local_18c = 0;
          }
          local_190 = local_18c;
        }
        local_38 = local_190;
        if (local_190 != 0) {
          if (*(int *)(local_190 + 0x20) == local_14) {
            FUN_000f2370(local_190,5);
          }
          else {
            FUN_000f2370(local_190,6);
          }
        }
      }
      for (local_2c = 0; local_2c < local_30; local_2c = local_2c + 1) {
        FUN_000ec1f0();
        FUN_000f2960();
        DAT_007350c4 = 0x3f800000;
        (**(code **)(*DAT_007350c0 + 0x14))();
      }
      if (local_70 != -1) {
        FUN_0023c150(local_70);
      }
      local_1c = FUN_000c5630(0x3e,0x1300d4,0x602e,0x3c);
      if (local_1c != 0) {
        *(uint *)(local_1c + 0xc) = *(uint *)(local_1c + 0xc) | 0x10;
        local_d0 = *(float *)(local_1c + 0x2c);
        local_14 = *(int *)(local_1c + 0x14);
        *(undefined4 *)(local_1c + 0x2c) = 0x3f800000;
        *(int *)(local_1c + 0x14) = -*(int *)(*(int *)(local_1c + 0x10) + 0xc);
        while (*(float *)(local_1c + 0x2c) < local_d0) {
          if (*(int *)(local_1c + 0x14) < local_14) {
            *(int *)(local_1c + 0x14) = *(int *)(local_1c + 0x14) + *(int *)(local_c + 0x9c);
            if (local_14 < *(int *)(local_1c + 0x14)) {
              *(int *)(local_1c + 0x14) = local_14;
            }
          }
          else {
            *(float *)(local_1c + 0x2c) = *(float *)(local_1c + 0x2c) + *(float *)(local_c + 0xa0);
            if (local_d0 < *(float *)(local_1c + 0x2c)) {
              *(float *)(local_1c + 0x2c) = local_d0;
            }
          }
          FUN_000ec1f0();
          FUN_000f2960();
          DAT_007350c4 = 0x3f800000;
          (**(code **)(*DAT_007350c0 + 0x14))();
        }
      }
      iVar3 = *(int *)(local_c + 4);
      local_c8 = iVar3 + 0x78c;
      local_14 = *(int *)(iVar3 + 0x790);
      local_10 = DAT_00831e18 - *(int *)(iVar3 + 0x794);
      for (local_2c = 0; local_2c < 8; local_2c = local_2c + 1) {
        local_ed = 0;
        iVar3 = *(int *)(local_cc + 0x29c + local_2c * 4);
        if (iVar3 < 0) {
          local_10 = local_10 - *(int *)(local_c + 0xa4);
        }
        else {
          if (*(int *)(local_cc + 0x140 + iVar3 * 4) == 0) {
            _sprintf(local_14c,"%d. %s",local_2c + 1,local_74);
            _sprintf(&DAT_005b82e0,local_14c,iVar3 + 1);
          }
          else {
            _sprintf(&DAT_005b82e0,"%d. %s",local_2c + 1,
                     *(undefined4 *)(local_cc + 0x140 + iVar3 * 4));
          }
          local_f4 = FUN_000934e0(0x603f,0x11,&DAT_005b82e0,local_14,local_10,0x36);
          if (local_f4 == 0) break;
          if (*(int *)(local_cc + 0x24c + iVar3 * 8) == 0) {
            local_198 = 0;
          }
          else {
            if (*(int *)(*(int *)(local_cc + 0x24c + iVar3 * 8) + 4) ==
                *(int *)(local_cc + 0x250 + iVar3 * 8)) {
              local_194 = *(int *)(local_cc + 0x24c + iVar3 * 8);
            }
            else {
              local_194 = 0;
            }
            local_198 = local_194;
          }
          local_78 = local_198;
          if (local_198 == 0) break;
          local_ec = *(int *)(local_198 + 0x1c) * 0x38 + *local_28;
          iVar3 = FUN_0009e050(0x1300d4,0x602e,*(undefined4 *)(local_ec + 0x34),0,0x3b);
          if (iVar3 == 0) break;
          iVar1 = *(int *)(local_c + 4);
          local_c8 = iVar1 + 0x754;
          *(undefined4 *)(iVar3 + 0x14) = *(undefined4 *)(iVar1 + 0x758);
          *(uint *)(iVar3 + 0x18) =
               (DAT_00831e18 - *(int *)(iVar1 + 0x75c)) - local_2c * *(int *)(local_c + 0xa4);
          for (local_150 = 0; local_150 < 0x14; local_150 = local_150 + 1) {
            FUN_0025b020(local_f4,local_ed);
            FUN_0025a5e0(iVar3,(float)local_ed);
            local_ed = local_ed + 0xc;
            FUN_000ec1f0();
            FUN_000f2960();
            DAT_007350c4 = 0x3f800000;
            (**(code **)(*DAT_007350c0 + 0x14))();
          }
          local_ed = 0xff;
          FUN_0025b020(local_f4,0xff);
          FUN_0025a5e0(iVar3,(float)local_ed);
          local_10 = local_10 - *(int *)(local_c + 0xa4);
        }
      }
    }
  }
  for (local_24 = 0; local_24 < 0xf0; local_24 = local_24 + 1) {
    FUN_000ec1f0();
    FUN_000f2960();
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  }
  FUN_0007b0a0();
  for (local_24 = 0; local_24 < 4; local_24 = local_24 + 1) {
    FUN_0025bde0(local_24,2);
  }
  FUN_00258ff0(0xc);
  FUN_000f50a0(1);
  return (float10)DAT_004d7b58;
}

