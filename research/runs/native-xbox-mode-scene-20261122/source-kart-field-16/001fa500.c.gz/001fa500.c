
void FUN_001fa500(int param_1,int param_2)

{
  if ((((-1 < param_1) && (param_1 < 9)) && (-1 < param_2)) && (param_2 < 8)) {
    *(undefined4 *)(param_1 * 0x1afc0 + 0x73653c + param_2 * 4) = 0;
  }
  return;
}

