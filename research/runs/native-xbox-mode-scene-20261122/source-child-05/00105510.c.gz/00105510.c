
void FUN_00105510(void)

{
  undefined4 uVar1;
  uint local_8;
  
  DAT_005b8344 = 0;
  for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
    uVar1 = FUN_00105040();
    *(undefined4 *)(&DAT_0082eca0 + local_8 * 0xc) = uVar1;
    *(undefined4 *)(&DAT_0082eca4 + local_8 * 0xc) = *(undefined4 *)(&DAT_0082eca0 + local_8 * 0xc);
    *(undefined4 *)(&DAT_0082eca8 + local_8 * 0xc) = *(undefined4 *)(&DAT_00736500 + local_8 * 4);
  }
  DAT_0082ecd0 = 0x2b;
  return;
}

