
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_001f98d0(void)

{
  FUN_001f9bf0(&DAT_00731460);
  DAT_00731448 = 0;
  DAT_00731444 = 0xffffffff;
  DAT_00731440 = 0xffffffff;
  FUN_001f9bf0(&DAT_0072de60);
  DAT_0072de48 = 0;
  DAT_0072de44 = 0xffffffff;
  DAT_0072de40 = 0xffffffff;
  DAT_005b8908 = &DAT_00731468;
  DAT_005b890c = &DAT_0072de68;
  _DAT_00736500 = &DAT_007316a0;
  _DAT_00736504 = &DAT_0072e0a0;
  FUN_001f9bf0(&DAT_0072a860);
  DAT_0072a848 = 0;
  DAT_0072a844 = 0xffffffff;
  DAT_0072a840 = 0xffffffff;
  FUN_001f9bf0(&DAT_00727260);
  DAT_00727248 = 0;
  DAT_00727244 = 0xffffffff;
  DAT_00727240 = 0xffffffff;
  DAT_005b8910 = 0x72a868;
  DAT_005b8914 = &DAT_00727268;
  _DAT_00736508 = &DAT_0072aaa0;
  _DAT_0073650c = &DAT_007274a0;
  return;
}

