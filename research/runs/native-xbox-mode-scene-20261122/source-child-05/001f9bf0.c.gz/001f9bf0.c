
void FUN_001f9bf0(undefined4 *param_1)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  char *local_10;
  char *local_c;
  int local_8;
  
  puVar3 = param_1;
  for (iVar2 = 0xd78; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0;
    puVar3 = puVar3 + 1;
  }
  *(undefined1 *)param_1 = 1;
  local_c = (char *)FUN_001df630(0,1);
  local_10 = (char *)(param_1 + 2);
  do {
    cVar1 = *local_c;
    *local_10 = cVar1;
    local_c = local_c + 1;
    local_10 = local_10 + 1;
  } while (cVar1 != '\0');
  for (local_8 = 0; local_8 < 0x10; local_8 = local_8 + 1) {
    param_1[local_8 + 0x1f] = *(undefined4 *)(&DAT_0054cca0 + local_8 * 0xc);
    param_1[local_8 + 0x2f] = *(undefined4 *)(&DAT_0054cca0 + local_8 * 0xc);
  }
  FUN_00188a60(param_1);
  FUN_002532b0(param_1 + 0x9e);
  puVar3 = param_1 + 0x48;
  for (iVar2 = 0x28; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0xffffffff;
    puVar3 = puVar3 + 1;
  }
  puVar3 = param_1 + 0x70;
  for (iVar2 = 0x1e; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0xffffffff;
    puVar3 = puVar3 + 1;
  }
  return;
}

