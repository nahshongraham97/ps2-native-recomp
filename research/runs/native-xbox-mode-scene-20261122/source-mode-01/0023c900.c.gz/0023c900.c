
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_0023c900(int param_1)

{
  char local_f4 [204];
  undefined4 local_28;
  undefined4 local_24;
  int local_20;
  int local_1c;
  undefined *local_18;
  int local_14;
  int local_10;
  int local_c;
  int local_8;
  
  local_28 = DAT_005af7d0;
  local_10 = -1;
  local_1c = 0;
  local_18 = (&PTR_DAT_0056c940)[param_1 * 9];
  local_20 = *(int *)(&DAT_0056c944 + param_1 * 0x24);
  local_c = 0;
  local_14 = 0;
  for (local_8 = 0; local_8 < local_20; local_8 = local_8 + 1) {
    local_24 = *(undefined4 *)(local_18 + local_8 * 0xc);
    local_10 = FUN_0023ca10(local_24);
    if (local_10 != -1) {
      local_1c = *(int *)(local_18 + local_8 * 0xc + 4);
      local_c = *(int *)(&DAT_00568c3c + local_10 * 0x28);
      local_14 = *(int *)(&DAT_0056c1e0 + local_1c * 0x10);
      if (local_c != local_14) {
        _sprintf(local_f4,
                 "error in bank load table for:%s ,entry number %i, bank type and slot type do not match. types must match!"
                 ,(&PTR_s_no_sounds_bank_list_0056c958)[param_1 * 9],local_8);
      }
    }
  }
  return;
}

