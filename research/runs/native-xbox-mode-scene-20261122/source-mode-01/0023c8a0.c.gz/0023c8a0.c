
void FUN_0023c8a0(int param_1)

{
  int iVar1;
  
  if ((((-1 < param_1) && (param_1 < 9)) &&
      (iVar1 = *(int *)(&DAT_0056c950 + param_1 * 0x24), -1 < iVar1)) && (iVar1 < 4)) {
    FUN_0023d060(param_1,iVar1);
  }
  return;
}

