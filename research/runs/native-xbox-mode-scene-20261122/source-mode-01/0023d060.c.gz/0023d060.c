
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0023d060(int param_1,int param_2)

{
  if (((-1 < param_1) && (param_1 < 9)) && (-1 < param_2)) {
    _DAT_005be3c8 = param_1;
    switch(param_2) {
    case 0:
      FUN_0023d4d0(param_1);
      FUN_0023d830(param_1);
      break;
    case 1:
      FUN_0023d780(param_1);
      FUN_0023d830(param_1);
      break;
    case 2:
      FUN_0023d780(param_1);
      if (*(int *)(&DAT_0056c954 + param_1 * 0x24) != -1) {
        FUN_0023d170(*(undefined4 *)(&DAT_0056c954 + param_1 * 0x24));
      }
      FUN_0023d830(param_1);
      break;
    case 3:
      FUN_0023d4d0(param_1);
      FUN_0023d5d0(param_1);
      FUN_0023d830(param_1);
    }
  }
  return;
}

