
void __fastcall FUN_00105280(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00105020(param_1);
  if (iVar1 != 0) {
    *(int *)(iVar1 + 0x40) = *(int *)(iVar1 + 0x40) + -1;
  }
  return;
}

