
float10 __fastcall FUN_00105230(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00105020(param_1);
  if (iVar1 != 0) {
    *(int *)(iVar1 + 0x40) = *(int *)(iVar1 + 0x40) + 1;
    *(undefined4 *)(iVar1 + 0x44) = 0;
  }
  return (float10)DAT_004d7b58;
}

