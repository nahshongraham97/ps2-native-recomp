
int FUN_0020b280(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int local_8;
  
  iVar2 = FUN_00105020();
  iVar1 = *(int *)(iVar2 + 0x30);
  *param_1 = iVar1;
  iVar3 = FUN_00337820(iVar1 << 2,0,"KART PSELECT: char names list");
  for (local_8 = 0; local_8 < iVar1; local_8 = local_8 + 1) {
    *(undefined **)(iVar3 + local_8 * 4) =
         (&PTR_s_ASHRAH_00560fc0)
         [*(int *)(&DAT_00560d98 + *(int *)(iVar2 + 8 + local_8 * 4) * 0x34) * 5];
  }
  return iVar3;
}

