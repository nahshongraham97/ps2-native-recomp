
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00105160(void)

{
  int iVar1;
  int iVar2;
  float10 fVar3;
  
  iVar1 = DAT_007350c8;
  iVar2 = FUN_00105020();
  if (iVar2 == 0) {
    fVar3 = (float10)DAT_004d7b58;
  }
  else if (iVar1 == 0) {
    fVar3 = (float10)DAT_004d7b58;
  }
  else if (*(int *)(iVar2 + 0x44) == 0) {
    *(undefined4 *)(iVar2 + 0x44) = 1;
    FUN_0023c150(0x12539);
    FUN_0023c5c0(*(undefined4 *)(iVar1 + 8),0x14);
    (**(code **)(*DAT_007350c0 + 0x20))(FUN_00105230,0x42f00000);
    fVar3 = (float10)_DAT_004dd5a8;
  }
  else {
    *(int *)(iVar1 + 0xc) = *(int *)(iVar1 + 0xc) + -1;
    if (*(int *)(iVar1 + 0xc) < 0) {
      *(undefined4 *)(iVar2 + 0x44) = 0;
    }
    fVar3 = (float10)DAT_004d7b54;
  }
  return fVar3;
}

