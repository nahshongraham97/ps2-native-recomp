
void FUN_0020a8f0(int param_1,int param_2)

{
  int iVar1;
  uint local_c;
  
  iVar1 = FUN_00105020();
  if ((0x10e53 < param_1) && (param_1 < 0x10e58)) {
    *(undefined4 *)(param_2 + 0xc) = 0;
    for (local_c = 0; local_c < *(uint *)(iVar1 + 0x30); local_c = local_c + 1) {
      if (*(int *)(iVar1 + 8 + local_c * 4) ==
          *(int *)((param_1 + -0x10e54) * 0xc + *(int *)(iVar1 + 0x34))) {
        if (local_c == 0) {
          local_c = *(uint *)(iVar1 + 0x30);
        }
        local_c = local_c - 1;
        *(uint *)(param_2 + 0xc) = local_c;
        return;
      }
    }
  }
  return;
}

