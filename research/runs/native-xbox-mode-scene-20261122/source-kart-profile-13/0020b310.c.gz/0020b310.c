
void FUN_0020b310(int *param_1,uint *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  uint local_14;
  uint local_c;
  
  iVar1 = FUN_00105020();
  if (param_1 != (int *)0x0) {
    iVar2 = FUN_001db830(0x50);
    *param_1 = iVar2;
    if (*param_1 != 0) {
      *(undefined4 *)(*param_1 + 0x10) = 0x50;
      iVar2 = *(int *)(*param_1 + 8);
      if (iVar2 != 0) {
        for (local_c = 0; local_c < 0x50; local_c = local_c + 1) {
          *(undefined4 *)(iVar2 + local_c * 4) = 0;
        }
        local_c = 0;
        for (local_14 = 0; local_14 < 10; local_14 = local_14 + 1) {
          iVar3 = FUN_00104ab0(*(undefined4 *)(&DAT_00560d9c + local_14 * 0x34));
          if (iVar3 != 0) {
            if ((&PTR_s_CAR_BARAKA_00560db0)[local_14 * 0xd] == (undefined *)0x0) {
              local_24 = 0;
            }
            else {
              local_24 = FUN_00027230(0x8002a,(&PTR_s_DRIVER_BARAKA_00560dac)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + local_c * 4) = local_24;
            if ((&PTR_s_DRIVER_BARAKA_00560dac)[local_14 * 0xd] == (undefined *)0x0) {
              local_28 = 0;
            }
            else {
              local_28 = FUN_00027230(0x8002a,(&PTR_s_CAR_BARAKA_00560db0)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + 4 + local_c * 4) = local_28;
            if ((&PTR_s_WHEEL_BARAKA_1_00560db4)[local_14 * 0xd] == (undefined *)0x0) {
              local_2c = 0;
            }
            else {
              local_2c = FUN_00027230(0x8002a,(&PTR_s_WHEEL_BARAKA_1_00560db4)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + 8 + local_c * 4) = local_2c;
            if ((&PTR_s_WHEEL_BARAKA_2_00560db8)[local_14 * 0xd] == (undefined *)0x0) {
              local_30 = 0;
            }
            else {
              local_30 = FUN_00027230(0x8002a,(&PTR_s_WHEEL_BARAKA_2_00560db8)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + 0xc + local_c * 4) = local_30;
            if ((&PTR_s_WHEEL_BARAKA_3_00560dbc)[local_14 * 0xd] == (undefined *)0x0) {
              local_34 = 0;
            }
            else {
              local_34 = FUN_00027230(0x8002a,(&PTR_s_WHEEL_BARAKA_3_00560dbc)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + 0x10 + local_c * 4) = local_34;
            if ((&PTR_s_WHEEL_BARAKA_1_00560dc0)[local_14 * 0xd] == (undefined *)0x0) {
              local_38 = 0;
            }
            else {
              local_38 = FUN_00027230(0x8002a,(&PTR_s_WHEEL_BARAKA_1_00560dc0)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + 0x14 + local_c * 4) = local_38;
            if ((&PTR_s_WHEEL_BARAKA_2_00560dc4)[local_14 * 0xd] == (undefined *)0x0) {
              local_3c = 0;
            }
            else {
              local_3c = FUN_00027230(0x8002a,(&PTR_s_WHEEL_BARAKA_2_00560dc4)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + 0x18 + local_c * 4) = local_3c;
            if ((&PTR_s_WHEEL_BARAKA_3_00560dc8)[local_14 * 0xd] == (undefined *)0x0) {
              local_40 = 0;
            }
            else {
              local_40 = FUN_00027230(0x8002a,(&PTR_s_WHEEL_BARAKA_3_00560dc8)[local_14 * 0xd]);
            }
            *(undefined4 *)(iVar2 + 0x1c + local_c * 4) = local_40;
            local_c = local_c + 8;
          }
        }
      }
      param_1[1] = 1;
    }
  }
  *param_2 = *(uint *)(iVar1 + 0x30) | 0x80000;
  return;
}

