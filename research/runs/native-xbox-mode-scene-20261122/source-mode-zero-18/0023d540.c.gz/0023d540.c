
undefined4 FUN_0023d540(int param_1,int param_2)

{
  undefined *puVar1;
  int iVar2;
  int iVar3;
  int local_8;
  
  puVar1 = (&PTR_DAT_0056c940)[param_2 * 9];
  iVar2 = *(int *)(&DAT_0056c944 + param_2 * 0x24);
  local_8 = 0;
  while( true ) {
    if (iVar2 <= local_8) {
      return 0;
    }
    iVar3 = FUN_0023ca10(*(undefined4 *)(puVar1 + local_8 * 0xc));
    if (iVar3 == param_1) break;
    local_8 = local_8 + 1;
  }
  return 1;
}

