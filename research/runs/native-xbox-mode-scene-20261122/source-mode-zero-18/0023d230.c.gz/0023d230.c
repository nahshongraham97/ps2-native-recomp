
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_0023d230(int param_1)

{
  char cVar1;
  char *pcVar2;
  undefined4 *puVar3;
  uint uVar4;
  char *pcVar5;
  undefined4 *local_c4;
  char *local_bc;
  undefined1 local_a8 [4];
  char local_a4 [4];
  undefined1 local_a0 [148];
  undefined4 local_c;
  int local_8;
  
  local_c = DAT_005af7d0;
  local_8 = 0;
  if (((param_1 != -1) && (-1 < param_1)) && (param_1 < 0x158)) {
    local_a4[0] = '\0';
    pcVar2 = (&PTR_s_permanent_00568c24)[param_1 * 10];
    local_a8 = (undefined1  [4])pcVar2;
    do {
      cVar1 = *(char *)local_a8;
      local_a8 = (undefined1  [4])((int)local_a8 + 1);
    } while (cVar1 != '\0');
    local_bc = local_a8 + 3;
    do {
      pcVar5 = local_bc + 1;
      local_bc = local_bc + 1;
    } while (*pcVar5 != '\0');
    pcVar5 = pcVar2;
    for (uVar4 = (uint)((int)local_a8 - (int)pcVar2) >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
      *(undefined4 *)local_bc = *(undefined4 *)pcVar5;
      pcVar5 = pcVar5 + 4;
      local_bc = local_bc + 4;
    }
    for (uVar4 = (int)local_a8 - (int)pcVar2 & 3; uVar4 != 0; uVar4 = uVar4 - 1) {
      *local_bc = *pcVar5;
      pcVar5 = pcVar5 + 1;
      local_bc = local_bc + 1;
    }
    puVar3 = (undefined4 *)(local_a8 + 3);
    do {
      local_c4 = puVar3;
      puVar3 = (undefined4 *)((int)local_c4 + 1);
    } while (*(char *)((int)local_c4 + 1) != '\0');
    *(undefined4 *)((int)local_c4 + 1) = DAT_0050438c;
    *(undefined1 *)((int)local_c4 + 5) = DAT_00504390;
    if (*(int *)(&DAT_00568c18 + param_1 * 0x28) == 0) {
      if (*(int *)(&DAT_00568c1c + param_1 * 0x28) == 1) {
        local_8 = FUN_0037c2a0(local_a4);
        if (local_8 == 0) {
          if (*(int *)(&DAT_00568c18 + param_1 * 0x28) != 0) {
            FUN_0023c700(*(undefined4 *)(&DAT_00568c18 + param_1 * 0x28));
          }
          *(undefined4 *)(&DAT_00568c18 + param_1 * 0x28) = 0;
        }
        else if (local_8 == 1) {
          *(undefined4 *)(&DAT_00568c18 + param_1 * 0x28) = 0;
        }
        else {
          *(undefined4 *)(&DAT_00568c18 + param_1 * 0x28) = 0;
        }
      }
    }
    else {
      FUN_0023c700(*(undefined4 *)(&DAT_00568c18 + param_1 * 0x28));
      *(undefined4 *)(&DAT_00568c18 + param_1 * 0x28) = 0;
    }
  }
  return;
}

