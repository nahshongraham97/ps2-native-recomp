
void FUN_0020b640(undefined4 param_1,int param_2)

{
  *(undefined4 *)(&DAT_0082eca0 + param_2 * 0xc) = param_1;
  return;
}

