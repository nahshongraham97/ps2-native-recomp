
undefined4 FUN_0020af20(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  bool bVar6;
  undefined4 *local_44;
  
  iVar3 = *(int *)(param_2 + 0xc);
  if (*(int *)(param_2 + 0x34) == 0) {
    uVar1 = 0;
  }
  else if ((iVar3 < 69000) || (69999 < iVar3)) {
    uVar1 = 0;
  }
  else {
    iVar2 = FUN_003394a0(0);
    switch(iVar3) {
    case 69000:
      iVar3 = FUN_003394a0(1);
      if ((iVar3 < 0) || (1 < iVar3)) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_003394a0(0);
        FUN_00207480(iVar3,uVar1);
        uVar1 = 1;
      }
      break;
    case 0x10d89:
      bVar6 = false;
      if ((iVar2 < 0) || (1 < iVar2)) {
        uVar1 = 0;
      }
      else {
        if (iVar2 == 0) {
          local_44 = &DAT_00831aec;
        }
        else {
          local_44 = &DAT_00831b34;
        }
        uVar1 = FUN_00259000();
        switch(uVar1) {
        case 0:
        case 1:
        case 4:
          bVar6 = local_44[2] == 2;
          break;
        case 0xf:
          if (local_44[2] != 0) {
            bVar6 = true;
          }
        }
        if (bVar6) {
          FUN_0033afc0(param_2,0);
          uVar1 = 1;
        }
        else {
          uVar1 = 0;
        }
      }
      break;
    default:
      uVar1 = 0;
      break;
    case 0x10d8c:
      iVar3 = FUN_003394a0(0);
      if (iVar3 == DAT_008292f8) {
        FUN_0033afc0(param_2,0);
        uVar1 = 1;
      }
      else {
        uVar1 = 0;
      }
      break;
    case 0x10d8e:
      iVar3 = FUN_00339480(1);
      iVar2 = iVar2 + -1;
      if ((iVar2 < 0) || (3 < iVar2)) {
        uVar1 = 0;
      }
      else {
        (&DAT_00831af4)[iVar2 * 0x12] = (iVar3 != 0) + 1;
        if ((&DAT_00831af4)[iVar2 * 0x12] == 2) {
          DAT_0082ecd4 = 1 << ((byte)*(int *)(&DAT_0082eca0 + iVar2 * 0xc) & 0x1f) | DAT_0082ecd4;
          FUN_00105120(*(undefined4 *)(&DAT_00560da0 + *(int *)(&DAT_0082eca0 + iVar2 * 0xc) * 0x34)
                      );
        }
        if ((&DAT_00831af4)[iVar2 * 0x12] == 1) {
          DAT_0082ecd4 = ~(1 << ((byte)*(undefined4 *)(&DAT_0082eca0 + iVar2 * 0xc) & 0x1f)) &
                         DAT_0082ecd4;
          FUN_0023c150(0x12536);
          FUN_00105280();
        }
        uVar1 = 1;
      }
      break;
    case 0x10d8f:
      iVar2 = iVar2 + -1;
      iVar3 = FUN_00105020();
      piVar5 = (int *)(iVar2 * 0xc + *(int *)(iVar3 + 0x34));
      iVar3 = *(int *)(iVar3 + 0x34);
      if ((iVar2 < 0) || (3 < iVar2)) {
        uVar1 = 0;
      }
      else {
        (&DAT_00831af4)[iVar2 * 0x12] = 1;
        if (*piVar5 == -1) {
          iVar4 = FUN_00105040();
          *piVar5 = iVar4;
          *(int *)(iVar3 + 4 + iVar2 * 0xc) = *piVar5;
        }
        FUN_0023c150(0x12534);
        uVar1 = 1;
      }
    }
  }
  return uVar1;
}

