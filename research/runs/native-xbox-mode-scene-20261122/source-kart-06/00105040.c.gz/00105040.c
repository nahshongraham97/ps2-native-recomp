
int FUN_00105040(void)

{
  int iVar1;
  byte bVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  
  iVar3 = 10;
  uVar5 = 0;
  if (9 < DAT_005b8344) {
    DAT_005b8344 = 0;
  }
  bVar2 = (byte)DAT_005b8344;
  do {
    uVar4 = 1 << (bVar2 & 0x1f);
    iVar1 = FUN_00104ab0(DAT_005b8344,iVar3,uVar4,uVar5);
    if ((iVar1 != 0) && ((DAT_0082ecd4 & uVar4) == 0)) goto LAB_001050f6;
    DAT_005b8344 = DAT_005b8344 + 1;
    if (9 < DAT_005b8344) {
      DAT_005b8344 = 0;
    }
    bVar2 = (byte)DAT_005b8344;
    iVar3 = iVar3 + -1;
  } while (0 < iVar3);
  DAT_005b8344 = 8;
LAB_001050f6:
  iVar3 = DAT_005b8344;
  DAT_005b8344 = DAT_005b8344 + 1;
  return iVar3;
}

