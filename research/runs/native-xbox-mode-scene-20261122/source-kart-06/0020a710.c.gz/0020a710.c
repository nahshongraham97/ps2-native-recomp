
void __thiscall FUN_0020a710(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  
  switch(param_2) {
  case 0x10def:
    DAT_00562354 = param_3;
    break;
  case 0x10e54:
  case 0x10e55:
  case 0x10e56:
  case 0x10e57:
    iVar1 = FUN_00105020();
    if (param_3 < 0) {
      param_3 = param_3 + *(int *)(iVar1 + 0x30);
    }
    if (*(int *)(iVar1 + 0x30) <= param_3) {
      param_3 = param_3 - *(int *)(iVar1 + 0x30);
    }
    *(undefined4 *)(&DAT_0082eca0 + (param_2 + -0x10e54) * 0xc) =
         *(undefined4 *)(iVar1 + 8 + param_3 * 4);
    *(undefined4 *)(&DAT_0082eca4 + (param_2 + -0x10e54) * 0xc) =
         *(undefined4 *)(&DAT_0082eca0 + (param_2 + -0x10e54) * 0xc);
    break;
  case 0x10e58:
    FUN_0009b580(param_3 + 0x2b,param_2 + -0x10def,param_1);
    if (DAT_00831a58 < 0) {
      FUN_0009b580(0x2b);
    }
    FUN_001ea5c0();
  }
  return;
}

