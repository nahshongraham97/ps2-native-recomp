
void FUN_000e68e0(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int local_78;
  int local_74;
  int *local_70;
  int local_6c;
  int local_60;
  int *local_50;
  int local_40;
  int local_3c;
  int local_38;
  int local_34 [10];
  char *local_c;
  int local_8;
  
  local_38 = DAT_005b8334;
  local_34[0] = 1;
  local_34[1] = 2;
  local_34[2] = 4;
  local_34[3] = 6;
  local_34[4] = 0x15;
  local_34[5] = 0x1c;
  local_34[6] = 0x23;
  local_34[7] = 0x2b;
  local_34[8] = 0x30;
  local_34[9] = 0x3b;
  local_c = (char *)FUN_001b02e0(2,7);
  if ((local_c == (char *)0x0) || (*local_c == '\0')) {
    local_c = "PLAYER %d";
  }
  *(undefined4 *)(local_38 + 100) = 0;
  *(undefined4 *)(local_38 + 0x68) = 0;
  for (local_8 = 0; local_8 < *(int *)(local_38 + 0x6c); local_8 = local_8 + 1) {
    iVar2 = FUN_000573b0(local_8);
    iVar3 = FUN_00057300(local_8);
    iVar4 = FUN_000572c0(local_8);
    *(undefined4 *)(local_38 + 0x44 + local_8 * 8) = 0;
    *(undefined4 *)(local_38 + 0x48 + local_8 * 8) = 0;
    FUN_00057440(local_8);
    if ((iVar2 != 0) && (iVar4 != 0)) {
      if (iVar3 != 0) {
        if (local_8 != 0) goto LAB_000e697b;
        if (iVar3 == 0) {
          *(undefined4 *)(local_38 + 100) = 0;
          *(undefined4 *)(local_38 + 0x68) = 0;
        }
        else {
          *(int *)(local_38 + 100) = iVar3;
          *(undefined4 *)(local_38 + 0x68) = *(undefined4 *)(iVar3 + 4);
        }
        FUN_00057de0(0,FUN_00057e70,0);
      }
      iVar3 = FUN_001c26f0(0x603d,0x20,FUN_000c6620,0xf4,&local_40);
      if (iVar3 != 0) {
        FUN_001c2920(0xf4,local_40);
        if (iVar3 == 0) {
          *(undefined4 *)(local_38 + 0x44 + local_8 * 8) = 0;
          *(undefined4 *)(local_38 + 0x48 + local_8 * 8) = 0;
        }
        else {
          *(int *)(local_38 + 0x44 + local_8 * 8) = iVar3;
          *(undefined4 *)(local_38 + 0x48 + local_8 * 8) = *(undefined4 *)(iVar3 + 4);
        }
        *(code **)(iVar3 + 0x28) = FUN_000e7040;
        *(code **)(iVar3 + 0x2c) = FUN_000e7070;
        if (iVar2 == 0) {
          *(undefined4 *)(local_40 + 0x10) = 0;
          *(undefined4 *)(local_40 + 0x14) = 0;
        }
        else {
          *(int *)(local_40 + 0x10) = iVar2;
          *(undefined4 *)(local_40 + 0x14) = *(undefined4 *)(iVar2 + 4);
        }
        if (iVar3 == 0) {
          *(undefined4 *)(local_40 + 0x20) = 0;
          *(undefined4 *)(local_40 + 0x24) = 0;
        }
        else {
          *(int *)(local_40 + 0x20) = iVar3;
          *(undefined4 *)(local_40 + 0x24) = *(undefined4 *)(iVar3 + 4);
        }
        *(int *)(local_40 + 0x30) = iVar4;
        *(int *)(local_40 + 0x90) = local_8;
        *(undefined4 *)(iVar2 + 0xc) = 0;
        if ((&PTR_DAT_0054ea2c)[local_8 * 2] != (undefined *)0x0) {
          local_50 = *(int **)(&PTR_DAT_0054ea2c)[local_8 * 2];
          while (local_50 != (int *)0x0) {
            local_70 = (int *)*local_50;
            if (local_50[4] == local_70[1]) {
              if ((local_70 == (int *)0x0) || (*(code **)(*local_70 + 0xc) != FUN_001b9700)) {
                local_70 = (int *)0x0;
              }
              if (local_70 != (int *)0x0) {
                if (local_70[3] == 0) {
                  local_78 = 0;
                }
                else {
                  if (*(int *)(local_70[3] + 4) == local_70[4]) {
                    local_74 = local_70[3];
                  }
                  else {
                    local_74 = 0;
                  }
                  local_78 = local_74;
                }
                if (local_78 != 0) {
                  *(undefined4 *)(local_40 + 0x60) = *(undefined4 *)(local_78 + 0xf4);
                  if (local_78 == 0) {
                    *(undefined4 *)(local_40 + 0x18) = 0;
                    *(undefined4 *)(local_40 + 0x1c) = 0;
                  }
                  else {
                    *(int *)(local_40 + 0x18) = local_78;
                    *(undefined4 *)(local_40 + 0x1c) = *(undefined4 *)(local_78 + 4);
                  }
                }
              }
              local_50 = (int *)local_50[1];
            }
            else {
              piVar1 = (int *)local_50[1];
              local_50[4] = 1;
              FUN_001c7410(local_50);
              local_50 = piVar1;
            }
          }
        }
      }
    }
LAB_000e697b:
  }
  local_8 = 0;
  do {
    if (0xb < local_8) {
      for (local_8 = 0; local_8 < 8; local_8 = local_8 + 1) {
        if ((local_8 < 4) && ((&DAT_00831af4)[local_8 * 0x12] == 2)) {
          *(undefined4 *)(local_38 + 0x160 + local_8 * 4) =
               *(undefined4 *)(&DAT_0082eca0 + local_8 * 0xc);
          if (**(int **)(local_38 + 0x105c + local_8 * 4) == 1) {
            *(int *)(local_38 + 0x140 + local_8 * 4) = *(int *)(local_38 + 0x104c + local_8 * 4) + 8
            ;
          }
          else {
            *(undefined4 *)(local_38 + 0x140 + local_8 * 4) = 0;
          }
        }
        else {
          iVar2 = FUN_00105040();
          *(int *)(local_38 + 0x160 + local_8 * 4) = iVar2;
          *(undefined **)(local_38 + 0x140 + local_8 * 4) =
               (&PTR_s_ASHRAH_00560fc0)[local_34[iVar2] * 5];
        }
      }
      for (local_8 = 0; local_8 < 8; local_8 = local_8 + 1) {
        if ((DAT_00831a44 & 1) == 0) {
          if (*(int *)(local_38 + 0x140 + local_8 * 4) == 0) {
            _sprintf(&DAT_005b82e0,local_c,local_8 + 1);
            local_6c = FUN_000935c0(0x6039,0x10,&DAT_005b82e0,0,0,0x38);
          }
          else {
            local_6c = FUN_000935c0(0x6039,0x10,*(undefined4 *)(local_38 + 0x140 + local_8 * 4),0,0,
                                    0x38);
          }
        }
        else {
          local_6c = FUN_000935c0(0x6039,0x10,&DAT_005ea37c + local_8 * 0x4c,0,0,0x38);
        }
        if (local_6c != 0) {
          if (local_6c == 0) {
            *(undefined4 *)(local_38 + 0x100 + local_8 * 8) = 0;
            *(undefined4 *)(local_38 + 0x104 + local_8 * 8) = 0;
          }
          else {
            *(int *)(local_38 + 0x100 + local_8 * 8) = local_6c;
            *(undefined4 *)(local_38 + 0x104 + local_8 * 8) = *(undefined4 *)(local_6c + 4);
          }
          *(uint *)(local_6c + 0xc) = *(uint *)(local_6c + 0xc) | 1;
        }
      }
      return;
    }
    if ((DAT_00831a44 & 1) == 0) {
      local_3c = *(int *)(&DAT_0054e9f8 + local_8 * 4);
      iVar2 = local_3c + -1;
      if ((iVar2 < 4) && (**(int **)(local_38 + 0x105c + iVar2 * 4) == 1)) {
        _sprintf(&DAT_005b82e0,"%s",*(int *)(local_38 + 0x104c + iVar2 * 4) + 8);
      }
      else {
        _sprintf(&DAT_005b82e0,local_c,local_3c);
      }
      local_60 = FUN_000935c0(0x6039,0x10,&DAT_005b82e0,0,0,0x3f);
LAB_000e6dc2:
      if (local_60 != 0) {
        if (local_60 == 0) {
          *(undefined4 *)(local_38 + 0x70 + local_8 * 8) = 0;
          *(undefined4 *)(local_38 + 0x74 + local_8 * 8) = 0;
        }
        else {
          *(int *)(local_38 + 0x70 + local_8 * 8) = local_60;
          *(undefined4 *)(local_38 + 0x74 + local_8 * 8) = *(undefined4 *)(local_60 + 4);
        }
        *(uint *)(local_60 + 0xc) = *(uint *)(local_60 + 0xc) | 1;
        *(int *)(local_38 + 0xd0 + local_8 * 4) = *(int *)(local_60 + 0x30) >> 1;
      }
    }
    else {
      if (local_8 < 8) {
        local_60 = FUN_000935c0(0x6039,0x10,&DAT_005ea37c + local_8 * 0x4c,0,0,0x3f);
        goto LAB_000e6dc2;
      }
      *(undefined4 *)(local_38 + 0x70 + local_8 * 8) = 0;
      *(undefined4 *)(local_38 + 0x74 + local_8 * 8) = 0;
    }
    local_8 = local_8 + 1;
  } while( true );
}

