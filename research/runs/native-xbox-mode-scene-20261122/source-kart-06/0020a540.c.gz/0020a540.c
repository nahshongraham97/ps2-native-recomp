
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_0020a540(int param_1)

{
  int iVar1;
  uint uVar2;
  uint local_8;
  
  switch(param_1) {
  case 0x10dee:
    FUN_001de4b0();
    uVar2 = FUN_00398614();
    break;
  case 0x10def:
    uVar2 = DAT_00562354;
    break;
  default:
    uVar2 = 0;
    break;
  case 0x10e50:
  case 0x10e51:
  case 0x10e52:
  case 0x10e53:
    iVar1 = FUN_00105020();
    for (local_8 = 0; local_8 < *(uint *)(iVar1 + 0x30); local_8 = local_8 + 1) {
      if (*(int *)(iVar1 + 8 + local_8 * 4) ==
          *(int *)((param_1 + -0x10e50) * 0xc + *(int *)(iVar1 + 0x34))) {
        return local_8;
      }
    }
    uVar2 = 0;
    break;
  case 0x10e54:
  case 0x10e55:
  case 0x10e56:
  case 0x10e57:
    uVar2 = *(uint *)(&DAT_0082eca0 + (param_1 + -0x10e54) * 0xc);
    break;
  case 0x10e58:
    uVar2 = DAT_00831a58 - 0x2b;
  }
  return uVar2;
}

