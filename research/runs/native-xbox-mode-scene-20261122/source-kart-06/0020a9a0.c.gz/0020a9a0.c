
void __thiscall FUN_0020a9a0(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  uint *puVar2;
  int local_8;
  
  if ((0x10e53 < param_2) && (param_2 < 0x10e58)) {
    iVar1 = FUN_00105020(param_2,param_1);
    puVar2 = (uint *)(&DAT_0082eca0 + (param_2 + -0x10e54) * 0xc);
    local_8 = *(int *)(param_3 + 0xc) + 1;
    if (*(int *)(iVar1 + 0x30) <= local_8) {
      local_8 = 0;
    }
    if (local_8 < *(int *)(iVar1 + 0x30)) {
      *puVar2 = *(uint *)(iVar1 + 8 + local_8 * 4);
      *(uint *)(&DAT_0082eca4 + (param_2 + -0x10e54) * 0xc) = *puVar2;
    }
    else {
      *puVar2 = *(uint *)(iVar1 + 8);
    }
    if (9 < *puVar2) {
      *puVar2 = 0;
    }
  }
  return;
}

