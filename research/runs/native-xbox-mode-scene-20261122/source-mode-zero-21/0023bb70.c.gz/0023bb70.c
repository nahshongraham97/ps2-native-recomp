
void __thiscall FUN_0023bb70(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  if (param_2 != (undefined4 *)0x0) {
    uVar1 = FUN_0023bc30(param_2,param_1);
    iVar2 = FUN_00374cc0(*param_2,uVar1);
    if (iVar2 != 0) {
      FUN_00374e70(*param_2);
    }
    FUN_0023bbc0(uVar1);
  }
  return;
}

