
undefined4 * FUN_0023bb20(int param_1)

{
  int local_8;
  
  local_8 = 0;
  while( true ) {
    if (DAT_005be3c4 <= local_8) {
      return (undefined4 *)0x0;
    }
    if (param_1 == (&DAT_00723ac4)[local_8 * 3]) break;
    local_8 = local_8 + 1;
  }
  return &DAT_00723ac0 + local_8 * 3;
}

