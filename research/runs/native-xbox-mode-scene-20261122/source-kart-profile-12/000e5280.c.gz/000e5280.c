
void FUN_000e5280(void)

{
  undefined4 *puVar1;
  int iVar2;
  int local_78;
  int local_74;
  undefined1 local_70 [12];
  undefined1 local_64 [12];
  int local_58;
  int local_54;
  int local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  int local_40;
  int *local_3c;
  int *local_38;
  int local_34;
  int local_30;
  int local_2c;
  undefined4 *local_28;
  int *local_24;
  undefined4 local_20;
  int local_1c;
  int local_18;
  int local_14;
  int local_10;
  int local_c;
  undefined4 *local_8;
  
  local_34 = DAT_005b8334;
  local_18 = *(int *)(DAT_00831a4c + 0xac);
  local_30 = 0;
  local_2c = 0;
  local_14 = 0;
  local_38 = *(int **)(local_18 + 0x1c);
  do {
    local_28 = (undefined4 *)0x0;
    if ((*local_38 == 0) || (*(char *)*local_38 == '\0')) break;
    local_24 = (int *)FUN_00027440(0x1500d6,*local_38);
    if (local_24 == (int *)0x0) {
      return;
    }
    local_c = *local_24;
    local_3c = local_24 + 4;
    local_20 = 0x18;
    if ((local_14 != 0) && (local_2c != local_c)) {
      return;
    }
    *(int **)(local_34 + 0xea8 + local_14 * 4) = local_3c;
    *(int *)(local_34 + 0xeb4 + local_14 * 4) = local_c;
    if (0x100 < local_c) {
      return;
    }
    local_2c = local_c;
    local_28 = (undefined4 *)FUN_001b66c0(local_c * 0x30);
    if (local_28 == (undefined4 *)0x0) {
      return;
    }
    local_30 = *(int *)(local_34 + 0xea8 + local_14 * 4);
    local_8 = local_28;
    for (local_10 = 0; local_10 < local_2c; local_10 = local_10 + 1) {
      local_1c = local_30 + 0x10 + local_10 * 0x60;
      for (local_40 = 0; local_40 < 3; local_40 = local_40 + 1) {
        if (local_40 == 0) {
          local_74 = 2;
        }
        else {
          local_74 = local_40 + -1;
        }
        local_50 = local_74;
        FUN_000e9ed0(&local_4c,local_1c + 0x20 + local_40 * 0x10,local_1c + 0x20 + local_74 * 0x10);
        for (local_54 = 0; local_54 < local_2c; local_54 = local_54 + 1) {
          local_58 = local_30 + 0x10 + local_54 * 0x60;
          if ((local_10 != local_54) &&
             (iVar2 = FUN_000dd890(&local_4c,local_58,0xbdcccccd), iVar2 != 0)) {
            local_8[8] = local_4c;
            local_8[9] = local_48;
            local_8[10] = local_44;
            if (local_50 == 0) {
              local_78 = 2;
            }
            else {
              local_78 = local_50 + -1;
            }
            local_54 = local_78;
            puVar1 = (undefined4 *)(local_1c + 0x20 + local_78 * 0x10);
            local_8[4] = *puVar1;
            local_8[5] = puVar1[1];
            local_8[6] = puVar1[2];
            local_8[7] = puVar1[3];
            FUN_000e9ed0(local_70,local_1c + 0x20 + local_78 * 0x10,
                         local_1c + 0x20 + local_40 * 0x10);
            FUN_000e9ed0(local_64,local_1c + 0x20 + local_50 * 0x10,
                         local_1c + 0x20 + local_54 * 0x10);
            FUN_001b5800(local_8,local_70,local_64);
            local_8 = local_8 + 0xc;
            goto LAB_000e53c8;
          }
        }
      }
      local_40 = local_2c + -1;
LAB_000e53c8:
    }
    local_8 = local_28;
    for (local_10 = 0; local_10 < local_2c; local_10 = local_10 + 1) {
      local_1c = local_30 + 0x10 + local_10 * 0x60;
      *(undefined4 *)(local_1c + 4) = *local_8;
      *(undefined4 *)(local_1c + 8) = local_8[1];
      *(undefined4 *)(local_1c + 0xc) = local_8[2];
      *(undefined4 *)(local_1c + 0x10) = local_8[4];
      *(undefined4 *)(local_1c + 0x14) = local_8[5];
      *(undefined4 *)(local_1c + 0x18) = local_8[6];
      *(undefined4 *)(local_1c + 0x1c) = local_8[7];
      *(undefined4 *)(local_1c + 0x20) = local_8[8];
      *(undefined4 *)(local_1c + 0x24) = local_8[9];
      *(undefined4 *)(local_1c + 0x28) = local_8[10];
      local_8 = local_8 + 0xc;
    }
    if (local_28 != (undefined4 *)0x0) {
      __tell(local_28);
    }
    local_14 = local_14 + 1;
    local_38 = local_38 + 1;
  } while (local_14 < 3);
  local_28 = (undefined4 *)0x0;
  FUN_000e68d0();
  FUN_000f84b0();
  return;
}

