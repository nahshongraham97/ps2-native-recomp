
void FUN_00207480(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 local_24;
  int local_20;
  int local_14;
  int *local_10;
  int local_c;
  
  iVar1 = FUN_00205410();
  if (iVar1 == 0) {
    return;
  }
  iVar2 = FUN_00206350();
  if (iVar2 != 0) {
    return;
  }
  iVar2 = FUN_001c4870(0x10012);
  if ((iVar2 != 0) && (iVar2 = FUN_001c4d20(iVar2), iVar2 != 0)) {
    *(undefined4 *)(iVar2 + 0x18) = 1;
  }
  if (DAT_008292f8 == 4) {
    if ((DAT_00831af4 == 2) && (DAT_00831b3c == 1)) {
      param_1 = 1;
    }
    else if ((DAT_00831af4 == 1) && (DAT_00831b3c == 2)) {
      param_1 = 0;
    }
  }
  if (param_1 == 0) {
    if ((DAT_008292f8 != 4) && (DAT_00831af4 == 0)) {
      return;
    }
    if (DAT_00831af4 == 2) {
      return;
    }
    local_10 = (int *)(iVar1 + 0x10);
    local_c = *(int *)(iVar1 + 0x10);
  }
  else {
    if (param_1 != 1) {
      return;
    }
    if ((DAT_008292f8 != 4) && (DAT_00831b3c == 0)) {
      return;
    }
    if (DAT_00831b3c == 2) {
      return;
    }
    local_10 = (int *)(iVar1 + 0x44);
    local_c = *(int *)(iVar1 + 0x44);
  }
  switch(param_2) {
  case 0:
    local_14 = *(int *)(&DAT_00561f10 + *local_10 * 0x10);
    break;
  case 1:
    local_14 = *(int *)(&DAT_00561f14 + *local_10 * 0x10);
    break;
  case 2:
    local_14 = *(int *)(&DAT_00561f08 + *local_10 * 0x10);
    break;
  case 3:
    local_14 = *(int *)(&DAT_00561f0c + *local_10 * 0x10);
    break;
  default:
    return;
  }
  local_20 = 0;
  local_24 = FUN_00207140(local_14);
  while( true ) {
    iVar1 = FUN_00208d90(local_24,0,param_1);
    if (iVar1 == 0) goto LAB_00207750;
    switch(param_2) {
    case 0:
      local_14 = *(int *)(&DAT_00561f10 + local_14 * 0x10);
      break;
    case 1:
      local_14 = *(int *)(&DAT_00561f14 + local_14 * 0x10);
      break;
    case 2:
      local_14 = *(int *)(&DAT_00561f08 + local_14 * 0x10);
      break;
    case 3:
      local_14 = *(int *)(&DAT_00561f0c + local_14 * 0x10);
      break;
    default:
      return;
    }
    local_20 = local_20 + 1;
    if (9 < local_20) break;
    local_24 = FUN_00207140(local_14);
  }
  local_20 = 0;
  while (iVar1 = FUN_00208d90(local_24,0,param_1), iVar1 != 0) {
    local_14 = local_14 + 1;
    local_20 = local_20 + 1;
    if (0x3f < local_14) {
      local_14 = 0;
    }
    local_24 = FUN_00207140(local_14);
    if (local_20 == 0x40) {
      return;
    }
  }
LAB_00207750:
  if (local_c != local_14) {
    local_c = local_14;
  }
  FUN_00207170(param_1,local_c,1);
  return;
}

