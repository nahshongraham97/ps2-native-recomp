
void FUN_000570a0(void)

{
  int iVar1;
  int iVar2;
  undefined4 local_8;
  
  if ((DAT_005b785c != 0) && (DAT_005b7adc != 0)) {
    iVar1 = FUN_002d91c0(DAT_005b785c);
    if (iVar1 == 0) {
      FUN_002d9160(DAT_005b7adc,DAT_005b785c);
    }
  }
  local_8 = 0;
  while( true ) {
    iVar1 = FUN_0007d6a0();
    if (iVar1 <= local_8) break;
    iVar1 = FUN_00057320(local_8);
    if (iVar1 != 0) {
      if (DAT_005b7adc != 0) {
        iVar2 = FUN_002d91c0(iVar1);
        if (iVar2 == 0) {
          FUN_002d9160(DAT_005b7adc,iVar1);
        }
      }
      FUN_0007ebe0();
    }
    local_8 = local_8 + 1;
  }
  return;
}

