
/* WARNING: Removing unreachable block (ram,0x00105816) */
/* WARNING: Removing unreachable block (ram,0x0010581a) */

void FUN_00105590(void)

{
  int iVar1;
  int local_18;
  uint local_14;
  uint local_c;
  int local_8;
  
  do {
    local_8 = 0;
    for (local_c = 0; local_c < 4; local_c = local_c + 1) {
      if ((&DAT_00831af4)[local_c * 0x12] == 1) {
        local_8 = local_8 + 1;
      }
    }
    if (local_8 == 0) {
      FUN_001d9530(DAT_005b895c,2);
      FUN_000a0b60();
    }
    iVar1 = FUN_00105020();
    if (DAT_005b7e64 != *(int *)(iVar1 + 0x38)) {
      *(undefined4 *)(iVar1 + 0x3c) = 0xa8c;
      *(int *)(iVar1 + 0x38) = DAT_005b7e64;
    }
    *(int *)(iVar1 + 0x3c) = *(int *)(iVar1 + 0x3c) + -1;
    if (*(int *)(iVar1 + 0x3c) < 1) {
      *(undefined4 *)(iVar1 + 0x3c) = 0xa8c;
      FUN_001d9530(DAT_005b895c,4);
    }
    if (DAT_005b8960 == 4) {
      if ((undefined **)*DAT_007350c0 != &PTR_FUN_0055db5c) {
        FUN_00057150();
      }
      FUN_001ddd90(1);
      DAT_007350c4 = 0x40000000;
      (**(code **)(*DAT_007350c0 + 0x14))();
      FUN_001df250();
      FUN_001de3a0();
      FUN_000a0b60();
      FUN_0009b580(0xffffffff);
      FUN_0019ca30(3,FUN_0019f3d0);
    }
    if (DAT_005b8960 == 2) {
      local_18 = 0;
      FUN_00105830();
      for (local_14 = 0; local_14 < 4; local_14 = local_14 + 1) {
        if ((&DAT_00831af4)[local_14 * 0x12] == 2) {
          local_18 = local_18 + 1;
        }
        else {
          (&DAT_00831af0)[local_14 * 0x12] = local_14;
          FUN_001f9a10(local_14);
        }
      }
      if (local_18 == 1) {
        for (local_14 = 0; local_14 < 4; local_14 = local_14 + 1) {
          if ((&DAT_00831af4)[local_14 * 0x12] == 2) {
            DAT_005b895c = (&DAT_00831af0)[local_14 * 0x12];
            break;
          }
        }
      }
      if ((undefined **)*DAT_007350c0 != &PTR_FUN_0055db5c) {
        FUN_0025a6f0(8,1);
      }
      FUN_001ddd90(1);
      DAT_007350c4 = 0x40000000;
      (**(code **)(*DAT_007350c0 + 0x14))();
      FUN_001df250();
      FUN_001de3a0();
      FUN_00057150();
      FUN_0007d680(local_18);
      FUN_00258f90();
      FUN_00258ff0(7);
      FUN_0023c5a0();
      FUN_0019ca30(10,FUN_000e47b0);
    }
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
  } while( true );
}

