
void FUN_001f9a10(int param_1)

{
  undefined4 *puVar1;
  int *local_18;
  undefined4 *local_14;
  undefined4 *local_10;
  undefined *local_c;
  int *local_8;
  
  puVar1 = (undefined4 *)FUN_0007afb0(param_1);
  switch(param_1) {
  case 0:
    local_18 = &DAT_00731444;
    local_8 = &DAT_00731440;
    local_10 = &DAT_00731448;
    local_14 = &DAT_00831aec;
    local_c = &DAT_00731460;
    break;
  case 1:
    local_18 = &DAT_0072de44;
    local_8 = &DAT_0072de40;
    local_10 = &DAT_0072de48;
    local_14 = &DAT_00831b34;
    local_c = &DAT_0072de60;
    break;
  case 2:
    local_18 = &DAT_0072a844;
    local_8 = &DAT_0072a840;
    local_10 = &DAT_0072a848;
    local_14 = &DAT_00831b7c;
    local_c = &DAT_0072a860;
    break;
  case 3:
    local_18 = &DAT_00727244;
    local_8 = &DAT_00727240;
    local_10 = &DAT_00727248;
    local_14 = &DAT_00831bc4;
    local_c = &DAT_00727260;
    break;
  default:
    goto LAB_001f9b9b;
  }
  if ((((local_18 != (int *)0x0) && (local_8 != (int *)0x0)) && (local_14 != (undefined4 *)0x0)) &&
     (local_c != (undefined *)0x0)) {
    if (*local_18 != -1 && *local_8 != -1) {
      FUN_001fa500(*local_18,*local_8);
    }
    if (puVar1 != (undefined4 *)0x0) {
      *puVar1 = 0;
    }
    FUN_001f9bf0(local_c);
    *local_10 = 0;
    *local_18 = -1;
    *local_8 = -1;
    FUN_0007aff0(local_14);
    (&DAT_0056162c)[param_1] = 8;
  }
LAB_001f9b9b:
  return;
}

