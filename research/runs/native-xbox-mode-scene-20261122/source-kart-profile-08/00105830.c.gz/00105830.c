
void FUN_00105830(void)

{
  int iVar1;
  int local_10;
  int local_c;
  int local_8;
  
  local_10 = 0xb4;
  local_c = 0;
  iVar1 = FUN_00105020();
  if (iVar1 != 0) {
    DAT_007350c4 = 0x3f800000;
    (**(code **)(*DAT_007350c0 + 0x14))();
    for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
      if ((&DAT_00831af4)[local_8 * 0x12] == 2) {
        local_c = local_c + 1;
      }
    }
    while ((0 < local_10 && (*(int *)(iVar1 + 0x40) < local_c))) {
      local_10 = local_10 + -1;
      DAT_007350c4 = 0x3f800000;
      (**(code **)(*DAT_007350c0 + 0x14))();
    }
  }
  return;
}

