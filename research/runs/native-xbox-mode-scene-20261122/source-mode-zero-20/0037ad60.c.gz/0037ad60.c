
undefined4 __thiscall FUN_0037ad60(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  
  if (param_2 != 0) {
    *(int *)(*(int *)(param_2 + 0x30) + 0x48) = *(int *)(*(int *)(param_2 + 0x30) + 0x48) + -1;
    FUN_003799d0(param_2,param_1);
    if (*(int *)(param_2 + 0x40) != 0) {
      if (*(int *)(*(int *)(param_2 + 0x40) + 0x18) != 0) {
        __Fiopen_std__YAPAU_iobuf__PB_WHH_Z(*(undefined4 *)(*(int *)(param_2 + 0x40) + 0x18),0,0);
        *(undefined4 *)(*(int *)(param_2 + 0x40) + 0x18) = 0;
      }
      __Fiopen_std__YAPAU_iobuf__PB_WHH_Z(*(undefined4 *)(param_2 + 0x40),0,0);
      *(undefined4 *)(param_2 + 0x40) = 0;
    }
    if (*(int *)(param_2 + 0x3c) != 0) {
      uVar1 = FUN_003808e0(*(undefined4 *)(param_2 + 0x3c),0,0);
      FUN_003809a0(uVar1);
      *(undefined4 *)(param_2 + 0x3c) = 0;
    }
    __Fiopen_std__YAPAU_iobuf__PB_WHH_Z(param_2,0,0);
  }
  return 0;
}

