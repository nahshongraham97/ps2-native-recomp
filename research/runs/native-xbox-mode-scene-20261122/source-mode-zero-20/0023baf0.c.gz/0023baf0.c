
void __thiscall FUN_0023baf0(int param_1,undefined4 param_2)

{
  while( true ) {
    param_1 = FUN_0023bb20(param_2,param_1);
    if (param_1 == 0) break;
    FUN_0023bb70(param_1);
  }
  return;
}

