#include "mka/retail_game_session.hpp"
#include <new>
#include <utility>

namespace mka::retail {
NativeRetailGameSession::NativeRetailGameSession(std::shared_ptr<NativeRetailGameControls> controls,
    std::shared_ptr<NativeRetailMainSettings> settings,
    std::unique_ptr<NativeRetailTaskDomain> task_domain) noexcept
    : controls_(std::move(controls)), settings_(std::move(settings)),
      task_domain_(std::move(task_domain)) {}
std::shared_ptr<NativeRetailGameSession> NativeRetailGameSession::create(RetailGameSessionFailure& failure) noexcept {
    failure = {};
    try {
        auto controls = NativeRetailGameControls::create(failure.controls);
        if (!controls) {
            failure.kind = RetailGameSessionError::controls;
            failure.operation = "native game controls construction";
            return {};
        }
        auto settings = NativeRetailMainSettings::create(controls, failure.settings);
        if (!settings) {
            failure.kind = RetailGameSessionError::settings;
            failure.operation = "native game settings construction";
            return {};
        }
        auto task_domain = NativeRetailTaskDomain::create(controls, failure.task_domain);
        if (!task_domain) {
            failure.kind = RetailGameSessionError::task_domain;
            failure.operation = "native persistent task domain construction";
            return {};
        }
        return std::shared_ptr<NativeRetailGameSession>(new NativeRetailGameSession(
            std::move(controls), std::move(settings), std::move(task_domain)));
    } catch (const std::bad_alloc&) {
        failure.kind = RetailGameSessionError::allocation;
        failure.operation = "native game session allocation";
    } catch (...) {
        failure.kind = RetailGameSessionError::native_exception;
        failure.operation = "native game session construction";
    }
    return {};
}
bool NativeRetailGameSession::validate_current_thread(RetailGameSessionFailure& failure) const noexcept {
    failure = {};
    if (std::this_thread::get_id() == owner_thread_) return true;
    failure.kind = RetailGameSessionError::wrong_thread;
    failure.operation = "native game session owner thread";
    return false;
}
std::shared_ptr<NativeRetailGameControls> NativeRetailGameSession::controls(RetailGameSessionFailure& failure) const noexcept {
    if (!validate_current_thread(failure)) return {};
    return controls_;
}
std::shared_ptr<NativeRetailMainSettings> NativeRetailGameSession::settings(RetailGameSessionFailure& failure) const noexcept {
    if (!validate_current_thread(failure)) return {};
    return settings_;
}
std::optional<std::int32_t> NativeRetailGameSession::scalar_mode(
    RetailGameSessionFailure& failure) const noexcept {
    if (!validate_current_thread(failure)) return {};
    return scalar_mode_;
}
bool NativeRetailGameSession::store_scalar_mode_from_source(
    std::int32_t mode, RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return false;
    scalar_mode_ = mode;
    return true;
}
NativeRetailGameOptions* NativeRetailGameSession::game_options(RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &game_options_;
}
NativeRetailRandom* NativeRetailGameSession::random(RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &random_;
}
NativeRetailAuxiliaryWords* NativeRetailGameSession::auxiliary_words(RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &auxiliary_;
}
NativeRetailInitialTaskState* NativeRetailGameSession::initial_task_state(
    RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &initial_task_state_;
}
NativeRetailTaskDomain* NativeRetailGameSession::task_domain(
    RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return task_domain_.get();
}
RetailGameRecordResetSnapshot* NativeRetailGameSession::game_record_values(
    RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &game_record_values_;
}
RetailGameRecordsValues* NativeRetailGameSession::game_records_values(
    RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &game_records_values_;
}
NativeRetailProfileResourceIds* NativeRetailGameSession::profile_resource_ids(
    RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &profile_resource_ids_;
}
NativeRetailProfileAggregate* NativeRetailGameSession::profile_aggregate(
    RetailGameSessionFailure& failure) noexcept {
    if (!validate_current_thread(failure)) return nullptr;
    return &profile_aggregate_;
}
NativeRetailSceneReference* NativeRetailGameSession::live_scene_reference(
    RetailGameSessionFailure& failure) noexcept {
    if(!validate_current_thread(failure)) return nullptr;
    return &live_scene_reference_;
}
bool NativeRetailGameSession::ensure_game_task_lists(
    std::shared_ptr<NativeRetailGamePool> pool,
    RetailGameSessionFailure& failure) noexcept {
    if(!validate_current_thread(failure)) return false;
    if(game_task_lists_) {
        if(game_task_lists_->same_pool(pool,failure.task_lists)) return true;
        failure.kind=RetailGameSessionError::task_lists;
        failure.operation="retained source callback heads use another pool";
        return false;
    }
    auto lists=NativeRetailGameTaskLists::create(std::move(pool),failure.task_lists);
    if(!lists) {
        failure.kind=RetailGameSessionError::task_lists;
        failure.operation="retained source callback-head birth";
        return false;
    }
    game_task_lists_=std::move(lists);
    return true;
}
std::shared_ptr<NativeRetailGameTaskLists>
NativeRetailGameSession::game_task_lists(
    RetailGameSessionFailure& failure) const noexcept {
    if(!validate_current_thread(failure)) return {};
    return game_task_lists_;
}
bool NativeRetailGameSession::ensure_initial_game_tasks(
    std::shared_ptr<NativeRetailGamePool> pool,
    RetailGameSessionFailure& failure) noexcept {
    if(!validate_current_thread(failure)) return false;
    if(!game_task_lists_ || !game_task_lists_->same_pool(pool,failure.task_lists)) {
        failure.kind=RetailGameSessionError::task_lists;
        failure.operation="initial game tasks require same-session callback heads";
        return false;
    }
    if(initial_game_tasks_) {
        if(initial_game_tasks_->same_pool(pool,failure.initial_game_tasks) &&
           initial_game_tasks_->same_lists(game_task_lists_,failure.initial_game_tasks))
            return true;
        failure.kind=RetailGameSessionError::initial_game_tasks;
        failure.operation="retained initial task owner uses another pool";
        return false;
    }
    auto tasks=NativeRetailInitialGameTasks::create(
        game_task_lists_,std::move(pool),failure.initial_game_tasks);
    if(!tasks) {
        failure.kind=RetailGameSessionError::initial_game_tasks;
        failure.operation="retained initial game task owner birth";
        return false;
    }
    initial_game_tasks_=std::move(tasks);
    return true;
}
std::shared_ptr<NativeRetailInitialGameTasks>
NativeRetailGameSession::initial_game_tasks(
    RetailGameSessionFailure& failure) const noexcept {
    if(!validate_current_thread(failure)) return {};
    return initial_game_tasks_;
}
bool NativeRetailGameSession::retain_source_task_1588c0(
    std::shared_ptr<NativeRetailTaskObject> task,
    RetailGameSessionFailure& failure) noexcept {
    if(!validate_current_thread(failure)) return false;
    if(!task) {
        failure.kind=RetailGameSessionError::task_domain;
        failure.operation="1588C0 real published task missing";
        return false;
    }
    source_task_1588c0_=std::move(task);
    return true;
}
std::shared_ptr<NativeRetailTaskObject>
NativeRetailGameSession::source_task_1588c0(
    RetailGameSessionFailure& failure) const noexcept {
    if(!validate_current_thread(failure)) return {};
    return source_task_1588c0_;
}
} // namespace mka::retail
