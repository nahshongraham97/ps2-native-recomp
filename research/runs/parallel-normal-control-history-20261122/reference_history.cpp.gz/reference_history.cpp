// Independent reference transcription: original959C four explicit branches.
// Pure game integer control math only. No runtime/audio/device/guest-memory code.
#include <cstdint>
#include <fstream>
#include <sstream>
#include <array>
#include <iostream>
#include "tests/fixtures/retail_sound_curve_data.hpp"
using byte=std::uint8_t;using uint=std::uint32_t;using ushort=std::uint16_t;using undefined2=std::int16_t;
struct RefHistory {short left=-4096,right=-4096,region=32760,remaining=0,delta=32760,divisor=32760;};
const std::uint16_t* gains;const std::uint8_t* pans;
#define DAT_000102ac (*reinterpret_cast<const unsigned char*>(gains))
#define DAT_0001043c (*pans)
#define DAT_0001049f (*(pans+99))
int reference_abs(int x){return x<0?-x:x;}
int reference_delta(const RefHistory& h,short l,short r){return reference_abs(h.left-int(l))>=10001||reference_abs(h.right-int(r))>=10001;}

void reference_history(int param_1,RefHistory& h,short param_3,short param_4,ushort *param_5,
                 ushort *param_6)

{
  ushort uVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar3 = (param_3 + -0x4000) * 199;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x3fff;
  }
  iVar3 = iVar3 >> 0xe;
  iVar5 = -iVar3;
  if (param_1 == 0) {
    uVar1 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
    *param_5 = uVar1;
    *param_6 = uVar1;
  }
  else {
    if (param_1 == 1) {
      iVar4 = (int)param_4;
      if (iVar4 < 0x2001) {
        if (iVar4 < -0x2000) {
          param_4 = (short)((uint)((-0x4000 - iVar4) * 0x10000) >> 0x10);
        }
      }
      else {
        param_4 = (short)((uint)((0x4000 - iVar4) * 0x10000) >> 0x10);
      }
    }
    iVar4 = (int)param_4;
    if (iVar4 < 0x2001) {
      if (iVar4 < 0) {
        if (iVar4 < -0x2000) {
          if ((h.left < 1) && (h.right != -0x1000)) {
            iVar4 = (iVar4 + 0x2000) * -99;
            *param_5 = -*(short *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
          }
          else {
            iVar4 = (iVar4 + 0x2000) * -99;
            *param_5 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = -*(short *)(&DAT_000102ac + iVar5 * 2);
          }
          if (h.right == -0x1000) {
            h.left = *param_5;
            h.right = *param_6;
          }
          if ((h.region != 3) &&
             (iVar3 = reference_delta(h,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0))
          {
            h.delta = h.right - *param_6;
            uVar2 = reference_abs((int)h.delta / 0x9c4);
            h.divisor = uVar2;
            h.remaining = h.divisor;
          }
          if (0 < h.remaining) {
            *param_6 = h.right -
                       h.delta / h.divisor;
            h.remaining = h.remaining + -1;
          }
          h.region = 3;
        }
        else {
          if ((h.left < 1) && (h.right != -0x1000)) {
            iVar4 = iVar4 * 99;
            *param_5 = -*(short *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (short)(ushort)(byte)(&DAT_0001043c)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = -*(short *)(&DAT_000102ac + iVar5 * 2);
          }
          else {
            iVar4 = iVar4 * 99;
            *param_5 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (uint)(byte)(&DAT_0001043c)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
          }
          if (h.right == -0x1000) {
            h.left = *param_5;
            h.right = *param_6;
          }
          if ((h.region != 1) &&
             (iVar3 = reference_delta(h,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0))
          {
            h.delta = h.right - *param_6;
            uVar2 = reference_abs((int)h.delta / 0x9c4);
            h.divisor = uVar2;
            h.remaining = h.divisor;
          }
          if (0 < h.remaining) {
            *param_6 = h.right -
                       h.delta / h.divisor;
            h.remaining = h.remaining + -1;
          }
          h.region = 1;
        }
      }
      else {
        if ((h.right < 0) && (h.right != -0x1000)) {
          iVar4 = iVar4 * 99;
          *param_6 = -*(short *)(&DAT_000102ac + iVar3 * -2);
          if (iVar4 < 0) {
            iVar4 = iVar4 + 0x1fff;
          }
          iVar5 = iVar5 + (uint)(byte)(&DAT_0001043c)[iVar4 >> 0xd];
          if (199 < iVar5) {
            iVar5 = 199;
          }
          *param_5 = -*(short *)(&DAT_000102ac + iVar5 * 2);
        }
        else {
          iVar4 = iVar4 * 99;
          *param_6 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
          if (iVar4 < 0) {
            iVar4 = iVar4 + 0x1fff;
          }
          iVar5 = iVar5 + (uint)(byte)(&DAT_0001043c)[iVar4 >> 0xd];
          if (199 < iVar5) {
            iVar5 = 199;
          }
          *param_5 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
        }
        if (h.right == -0x1000) {
          h.left = *param_5;
          h.right = *param_6;
        }
        if ((h.region != 2) &&
           (iVar3 = reference_delta(h,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0)) {
          h.delta = h.left - *param_5;
          uVar2 = reference_abs((int)h.delta / 0x9c4);
          h.divisor = uVar2;
          h.remaining = h.divisor;
        }
        if (0 < h.remaining) {
          *param_5 = h.left -
                     h.delta / h.divisor;
          h.remaining = h.remaining + -1;
        }
        h.region = 2;
      }
    }
    else {
      if ((h.right < 1) && (h.right != -0x1000)) {
        iVar4 = (iVar4 + -0x2000) * -99;
        *param_6 = -*(short *)(&DAT_000102ac + iVar3 * -2);
        if (iVar4 < 0) {
          iVar4 = iVar4 + 0x1fff;
        }
        iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[iVar4 >> 0xd];
        if (199 < iVar5) {
          iVar5 = 199;
        }
        *param_5 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
      }
      else {
        iVar4 = (iVar4 + -0x2000) * -99;
        *param_6 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
        if (iVar4 < 0) {
          iVar4 = iVar4 + 0x1fff;
        }
        iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[iVar4 >> 0xd];
        if (199 < iVar5) {
          iVar5 = 199;
        }
        *param_5 = -*(short *)(&DAT_000102ac + iVar5 * 2);
      }
      if (h.right == -0x1000) {
        h.left = *param_5;
        h.right = *param_6;
      }
      if ((h.region != 4) &&
         (iVar3 = reference_delta(h,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0)) {
        h.delta = h.left - *param_5;
        uVar2 = reference_abs((int)h.delta / 0x9c4);
        h.divisor = uVar2;
        h.remaining = h.divisor;
      }
      if (0 < h.remaining) {
        *param_5 = h.left -
                   h.delta / h.divisor;
        h.remaining = h.remaining + -1;
      }
      h.region = 4;
    }
    h.left = *param_5;
    h.right = *param_6;
    if ((short)*param_5 < 0) {
      *param_5 = *param_5 & 0x7fff;
    }
    if ((short)*param_6 < 0) {
      *param_6 = *param_6 & 0x7fff;
    }
  }
  return;
}


int gain_q15(ushort bits){int word=bits&32767;return 2*((word&16384)?word-32768:word);}
int main(int argc,char** argv){if(argc!=2)return 2;std::ostringstream rows;std::size_t count=0;
for(int curve=0;curve<2;++curve)for(int planes=1;planes<=2;++planes){
 gains=curve?sound_curve_fixture::linear_gain.data():sound_curve_fixture::initial_gain.data();
 pans=curve?sound_curve_fixture::linear_pan.data():sound_curve_fixture::initial_pan.data();
 RefHistory h;bool known_region=false,known_transition=false;
 auto emit=[&](int reset,int mode,int volume,int pan){
  if(reset==1){h={};known_region=known_transition=false;}
  const auto before=h;const bool kr=known_region,kt=known_transition;
  int outputs[4]{};
  for(int plane=0;plane<planes;++plane){ushort left,right;reference_history(mode,h,short(volume),short(pan),&left,&right);
   outputs[plane*2]=gain_q15(left);outputs[plane*2+1]=gain_q15(right);
   if(mode&&planes==2)outputs[plane*2+(plane==0?1:0)]=0;
   if(mode)known_region=true;if(h.divisor!=32760)known_transition=true;
  }
  rows<<reset<<' '<<curve<<' '<<planes<<' '<<mode<<' '<<volume<<' '<<pan<<' '
   <<before.left<<' '<<before.right<<' '<<before.region<<' '<<before.remaining<<' '<<before.delta<<' '<<before.divisor<<' '<<kr<<' '<<kt;
  for(int x:outputs)rows<<' '<<x;
  rows<<' '<<h.left<<' '<<h.right<<' '<<h.region<<' '<<h.remaining<<' '<<h.delta<<' '<<h.divisor<<' '<<known_region<<' '<<known_transition<<'\n';++count;
 };
 const int positions[]{-16384,-12288,-8193,-8192,-1,0,1,8192,8193,12288,16384};
 for(int a:positions)for(int b:positions){
  emit(1,3,16384,a);for(int n=0;n<16;++n)emit(0,3,16384,b);
  emit(0,0,8192,a);emit(0,1,16384,b);emit(0,3,0,a);emit(0,3,16384,a);
 }
 emit(1,3,16384,0);std::uint32_t rng=0x2917493u;
 for(int n=0;n<4096;++n){rng=rng*1664525u+1013904223u;const auto volume=int(rng%16385);rng=rng*1664525u+1013904223u;const auto pan=int(rng%32769)-16384;const int modes[]{0,1,3};emit(0,modes[(rng>>18)%3],volume,pan);}
 // Explicit mathematical state fixtures, not inferred game producers.
 for(int cached:{10000,10001,-10000,-10001,32767,-32768}){
  h={};h.left=short(cached);h.right=short(cached);h.region=1;known_region=true;known_transition=false;emit(2,3,0,0);
 }
}
std::ofstream file(argv[1],std::ios::binary);file<<count<<'\n'<<rows.str();std::cout<<"SOURCE_CONTROL_HISTORY_ROWS "<<count<<'\n';return file?0:1;}
