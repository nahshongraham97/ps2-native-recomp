
undefined4 FUN_00009534(int param_1,short param_2,short param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = (int)*(short *)(param_1 + 0x52) - (int)param_3;
  iVar1 = FUN_0000934c((int)*(short *)(param_1 + 0x50) - (int)param_2,iVar3);
  if ((iVar1 < 0x2711) && (iVar1 = FUN_0000934c(iVar3), iVar1 < 0x2711)) {
    uVar2 = 0;
  }
  else {
    uVar2 = 1;
  }
  return uVar2;
}

