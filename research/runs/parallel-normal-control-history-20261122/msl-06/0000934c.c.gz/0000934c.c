
int FUN_0000934c(int param_1)

{
  if (param_1 == 0) {
    param_1 = 0;
  }
  else if (param_1 < 1) {
    param_1 = -param_1;
  }
  return param_1;
}

