
undefined4 FUN_0000a49c(int param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  
  if (*(int *)(param_3 + 4) != 0) {
    FUN_0000a298(param_1,param_3,0);
  }
  *(int *)(param_3 + 8) = param_2;
  *(undefined4 *)(param_3 + 0x24) = param_4;
  *(undefined2 *)(param_3 + 0x50) = 0xf000;
  *(undefined2 *)(param_3 + 0x52) = 0xf000;
  *(undefined2 *)(param_3 + 0x56) = 0;
  if ((*(ushort *)(param_3 + 0xc) & 2) == 0) {
    iVar1 = FUN_00006330(param_1,param_3,(*(ushort *)(param_2 + 0x1e) & 8) == 0);
    if (iVar1 != 0) {
      return 2;
    }
  }
  else {
    iVar1 = FUN_00006798(param_1,param_3,(*(ushort *)(param_2 + 0x1e) & 8) == 0);
    if (iVar1 != 0) {
      return 1;
    }
  }
  FUN_0000a7d8(param_1 + 0x3ac);
  FUN_000046a8(param_2 + 0x28,param_3);
  FUN_0000a7e4(param_1 + 0x3ac);
  return 0;
}

