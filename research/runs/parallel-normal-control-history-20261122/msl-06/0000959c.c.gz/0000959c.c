
void FUN_0000959c(int param_1,int param_2,short param_3,short param_4,ushort *param_5,
                 ushort *param_6)

{
  ushort uVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar3 = (param_3 + -0x4000) * 199;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x3fff;
  }
  iVar3 = iVar3 >> 0xe;
  iVar5 = -iVar3;
  if (param_1 == 0) {
    uVar1 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
    *param_5 = uVar1;
    *param_6 = uVar1;
  }
  else {
    if (param_1 == 1) {
      iVar4 = (int)param_4;
      if (iVar4 < 0x2001) {
        if (iVar4 < -0x2000) {
          param_4 = (short)((uint)((-0x4000 - iVar4) * 0x10000) >> 0x10);
        }
      }
      else {
        param_4 = (short)((uint)((0x4000 - iVar4) * 0x10000) >> 0x10);
      }
    }
    iVar4 = (int)param_4;
    if (iVar4 < 0x2001) {
      if (iVar4 < 0) {
        if (iVar4 < -0x2000) {
          if ((*(short *)(param_2 + 0x50) < 1) && (*(short *)(param_2 + 0x52) != -0x1000)) {
            iVar4 = (iVar4 + 0x2000) * -99;
            *param_5 = -*(short *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
          }
          else {
            iVar4 = (iVar4 + 0x2000) * -99;
            *param_5 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = -*(short *)(&DAT_000102ac + iVar5 * 2);
          }
          if (*(short *)(param_2 + 0x52) == -0x1000) {
            *(ushort *)(param_2 + 0x50) = *param_5;
            *(ushort *)(param_2 + 0x52) = *param_6;
          }
          if ((*(short *)(param_2 + 0x54) != 3) &&
             (iVar3 = FUN_00009534(param_2,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0))
          {
            *(ushort *)(param_2 + 0x58) = *(short *)(param_2 + 0x52) - *param_6;
            uVar2 = FUN_0000934c((int)*(short *)(param_2 + 0x58) / 0x9c4);
            *(undefined2 *)(param_2 + 0x5a) = uVar2;
            *(undefined2 *)(param_2 + 0x56) = *(undefined2 *)(param_2 + 0x5a);
          }
          if (0 < *(short *)(param_2 + 0x56)) {
            *param_6 = *(short *)(param_2 + 0x52) -
                       *(short *)(param_2 + 0x58) / *(short *)(param_2 + 0x5a);
            *(short *)(param_2 + 0x56) = *(short *)(param_2 + 0x56) + -1;
          }
          *(undefined2 *)(param_2 + 0x54) = 3;
        }
        else {
          if ((*(short *)(param_2 + 0x50) < 1) && (*(short *)(param_2 + 0x52) != -0x1000)) {
            iVar4 = iVar4 * 99;
            *param_5 = -*(short *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (short)(ushort)(byte)(&DAT_0001043c)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = -*(short *)(&DAT_000102ac + iVar5 * 2);
          }
          else {
            iVar4 = iVar4 * 99;
            *param_5 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0x1fff;
            }
            iVar5 = iVar5 + (uint)(byte)(&DAT_0001043c)[-(iVar4 >> 0xd)];
            if (199 < iVar5) {
              iVar5 = 199;
            }
            *param_6 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
          }
          if (*(short *)(param_2 + 0x52) == -0x1000) {
            *(ushort *)(param_2 + 0x50) = *param_5;
            *(ushort *)(param_2 + 0x52) = *param_6;
          }
          if ((*(short *)(param_2 + 0x54) != 1) &&
             (iVar3 = FUN_00009534(param_2,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0))
          {
            *(ushort *)(param_2 + 0x58) = *(short *)(param_2 + 0x52) - *param_6;
            uVar2 = FUN_0000934c((int)*(short *)(param_2 + 0x58) / 0x9c4);
            *(undefined2 *)(param_2 + 0x5a) = uVar2;
            *(undefined2 *)(param_2 + 0x56) = *(undefined2 *)(param_2 + 0x5a);
          }
          if (0 < *(short *)(param_2 + 0x56)) {
            *param_6 = *(short *)(param_2 + 0x52) -
                       *(short *)(param_2 + 0x58) / *(short *)(param_2 + 0x5a);
            *(short *)(param_2 + 0x56) = *(short *)(param_2 + 0x56) + -1;
          }
          *(undefined2 *)(param_2 + 0x54) = 1;
        }
      }
      else {
        if ((*(short *)(param_2 + 0x52) < 0) && (*(short *)(param_2 + 0x52) != -0x1000)) {
          iVar4 = iVar4 * 99;
          *param_6 = -*(short *)(&DAT_000102ac + iVar3 * -2);
          if (iVar4 < 0) {
            iVar4 = iVar4 + 0x1fff;
          }
          iVar5 = iVar5 + (uint)(byte)(&DAT_0001043c)[iVar4 >> 0xd];
          if (199 < iVar5) {
            iVar5 = 199;
          }
          *param_5 = -*(short *)(&DAT_000102ac + iVar5 * 2);
        }
        else {
          iVar4 = iVar4 * 99;
          *param_6 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
          if (iVar4 < 0) {
            iVar4 = iVar4 + 0x1fff;
          }
          iVar5 = iVar5 + (uint)(byte)(&DAT_0001043c)[iVar4 >> 0xd];
          if (199 < iVar5) {
            iVar5 = 199;
          }
          *param_5 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
        }
        if (*(short *)(param_2 + 0x52) == -0x1000) {
          *(ushort *)(param_2 + 0x50) = *param_5;
          *(ushort *)(param_2 + 0x52) = *param_6;
        }
        if ((*(short *)(param_2 + 0x54) != 2) &&
           (iVar3 = FUN_00009534(param_2,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0)) {
          *(ushort *)(param_2 + 0x58) = *(short *)(param_2 + 0x50) - *param_5;
          uVar2 = FUN_0000934c((int)*(short *)(param_2 + 0x58) / 0x9c4);
          *(undefined2 *)(param_2 + 0x5a) = uVar2;
          *(undefined2 *)(param_2 + 0x56) = *(undefined2 *)(param_2 + 0x5a);
        }
        if (0 < *(short *)(param_2 + 0x56)) {
          *param_5 = *(short *)(param_2 + 0x50) -
                     *(short *)(param_2 + 0x58) / *(short *)(param_2 + 0x5a);
          *(short *)(param_2 + 0x56) = *(short *)(param_2 + 0x56) + -1;
        }
        *(undefined2 *)(param_2 + 0x54) = 2;
      }
    }
    else {
      if ((*(short *)(param_2 + 0x52) < 1) && (*(short *)(param_2 + 0x52) != -0x1000)) {
        iVar4 = (iVar4 + -0x2000) * -99;
        *param_6 = -*(short *)(&DAT_000102ac + iVar3 * -2);
        if (iVar4 < 0) {
          iVar4 = iVar4 + 0x1fff;
        }
        iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[iVar4 >> 0xd];
        if (199 < iVar5) {
          iVar5 = 199;
        }
        *param_5 = *(ushort *)(&DAT_000102ac + iVar5 * 2);
      }
      else {
        iVar4 = (iVar4 + -0x2000) * -99;
        *param_6 = *(ushort *)(&DAT_000102ac + iVar3 * -2);
        if (iVar4 < 0) {
          iVar4 = iVar4 + 0x1fff;
        }
        iVar5 = iVar5 + (uint)(byte)(&DAT_0001049f)[iVar4 >> 0xd];
        if (199 < iVar5) {
          iVar5 = 199;
        }
        *param_5 = -*(short *)(&DAT_000102ac + iVar5 * 2);
      }
      if (*(short *)(param_2 + 0x52) == -0x1000) {
        *(ushort *)(param_2 + 0x50) = *param_5;
        *(ushort *)(param_2 + 0x52) = *param_6;
      }
      if ((*(short *)(param_2 + 0x54) != 4) &&
         (iVar3 = FUN_00009534(param_2,(int)(short)*param_5,(int)(short)*param_6), iVar3 != 0)) {
        *(ushort *)(param_2 + 0x58) = *(short *)(param_2 + 0x50) - *param_5;
        uVar2 = FUN_0000934c((int)*(short *)(param_2 + 0x58) / 0x9c4);
        *(undefined2 *)(param_2 + 0x5a) = uVar2;
        *(undefined2 *)(param_2 + 0x56) = *(undefined2 *)(param_2 + 0x5a);
      }
      if (0 < *(short *)(param_2 + 0x56)) {
        *param_5 = *(short *)(param_2 + 0x50) -
                   *(short *)(param_2 + 0x58) / *(short *)(param_2 + 0x5a);
        *(short *)(param_2 + 0x56) = *(short *)(param_2 + 0x56) + -1;
      }
      *(undefined2 *)(param_2 + 0x54) = 4;
    }
    *(ushort *)(param_2 + 0x50) = *param_5;
    *(ushort *)(param_2 + 0x52) = *param_6;
    if ((short)*param_5 < 0) {
      *param_5 = *param_5 & 0x7fff;
    }
    if ((short)*param_6 < 0) {
      *param_6 = *param_6 & 0x7fff;
    }
  }
  return;
}

