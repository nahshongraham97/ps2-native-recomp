
void FUN_00003fcc(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0x290) * (int)*(short *)(param_2 + 0x12);
  if (iVar2 < 0) {
    iVar2 = iVar2 + 0x3fff;
  }
  iVar2 = (int)*(short *)(param_3 + 0x44) * (iVar2 >> 0xe);
  if (iVar2 < 0) {
    iVar2 = iVar2 + 0x3fff;
  }
  iVar2 = iVar2 >> 0xe;
  iVar3 = *(int *)(param_1 + 0x298) * (int)*(short *)(param_2 + 0x16);
  iVar4 = (int)*(short *)(param_3 + 0x46) +
          *(int *)(param_1 + 0x294) + (int)*(short *)(param_2 + 0x14);
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0xfff;
  }
  iVar3 = (int)*(short *)(param_3 + 0x48) * (iVar3 >> 0xc);
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0xfff;
  }
  iVar3 = iVar3 >> 0xc;
  if ((*(ushort *)(param_3 + 0xc) & 4) != 0) {
    iVar2 = iVar2 * *(int *)(param_1 + 0x29c);
    if (iVar2 < 0) {
      iVar2 = iVar2 + 0x3fff;
    }
    iVar2 = (int)*(short *)(param_2 + 0x18) * (iVar2 >> 0xe);
    if (iVar2 < 0) {
      iVar2 = iVar2 + 0x3fff;
    }
    iVar2 = iVar2 >> 0xe;
    iVar3 = iVar3 * *(int *)(param_1 + 0x2a4);
    iVar4 = iVar4 + *(int *)(param_1 + 0x2a0) + (int)*(short *)(param_2 + 0x1a);
    if (iVar3 < 0) {
      iVar3 = iVar3 + 0xfff;
    }
    iVar1 = (int)*(short *)(param_2 + 0x1c) * (iVar3 >> 0xc);
    iVar3 = iVar1 >> 0xc;
    if (iVar1 < 0) {
      iVar3 = iVar1 + 0xfff >> 0xc;
    }
  }
  FUN_00009f1c(param_1,param_3,iVar2,iVar4);
  FUN_0000a0ec(param_1,param_3,iVar3);
  return;
}

