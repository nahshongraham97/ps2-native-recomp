
void FUN_002e8f80(int param_1,int param_2)

{
  param_1 = param_1 * 0x1c;
  if ((*(char *)(param_1 + 0x6d0918) != '\0') &&
     (*(undefined1 *)(param_1 + 0x6d0918) = 0, param_2 <= *(int *)(param_1 + 0x6d0914))) {
    *(int *)(param_1 + 0x6d0910) = *(int *)(param_1 + 0x6d0910) + (param_2 + 0xfU & 0xfffffff0);
  }
  return;
}

