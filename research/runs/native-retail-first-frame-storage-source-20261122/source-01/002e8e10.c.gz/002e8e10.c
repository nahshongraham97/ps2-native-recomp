
void FUN_002e8e10(void)

{
  int iVar1;
  int iVar2;
  
  iVar2 = 0;
  iVar1 = 0x6d0910;
  do {
    FUN_001dba60(iVar1,0,0x1c);
    iVar2 = iVar2 + 1;
    iVar1 = iVar1 + 0x1c;
  } while (iVar2 < 2);
  uRam006d091b = 3;
  uRam006d0924 = 150000;
  uRam006d0920 = 0x6d0950;
  uRam006d091c = 0x6d0950;
  uRam006d0937 = 2;
  uRam006d0940 = 150000;
  uRam006d093c = 0x73e730;
  uRam006d0938 = 0x73e730;
  return;
}

