
void FUN_002e8ee0(void)

{
  byte bVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = 0;
  piVar2 = (int *)0x6d0910;
  do {
    if (0 < *piVar2) {
      *piVar2 = 0;
      *(undefined1 *)(piVar2 + 2) = 0;
      piVar2[6] = 0;
      bVar1 = *(byte *)((int)piVar2 + 10);
      if (*(char *)((int)piVar2 + 9) == '\0') {
        uVar3 = bVar1 + 1;
        if (*(byte *)((int)piVar2 + 0xb) <= uVar3) {
          uVar3 = 0;
        }
      }
      else if (bVar1 == 0) {
        uVar3 = *(byte *)((int)piVar2 + 0xb) - 1;
      }
      else {
        uVar3 = bVar1 - 1;
      }
      *(char *)((int)piVar2 + 10) = (char)uVar3;
      piVar2[3] = piVar2[4] + uVar3 * piVar2[5];
    }
    iVar4 = iVar4 + 1;
    piVar2 = piVar2 + 7;
  } while (iVar4 < 2);
  return;
}

