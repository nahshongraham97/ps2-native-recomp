
void FUN_001a4fc0(int param_1)

{
  int iVar1;
  float *pfVar2;
  float *pfVar3;
  float *pfVar4;
  int iVar5;
  float *pfVar6;
  int iVar7;
  float fVar8;
  undefined4 uVar9;
  float fVar10;
  float fVar11;
  undefined4 uVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  
  iVar1 = *(int *)(param_1 + 4);
  pfVar3 = (float *)(param_1 + 0x124);
  pfVar2 = (float *)(param_1 + 0x94);
  fVar10 = -*(float *)(param_1 + 0x78);
  iVar7 = 0;
  iVar5 = 0;
  fVar8 = *(float *)(param_1 + 0x7c);
  fVar13 = *(float *)(iVar1 + 0x60) * fVar8 + *(float *)(iVar1 + 0x50) * fVar10;
  fVar15 = *(float *)(iVar1 + 100) * fVar8 + *(float *)(iVar1 + 0x54) * fVar10 + 0.0;
  fVar16 = *(float *)(param_1 + 0x68);
  fVar14 = *(float *)(iVar1 + 0x68) * fVar8 + *(float *)(iVar1 + 0x58) * fVar10 + 0.0;
  fVar8 = *(float *)(iVar1 + 0x50) * fVar16;
  fVar19 = *(float *)(iVar1 + 0x54) * fVar16;
  fVar16 = *(float *)(iVar1 + 0x58) * fVar16;
  fVar11 = *(float *)(param_1 + 0x6c);
  fVar20 = fVar8 * 2.0;
  fVar18 = *(float *)(iVar1 + 0x60) * fVar11;
  fVar10 = *(float *)(iVar1 + 100) * fVar11;
  fVar11 = *(float *)(iVar1 + 0x68) * fVar11;
  fVar21 = *(float *)(iVar1 + 0x70) + fVar8 + fVar18;
  fVar8 = *(float *)(iVar1 + 0x74) + fVar19 + fVar10;
  fVar17 = *(float *)(iVar1 + 0x78) + fVar16 + fVar11;
  fVar19 = fVar19 * 2.0;
  *(float *)(param_1 + 0x124) = fVar21;
  *(float *)(param_1 + 0x128) = fVar8;
  fVar8 = fVar8 - fVar19;
  *(float *)(param_1 + 300) = fVar17;
  fVar21 = fVar21 - fVar20;
  fVar16 = fVar16 * 2.0;
  fVar10 = fVar8 - fVar10 * 2.0;
  fVar17 = fVar17 - fVar16;
  fVar18 = fVar21 - fVar18 * 2.0;
  fVar11 = fVar17 - fVar11 * 2.0;
  *(float *)(param_1 + 0x130) = fVar21;
  *(float *)(param_1 + 0x134) = fVar8;
  *(float *)(param_1 + 0x138) = fVar17;
  *(float *)(param_1 + 0x13c) = fVar18;
  *(float *)(param_1 + 0x140) = fVar10;
  *(float *)(param_1 + 0x144) = fVar11;
  *(float *)(param_1 + 0x148) = fVar18 + fVar20;
  *(float *)(param_1 + 0x14c) = fVar10 + fVar19;
  *(float *)(param_1 + 0x150) = fVar11 + fVar16;
  pfVar6 = pfVar3;
  do {
    fVar8 = *pfVar6;
    pfVar4 = (float *)((int)pfVar3 + iVar5 + 0x30);
    iVar7 = iVar7 + 1;
    iVar5 = iVar5 + 0xc;
    fVar10 = pfVar6[1];
    fVar11 = pfVar6[2];
    *pfVar6 = fVar13 + *(float *)(iVar1 + 0x80);
    pfVar6[1] = fVar15 + *(float *)(iVar1 + 0x84);
    pfVar6[2] = fVar14 + *(float *)(iVar1 + 0x88);
    *pfVar6 = (fVar8 - fVar13) * *(float *)(param_1 + 0x80) + *pfVar6 + 0.0;
    pfVar6[1] = (fVar10 - fVar15) * *(float *)(param_1 + 0x80) + pfVar6[1] + 0.0;
    pfVar6[2] = (fVar11 - fVar14) * *(float *)(param_1 + 0x80) + pfVar6[2] + 0.0;
    pfVar6 = pfVar6 + 3;
    *pfVar4 = fVar13 + *(float *)(iVar1 + 0x80);
    pfVar4[1] = fVar15 + *(float *)(iVar1 + 0x84);
    pfVar4[2] = fVar14 + *(float *)(iVar1 + 0x88);
    *pfVar4 = (fVar8 - fVar13) * *(float *)(param_1 + 0x84) + *pfVar4 + 0.0;
    pfVar4[1] = (fVar10 - fVar15) * *(float *)(param_1 + 0x84) + pfVar4[1] + 0.0;
    pfVar4[2] = (fVar11 - fVar14) * *(float *)(param_1 + 0x84) + pfVar4[2] + 0.0;
  } while (iVar7 < 4);
  uVar9 = *(undefined4 *)(iVar1 + 0x74);
  uVar12 = *(undefined4 *)(iVar1 + 0x78);
  *pfVar2 = *(float *)(iVar1 + 0x70);
  *(undefined4 *)(param_1 + 0x98) = uVar9;
  *(undefined4 *)(param_1 + 0x9c) = uVar12;
  *(float *)(param_1 + 0xa0) =
       *(float *)(param_1 + 0x15c) * *(float *)(iVar1 + 0x78) +
       *(float *)(param_1 + 0x154) * *(float *)(iVar1 + 0x70) +
       *(float *)(param_1 + 0x158) * *(float *)(iVar1 + 0x74) + 0.0 + 0.0;
  *(char *)(param_1 + 0xa4) = (char)((int)*pfVar2 >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xa5) = (char)((int)*(undefined4 *)(param_1 + 0x98) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xa6) = (char)((int)*(undefined4 *)(param_1 + 0x9c) >> 0x1f) + '\x01';
  *(float *)(param_1 + 0xa8) = -*pfVar2;
  *(float *)(param_1 + 0xac) = -*(float *)(param_1 + 0x98);
  *(float *)(param_1 + 0xb0) = -*(float *)(param_1 + 0x9c);
  *(float *)(param_1 + 0xb4) =
       *(float *)(param_1 + 300) * *(float *)(param_1 + 0xb0) +
       *pfVar3 * *(float *)(param_1 + 0xa8) +
       *(float *)(param_1 + 0x128) * *(float *)(param_1 + 0xac) + 0.0 + 0.0;
  *(char *)(param_1 + 0xb8) = (char)((int)*(undefined4 *)(param_1 + 0xa8) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xb9) = (char)((int)*(undefined4 *)(param_1 + 0xac) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xba) = (char)((int)*(undefined4 *)(param_1 + 0xb0) >> 0x1f) + '\x01';
  fVar10 = *(float *)(param_1 + 0x130) - *(float *)(param_1 + 0x160);
  fVar13 = *(float *)(param_1 + 0x16c) - *(float *)(param_1 + 0x160);
  fVar11 = *(float *)(param_1 + 0x138) - *(float *)(param_1 + 0x168);
  fVar8 = *(float *)(param_1 + 0x134) - *(float *)(param_1 + 0x164);
  fVar18 = *(float *)(param_1 + 0x174) - *(float *)(param_1 + 0x168);
  fVar21 = *(float *)(param_1 + 0x170) - *(float *)(param_1 + 0x164);
  *(float *)(param_1 + 0xbc) = (fVar8 * fVar18 + 0.0) - fVar11 * fVar21;
  *(float *)(param_1 + 0xc0) = (fVar11 * fVar13 + 0.0) - fVar10 * fVar18;
  *(float *)(param_1 + 0xc4) = (fVar10 * fVar21 + 0.0) - fVar8 * fVar13;
  fVar21 = SQRT(*(float *)(param_1 + 0xc4) * *(float *)(param_1 + 0xc4) +
                *(float *)(param_1 + 0xbc) * *(float *)(param_1 + 0xbc) +
                *(float *)(param_1 + 0xc0) * *(float *)(param_1 + 0xc0) + 0.0 + 0.0);
  if (0.0 < fVar21) {
    fVar21 = 1.0 / fVar21;
  }
  *(float *)(param_1 + 0xbc) = *(float *)(param_1 + 0xbc) * fVar21;
  *(float *)(param_1 + 0xc0) = *(float *)(param_1 + 0xc0) * fVar21;
  *(float *)(param_1 + 0xc4) = *(float *)(param_1 + 0xc4) * fVar21;
  *(float *)(param_1 + 200) =
       *(float *)(param_1 + 0x138) * *(float *)(param_1 + 0xc4) +
       *(float *)(param_1 + 0x130) * *(float *)(param_1 + 0xbc) +
       *(float *)(param_1 + 0x134) * *(float *)(param_1 + 0xc0);
  *(char *)(param_1 + 0xcc) = (char)((int)*(undefined4 *)(param_1 + 0xbc) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xcd) = (char)((int)*(undefined4 *)(param_1 + 0xc0) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xce) = (char)((int)*(undefined4 *)(param_1 + 0xc4) >> 0x1f) + '\x01';
  fVar13 = *(float *)(param_1 + 0x154) - *(float *)(param_1 + 0x160);
  fVar21 = *(float *)(param_1 + 0x158) - *(float *)(param_1 + 0x164);
  fVar18 = *(float *)(param_1 + 0x15c) - *(float *)(param_1 + 0x168);
  *(float *)(param_1 + 0xd0) = fVar21 * fVar11 - fVar18 * fVar8;
  *(float *)(param_1 + 0xd4) = fVar18 * fVar10 - fVar13 * fVar11;
  *(float *)(param_1 + 0xd8) = fVar13 * fVar8 - fVar21 * fVar10;
  fVar8 = SQRT(*(float *)(param_1 + 0xd8) * *(float *)(param_1 + 0xd8) +
               *(float *)(param_1 + 0xd0) * *(float *)(param_1 + 0xd0) +
               *(float *)(param_1 + 0xd4) * *(float *)(param_1 + 0xd4));
  if (0.0 < fVar8) {
    fVar8 = 1.0 / fVar8;
  }
  *(float *)(param_1 + 0xd0) = *(float *)(param_1 + 0xd0) * fVar8;
  *(float *)(param_1 + 0xd4) = *(float *)(param_1 + 0xd4) * fVar8;
  *(float *)(param_1 + 0xd8) = *(float *)(param_1 + 0xd8) * fVar8;
  *(float *)(param_1 + 0xdc) =
       *(float *)(param_1 + 0x138) * *(float *)(param_1 + 0xd8) +
       *(float *)(param_1 + 0x130) * *(float *)(param_1 + 0xd0) +
       *(float *)(param_1 + 0x134) * *(float *)(param_1 + 0xd4);
  *(char *)(param_1 + 0xe0) = (char)((int)*(undefined4 *)(param_1 + 0xd0) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xe1) = (char)((int)*(undefined4 *)(param_1 + 0xd4) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xe2) = (char)((int)*(undefined4 *)(param_1 + 0xd8) >> 0x1f) + '\x01';
  fVar8 = *(float *)(param_1 + 0x14c) - *(float *)(param_1 + 0x17c);
  fVar10 = *(float *)(param_1 + 0x148) - *(float *)(param_1 + 0x178);
  fVar21 = *(float *)(param_1 + 0x158) - *(float *)(param_1 + 0x17c);
  fVar13 = *(float *)(param_1 + 0x154) - *(float *)(param_1 + 0x178);
  fVar18 = *(float *)(param_1 + 0x15c) - *(float *)(param_1 + 0x180);
  fVar11 = *(float *)(param_1 + 0x150) - *(float *)(param_1 + 0x180);
  *(float *)(param_1 + 0xe4) = fVar8 * fVar18 - fVar11 * fVar21;
  *(float *)(param_1 + 0xe8) = fVar11 * fVar13 - fVar10 * fVar18;
  *(float *)(param_1 + 0xec) = fVar10 * fVar21 - fVar8 * fVar13;
  fVar21 = SQRT(*(float *)(param_1 + 0xec) * *(float *)(param_1 + 0xec) +
                *(float *)(param_1 + 0xe4) * *(float *)(param_1 + 0xe4) +
                *(float *)(param_1 + 0xe8) * *(float *)(param_1 + 0xe8));
  if (0.0 < fVar21) {
    fVar21 = 1.0 / fVar21;
  }
  *(float *)(param_1 + 0xe4) = *(float *)(param_1 + 0xe4) * fVar21;
  *(float *)(param_1 + 0xe8) = *(float *)(param_1 + 0xe8) * fVar21;
  *(float *)(param_1 + 0xec) = *(float *)(param_1 + 0xec) * fVar21;
  *(float *)(param_1 + 0xf0) =
       *(float *)(param_1 + 0x150) * *(float *)(param_1 + 0xec) +
       *(float *)(param_1 + 0x148) * *(float *)(param_1 + 0xe4) +
       *(float *)(param_1 + 0x14c) * *(float *)(param_1 + 0xe8);
  *(char *)(param_1 + 0xf4) = (char)((int)*(undefined4 *)(param_1 + 0xe4) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xf5) = (char)((int)*(undefined4 *)(param_1 + 0xe8) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xf6) = (char)((int)*(undefined4 *)(param_1 + 0xec) >> 0x1f) + '\x01';
  fVar13 = *(float *)(param_1 + 0x16c) - *(float *)(param_1 + 0x178);
  fVar21 = *(float *)(param_1 + 0x170) - *(float *)(param_1 + 0x17c);
  fVar18 = *(float *)(param_1 + 0x174) - *(float *)(param_1 + 0x180);
  *(float *)(param_1 + 0xf8) = fVar21 * fVar11 - fVar18 * fVar8;
  *(float *)(param_1 + 0xfc) = fVar18 * fVar10 - fVar13 * fVar11;
  *(float *)(param_1 + 0x100) = fVar13 * fVar8 - fVar21 * fVar10;
  fVar8 = SQRT(*(float *)(param_1 + 0x100) * *(float *)(param_1 + 0x100) +
               *(float *)(param_1 + 0xf8) * *(float *)(param_1 + 0xf8) +
               *(float *)(param_1 + 0xfc) * *(float *)(param_1 + 0xfc));
  if (0.0 < fVar8) {
    fVar8 = 1.0 / fVar8;
  }
  *(float *)(param_1 + 0xf8) = *(float *)(param_1 + 0xf8) * fVar8;
  *(float *)(param_1 + 0xfc) = *(float *)(param_1 + 0xfc) * fVar8;
  *(float *)(param_1 + 0x100) = *(float *)(param_1 + 0x100) * fVar8;
  *(float *)(param_1 + 0x104) =
       *(float *)(param_1 + 0x150) * *(float *)(param_1 + 0x100) +
       *(float *)(param_1 + 0x148) * *(float *)(param_1 + 0xf8) +
       *(float *)(param_1 + 0x14c) * *(float *)(param_1 + 0xfc);
  *(char *)(param_1 + 0x108) = (char)((int)*(undefined4 *)(param_1 + 0xf8) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0x109) = (char)((int)*(undefined4 *)(param_1 + 0xfc) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0x10a) = (char)((int)*(undefined4 *)(param_1 + 0x100) >> 0x1f) + '\x01';
  return;
}

