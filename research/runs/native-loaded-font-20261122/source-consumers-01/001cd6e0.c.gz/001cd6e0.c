
long FUN_001cd6e0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  long lVar4;
  long lVar5;
  long lVar6;
  int iVar7;
  int *piVar8;
  undefined1 *puVar9;
  undefined1 *puVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  int aiStack_110 [64];
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  lVar4 = (*pcRam0069f3c4)(DAT_005a4350,0x3000b);
  if (lVar4 == 0) {
    uStack_8 = 2;
    uStack_4 = FUN_0019f510(0xffffffff80000013,DAT_005a4350);
    FUN_0019f460(&uStack_8);
    lVar4 = 0;
  }
  else {
    puVar10 = (undefined1 *)lVar4;
    *puVar10 = 7;
    puVar10[1] = 0;
    puVar10[2] = 0;
    puVar10[3] = 0;
    *(undefined4 *)(puVar10 + 4) = 0;
    FUN_001cc2b0(puVar10 + 0x10);
    *(undefined4 *)(puVar10 + 0xc) = 2;
    *(undefined4 *)(puVar10 + 8) = 0;
    lVar5 = (*pcRam0069f3c4)(DAT_005a4330,0x3000b);
    if (lVar5 == 0) {
      uStack_10 = 2;
      uStack_c = FUN_0019f510(0xffffffff80000013,4);
      FUN_0019f460(&uStack_10);
      (*pcRam0069f3c8)(lVar4);
      lVar4 = 0;
    }
    else {
      puVar2 = (undefined4 *)lVar5;
      *puVar2 = 0xffffffff;
      puVar2[0xd] = 0;
      puVar2[0x1e] = 0;
      puVar2[0xe] = puVar2 + 0xe;
      puVar2[0xf] = puVar2 + 0xe;
      puVar2[0x10] = puVar2 + 0x10;
      puVar2[0x11] = puVar2 + 0x10;
      *(undefined2 *)((int)puVar2 + 0x82) = 0;
      *(undefined2 *)(puVar2 + 0x21) = 0;
      puVar2[2] = 0;
      puVar2[1] = 0;
      puVar2[3] = 0;
      FUN_001dba60(puVar2 + 4,0,0x20);
      puVar2[0xc] = 0;
      uVar11 = param_1[4];
      uVar12 = param_1[5];
      puVar9 = puVar10 + 0x2c;
      puVar2[0x15] = param_1[3];
      puVar2[0x16] = uVar11;
      puVar2[0x17] = uVar12;
      uVar11 = param_1[1];
      uVar12 = param_1[2];
      puVar2[0x12] = *param_1;
      puVar2[0x13] = uVar11;
      puVar2[0x14] = uVar12;
      uVar11 = param_1[4];
      uVar12 = param_1[5];
      puVar2[0x1b] = param_1[3];
      puVar2[0x1c] = uVar11;
      puVar2[0x1d] = uVar12;
      uVar11 = param_1[1];
      uVar12 = param_1[2];
      puVar2[0x18] = *param_1;
      puVar2[0x19] = uVar11;
      puVar2[0x1a] = uVar12;
      puVar2[0x1f] = 0;
      *(undefined4 **)(puVar10 + 0x1c) = puVar2;
      *(undefined4 *)(puVar10 + 0x20) = 0;
      *(undefined4 *)(puVar10 + 0x4c) = 0;
      *(undefined4 *)(puVar10 + 0x48) = 0;
      *(undefined4 *)(puVar10 + 0x44) = 0;
      uVar11 = param_1[4];
      uVar12 = param_1[5];
      *(undefined4 *)(puVar10 + 0x5c) = param_1[3];
      *(undefined4 *)(puVar10 + 0x60) = uVar11;
      *(undefined4 *)(puVar10 + 100) = uVar12;
      uVar11 = param_1[1];
      uVar12 = param_1[2];
      *(undefined4 *)(puVar10 + 0x50) = *param_1;
      *(undefined4 *)(puVar10 + 0x54) = uVar11;
      *(undefined4 *)(puVar10 + 0x58) = uVar12;
      *(undefined1 **)(puVar10 + 0x2c) = puVar9;
      *(undefined1 **)(puVar10 + 0x30) = puVar9;
      *(undefined4 *)(puVar10 + 0x24) = 0;
      *(undefined1 **)(puVar10 + 0x28) = puVar9;
      *(undefined1 **)(puVar10 + 0x34) = puVar10 + 0x34;
      *(undefined1 **)(puVar10 + 0x38) = puVar10 + 0x34;
      *(undefined1 **)(puVar10 + 0x3c) = puVar10 + 0x3c;
      *(undefined1 **)(puVar10 + 0x40) = puVar10 + 0x3c;
      *(undefined4 *)(puVar10 + 0x6c) = 0;
      uVar11 = DAT_005a4350;
      lVar6 = (*pcRam0069f3d4)(*(undefined4 *)(iRam0064e740 + 0x69f290),0x40507);
      if (lVar6 != 0) {
        puVar2 = (undefined4 *)lVar6;
        *puVar2 = puVar10;
        puVar2[1] = uVar11;
        puVar2[2] = *(undefined4 *)(iRam0064e740 + 0x69f294);
        puVar2[3] = iRam0064e740 + 0x69f294;
        *(undefined4 **)(*(int *)(iRam0064e740 + 0x69f294) + 4) = puVar2 + 2;
        *(undefined4 **)(iRam0064e740 + 0x69f294) = puVar2 + 2;
      }
      FUN_001a3480(0x5a4350,lVar4);
      FUN_001a3480(0x5a4330,lVar5);
      piVar8 = *(int **)(puVar10 + 0x1c);
      iVar7 = 0;
      if (piVar8 == (int *)0x0) {
        lVar5 = 0;
      }
      else {
        iVar3 = *piVar8;
        while( true ) {
          if (iVar3 < 0) {
            piVar8 = (int *)aiStack_110[iVar7];
            iVar7 = iVar7 + -1;
          }
          else {
            piVar1 = piVar8 + 3;
            iVar7 = iVar7 + 1;
            piVar8 = (int *)piVar8[2];
            aiStack_110[iVar7] = *piVar1;
          }
          lVar5 = lVar4;
          if (iVar7 < 0) break;
          iVar3 = *piVar8;
        }
      }
      if (lVar5 == 0) {
        FUN_001cd470(lVar4);
        FUN_001cd500(lVar4);
        FUN_001cc210(puVar10 + 0x10);
        if ((puVar10[3] & 1) == 0) {
          if (*(int *)(puVar10 + 0x1c) != 0) {
            FUN_001cd030();
          }
          FUN_001a3520(0x5a4350,lVar4);
          (*pcRam0069f3c8)(lVar4);
          lVar4 = 0;
        }
        else {
          if (*(int *)(puVar10 + 0x1c) != 0) {
            FUN_001ccf20();
          }
          FUN_001a3520(0x5a4350,lVar4);
          (*pcRam0069f3c8)(lVar4);
          lVar4 = 0;
        }
      }
    }
  }
  return lVar4;
}

