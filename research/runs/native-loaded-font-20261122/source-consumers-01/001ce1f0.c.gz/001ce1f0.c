
void FUN_001ce1f0(int param_1,undefined8 param_2)

{
  int *piVar1;
  float *pfVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  float fVar7;
  int aiStack_120 [64];
  float afStack_20 [4];
  float afStack_10 [4];
  
  iVar4 = 0;
  pfVar2 = (float *)FUN_001c9520(param_2);
  piVar5 = *(int **)(param_1 + 0x1c);
  fVar7 = pfVar2[3];
  afStack_10[0] = *pfVar2 - fVar7;
  afStack_20[0] = *pfVar2 + fVar7;
  afStack_10[1] = pfVar2[1] - fVar7;
  afStack_20[1] = pfVar2[1] + fVar7;
  afStack_10[2] = pfVar2[2] - fVar7;
  afStack_20[2] = pfVar2[2] + fVar7;
  iVar6 = *piVar5;
  while( true ) {
    if (iVar6 < 0) {
      piVar3 = (int *)(*pcRam0069f3d4)(*(undefined4 *)(iRam0064e758 + 0x69f290),0x30507);
      piVar3[5] = (int)piVar5;
      iVar6 = (int)param_2;
      piVar3[2] = iVar6;
      *piVar3 = piVar5[0xe];
      piVar3[1] = (int)(piVar5 + 0xe);
      *(int **)(piVar5[0xe] + 4) = piVar3;
      piVar5[0xe] = (int)piVar3;
      piVar1 = (int *)aiStack_120[iVar4];
      piVar3[3] = *(int *)(iVar6 + 100);
      piVar3[4] = iVar6 + 100;
      *(int **)(*(int *)(iVar6 + 100) + 4) = piVar3 + 3;
      *(int **)(iVar6 + 100) = piVar3 + 3;
      iVar4 = iVar4 + -1;
    }
    else if (*(float *)((int)afStack_10 + iVar6) < (float)piVar5[4]) {
      piVar1 = (int *)piVar5[2];
      if ((float)piVar5[5] < *(float *)((int)afStack_20 + iVar6)) {
        iVar4 = iVar4 + 1;
        aiStack_120[iVar4] = piVar5[3];
      }
    }
    else if ((float)piVar5[5] < *(float *)((int)afStack_20 + iVar6)) {
      piVar1 = (int *)piVar5[3];
    }
    else {
      piVar1 = (int *)aiStack_120[iVar4];
      iVar4 = iVar4 + -1;
    }
    piVar5 = piVar1;
    if (iVar4 < 0) break;
    iVar6 = *piVar5;
  }
  return;
}

