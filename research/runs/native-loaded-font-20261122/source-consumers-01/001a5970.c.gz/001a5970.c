
void FUN_001a5970(int param_1)

{
  int iVar1;
  float *pfVar2;
  float *pfVar3;
  float fVar4;
  undefined4 uVar5;
  float fVar6;
  undefined4 uVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  
  pfVar3 = (float *)(param_1 + 0x124);
  iVar1 = *(int *)(param_1 + 4);
  fVar8 = *(float *)(param_1 + 0x80);
  pfVar2 = (float *)(param_1 + 0x94);
  fVar11 = *(float *)(param_1 + 0x68);
  fVar12 = *(float *)(param_1 + 0x6c);
  fVar9 = *(float *)(param_1 + 0x84);
  *(float *)(param_1 + 0x150) = fVar8;
  *(float *)(param_1 + 0x144) = fVar8;
  *(float *)(param_1 + 0x138) = fVar8;
  *(float *)(param_1 + 300) = fVar8;
  *(float *)(param_1 + 0x180) = fVar9;
  *(float *)(param_1 + 0x174) = fVar9;
  *(float *)(param_1 + 0x168) = fVar9;
  *(float *)(param_1 + 0x15c) = fVar9;
  fVar10 = (1.0 - fVar8) * -*(float *)(param_1 + 0x78);
  fVar4 = (1.0 - fVar9) * -*(float *)(param_1 + 0x78);
  fVar6 = (1.0 - fVar8) * *(float *)(param_1 + 0x7c);
  fVar8 = (1.0 - fVar9) * *(float *)(param_1 + 0x7c);
  fVar9 = fVar11 + fVar10;
  *(float *)(param_1 + 0x148) = fVar9;
  *(float *)(param_1 + 0x124) = fVar9;
  fVar10 = -fVar11 + fVar10;
  fVar9 = fVar11 + fVar4;
  *(float *)(param_1 + 0x13c) = fVar10;
  *(float *)(param_1 + 0x130) = fVar10;
  *(float *)(param_1 + 0x178) = fVar9;
  *(float *)(param_1 + 0x154) = fVar9;
  fVar4 = -fVar11 + fVar4;
  *(float *)(param_1 + 0x16c) = fVar4;
  *(float *)(param_1 + 0x160) = fVar4;
  fVar4 = fVar12 + fVar6;
  *(float *)(param_1 + 0x134) = fVar4;
  *(float *)(param_1 + 0x128) = fVar4;
  fVar6 = -fVar12 + fVar6;
  fVar4 = fVar12 + fVar8;
  *(float *)(param_1 + 0x14c) = fVar6;
  *(float *)(param_1 + 0x140) = fVar6;
  *(float *)(param_1 + 0x164) = fVar4;
  fVar8 = -fVar12 + fVar8;
  *(float *)(param_1 + 0x158) = fVar4;
  *(float *)(param_1 + 0x17c) = fVar8;
  *(float *)(param_1 + 0x170) = fVar8;
  FUN_001a3a90(pfVar3,pfVar3,8,iVar1 + 0x50);
  uVar7 = *(undefined4 *)(iVar1 + 0x74);
  uVar5 = *(undefined4 *)(iVar1 + 0x78);
  *pfVar2 = *(float *)(iVar1 + 0x70);
  *(undefined4 *)(param_1 + 0x98) = uVar7;
  *(undefined4 *)(param_1 + 0x9c) = uVar5;
  *(float *)(param_1 + 0xa0) =
       *(float *)(param_1 + 0x15c) * *(float *)(param_1 + 0x9c) +
       *(float *)(param_1 + 0x154) * *pfVar2 +
       *(float *)(param_1 + 0x158) * *(float *)(param_1 + 0x98);
  *(char *)(param_1 + 0xa4) = (char)((int)*pfVar2 >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xa5) = (char)((int)*(undefined4 *)(param_1 + 0x98) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xa6) = (char)((int)*(undefined4 *)(param_1 + 0x9c) >> 0x1f) + '\x01';
  *(float *)(param_1 + 0xa8) = -*pfVar2;
  *(float *)(param_1 + 0xac) = -*(float *)(param_1 + 0x98);
  *(float *)(param_1 + 0xb0) = -*(float *)(param_1 + 0x9c);
  *(float *)(param_1 + 0xb4) =
       *(float *)(param_1 + 300) * *(float *)(param_1 + 0xb0) +
       *pfVar3 * *(float *)(param_1 + 0xa8) +
       *(float *)(param_1 + 0x128) * *(float *)(param_1 + 0xac);
  *(char *)(param_1 + 0xb8) = (char)((int)*(undefined4 *)(param_1 + 0xa8) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xb9) = (char)((int)*(undefined4 *)(param_1 + 0xac) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xba) = (char)((int)*(undefined4 *)(param_1 + 0xb0) >> 0x1f) + '\x01';
  fVar9 = *(float *)(param_1 + 0x134) - *(float *)(param_1 + 0x164);
  fVar4 = *(float *)(param_1 + 0x130) - *(float *)(param_1 + 0x160);
  fVar11 = *(float *)(param_1 + 0x170) - *(float *)(param_1 + 0x164);
  fVar10 = *(float *)(param_1 + 0x16c) - *(float *)(param_1 + 0x160);
  fVar6 = *(float *)(param_1 + 0x174) - *(float *)(param_1 + 0x168);
  fVar8 = *(float *)(param_1 + 0x138) - *(float *)(param_1 + 0x168);
  *(float *)(param_1 + 0xbc) = fVar9 * fVar6 - fVar8 * fVar11;
  *(float *)(param_1 + 0xc0) = fVar8 * fVar10 - fVar4 * fVar6;
  *(float *)(param_1 + 0xc4) = fVar4 * fVar11 - fVar9 * fVar10;
  fVar6 = SQRT(*(float *)(param_1 + 0xc4) * *(float *)(param_1 + 0xc4) +
               *(float *)(param_1 + 0xbc) * *(float *)(param_1 + 0xbc) +
               *(float *)(param_1 + 0xc0) * *(float *)(param_1 + 0xc0));
  if (0.0 < fVar6) {
    fVar6 = 1.0 / fVar6;
  }
  *(float *)(param_1 + 0xbc) = *(float *)(param_1 + 0xbc) * fVar6;
  *(float *)(param_1 + 0xc0) = *(float *)(param_1 + 0xc0) * fVar6;
  *(float *)(param_1 + 0xc4) = *(float *)(param_1 + 0xc4) * fVar6;
  *(float *)(param_1 + 200) =
       *(float *)(param_1 + 0x138) * *(float *)(param_1 + 0xc4) +
       *(float *)(param_1 + 0x130) * *(float *)(param_1 + 0xbc) +
       *(float *)(param_1 + 0x134) * *(float *)(param_1 + 0xc0);
  *(char *)(param_1 + 0xcc) = (char)((int)*(undefined4 *)(param_1 + 0xbc) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xcd) = (char)((int)*(undefined4 *)(param_1 + 0xc0) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xce) = (char)((int)*(undefined4 *)(param_1 + 0xc4) >> 0x1f) + '\x01';
  fVar11 = *(float *)(param_1 + 0x154) - *(float *)(param_1 + 0x160);
  fVar6 = *(float *)(param_1 + 0x158) - *(float *)(param_1 + 0x164);
  fVar10 = *(float *)(param_1 + 0x15c) - *(float *)(param_1 + 0x168);
  *(float *)(param_1 + 0xd0) = fVar6 * fVar8 - fVar10 * fVar9;
  *(float *)(param_1 + 0xd4) = fVar10 * fVar4 - fVar11 * fVar8;
  *(float *)(param_1 + 0xd8) = fVar11 * fVar9 - fVar6 * fVar4;
  fVar4 = SQRT(*(float *)(param_1 + 0xd8) * *(float *)(param_1 + 0xd8) +
               *(float *)(param_1 + 0xd0) * *(float *)(param_1 + 0xd0) +
               *(float *)(param_1 + 0xd4) * *(float *)(param_1 + 0xd4));
  if (0.0 < fVar4) {
    fVar4 = 1.0 / fVar4;
  }
  *(float *)(param_1 + 0xd0) = *(float *)(param_1 + 0xd0) * fVar4;
  *(float *)(param_1 + 0xd4) = *(float *)(param_1 + 0xd4) * fVar4;
  *(float *)(param_1 + 0xd8) = *(float *)(param_1 + 0xd8) * fVar4;
  *(float *)(param_1 + 0xdc) =
       *(float *)(param_1 + 0x138) * *(float *)(param_1 + 0xd8) +
       *(float *)(param_1 + 0x130) * *(float *)(param_1 + 0xd0) +
       *(float *)(param_1 + 0x134) * *(float *)(param_1 + 0xd4);
  *(char *)(param_1 + 0xe0) = (char)((int)*(undefined4 *)(param_1 + 0xd0) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xe1) = (char)((int)*(undefined4 *)(param_1 + 0xd4) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xe2) = (char)((int)*(undefined4 *)(param_1 + 0xd8) >> 0x1f) + '\x01';
  *(float *)(param_1 + 0xe4) = -*(float *)(param_1 + 0xbc);
  *(float *)(param_1 + 0xe8) = -*(float *)(param_1 + 0xc0);
  *(float *)(param_1 + 0xec) = -*(float *)(param_1 + 0xc4);
  *(float *)(param_1 + 0xf0) =
       *(float *)(param_1 + 0x150) * *(float *)(param_1 + 0xec) +
       *(float *)(param_1 + 0x148) * *(float *)(param_1 + 0xe4) +
       *(float *)(param_1 + 0x14c) * *(float *)(param_1 + 0xe8);
  *(char *)(param_1 + 0xf4) = (char)((int)*(undefined4 *)(param_1 + 0xe4) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xf5) = (char)((int)*(undefined4 *)(param_1 + 0xe8) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0xf6) = (char)((int)*(undefined4 *)(param_1 + 0xec) >> 0x1f) + '\x01';
  *(float *)(param_1 + 0xf8) = -*(float *)(param_1 + 0xd0);
  *(float *)(param_1 + 0xfc) = -*(float *)(param_1 + 0xd4);
  *(float *)(param_1 + 0x100) = -*(float *)(param_1 + 0xd8);
  *(float *)(param_1 + 0x104) =
       *(float *)(param_1 + 0x150) * *(float *)(param_1 + 0x100) +
       *(float *)(param_1 + 0x148) * *(float *)(param_1 + 0xf8) +
       *(float *)(param_1 + 0x14c) * *(float *)(param_1 + 0xfc);
  *(char *)(param_1 + 0x108) = (char)((int)*(undefined4 *)(param_1 + 0xf8) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0x109) = (char)((int)*(undefined4 *)(param_1 + 0xfc) >> 0x1f) + '\x01';
  *(char *)(param_1 + 0x10a) = (char)((int)*(undefined4 *)(param_1 + 0x100) >> 0x1f) + '\x01';
  return;
}

