
void FUN_0019b3e0(uint param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  uint *puVar5;
  
  if (piRam0069f10c == (int *)0x0) {
LAB_0019b420:
    piVar3 = (int *)0x0;
  }
  else {
    iVar2 = *piRam0069f10c;
    piVar3 = piRam0069f10c;
    while (iVar2 != (int)param_1 >> 0x10) {
      piVar3 = (int *)piVar3[6];
      if (piVar3 == (int *)0x0) goto LAB_0019b420;
      iVar2 = *piVar3;
    }
  }
  if (piVar3 == (int *)0x0) {
    puVar5 = (uint *)0x0;
  }
  else {
    puVar5 = (uint *)piVar3[5];
    uVar4 = 0;
    if (piVar3[2] != 0) {
      do {
        if (*puVar5 == (param_1 & 0xffff)) goto LAB_0019b464;
        uVar4 = uVar4 + 1;
        puVar5 = puVar5 + 6;
      } while (uVar4 < (uint)piVar3[2]);
    }
    puVar5 = (uint *)0x0;
  }
LAB_0019b464:
  if (((puVar5 != (uint *)0x0) && (piVar3 = (int *)puVar5[4], piVar3 != (int *)0x0)) &&
     (piVar3 != (int *)0x0)) {
    cVar1 = (char)piVar3[7];
    while( true ) {
      if (((cVar1 == '\0') && (FUN_003ddef0(piVar3), (char)piVar3[7] == '\0')) && (*piVar3 != 0)) {
        iVar2 = *(int *)(*piVar3 + 8);
        if (iVar2 == 3) {
          FUN_00215120(piVar3);
        }
        else if (iVar2 == 1) {
          FUN_003011d0(piVar3);
        }
        else if (iVar2 == 2) {
          FUN_002ffe40(piVar3);
        }
      }
      piVar3 = (int *)piVar3[6];
      if (piVar3 == (int *)0x0) break;
      cVar1 = (char)piVar3[7];
    }
  }
  return;
}

