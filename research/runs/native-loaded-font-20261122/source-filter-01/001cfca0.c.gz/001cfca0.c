
void FUN_001cfca0(long param_1)

{
  uRam0064e608 = uRam0064e608 & 0xfffffffffffffe1f;
  if (param_1 == 6) {
    uRam0064e608 = uRam0064e608 | 0x160;
  }
  else if (param_1 == 5) {
    uRam0064e608 = uRam0064e608 | 0xc0;
  }
  else if (param_1 == 4) {
    uRam0064e608 = uRam0064e608 | 0x120;
  }
  else if (param_1 == 3) {
    uRam0064e608 = uRam0064e608 | 0x80;
  }
  else if (param_1 == 2) {
    uRam0064e608 = uRam0064e608 | 0x60;
  }
  return;
}

