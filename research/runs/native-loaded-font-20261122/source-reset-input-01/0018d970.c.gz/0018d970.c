
void FUN_0018d970(void)

{
  FUN_0019c550(3);
  uRam00660158 = 0x40;
  uRam006601a0 = 0x40;
  uRam00660140 = 0;
  uRam00660188 = 0;
  bRam00660084 = bRam00660084 & 0xfb;
  FUN_00185cc0(0xc);
  uRam0064e334 = 0;
  uRam0064e330 = 0;
  FUN_00185d60(3);
  FUN_001319e0(0x66012c,0);
  FUN_001319e0(0x660174,0);
  uRam006602d0 = 0;
  FUN_00246070();
  FUN_00334700();
  FUN_00165780(0xffffffffffffffff);
  FUN_0012a4f0(1);
  FUN_0012abd0();
  uRam0064e348 = 0;
  uRam0064e34c = 0;
  uRam0064e340 = 0;
  uRam0064e344 = 0;
  FUN_0016fc70(0);
  FUN_00163a50();
  uRam006602d0 = 0;
  return;
}

