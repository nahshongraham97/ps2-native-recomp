
undefined4 FUN_0000f318(undefined4 param_1,int param_2)

{
  undefined4 uStack_4;
  
  uStack_4 = CONCAT22(*(undefined2 *)(param_2 + 0xe),*(ushort *)(param_2 + 0xc) >> 2);
  return uStack_4;
}

