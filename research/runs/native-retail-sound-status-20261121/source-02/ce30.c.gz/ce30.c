
int * FUN_0000ce30(int param_1)

{
  int in_v0;
  int *piVar1;
  int in_v1;
  int unaff_s0;
  int iVar2;
  int *unaff_s2;
  int unaff_s3;
  
  while( true ) {
    param_1 = param_1 + 1;
    iVar2 = unaff_s0 + in_v0;
    if (((in_v1 <= param_1) ||
        (piVar1 = (int *)*unaff_s2, unaff_s0 = iRam00028d70, piVar1 == (int *)0x0)) ||
       (unaff_s0 = piVar1[1], unaff_s3 <= unaff_s0 - iVar2)) break;
    in_v0 = piVar1[2];
    unaff_s2 = piVar1;
  }
  if (param_1 < 1000000) {
    piVar1 = (int *)0x0;
    if ((unaff_s3 <= unaff_s0 - iVar2) &&
       (piVar1 = (int *)func_0x00006b4c(0xc), piVar1 != (int *)0x0)) {
      piVar1[1] = iVar2;
      piVar1[2] = unaff_s3;
      *piVar1 = *unaff_s2;
      *unaff_s2 = (int)piVar1;
      iRam00028d6c = iRam00028d6c - unaff_s3;
      *(int *)(iRam000248e0 + 0x3b8) = *(int *)(iRam000248e0 + 0x3b8) + unaff_s3;
    }
    func_0x000001cc(uRam000109ec);
  }
  else {
    func_0x000001cc(uRam000109ec);
    piVar1 = (int *)0x0;
  }
  return piVar1;
}

