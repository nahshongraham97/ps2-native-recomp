
void FUN_00007100(undefined4 param_1,undefined4 param_2,int *param_3,int *param_4)

{
  int in_v0;
  int *piVar1;
  int *in_t0;
  int unaff_s0;
  int *unaff_s1;
  undefined4 in_stack_00000024;
  
  while (in_t0 != (int *)0x0) {
    if (unaff_s0 < 2) {
      if (in_t0 < unaff_s1) {
        if (unaff_s1 != (int *)((int)in_t0 + *in_t0)) goto LAB_000070d0;
        *in_t0 = *in_t0 + *unaff_s1;
        unaff_s1 = in_t0;
      }
      else {
        if ((in_t0 <= unaff_s1) || (in_t0 != (int *)((int)unaff_s1 + *unaff_s1))) goto LAB_000070d0;
        *unaff_s1 = *unaff_s1 + *in_t0;
      }
      unaff_s0 = unaff_s0 + 1;
      *param_4 = in_t0[1];
      piVar1 = param_4;
    }
    else {
LAB_000070d0:
      param_4 = in_t0 + 1;
      piVar1 = param_4;
      if ((*unaff_s1 <= *in_t0) && (piVar1 = param_3, 1 < unaff_s0)) break;
    }
    param_3 = piVar1;
    in_t0 = (int *)*param_4;
  }
  unaff_s1[1] = *param_3;
  *param_3 = (int)unaff_s1;
  if (in_v0 == 0) {
    func_0x00000058(in_stack_00000024);
  }
  func_0x00006a24();
  return;
}

