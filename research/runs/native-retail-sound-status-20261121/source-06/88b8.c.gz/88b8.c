
void FUN_000088b8(void)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  int unaff_s0;
  int unaff_s1;
  int *unaff_s2;
  int in_stack_00000020;
  int in_stack_00000024;
  
  while( true ) {
    while( true ) {
      do {
        if (-1 < unaff_s0) {
          if (*unaff_s2 == 0) {
            if (unaff_s1 != 0) {
              iVar2 = (int)unaff_s2 - iRam000248bc;
              if (iVar2 < 0) {
                iVar2 = iVar2 + 0x3f;
              }
              in_stack_00000024 = iRam000248c0 + (iVar2 >> 6) * 0x10;
              in_stack_00000024 = func_0x0000f3d8(&stack0x00000024);
            }
            *(ushort *)((int)unaff_s2 + 0x1e) = *(ushort *)((int)unaff_s2 + 0x1e) & 0x7fff;
            if (*(int *)(unaff_s2[0xf] + 0x2a8) != 0) {
              FUN_000046f8();
            }
            if (unaff_s1 != 0) {
              func_0x00007918(in_stack_00000024);
            }
          }
          else {
            piVar3 = (int *)unaff_s2[10];
            while (piVar3 != (int *)0x0) {
              iVar2 = *piVar3;
              func_0x0000a298(unaff_s2[0xf],piVar3,0);
              piVar3 = (int *)iVar2;
            }
            unaff_s2[10] = 0;
            in_stack_00000020 = unaff_s2[0xe];
            while (in_stack_00000020 != 0) {
              uVar1 = func_0x0000f3d8(&stack0x00000020);
              func_0x0000f1a8(0x248a0,uVar1);
            }
            unaff_s2[0xe] = 0;
            if (unaff_s1 != 0) {
              if (-1 < (short)unaff_s2[3]) {
                piVar3 = (int *)(*(int *)(unaff_s2[0xf] + 0x268) + (short)unaff_s2[3] * 8);
                if (unaff_s2 == (int *)*piVar3) {
                  *piVar3 = 0;
                }
                *(undefined2 *)(unaff_s2 + 3) = 0xffff;
              }
              iVar2 = (int)unaff_s2 - iRam000248bc;
              if (iVar2 < 0) {
                iVar2 = iVar2 + 0x3f;
              }
              in_stack_00000024 = iRam000248c0 + (iVar2 >> 6) * 0x10;
              in_stack_00000024 = func_0x0000f3d8(&stack0x00000024);
            }
            *(ushort *)((int)unaff_s2 + 0x1e) = *(ushort *)((int)unaff_s2 + 0x1e) & 0x7fff;
            if (*(int *)(unaff_s2[0xf] + 0x2a8) != 0) {
              FUN_000046f8();
            }
            if (unaff_s1 != 0) {
              iVar2 = unaff_s2[0xd];
              func_0x00007918(in_stack_00000024);
              if (iVar2 != 0) {
                func_0x000014c8(iVar2);
              }
            }
          }
          return;
        }
        unaff_s0 = func_0x00008fc8();
      } while (unaff_s0 == 0);
      if (unaff_s0 < 1) break;
      iVar2 = (int)unaff_s2 - iRam000248bc;
      if (iVar2 < 0) {
        iVar2 = iVar2 + 0x3f;
      }
      func_0x0000f318(0,iRam000248c0 + (iVar2 >> 6) * 0x10);
    }
    if (unaff_s0 == -2) break;
    iVar2 = (int)unaff_s2 - iRam000248bc;
    if (iVar2 < 0) {
      iVar2 = iVar2 + 0x3f;
    }
    func_0x0000f318(0,iRam000248c0 + (iVar2 >> 6) * 0x10);
  }
  return;
}

