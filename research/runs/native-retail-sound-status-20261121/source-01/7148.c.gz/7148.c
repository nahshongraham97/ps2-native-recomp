
undefined4 FUN_00007148(void)

{
  return uRam00024cbc;
}

