
void FUN_000087ec(int *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iStack_8;
  int iStack_4;
  
  iStack_4 = 0;
  do {
    iVar1 = func_0x00008fc8(param_1,1000,1000,0x10288);
    if (iVar1 != 0) {
      if (iVar1 < 1) {
        if (iVar1 == -2) {
          return;
        }
        iVar3 = (int)param_1 - iRam000248bc;
        if (iVar3 < 0) {
          iVar3 = iVar3 + 0x3f;
        }
        func_0x0000f318(0,iRam000248c0 + (iVar3 >> 6) * 0x10);
      }
      else {
        iVar3 = (int)param_1 - iRam000248bc;
        if (iVar3 < 0) {
          iVar3 = iVar3 + 0x3f;
        }
        func_0x0000f318(0,iRam000248c0 + (iVar3 >> 6) * 0x10);
      }
    }
  } while (iVar1 < 0);
  if (*param_1 == 0) {
    if (param_2 != 0) {
      iVar1 = (int)param_1 - iRam000248bc;
      if (iVar1 < 0) {
        iVar1 = iVar1 + 0x3f;
      }
      iStack_4 = iRam000248c0 + (iVar1 >> 6) * 0x10;
      iStack_4 = func_0x0000f3d8(&iStack_4);
    }
    *(ushort *)((int)param_1 + 0x1e) = *(ushort *)((int)param_1 + 0x1e) & 0x7fff;
    if (*(int *)(param_1[0xf] + 0x2a8) != 0) {
      FUN_000046f8();
    }
    if (param_2 != 0) {
      func_0x00007918(iStack_4);
    }
  }
  else {
    piVar4 = (int *)param_1[10];
    while (piVar4 != (int *)0x0) {
      iVar1 = *piVar4;
      func_0x0000a298(param_1[0xf],piVar4,0);
      piVar4 = (int *)iVar1;
    }
    param_1[10] = 0;
    iStack_8 = param_1[0xe];
    while (iStack_8 != 0) {
      uVar2 = func_0x0000f3d8(&iStack_8);
      func_0x0000f1a8(0x248a0,uVar2);
    }
    param_1[0xe] = 0;
    if (param_2 != 0) {
      if (-1 < (short)param_1[3]) {
        piVar4 = (int *)(*(int *)(param_1[0xf] + 0x268) + (short)param_1[3] * 8);
        if (param_1 == (int *)*piVar4) {
          *piVar4 = 0;
        }
        *(undefined2 *)(param_1 + 3) = 0xffff;
      }
      iVar1 = (int)param_1 - iRam000248bc;
      if (iVar1 < 0) {
        iVar1 = iVar1 + 0x3f;
      }
      iStack_4 = iRam000248c0 + (iVar1 >> 6) * 0x10;
      iStack_4 = func_0x0000f3d8(&iStack_4);
    }
    *(ushort *)((int)param_1 + 0x1e) = *(ushort *)((int)param_1 + 0x1e) & 0x7fff;
    if (*(int *)(param_1[0xf] + 0x2a8) != 0) {
      FUN_000046f8();
    }
    if (param_2 != 0) {
      iVar1 = param_1[0xd];
      func_0x00007918(iStack_4);
      if (iVar1 != 0) {
        func_0x000014c8(iVar1);
      }
    }
  }
  return;
}

