
int FUN_00006b4c(undefined4 param_1)

{
  int iVar1;
  
  func_0x0000a7d8(0x24cc8);
  iRam00024ca4 = iRam00024ca4 + 1;
  iVar1 = func_0x00006d8c(param_1);
  if (iVar1 != 0) {
    func_0x000000ec(iVar1,0,param_1);
  }
  func_0x0000a7e4(0x24cc8);
  return iVar1;
}

