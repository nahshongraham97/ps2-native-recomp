
int * FUN_00006f18(void)

{
  int in_at;
  undefined4 in_v0;
  int in_v1;
  int unaff_s0;
  int *unaff_s2;
  undefined4 in_stack_0000002c;
  
  *(undefined4 *)(in_at + 0x4cbc) = in_v0;
  iRam00024cb8 = in_v1 - *unaff_s2;
  if (unaff_s0 == 0) {
    func_0x00000058(in_stack_0000002c);
  }
  return unaff_s2 + 2;
}

