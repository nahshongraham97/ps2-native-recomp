
int * FUN_0000cd88(int param_1)

{
  int *piVar1;
  int iVar2;
  int unaff_s0;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  func_0x000001dc(uRam000109ec);
  if (param_1 == 0) {
    piVar1 = (int *)0x0;
  }
  else {
    uVar5 = param_1 + 0x3fU & 0xffffffc0;
    iVar2 = 0;
    iVar3 = iRam00028d74;
    piVar4 = (int *)0x28d78;
    while (((iVar2 < 1000000 &&
            (piVar1 = (int *)*piVar4, unaff_s0 = iRam00028d70, piVar1 != (int *)0x0)) &&
           (unaff_s0 = piVar1[1], unaff_s0 - iVar3 < (int)uVar5))) {
      iVar2 = iVar2 + 1;
      piVar4 = piVar1;
      iVar3 = unaff_s0 + piVar1[2];
    }
    if (iVar2 < 1000000) {
      piVar1 = (int *)0x0;
      if (((int)uVar5 <= unaff_s0 - iVar3) &&
         (piVar1 = (int *)func_0x00006b4c(0xc), piVar1 != (int *)0x0)) {
        piVar1[1] = iVar3;
        piVar1[2] = uVar5;
        *piVar1 = *piVar4;
        *piVar4 = (int)piVar1;
        iRam00028d6c = iRam00028d6c - uVar5;
        *(uint *)(iRam000248e0 + 0x3b8) = *(int *)(iRam000248e0 + 0x3b8) + uVar5;
      }
      func_0x000001cc(uRam000109ec);
    }
    else {
      func_0x000001cc(uRam000109ec);
      piVar1 = (int *)0x0;
    }
  }
  return piVar1;
}

