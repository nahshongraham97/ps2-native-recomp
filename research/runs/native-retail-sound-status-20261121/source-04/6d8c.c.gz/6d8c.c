
uint * FUN_00006d8c(int param_1)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  undefined4 uStack_4;
  
  if (param_1 != 0) {
    if ((iRam00024cbc == 0) && (iRam00024cb8 == 0)) {
      iVar1 = func_0x00000024();
      func_0x0000002c();
      iVar2 = 0x54000;
      if (iVar1 < 0x54000) {
        iVar2 = iVar1;
      }
      func_0x00006cd0(iVar2);
      func_0x00000024();
      func_0x0000002c();
    }
    iVar2 = func_0x00000050(&uStack_4);
    uVar6 = param_1 + 0xbU & 0xfffffffc;
    puVar5 = (uint *)0x24cc4;
    for (puVar3 = puRam00024cc4; puVar3 != (uint *)0x0; puVar3 = (uint *)puVar3[1]) {
      uVar4 = *puVar3;
      if ((int)uVar6 < (int)(uVar4 - 8)) {
        puVar5 = (uint *)((int)puVar3 + (uVar4 - uVar6));
        *puVar5 = uVar6;
        puVar5[1] = 0;
        *puVar3 = *puVar3 - uVar6;
        iRam00024cbc = iRam00024cbc + uVar6;
        iRam00024cb8 = iRam00024cb8 - uVar6;
        if (iRam00024cb8 < iRam00024cb4) {
          iRam00024cb4 = iRam00024cb8;
        }
        if (iVar2 == 0) {
          func_0x00000058(uStack_4);
        }
        return puVar5 + 2;
      }
      if ((int)uVar6 <= (int)uVar4) {
        *puVar5 = puVar3[1];
        puVar3[1] = 0;
        iRam00024cbc = iRam00024cbc + *puVar3;
        iRam00024cb8 = iRam00024cb8 - *puVar3;
        if (iVar2 == 0) {
          func_0x00000058(uStack_4);
        }
        return puVar3 + 2;
      }
      if ((uVar4 & 0x80000000) != 0) {
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      puVar5 = puVar3 + 1;
    }
    func_0x00000058(uStack_4);
    func_0x00006a4c();
    for (puVar3 = puRam00024cc4; puVar3 != (uint *)0x0; puVar3 = (uint *)puVar3[1]) {
    }
    func_0x00006a90(1);
    if (iVar2 == -0x66) {
      func_0x00000050(&uStack_4);
    }
  }
  return (uint *)0x0;
}

