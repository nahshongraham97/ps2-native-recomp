
void FUN_0000cf04(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *unaff_s0;
  
  func_0x000001dc(uRam000109ec);
  puVar2 = (undefined4 *)0x28d78;
  for (iVar1 = 0; iVar1 < 1000000; iVar1 = iVar1 + 1) {
    unaff_s0 = (undefined4 *)*puVar2;
    if (unaff_s0 == (undefined4 *)0x0) {
      func_0x000001cc(uRam000109ec);
      return;
    }
    if (param_1 == unaff_s0) break;
    puVar2 = unaff_s0;
  }
  if (iVar1 < 1000000) {
    iRam00028d6c = iRam00028d6c + unaff_s0[2];
    *(int *)(iRam000248e0 + 0x3b8) = *(int *)(iRam000248e0 + 0x3b8) - unaff_s0[2];
    *puVar2 = *unaff_s0;
    func_0x00006bc8(unaff_s0);
    func_0x000001cc(uRam000109ec);
  }
  else {
    func_0x000001cc(uRam000109ec);
  }
  return;
}

