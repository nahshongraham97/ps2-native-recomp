
void FUN_0012e670(long param_1)

{
  int *piVar1;
  long lVar2;
  int *piStack_4;
  
  if (param_1 != 0) {
    piStack_4 = (int *)*(undefined4 *)param_1;
    while (piStack_4 != (int *)0x0) {
      piVar1 = (int *)*piStack_4;
      if (piStack_4[4] == piVar1[1]) {
        piRam0064df50 = (int *)0x0;
        piRam0064df54 = piVar1;
        if ((piVar1 != (int *)0x0) &&
           (((-1 < (long)((ulong)bRam00660081 << 0x3a) && (iRam0064df64 == 0)) ||
            ((long)((ulong)*(byte *)(piVar1 + 0x34) << 0x3b) < 0)))) {
          if ((long)((ulong)*(byte *)(piVar1 + 0x34) << 0x3c) < 0) {
            piVar1[3] = (int)((float)piVar1[3] - fRam0064de94);
          }
          else {
            piVar1[3] = (int)((float)piVar1[3] - 1.0);
          }
          if ((float)piRam0064df54[3] <= 0.0) {
            lVar2 = FUN_00130700(piRam0064df54 + 0x3a);
            piRam0064df48 = (int *)lVar2;
            if (lVar2 == 0) {
              if ((*(byte *)(piRam0064df54 + 0x34) & 1) == 0) {
                iRam0064df4c = 0;
LAB_0012e870:
                piRam0064df50 = (int *)0x0;
                if ((piRam0064df54[0x36] == 0) ||
                   ((*(code *)piRam0064df54[0x36])(), piRam0064df54[1] != 0)) {
                  piRam0064df50 = piRam0064df54;
                  if ((long)((ulong)*(byte *)(piRam0064df54 + 0x34) << 0x3a) < 0) {
                    FUN_002168f0();
                  }
                  (**(code **)(*piRam0064df54 + 0x10))();
                  FUN_002168e0();
                }
              }
              else if ((piRam0064df54 != (int *)0x0) && (piRam0064df54[1] != 0)) {
                (**(code **)(*piRam0064df54 + 0xc))(piRam0064df54);
              }
            }
            else {
              iRam0064df4c = *piRam0064df48;
              if (iRam0064df4c != 0) goto LAB_0012e870;
              if ((piRam0064df54 != (int *)0x0) && (piRam0064df54[1] != 0)) {
                (**(code **)(*piRam0064df54 + 0xc))(piRam0064df54);
              }
            }
          }
        }
        piStack_4 = (int *)piStack_4[1];
      }
      else {
        piVar1 = (int *)piStack_4[1];
        piStack_4[4] = 1;
        FUN_0012fa00(piStack_4);
        piStack_4 = piVar1;
      }
    }
  }
  return;
}

