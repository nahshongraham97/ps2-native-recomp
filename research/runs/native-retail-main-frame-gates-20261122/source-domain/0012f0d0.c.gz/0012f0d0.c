
void FUN_0012f0d0(void)

{
  FUN_00136dd0();
  uRam0064df34 = 0;
  uRam0064df60 = 0;
  FUN_00182bb0(0);
  uRam0064df64 = 0;
  return;
}

