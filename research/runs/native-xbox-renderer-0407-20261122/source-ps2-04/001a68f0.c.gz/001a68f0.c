
ulong FUN_001a68f0(int param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,long param_5
                  )

{
  ulong uVar1;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uVar1 = (**(code **)(param_1 + 4))(param_2,param_3,param_4,param_5);
  if (uVar1 == 0) {
    switch((int)param_2) {
    case 0xd:
      uVar1 = 1;
      *(undefined4 *)param_3 = 1;
      break;
    case 0xe:
      uVar1 = (ulong)(param_5 == 0);
      if (uVar1 != 0) {
        (*pcRam0069f388)(param_3,0x5a36a0);
      }
      break;
    case 0xf:
      *(undefined4 *)param_3 = 0;
      uVar1 = 1;
      break;
    case 0x10:
      uVar1 = (ulong)(param_5 == 0);
      break;
    case 0x11:
    case 0x12:
      uVar1 = 1;
    }
  }
  if (uVar1 == 0) {
    uStack_8 = 1;
    uStack_4 = FUN_0019f510(0x18,param_2);
    FUN_0019f460(&uStack_8);
  }
  return uVar1;
}

