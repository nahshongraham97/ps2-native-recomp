
undefined4 * FUN_002b9df0(undefined4 *param_1,undefined4 *param_2,short *param_3)

{
  int iVar1;
  
  if (-1 < *(char *)((int)param_1 + 0x21)) {
    return (undefined4 *)0x0;
  }
  param_1[3] = *(undefined4 *)(param_3 + 4);
  param_1[4] = *(undefined4 *)(param_3 + 6);
  *(short *)(param_1 + 7) = *(short *)(param_2 + 7) + *param_3;
  *(short *)((int)param_1 + 0x1e) = *(short *)((int)param_2 + 0x1e) + param_3[2];
  iVar1 = (*DAT_008353b8)(param_1,param_2,0);
  if (iVar1 != 0) {
    *param_1 = *param_2;
    return param_1;
  }
  return (undefined4 *)0x0;
}

