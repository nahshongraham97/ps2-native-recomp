
undefined8 FUN_001be5d0(undefined8 param_1,undefined8 param_2)

{
  bool bVar1;
  bool bVar2;
  byte bVar3;
  long lVar4;
  undefined8 uVar5;
  int iVar6;
  
  iVar6 = (int)param_1;
  bVar1 = (*(byte *)(iVar6 + 0x22) & 4) != 0;
  bVar2 = false;
  if (bVar1) {
    bVar3 = *(byte *)(iVar6 + 0x23);
  }
  else {
    lVar4 = FUN_001a8900(param_1,0,1);
    if (lVar4 == 0) {
      return 0;
    }
    bVar3 = *(byte *)(iVar6 + 0x23);
  }
  if ((bVar3 & 0x60) == 0) {
    bVar3 = *(byte *)(iVar6 + 0x23);
  }
  else {
    bVar2 = (*(byte *)(iVar6 + 0x22) & 0x10) != 0;
    if ((!bVar2) && (lVar4 = FUN_001a8640(param_1,1), lVar4 == 0)) {
      return 0;
    }
    bVar3 = *(byte *)(iVar6 + 0x23);
  }
  if (((bVar3 & 0x60) == 0x20) || ((bVar3 & 0x60) == 0x40)) {
    uVar5 = FUN_001bdef0(param_1,param_2);
  }
  else {
    uVar5 = FUN_001be160(param_1,param_2);
  }
  if (((*(byte *)(iVar6 + 0x23) & 0x60) != 0) && (!bVar2)) {
    FUN_001a8550(param_1);
  }
  if (!bVar1) {
    FUN_001a8510(param_1);
  }
  return uVar5;
}

