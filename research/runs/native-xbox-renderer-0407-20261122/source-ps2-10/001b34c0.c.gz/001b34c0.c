
undefined8 FUN_001b34c0(undefined8 param_1,int param_2)

{
  char cVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  ulong uVar6;
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 in_zero_qw [16];
  byte bVar15;
  undefined4 uVar16;
  long lVar17;
  ulong extraout_v0_udw;
  ulong extraout_v0_udw_00;
  ulong uVar29;
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 auVar25 [16];
  undefined1 auVar26 [16];
  undefined1 auVar27 [16];
  undefined1 auVar28 [16];
  uint uVar30;
  int iVar31;
  undefined8 in_v1_udw;
  undefined1 auVar32 [16];
  undefined1 auVar33 [16];
  undefined1 auVar34 [16];
  undefined1 auVar35 [16];
  undefined1 auVar36 [16];
  undefined8 in_a0_udw;
  undefined1 auVar37 [16];
  undefined1 auVar38 [16];
  int iVar39;
  ulong in_a1_udw;
  undefined8 uVar45;
  undefined1 auVar40 [16];
  undefined1 auVar41 [16];
  undefined1 auVar42 [16];
  undefined1 auVar43 [16];
  undefined1 auVar44 [16];
  uint uVar46;
  uint uVar47;
  uint uVar48;
  undefined4 in_a2_udw;
  undefined4 in_register_0000006c;
  uint uVar49;
  uint uVar50;
  uint uVar51;
  int iVar52;
  uint *puVar53;
  ulong in_t4_udw;
  undefined1 auVar54 [16];
  undefined1 auVar55 [16];
  undefined4 uVar57;
  undefined4 uVar58;
  undefined1 auVar56 [16];
  undefined4 uVar59;
  ulong *puVar60;
  undefined4 *puVar61;
  int iVar62;
  int iVar63;
  ulong uVar64;
  undefined1 in_s3_qw [16];
  undefined1 auVar65 [16];
  ulong uVar69;
  undefined1 auVar66 [16];
  undefined1 auVar67 [16];
  undefined1 auVar68 [16];
  undefined4 *puVar70;
  undefined4 in_s4_udw;
  undefined4 in_register_0000014c;
  int iVar71;
  uint uVar72;
  uint uVar73;
  undefined4 in_s5_udw;
  undefined4 in_register_0000015c;
  ulong *puVar74;
  undefined1 auVar75 [16];
  undefined8 in_hi;
  int iStack_160;
  long lStack_140;
  int iStack_130;
  int iStack_120;
  int iStack_110;
  uint auStack_100 [8];
  ulong auStack_e0 [8];
  ulong auStack_a0 [7];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  uint uStack_10;
  int iStack_c;
  int iStack_8;
  uint uStack_4;
  
  uVar50 = (uint)((ulong)in_hi >> 0x20);
  iVar62 = param_2 + iRam0064e650;
  lVar17 = FUN_001b1790();
  if (lVar17 == 0) {
    return 0;
  }
  if ((*(byte *)(param_2 + 0x23) & 0x60) == 0) {
    *(byte *)(param_2 + 0x21) = *(byte *)(param_2 + 0x21) & 0xbf;
    *(undefined4 *)(param_2 + 4) = 0;
  }
  else {
    *(undefined4 *)(param_2 + 4) = 0;
  }
  *(undefined4 *)(param_2 + 8) = 0;
  *(undefined1 *)(iVar62 + 0x17) = 0;
  *(undefined1 *)(iVar62 + 0x34) = 0;
  *(undefined4 *)(iVar62 + 0x38) = 0;
  *(undefined4 *)(iVar62 + 0x3c) = 0;
  *(undefined4 *)(iVar62 + 0x40) = 0;
  *(undefined4 *)(iVar62 + 0x44) = 0;
  *(undefined4 *)(iVar62 + 0x48) = 0;
  *(undefined4 *)(iVar62 + 0x4c) = 0;
  *(undefined4 *)(iVar62 + 0x50) = 0;
  *(undefined4 *)(iVar62 + 0x54) = 0;
  *(undefined4 *)(iVar62 + 0x58) = 0;
  *(undefined1 *)(iVar62 + 0x36) = 0;
  *(undefined4 *)(param_2 + 0x28) = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)(param_2 + 0x2c) = *(undefined4 *)(param_2 + 0x10);
  *(undefined4 *)(param_2 + 0x24) = *(undefined4 *)(param_2 + 4);
  uVar30 = *(uint *)(param_2 + 0xc);
  if ((uVar30 == 0) || (uVar72 = *(uint *)(param_2 + 0x10), uVar72 == 0)) {
    *(undefined1 *)(param_2 + 0x21) = 0x80;
    *(undefined4 *)(param_2 + 0x18) = 0;
    *(undefined4 *)(param_2 + 0x30) = 0;
    goto LAB_001b4f88;
  }
  cVar1 = *(char *)(param_2 + 0x20);
  if (cVar1 == '\x02') {
    if ((*piRam0064e5b8 < (int)uVar30) || (piRam0064e5b8[1] < (int)uVar72)) {
      if (cRam0064e5c0 == '\0') {
        uStack_68 = 1;
        uStack_64 = FUN_0019f510(0xffffffff80000010);
        FUN_0019f460(&uStack_68);
        return 0;
      }
      iVar62 = piRam0064e5b8[2];
    }
    else {
      iVar62 = piRam0064e5b8[2];
    }
    *(int *)(param_2 + 0x18) = (iVar62 + 7 >> 3) * (*piRam0064e5b8 + 0x3f >> 6) * 0x40;
    *(undefined4 *)(param_2 + 4) = 0;
    *(undefined4 *)(param_2 + 0x24) = 0;
    *(undefined4 *)(param_2 + 0x30) = *(undefined4 *)(param_2 + 0x18);
    *(undefined1 *)(param_2 + 0x21) = 0x80;
    goto LAB_001b4f88;
  }
  if (cVar1 == '\x01') {
    if ((*piRam0064e5b8 + 0x3f >> 6) * piRam0064e5b8[1] <
        (int)(((int)(uVar30 + 0x3f) >> 6) * uVar72)) {
      uStack_60 = 1;
      uStack_5c = FUN_0019f510(0xffffffff80000010);
      FUN_0019f460(&uStack_60);
      return 0;
    }
    *(undefined4 *)(param_2 + 0x18) = 0;
    *(undefined4 *)(param_2 + 4) = 0;
    *(undefined1 *)(param_2 + 0x21) = 0x80;
    *(undefined4 *)(param_2 + 0x24) = *(undefined4 *)(param_2 + 4);
    *(undefined4 *)(param_2 + 0x30) = *(undefined4 *)(param_2 + 0x18);
    goto LAB_001b4f88;
  }
  if (cVar1 == '\0') {
    iVar31 = *(int *)(param_2 + 0x14) * 4;
    iVar52 = *(int *)(&DAT_005fcfbc + iVar31);
    iVar31 = *(int *)(&DAT_005fd03c + iVar31);
    iVar39 = (int)(*(int *)(param_2 + 0x14) * uVar30) >> 3;
    *(int *)(param_2 + 0x18) = iVar39;
    *(int *)(iVar62 + 0x28) = *(int *)(param_2 + 0x10) * iVar39;
    *(int *)(iVar62 + 0x30) =
         ((*(int *)(param_2 + 0xc) + iVar52 + -1) / iVar52) *
         ((*(int *)(param_2 + 0x10) + iVar31 + -1) / iVar31) * 0x800;
    if ((*(byte *)(param_2 + 0x21) & 0x80) == 0) {
      lVar17 = (*pcRam0069f3c4)(*(undefined4 *)(iVar62 + 0x28),0x30411);
      *(int *)(param_2 + 4) = (int)lVar17;
      if (lVar17 == 0) {
        uStack_58 = 1;
        uStack_54 = FUN_0019f510(0xffffffff80000013,*(undefined4 *)(iVar62 + 0x28));
        FUN_0019f460(&uStack_58);
        return 0;
      }
    }
    else {
      *(undefined4 *)(param_2 + 4) = 0;
    }
    *(undefined4 *)(param_2 + 0x24) = *(undefined4 *)(param_2 + 4);
    *(undefined4 *)(param_2 + 0x30) = *(undefined4 *)(param_2 + 0x18);
    goto LAB_001b4f88;
  }
  if (cVar1 == '\x04') {
    iVar52 = *(int *)(param_2 + 0x14);
  }
  else {
    if (cVar1 != '\x05') {
      return 0;
    }
    if ((*(byte *)(param_2 + 0x23) & 0x60) != 0) {
      uStack_18 = 1;
      uStack_14 = FUN_0019f510(0xffffffff8000000d);
      FUN_0019f460(&uStack_18);
      return 0;
    }
    if ((*piRam0064e5b8 + 0x3f >> 6) * piRam0064e5b8[1] <
        (int)(((int)(uVar30 + 0x3f) >> 6) * uVar72)) {
      uStack_20 = 1;
      uStack_1c = FUN_0019f510(0xffffffff8000000d);
      FUN_0019f460(&uStack_20);
      return 0;
    }
    iVar52 = *(int *)(param_2 + 0x14);
  }
  uVar73 = *(uint *)(&DAT_005fcfbc + iVar52 * 4);
  iVar52 = *(int *)(&DAT_005fd03c + iVar52 * 4);
  uVar51 = 0xffffffff;
  for (uVar49 = uVar30; uVar49 != 0; uVar49 = uVar49 >> 1) {
    uVar51 = uVar51 + 1;
  }
  if (1 << (uVar51 & 0x1f) < (int)uVar30) {
    uVar51 = uVar51 + 1;
  }
  uVar46 = 0xffffffff;
  for (uVar49 = uVar72; uVar49 != 0; uVar49 = uVar49 >> 1) {
    uVar46 = uVar46 + 1;
  }
  if (1 << (uVar46 & 0x1f) < (int)uVar72) {
    uVar46 = uVar46 + 1;
  }
  if (uVar30 <= uVar73) {
    uVar30 = uVar73;
  }
  *(uint *)(iVar62 + 8) = uVar46 << 0x1e | (uVar51 & 0xf) << 0x1a | (uVar30 >> 6) << 0xe;
  iVar31 = 0x20;
  *(int *)(iVar62 + 0xc) = (int)(uVar46 & 0xf) >> 2;
  *(short *)(iVar62 + 0x14) = (short)DAT_0064c4ec;
  *(undefined1 *)(iVar62 + 0x34) = 1;
  bVar15 = *(byte *)(param_2 + 0x23);
  if ((bVar15 & 0x60) == 0x20) {
    iStack_130 = 0x10;
    iStack_120 = 0x10;
    *(uint *)(iVar62 + 8) = *(uint *)(iVar62 + 8) | 0x1300000;
    uVar30 = *(uint *)(iVar62 + 0xc);
    *(uint *)(iVar62 + 0xc) = uVar30 | 4;
    *(uint *)(iVar62 + 0xc) = uVar30 | 0x20000004;
    bVar15 = *(byte *)(param_2 + 0x23) & 0xf;
    if (bVar15 == 5) {
      auVar55._8_8_ = in_a1_udw;
      auVar55._0_8_ = 0x40;
      iStack_110 = 4;
    }
    else {
      if (bVar15 != 1) {
        uStack_38 = 1;
        uStack_34 = FUN_0019f510(0xffffffff8000000d);
        FUN_0019f460(&uStack_38);
        return 0;
      }
      auVar55._8_8_ = in_a1_udw;
      auVar55._0_8_ = 0x40;
      iStack_110 = 2;
      iVar31 = 0x40;
      *(uint *)(iVar62 + 0xc) = *(uint *)(iVar62 + 0xc) | 0x500000;
    }
  }
  else {
    auVar55._8_8_ = in_a1_udw;
    auVar55._0_8_ = 0x40;
    if ((bVar15 & 0x60) == 0x40) {
      iStack_130 = 8;
      *(uint *)(iVar62 + 8) = *(uint *)(iVar62 + 8) | 0x1400000;
      uVar30 = *(uint *)(iVar62 + 0xc);
      iStack_120 = 2;
      *(uint *)(iVar62 + 0xc) = uVar30 | 4;
      *(uint *)(iVar62 + 0xc) = uVar30 | 0x20000004;
      bVar15 = *(byte *)(param_2 + 0x23) & 0xf;
      if (bVar15 == 5) {
        iStack_110 = 4;
      }
      else {
        if (bVar15 != 1) {
          uStack_30 = 1;
          uStack_2c = FUN_0019f510(0xffffffff8000000d);
          FUN_0019f460(&uStack_30);
          return 0;
        }
        iVar31 = 0x40;
        iStack_110 = 2;
        *(uint *)(iVar62 + 0xc) = *(uint *)(iVar62 + 0xc) | 0x500000;
      }
    }
    else {
      if ((bVar15 & 0x60) != 0) {
        uStack_40 = 1;
        uStack_3c = FUN_0019f510(0xffffffff8000000d);
        FUN_0019f460(&uStack_40);
        return 0;
      }
      bVar15 = bVar15 & 0xf;
      iStack_120 = 0;
      iVar31 = 0;
      iStack_130 = 0;
      auVar56._8_8_ = 0;
      auVar56._0_8_ = in_a1_udw;
      auVar55 = auVar56 << 0x40;
      iStack_110 = 0;
      if (bVar15 == 5) {
        *(uint *)(iVar62 + 0xc) = *(uint *)(iVar62 + 0xc) | 4;
      }
      else if (bVar15 == 6) {
        *(uint *)(iVar62 + 8) = *(uint *)(iVar62 + 8) | 0x100000;
      }
      else {
        if (bVar15 != 1) {
          uStack_28 = 1;
          uStack_24 = FUN_0019f510(0xffffffff8000000d);
          FUN_0019f460(&uStack_28);
          return 0;
        }
        *(uint *)(iVar62 + 8) = *(uint *)(iVar62 + 8) | 0xa00000;
        *(uint *)(iVar62 + 0xc) = *(uint *)(iVar62 + 0xc) | 4;
      }
    }
  }
  *(int *)(param_2 + 0x18) = *(int *)(param_2 + 0x14) * *(int *)(param_2 + 0xc) >> 3;
  if ((*(byte *)(param_2 + 0x23) & 0x80) == 0) {
    *(uint *)(iVar62 + 0x28) =
         *(int *)(param_2 + 0x10) * *(int *)(param_2 + 0x18) + 0xfU & 0xfffffff0;
    *(undefined4 *)(iVar62 + 0x18) = 0x4000;
    *(undefined4 *)(iVar62 + 0x1c) = 0x400004;
    *(undefined4 *)(iVar62 + 0x20) = 0x4000;
    *(undefined4 *)(iVar62 + 0x24) = 0x400004;
    *(undefined1 *)(iVar62 + 0x16) = 0;
    auStack_a0[0] = 0;
    auStack_100[0] = 0;
    iVar39 = (int)(*(int *)(param_2 + 0xc) + uVar73 + -1) / (int)uVar73;
    auStack_e0[0] = (ulong)((uVar73 >> 6) * iVar39);
    iVar63 = (*(int *)(param_2 + 0x10) + iVar52 + -1) / iVar52;
    *(int *)(iVar62 + 0x30) = iVar39 * iVar63 * 0x800;
    iStack_160 = iStack_110 * iStack_130 * iStack_120;
    *(int *)(iVar62 + 0x2c) = iStack_160;
    if (iStack_160 == 0) {
      *(undefined4 *)(iVar62 + 0x10) = 0;
    }
    else {
      if (*(int *)(param_2 + 0xc) < (int)(iVar39 * uVar73)) {
        uVar50 = *(uint *)(iVar62 + 0x30);
      }
      else {
        if (iVar63 * iVar52 <= *(int *)(param_2 + 0x10)) {
          *(uint *)(iVar62 + 0x10) = *(uint *)(iVar62 + 0x30) >> 6;
          *(uint *)(iVar62 + 0x30) =
               *(int *)(iVar62 + 0x30) +
               ((iStack_130 + auVar55._0_4_ + -1) / auVar55._0_4_) *
               ((iStack_120 + iVar31 + -1) / iVar31) * 0x800 & 0xfffff800;
          goto LAB_001b4024;
        }
        uVar50 = *(uint *)(iVar62 + 0x30);
      }
      *(uint *)(iVar62 + 0x10) = (uVar50 >> 6) - 4;
    }
  }
  else {
    uVar30 = *(uint *)(param_2 + 0xc);
    uVar72 = *(uint *)(param_2 + 0x10);
    uVar51 = 0;
    iVar31 = 0;
    uStack_4 = 0;
    auStack_a0[2] = 0;
    auStack_a0[1] = 0;
    auStack_a0[0] = 0;
    auStack_a0[5] = 0;
    auStack_a0[4] = 0;
    auStack_a0[3] = 0;
    auStack_a0[6] = 0;
    auStack_e0[2] = 1;
    auStack_e0[1] = 1;
    auStack_e0[0] = 1;
    auStack_e0[5] = 1;
    auStack_e0[4] = 1;
    auStack_e0[3] = 1;
    auStack_e0[6] = 1;
    uVar49 = uVar73;
    if (uVar73 < uVar30) {
      uVar49 = uVar30;
    }
    uVar45 = auVar55._8_8_;
    in_s3_qw._4_4_ = 0;
    in_s3_qw._0_4_ = uVar49 >> 6;
    puVar74 = auStack_e0;
    puVar60 = auStack_a0;
    uVar49 = 0;
    for (; ((uVar30 != 0 && (uVar72 != 0)) && (uVar51 < DAT_0064c4e8)); uVar51 = uVar51 + 1) {
      if (*(int *)(param_2 + 0xc) < 8) {
        iVar39 = *(int *)(param_2 + 0x14);
      }
      else {
        if ((7 < *(int *)(param_2 + 0x10)) && ((uVar30 < 8 || (uVar72 < 8)))) break;
        iVar39 = *(int *)(param_2 + 0x14);
      }
      iVar31 = iVar31 + ((uVar72 * iVar39 * uVar30 >> 3) + 0xf & 0xfffffff0);
      uVar46 = uVar73;
      if (uVar73 < uVar30) {
        uVar46 = uVar30;
      }
      *puVar74 = (ulong)(uVar46 >> 6);
      iVar39 = *(int *)(param_2 + 0x14);
      lVar17 = *puVar74 << 6;
      auVar55 = _pextlw((ulong)uVar50 << 0x20,(ulong)(uint)(iVar39 * (int)lVar17));
      uVar46 = uStack_4;
      if (in_s3_qw._0_8_ != *puVar74) {
        iVar63 = iVar52 + -1 + (*(int *)(param_2 + 0x10) >> (uVar51 - 1 & 0x1f));
        uVar50 = iVar63 % iVar52 >> 0x1f;
        uVar46 = uVar49 + ((int)((uVar73 - 1) + (*(int *)(param_2 + 0xc) >> (uVar51 - 1 & 0x1f))) /
                          (int)uVar73) * (iVar63 / iVar52) * 0x800 & 0xfffff800;
      }
      uVar47 = uVar46 + 0x3f;
      uStack_4 = uVar46;
      uVar48 = (uVar47 & 0x7c0) >> 8;
      uVar49 = *(uint *)(iVar62 + 8) >> 0x14 & 0x3f;
      in_s3_qw._0_8_ = *puVar74;
      if (uVar49 == 0x14) {
        *puVar60 = (ulong)((uVar47 >> 0xb) * 0x20 + *(int *)(&DAT_005fd140 + uVar48 * 4));
      }
      else if (uVar49 == 0x13) {
        *puVar60 = (ulong)((uVar47 >> 0xb) * 0x20 + *(int *)(&DAT_005fd120 + uVar48 * 4));
      }
      else if (uVar49 == 10) {
        *puVar60 = (ulong)((uVar47 >> 0xb) * 0x20 + *(int *)(&DAT_005fd100 + uVar48 * 4));
      }
      else if (uVar49 == 2) {
        *puVar60 = (ulong)((uVar47 >> 0xb) * 0x20 + *(int *)(&DAT_005fd0e0 + uVar48 * 4));
      }
      else if ((uVar49 == 1) || (uVar49 == 0)) {
        *puVar60 = (ulong)((uVar47 >> 0xb) * 0x20 + *(int *)(&DAT_005fd0c0 + uVar48 * 4));
      }
      uVar49 = uVar72 * (int)((ulong)(((long)((int)((ulong)lVar17 >> 0x20) * iVar39) << 0x20) +
                                     auVar55._0_8_) >> 3);
      puVar74 = puVar74 + 1;
      puVar60 = puVar60 + 1;
      uVar30 = uVar30 >> 1;
      uVar72 = uVar72 >> 1;
      uStack_4 = uVar46 + (uVar49 >> 2) + 0x3f & 0xffffffc0;
      uVar49 = uVar46;
    }
    FUN_001b1de0(*(undefined4 *)(param_2 + 0xc),*(undefined4 *)(param_2 + 0x10),
                 *(uint *)(iVar62 + 8) >> 0x14 & 0x3f,auStack_a0,auStack_e0,auStack_100,&uStack_4,
                 &iStack_8);
    *(int *)(iVar62 + 0x28) = iVar31;
    *(char *)(iVar62 + 0x16) = ((char)uVar51 + -1) * '\x04';
    auVar22._8_8_ =
         (auStack_a0[2] & 0x3fff) << 0x14 |
         CONCAT44((int)((auStack_e0[1] << 0xe) >> 0x20),
                  (uint)auStack_a0[1] & 0x3fff | (uint)(auStack_e0[1] << 0xe));
    iStack_160 = iStack_110 * iStack_130 * iStack_120;
    *(int *)(iVar62 + 0x18) = (int)auVar22._8_8_;
    *(uint *)(iVar62 + 0x1c) =
         (uint)((auStack_e0[3] << 0x36) >> 0x20) |
         (uint)(((auStack_a0[3] & 0x3fff) << 0x28) >> 0x20) |
         (uint)((auStack_e0[2] << 0x22) >> 0x20) | (uint)(auVar22._8_8_ >> 0x20);
    auVar55._0_8_ = (auStack_a0[5] & 0x3fff) << 0x14 | auStack_a0[4] & 0x3fff | auStack_e0[4] << 0xe
    ;
    auVar55._8_8_ = uVar45;
    *(int *)(iVar62 + 0x20) = (int)auVar55._0_8_;
    *(uint *)(iVar62 + 0x24) =
         (uint)((auStack_e0[6] << 0x36) >> 0x20) |
         (uint)(((auStack_a0[6] & 0x3fff) << 0x28) >> 0x20) |
         (uint)((auStack_e0[5] << 0x22) >> 0x20) | (uint)(auVar55._0_8_ >> 0x20);
    *(int *)(iVar62 + 0x2c) = iStack_160;
    *(uint *)(iVar62 + 0x30) = uStack_4;
    if (*(int *)(iVar62 + 0x2c) == 0) {
      *(undefined4 *)(iVar62 + 0x10) = 0;
    }
    else {
      *(int *)(iVar62 + 0x10) = iStack_8;
      if (iStack_8 << 6 == uStack_4) {
        *(int *)(iVar62 + 0x30) = *(int *)(iVar62 + 0x30) + 0x800;
      }
    }
  }
LAB_001b4024:
  *(uint *)(iVar62 + 0x28) = *(int *)(iVar62 + 0x28) + 0xfU & 0xfffffff0;
  auVar75._8_8_ = auVar55._8_8_;
  if (iRam0064e5c4 == 0) {
    if (((*(byte *)(param_2 + 0x21) & 0x80) != 0) ||
       (0x7ffe < *(int *)(param_2 + 0x14) * *(int *)(param_2 + 0x10) * *(int *)(param_2 + 0xc) >> 7)
       ) {
      bVar15 = *(byte *)(param_2 + 0x21);
      goto LAB_001b4c5c;
    }
    *(byte *)(iVar62 + 0x36) = *(byte *)(iVar62 + 0x36) | 1;
    lStack_140 = 0;
    if ((*(uint *)(iVar62 + 8) >> 0x14 & 0x3f) == 0x13) {
      *(byte *)(iVar62 + 0x36) = *(byte *)(iVar62 + 0x36) | 2;
      if ((*(uint *)(iVar62 + 0xc) >> 0x13 & 0xf) == 0) {
        auVar21._8_8_ = 0;
        auVar21._0_8_ = auVar75._8_8_;
        iVar52 = (int)(uint)*(byte *)(iVar62 + 0x16) >> 2;
        auVar55 = auVar21 << 0x40;
        if (auStack_e0[iVar52] == 2) {
          auVar22._8_8_ = auStack_a0[iVar52];
          uVar50 = *(uint *)(iVar62 + 0x10);
          auVar54._8_8_ = in_t4_udw;
          auVar54._0_8_ = 0xffffffffffffffe1;
          uVar30 = *(uint *)((int)auStack_100 + (*(byte *)(iVar62 + 0x16) & 0xfffffffc));
          auVar55 = _pcpyld(in_zero_qw,auVar54);
          in_t4_udw = auVar55._8_8_;
          auVar75._0_8_ =
               ((auVar22._8_8_ & 0x10) >> 2 |
               (auVar22._8_8_ & 8) << 1 |
               (auVar22._8_8_ & 4) >> 1 | (auVar22._8_8_ & 2) << 2 | auVar22._8_8_ & auVar55._0_8_)
               - (long)(int)((uVar30 & 0x7ff) >> 4);
          uVar50 = ((uVar50 & 0x10) >> 2 |
                   (uVar50 & 8) << 1 | (uVar50 & 4) >> 1 | (uVar50 & 2) << 2 | uVar50 & 0xffffffe1)
                   - ((int)auVar75._0_8_ + ((uVar30 >> 0x10 & 0x7ff) >> 4) * -8);
          uVar30 = (uVar50 & 0x1fffffff) >> 3;
          auVar55 = auVar75;
          if (uVar30 << 3 < 0x800) {
            lStack_140 = ((ulong)(uVar30 << 0x13) | (long)(int)(uVar50 * 8) & 0x3fU) << 0x20;
          }
        }
        goto LAB_001b41d4;
      }
      uVar50 = *(uint *)(iVar62 + 8);
    }
    else {
LAB_001b41d4:
      uVar50 = *(uint *)(iVar62 + 8);
    }
    if ((uVar50 >> 0x14 & 0x3f) == 0x14) {
      auVar55._0_8_ = 2;
      *(byte *)(iVar62 + 0x36) = *(byte *)(iVar62 + 0x36) | 4;
      if ((*(uint *)(iVar62 + 0xc) >> 0x13 & 0xf) == 2) {
        iVar52 = (int)(uint)*(byte *)(iVar62 + 0x16) >> 2;
        if (auStack_e0[iVar52] == 2) {
          auVar22._8_8_ = auStack_a0[iVar52];
          auVar40._8_8_ = auVar55._8_8_;
          auVar40._0_8_ = 0xffffffffffffffe0;
          uVar50 = *(uint *)(iVar62 + 0x10);
          uVar30 = *(uint *)((int)auStack_100 + (*(byte *)(iVar62 + 0x16) & 0xfffffffc));
          auVar56 = _pcpyld(in_zero_qw,auVar40);
          in_a0_udw = auVar56._8_8_;
          auVar55._0_8_ =
               (long)(int)((uVar50 & 2) >> 1) |
               (long)(int)uVar50 & 0xffffffffffffffe0U | (long)(int)((uVar50 & 1) << 2);
          uVar50 = (uVar50 & 0x10 | (uVar50 & 8) >> 2 | (uVar50 & 4) << 1 | (uint)auVar55._0_8_) -
                   ((((uint)auVar22._8_8_ & 0x10 |
                     (uint)((auVar22._8_8_ & 8) >> 2) |
                     (uint)((auVar22._8_8_ & 4) << 1) |
                     (uint)((auVar22._8_8_ & 2) >> 1) |
                     (uint)auVar22._8_8_ & auVar56._0_4_ | (uint)((auVar22._8_8_ & 1) << 2)) -
                    ((uVar30 & 0x7ff) >> 5)) + ((uVar30 >> 0x10 & 0x7ff) >> 4) * -4);
          uVar30 = (uVar50 & 0xfffffff) >> 2;
          if (uVar30 << 3 < 0x800) {
            lStack_140 = ((ulong)(uVar30 << 0x13) | (long)(int)(uVar50 * 0x10) & 0x3fU) << 0x20;
          }
          else {
            lStack_140 = 0;
          }
        }
        else {
          lStack_140 = 0;
        }
      }
      bVar15 = *(byte *)(iVar62 + 0x16);
    }
    else {
      bVar15 = *(byte *)(iVar62 + 0x16);
    }
    *(int *)(iVar62 + 0x28) = (((int)(uint)bVar15 >> 2) + 1) * 0x50;
    uVar45 = auVar55._8_8_;
    FUN_001b33c0(*(uint *)(iVar62 + 8) >> 0x14 & 0x3f,*(undefined1 *)(iVar62 + 0x36),&iStack_c,
                 &uStack_10);
    iVar52 = *(int *)(param_2 + 0xc);
    iVar31 = *(int *)(param_2 + 0x10);
    iVar39 = 0;
    do {
      iVar63 = iStack_c;
      if (iStack_c <= iVar52) {
        iVar63 = iVar52;
      }
      iVar71 = iStack_c;
      if ((int)uStack_10 <= iVar31) {
        iVar71 = iVar31;
      }
      iVar39 = iVar39 + 1;
      iVar52 = iVar52 >> 1;
      *(uint *)(iVar62 + 0x28) =
           *(int *)(iVar62 + 0x28) +
           ((*(int *)(param_2 + 0x14) * iVar63 * iVar71 >> 3) + 0xfU & 0xfffffff0);
      iVar31 = iVar31 >> 1;
    } while (iVar39 <= (int)(uint)*(byte *)(iVar62 + 0x16) >> 2);
    if (*(int *)(iVar62 + 0x2c) == 0) {
      bVar15 = *(byte *)(iVar62 + 0x16);
    }
    else {
      if (iStack_120 == 2) {
        iStack_120 = 3;
      }
      iStack_160 = iStack_110 * iStack_130 * iStack_120;
      *(int *)(iVar62 + 0x2c) = iStack_160 + 0x50;
      bVar15 = *(byte *)(iVar62 + 0x16);
    }
    iVar39 = 0x10;
    iVar52 = 0;
    iVar31 = 0;
    puVar53 = auStack_100;
    do {
      if (*puVar53 == 0) {
        iVar39 = iVar39 + 0x40;
        iVar52 = iVar52 + 1;
      }
      iVar31 = iVar31 + 1;
      puVar53 = puVar53 + 1;
    } while (iVar31 <= (int)(uint)bVar15 >> 2);
    iVar31 = *(int *)(iVar62 + 0x2c);
    auVar22._8_8_ = in_s3_qw._8_8_;
    if (iVar31 == 0) {
      iVar71 = *(int *)(iVar62 + 0x28);
      iVar63 = iVar39;
LAB_001b4510:
      iVar39 = iVar63 + 0x70;
      uVar16 = (*pcRam0069f3c4)(iVar39 + (iVar71 + iVar31 + 0x3fU & 0xffffffc0),0x30411);
      *(undefined4 *)(param_2 + 4) = uVar16;
      uVar29 = extraout_v0_udw_00;
    }
    else {
      iVar63 = iVar39 + 0x40;
      iVar52 = iVar52 + 1;
      if (lStack_140 != 0) {
        iVar71 = *(int *)(iVar62 + 0x28);
        goto LAB_001b4510;
      }
      iVar39 = iVar39 + 0xb0;
      uVar16 = (*pcRam0069f3c4)((iVar31 + 0x3fU & 0xffffffc0) +
                                iVar39 + (*(int *)(iVar62 + 0x28) + 0x7fU & 0xffffff80),0x30411);
      *(undefined4 *)(param_2 + 4) = uVar16;
      uVar29 = extraout_v0_udw;
    }
    if (*(int **)(param_2 + 4) == (int *)0x0) {
      uStack_48 = 1;
      uStack_44 = FUN_0019f510(0xffffffff80000013,
                               (*(int *)(iVar62 + 0x2c) + 0x3fU & 0xffffffc0) +
                               iVar39 + (*(int *)(iVar62 + 0x28) + 0x7fU & 0xffffff80));
      FUN_0019f460(&uStack_48);
      return 0;
    }
    **(int **)(param_2 + 4) = iVar52;
    *(uint *)(*(int *)(param_2 + 4) + 4) = *(int *)(param_2 + 4) + 0x8f + iVar52 * 0x40 & 0xffffff80
    ;
    *(int *)(*(int *)(param_2 + 4) + 8) = iVar52;
    if (*(int *)(iVar62 + 0x2c) == 0) {
      iVar52 = *(int *)(param_2 + 4);
    }
    else {
      if (lStack_140 == 0) {
        iVar52 = (*(int *)(iVar62 + 0x28) + 0x7fU & 0xffffff80) +
                 (*(int *)(param_2 + 4) + iVar63 + 0x70U & 0xffffff80);
        *(int *)(param_2 + 8) = iVar52;
        *(int *)(param_2 + 8) = iVar52 + 0x50;
      }
      iVar52 = *(int *)(param_2 + 4);
    }
    auVar18._8_8_ = uVar29;
    auVar18._0_8_ = 0x1000000000000001;
    auVar2._8_4_ = in_a2_udw;
    auVar2._0_8_ = 0xe;
    auVar2._12_4_ = in_register_0000006c;
    auVar55 = _pcpyld(auVar2,auVar18);
    puVar70 = *(undefined4 **)(iVar52 + 4);
    puVar61 = (undefined4 *)(iVar52 + 0x10);
    auVar32._8_8_ = in_v1_udw;
    auVar32._0_8_ = 0x1000000000000003;
    iVar52 = *(int *)(param_2 + 0xc);
    auVar3._8_4_ = in_a2_udw;
    auVar3._0_8_ = 0xe;
    auVar3._12_4_ = in_register_0000006c;
    auVar56 = _pcpyld(auVar3,auVar32);
    uVar50 = *(uint *)(param_2 + 0x10);
    iVar31 = 0;
    uVar16 = auVar56._0_4_;
    uVar57 = auVar56._4_4_;
    uVar58 = auVar56._8_4_;
    uVar59 = auVar56._12_4_;
    auVar37._8_8_ = in_a0_udw;
    auVar37._0_8_ = 0x53;
    auVar68._8_8_ = 0;
    auVar68._0_8_ = auVar22._8_8_;
    auVar68 = auVar68 << 0x40;
    auVar9._8_8_ = 0;
    auVar9._0_8_ = in_t4_udw;
    auVar33._8_8_ = in_v1_udw;
    auVar33._0_8_ = 0x10000002;
    puVar53 = auStack_100;
    auVar19._8_8_ = uVar29;
    auVar19._0_8_ = 0x5000000200000000;
    puVar74 = auStack_a0;
    auVar56 = _pcpyld(auVar19,auVar33);
    puVar60 = auStack_e0;
    auVar75 = _pcpyld(auVar37,auVar68);
    auVar22._8_8_ = uVar29;
    do {
      auVar65._8_8_ = auVar68._8_8_;
      auVar34._8_8_ = auVar33._8_8_;
      iVar39 = iStack_c;
      if (iStack_c <= iVar52) {
        iVar39 = iVar52;
      }
      if ((int)uVar50 < (int)uStack_10) {
        *puVar70 = uVar16;
        puVar70[1] = uVar57;
        puVar70[2] = uVar58;
        puVar70[3] = uVar59;
        uVar30 = uStack_10;
      }
      else {
        *puVar70 = uVar16;
        puVar70[1] = uVar57;
        puVar70[2] = uVar58;
        puVar70[3] = uVar59;
        uVar30 = uVar50;
      }
      if ((((*(byte *)(iVar62 + 0x36) & 2) == 0) || ((*(uint *)(iVar62 + 8) >> 0x14 & 0x3f) != 0x13)
          ) && (((*(byte *)(iVar62 + 0x36) & 4) == 0 ||
                ((*(uint *)(iVar62 + 8) >> 0x14 & 0x3f) != 0x14)))) {
        uVar72 = *puVar53;
      }
      else {
        uVar72 = (uint)((((long)(int)*puVar53 & 0xfffefffeU) << 0x1f) >> 0x20);
      }
      auVar20._8_8_ = auVar22._8_8_;
      auVar20._0_8_ = 0x51;
      auVar14._4_4_ = in_s5_udw;
      auVar14._0_4_ = uVar72;
      auVar14._8_4_ = in_register_0000015c;
      auVar14._12_4_ = 0;
      auVar21 = _pcpyld(auVar20,auVar14 << 0x20);
      puVar70[4] = auVar21._0_4_;
      puVar70[5] = auVar21._4_4_;
      puVar70[6] = auVar21._8_4_;
      puVar70[7] = auVar21._12_4_;
      auVar22._8_8_ = auVar21._8_8_;
      if ((((*(byte *)(iVar62 + 0x36) & 2) != 0) && ((*(uint *)(iVar62 + 8) >> 0x14 & 0x3f) == 0x13)
          ) || ((iVar71 = iVar39, uVar72 = uVar30, (*(byte *)(iVar62 + 0x36) & 4) != 0 &&
                ((*(uint *)(iVar62 + 8) >> 0x14 & 0x3f) == 0x14)))) {
        iVar71 = iVar39 >> 1;
        uVar72 = (int)uVar30 >> 1;
      }
      auVar34._0_8_ = 0x52;
      auVar7._4_4_ = iVar39 >> 0x1f | uVar72;
      auVar7._0_4_ = iVar71;
      auVar7._8_4_ = in_s5_udw;
      auVar7._12_4_ = in_register_0000015c;
      auVar21 = _pcpyld(auVar34,auVar7);
      puVar70[8] = auVar21._0_4_;
      puVar70[9] = auVar21._4_4_;
      puVar70[10] = auVar21._8_4_;
      puVar70[0xb] = auVar21._12_4_;
      puVar70[0xc] = auVar75._0_4_;
      puVar70[0xd] = auVar75._4_4_;
      puVar70[0xe] = auVar75._8_4_;
      puVar70[0xf] = auVar75._12_4_;
      uVar30 = ((int)(*(int *)(param_2 + 0x14) * iVar39 * uVar30) >> 3) + 0xf >> 4;
      auVar65._0_8_ = (long)(int)uVar30 | 0x800000000000000;
      uVar30 = uVar30 & 0x7fff;
      auVar21 = _pcpyld(auVar9 << 0x40,auVar65);
      puVar70[0x10] = auVar21._0_4_;
      puVar70[0x11] = auVar21._4_4_;
      puVar70[0x12] = auVar21._8_4_;
      puVar70[0x13] = auVar21._12_4_;
      uVar69 = auVar21._8_8_;
      if (*puVar53 == 0) {
        *puVar61 = auVar56._0_4_;
        puVar61[1] = auVar56._4_4_;
        puVar61[2] = auVar56._8_4_;
        puVar61[3] = auVar56._12_4_;
        puVar61[4] = auVar55._0_4_;
        puVar61[5] = auVar55._4_4_;
        puVar61[6] = auVar55._8_4_;
        puVar61[7] = auVar55._12_4_;
        if (((*(byte *)(iVar62 + 0x36) & 2) == 0) ||
           ((*(uint *)(iVar62 + 8) >> 0x14 & 0x3f) != 0x13)) {
          if (((*(byte *)(iVar62 + 0x36) & 4) == 0) ||
             ((*(uint *)(iVar62 + 8) >> 0x14 & 0x3f) != 0x14)) {
            uVar6 = *puVar60;
            uVar64 = (long)(int)(*(uint *)(iVar62 + 8) >> 0x14) & 0x3f;
            uVar72 = (int)uVar64 << 0x18 | (uint)(uVar6 << 0x10);
            uVar73 = (uint)((uVar64 << 0x38) >> 0x20) |
                     (uint)((uVar6 << 0x30) >> 0x20) | (uint)(uVar6 >> 0x10) | (uint)*puVar74;
          }
          else {
            uVar72 = (uint)((*puVar60 & 0x3e) << 0xf) | 0x2000000;
            uVar73 = (uint)(((*puVar60 & 0x3e) << 0x2f) >> 0x20) | (uint)*puVar74 | 0x2000000;
            uVar69 = uVar29;
          }
        }
        else {
          uVar73 = (uint)(((*puVar60 & 0x3e) << 0x2f) >> 0x20) | (uint)*puVar74;
          uVar72 = (uint)((*puVar60 & 0x3e) << 0xf);
        }
        auVar66._8_8_ = uVar69;
        auVar66._0_8_ = 0x50;
        auVar8._4_4_ = uVar73;
        auVar8._0_4_ = uVar72;
        auVar8._8_4_ = in_s5_udw;
        auVar8._12_4_ = in_register_0000015c;
        auVar21 = _pcpyld(auVar66,auVar8);
        puVar61[8] = auVar21._0_4_;
        puVar61[9] = auVar21._4_4_;
        puVar61[10] = auVar21._8_4_;
        puVar61[0xb] = auVar21._12_4_;
        auVar67._8_8_ = auVar21._8_8_;
        auVar67._0_8_ = ((long)(int)(uVar30 + 5) | 0x50000000U) << 0x20;
        auVar5._8_4_ = in_s4_udw;
        auVar5._0_8_ = (long)(int)(uVar30 + 5) | 0x30000000U | ZEXT48(puVar70) << 0x20;
        auVar5._12_4_ = in_register_0000014c;
        auVar68 = _pcpyld(auVar67,auVar5);
        puVar61[0xc] = auVar68._0_4_;
        puVar61[0xd] = auVar68._4_4_;
        puVar61[0xe] = auVar68._8_4_;
        puVar61[0xf] = auVar68._12_4_;
        puVar61 = puVar61 + 0x10;
      }
      else {
        puVar61[-4] = (uint)*(ushort *)(puVar61 + -4) + uVar30 + 5 | 0x30000000;
        auVar12._8_8_ = 0;
        auVar12._0_8_ = uVar69;
        auVar68 = auVar12 << 0x40;
        puVar61[-1] = (uint)*(ushort *)(puVar61 + -1) + uVar30 + 5 | 0x50000000;
      }
      auVar13._8_8_ = 0;
      auVar13._0_8_ = uVar29;
      auVar33 = auVar13 << 0x40;
      puVar70 = puVar70 + uVar30 * 4 + 0x14;
      iVar31 = iVar31 + 1;
      iVar52 = iVar52 >> 1;
      uVar50 = (int)uVar50 >> 1;
      puVar53 = puVar53 + 1;
      puVar74 = puVar74 + 1;
      puVar60 = puVar60 + 1;
    } while (iVar31 <= (int)(uint)*(byte *)(iVar62 + 0x16) >> 2);
    if (*(int *)(iVar62 + 0x2c) == 0) {
      iVar52 = *(int *)(param_2 + 8);
    }
    else {
      if (lStack_140 != 0) {
        *(undefined4 **)(param_2 + 8) = puVar70 + 0x14;
      }
      auVar41._8_8_ = uVar45;
      auVar41._0_8_ = 0x51;
      iVar52 = *(int *)(param_2 + 8);
      *(undefined4 *)(iVar52 + -0x50) = uVar16;
      *(undefined4 *)(iVar52 + -0x4c) = uVar57;
      *(undefined4 *)(iVar52 + -0x48) = uVar58;
      *(undefined4 *)(iVar52 + -0x44) = uVar59;
      auVar38._0_8_ = (long)iStack_130 | (long)iStack_120 << 0x20;
      auVar38._8_8_ = in_a0_udw;
      iVar31 = iStack_160 + 0xf >> 4;
      auVar22._0_8_ = 0x52;
      auVar75 = _pcpyld(auVar22,auVar38);
      auVar23._8_8_ = auVar22._8_8_;
      auVar23._0_8_ = lStack_140;
      auVar56 = _pcpyld(auVar41,auVar23);
      *(int *)(iVar52 + -0x40) = auVar56._0_4_;
      *(int *)(iVar52 + -0x3c) = auVar56._4_4_;
      *(int *)(iVar52 + -0x38) = auVar56._8_4_;
      *(int *)(iVar52 + -0x34) = auVar56._12_4_;
      auVar42._8_8_ = uVar45;
      auVar42._0_8_ = 0x53;
      auVar24._8_8_ = auVar56._8_8_;
      *(int *)(iVar52 + -0x30) = auVar75._0_4_;
      *(int *)(iVar52 + -0x2c) = auVar75._4_4_;
      *(int *)(iVar52 + -0x28) = auVar75._8_4_;
      *(int *)(iVar52 + -0x24) = auVar75._12_4_;
      auVar10._8_8_ = 0;
      auVar10._0_8_ = auVar75._8_8_;
      auVar24._0_8_ = (long)iVar31 | 0x800000000000000;
      auVar75 = _pcpyld(auVar42,auVar10 << 0x40);
      auVar11._8_8_ = 0;
      auVar11._0_8_ = uVar29;
      *(int *)(iVar52 + -0x20) = auVar75._0_4_;
      *(int *)(iVar52 + -0x1c) = auVar75._4_4_;
      *(int *)(iVar52 + -0x18) = auVar75._8_4_;
      *(int *)(iVar52 + -0x14) = auVar75._12_4_;
      auVar56 = _pcpyld(auVar11 << 0x40,auVar24);
      *(int *)(iVar52 + -0x10) = auVar56._0_4_;
      *(int *)(iVar52 + -0xc) = auVar56._4_4_;
      *(int *)(iVar52 + -8) = auVar56._8_4_;
      *(int *)(iVar52 + -4) = auVar56._12_4_;
      auVar35._8_8_ = auVar56._8_8_;
      auVar43._8_8_ = auVar75._8_8_;
      auVar43._0_8_ = 0x10000002;
      auVar4._8_4_ = in_a2_udw;
      auVar4._0_8_ = 0x5000000200000000;
      auVar4._12_4_ = in_register_0000006c;
      auVar56 = _pcpyld(auVar4,auVar43);
      *puVar61 = auVar56._0_4_;
      puVar61[1] = auVar56._4_4_;
      puVar61[2] = auVar56._8_4_;
      puVar61[3] = auVar56._12_4_;
      auVar44._8_8_ = auVar56._8_8_;
      puVar61[4] = auVar55._0_4_;
      puVar61[5] = auVar55._4_4_;
      puVar61[6] = auVar55._8_4_;
      puVar61[7] = auVar55._12_4_;
      if ((lStack_140 == 0) || ((*(byte *)(param_2 + 0x21) & 0x40) != 0)) {
        if (lStack_140 == 0) {
          auVar25._8_8_ = auVar24._8_8_;
          auVar25._0_8_ = 0x50;
          auVar22._8_8_ = (long)(int)(*(uint *)(iVar62 + 0xc) >> 0x13) & 0xf;
          auVar44._0_8_ =
               auVar22._8_8_ << 0x38 |
               auVar22._8_8_ << 0x18 | 0x10000 | (ulong)*(uint *)(iVar62 + 0x10) << 0x20 |
               0x1000000000000;
          auVar26 = _pcpyld(auVar25,auVar44);
        }
        else {
          auVar26 = *(undefined1 (*) [16])(puVar61 + -8);
        }
        puVar61[8] = auVar26._0_4_;
        puVar61[9] = auVar26._4_4_;
        puVar61[10] = auVar26._8_4_;
        puVar61[0xb] = auVar26._12_4_;
      }
      else {
        puVar61[8] = puVar61[-8];
        puVar61[9] = puVar61[-7];
        puVar61[10] = puVar61[-6];
        puVar61[0xb] = puVar61[-5];
        **(int **)(param_2 + 4) = **(int **)(param_2 + 4) + -1;
        puVar61[-4] = (uint)*(ushort *)(puVar61 + -4) + iVar31 + 5 | 0x30000000;
        auVar26._8_8_ = 0;
        auVar26._0_8_ = auVar24._8_8_;
        auVar26 = auVar26 << 0x40;
        puVar61[-1] = (uint)*(ushort *)(puVar61 + -1) + iVar31 + 5 | 0x50000000;
      }
      auVar27._8_8_ = auVar26._8_8_;
      if ((*(byte *)(param_2 + 0x21) & 0x40) == 0) {
        auVar36._0_8_ = (long)(iVar31 + 5) | 0x30000000U | (long)(iVar52 + -0x50) << 0x20;
        auVar36._8_8_ = auVar35._8_8_;
        auVar28._0_8_ = ((long)(iVar31 + 5) | 0x50000000U) << 0x20;
        auVar28._8_8_ = auVar27._8_8_;
        auVar55 = _pcpyld(auVar28,auVar36);
        puVar61[0xc] = auVar55._0_4_;
        puVar61[0xd] = auVar55._4_4_;
        puVar61[0xe] = auVar55._8_4_;
        puVar61[0xf] = auVar55._12_4_;
      }
      else {
        auVar35._0_8_ = (long)(iVar31 + 5) | 0x10000000U | (long)(iVar52 + -0x50) << 0x20;
        auVar27._0_8_ = ((long)(iVar31 + 5) | 0x50000000U) << 0x20;
        auVar55 = _pcpyld(auVar27,auVar35);
        puVar61[0xc] = auVar55._0_4_;
        puVar61[0xd] = auVar55._4_4_;
        puVar61[0xe] = auVar55._8_4_;
        puVar61[0xf] = auVar55._12_4_;
      }
      iVar52 = *(int *)(param_2 + 8);
    }
    if (iVar52 == 0) {
      FUN_0010d0d8(*(int *)(param_2 + 4),
                   (*(int *)(iVar62 + 0x28) + 0x7fU & 0xffffff80) +
                   (*(int *)(param_2 + 4) + iVar63 + 0x70U & 0xffffff80));
      goto LAB_001b4d24;
    }
    FUN_0010d0d8(*(undefined4 *)(param_2 + 4),iVar52 + *(int *)(iVar62 + 0x2c) + 0x2f);
    uVar16 = *(undefined4 *)(param_2 + 4);
  }
  else {
    bVar15 = *(byte *)(param_2 + 0x21);
LAB_001b4c5c:
    *(byte *)(param_2 + 0x21) = bVar15 & 0xbf;
    if ((*(byte *)(param_2 + 0x21) & 0x80) == 0) {
      lVar17 = (*pcRam0069f3c4)(*(int *)(iVar62 + 0x28) + *(int *)(iVar62 + 0x2c),0x30411);
      *(int *)(param_2 + 4) = (int)lVar17;
      if (lVar17 == 0) {
        uStack_50 = 1;
        uStack_4c = FUN_0019f510(0xffffffff80000013,
                                 *(int *)(iVar62 + 0x28) + *(int *)(iVar62 + 0x2c));
        FUN_0019f460(&uStack_50);
        return 0;
      }
      if (*(int *)(iVar62 + 0x2c) == 0) {
        iVar52 = *(int *)(param_2 + 0x14);
      }
      else {
        *(int *)(param_2 + 8) = (int)lVar17 + *(int *)(iVar62 + 0x28);
        iVar52 = *(int *)(param_2 + 0x14);
      }
      if (iVar52 == 8) {
        *(byte *)(iVar62 + 0x36) = *(byte *)(iVar62 + 0x36) | 2;
      }
      FUN_001c15a0();
    }
    else {
      *(undefined4 *)(param_2 + 4) = 0;
      *(undefined4 *)(param_2 + 8) = 0;
      *(undefined4 *)(param_2 + 0x18) = 0;
    }
LAB_001b4d24:
    uVar16 = *(undefined4 *)(param_2 + 4);
  }
  *(undefined4 *)(param_2 + 0x24) = uVar16;
  *(undefined4 *)(param_2 + 0x30) = *(undefined4 *)(param_2 + 0x18);
  if (((*(byte *)(iVar62 + 0x36) & 1) != 0) && ((*(byte *)(param_2 + 0x21) & 0x80) == 0)) {
    *(int *)(param_2 + 4) = *(int *)(*(int *)(param_2 + 4) + 4) + 0x50;
  }
LAB_001b4f88:
  *(undefined4 *)(param_2 + iRam0064e650) = 0;
  *(undefined4 *)(param_2 + iRam0064e650 + 4) = 0;
  return 1;
}

