
undefined4 recovery0406_002c85f0(int *param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  byte bVar4;
  int iVar5;
  uint uVar6;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  uint uStack_8;
  int iStack_4;
  
  piVar2 = (int *)*param_2;
  piVar1 = (int *)(DAT_008343fc + (int)piVar2);
  uVar6 = 0;
  bVar4 = (byte)(param_3 >> 8);
  switch(*(byte *)(param_2 + 8) & 7) {
  case 0:
    uStack_8 = param_3 & 1;
    FUN_002c85a0(piVar1);
    piVar1[3] = iStack_10;
    param_2[6] = iStack_14;
    param_2[1] = (iStack_14 / piVar2[3]) * (int)(short)param_2[7] +
                 *(short *)((int)param_2 + 0x1e) * iStack_14 + piVar1[3];
    *(byte *)(piVar1 + 4) = bVar4;
    if ((param_3 & 2) != 0) {
      *(byte *)((int)param_2 + 0x22) = *(byte *)((int)param_2 + 0x22) | 2;
      *(byte *)((int)piVar2 + 0x22) = *(byte *)((int)piVar2 + 0x22) | 2;
    }
    if (uStack_8 != 0) {
      *(byte *)((int)param_2 + 0x22) = *(byte *)((int)param_2 + 0x22) | 4;
      *(byte *)((int)piVar2 + 0x22) = *(byte *)((int)piVar2 + 0x22) | 4;
      *param_1 = param_2[1];
      return 1;
    }
    goto LAB_002c8905;
  case 1:
  case 2:
    break;
  default:
    uStack_8 = 1;
    iStack_4 = FUN_002c2400(0x8000000e);
LAB_002c8932:
    FUN_002c2370(&uStack_8);
    return 0;
  case 4:
  case 5:
    uStack_8 = param_3 & 1;
    FUN_002c85a0(piVar1);
    iStack_c = piVar2[3] >> (bVar4 & 0x1f);
    iVar5 = piVar2[4] >> (bVar4 & 0x1f);
    if (iStack_c == 0) {
      iStack_c = 1;
    }
    if (iVar5 == 0) {
      iVar5 = 1;
    }
    if ((*(char *)((int)piVar1 + 0x11) == '\0') && ((param_3 & 8) == 0)) {
      iVar3 = (*DAT_00835474)(iVar5 * iStack_14,0x30411);
      piVar1[2] = iVar3;
      if (iVar3 == 0) {
        return 0;
      }
    }
    if (piVar2 == param_2) {
      param_2[10] = param_2[3];
      param_2[0xb] = param_2[4];
      param_2[3] = iStack_c;
      param_2[4] = iVar5;
      if ((*(char *)((int)piVar1 + 0x11) == '\0') && ((param_3 & 8) == 0)) {
        iVar3 = piVar1[2];
        goto LAB_002c87cc;
      }
      param_2[1] = iStack_10;
    }
    else {
      if ((*(char *)((int)piVar1 + 0x11) != '\0') || ((param_3 & 8) != 0)) {
        uStack_8 = 1;
        iStack_4 = FUN_002c2400(0x8000000e);
        goto LAB_002c8932;
      }
      iVar3 = (iStack_14 / piVar2[3]) * (int)(short)param_2[7] +
              *(short *)((int)param_2 + 0x1e) * iStack_14 + piVar1[2];
LAB_002c87cc:
      param_2[1] = iVar3;
    }
    piVar1[3] = iStack_10;
    param_2[6] = iStack_14;
    *(byte *)(piVar1 + 4) = bVar4;
    if ((param_3 & 2) != 0) {
      *(byte *)((int)param_2 + 0x22) = *(byte *)((int)param_2 + 0x22) | 2;
      *(byte *)((int)piVar2 + 0x22) = *(byte *)((int)piVar2 + 0x22) | 2;
      if ((*(char *)((int)piVar1 + 0x11) == '\0') && ((param_3 & 8) == 0)) {
        XGRAPHC::XGUnswizzleRect
                  (piVar1[3],iStack_c,iVar5,0,piVar1[2],0,0,
                   (int)(param_2[5] + (param_2[5] >> 0x1f & 7U)) >> 3);
      }
    }
    if (uStack_8 != 0) {
      *(byte *)((int)param_2 + 0x22) = *(byte *)((int)param_2 + 0x22) | 4;
      *(byte *)((int)piVar2 + 0x22) = *(byte *)((int)piVar2 + 0x22) | 4;
    }
    if ((param_3 & 8) != 0) {
      *(byte *)((int)param_2 + 0x22) = *(byte *)((int)param_2 + 0x22) | 0x20;
      *(byte *)((int)piVar2 + 0x22) = *(byte *)((int)piVar2 + 0x22) | 0x20;
      *param_1 = param_2[1];
      return 1;
    }
    goto LAB_002c8905;
  }
  if ((*piVar1 == DAT_0083444c) || (*piVar1 == DAT_00834448)) {
    uVar6 = 0x40;
  }
  if ((param_3 & 2) == 0) {
LAB_002c88ba:
    if ((param_3 & 1) != 0) goto LAB_002c88bf;
  }
  else {
    *(byte *)((int)param_2 + 0x22) = *(byte *)((int)param_2 + 0x22) | 2;
    *(byte *)((int)piVar2 + 0x22) = *(byte *)((int)piVar2 + 0x22) | 2;
    if ((param_3 & 1) == 0) {
      uVar6 = uVar6 | 0x80;
      goto LAB_002c88ba;
    }
LAB_002c88bf:
    *(byte *)((int)param_2 + 0x22) = *(byte *)((int)param_2 + 0x22) | 4;
    *(byte *)((int)piVar2 + 0x22) = *(byte *)((int)piVar2 + 0x22) | 4;
  }
  D3D8::D3DSurface_LockRect(*piVar1,&uStack_8,0,uVar6);
  piVar1[3] = iStack_4;
  iVar5 = piVar2[3];
  param_2[6] = uStack_8;
  param_2[1] = (int)*(short *)((int)param_2 + 0x1e) * uStack_8 +
               ((int)uStack_8 / iVar5) * (int)(short)param_2[7] + iStack_4;
LAB_002c8905:
  *param_1 = param_2[1];
  return 1;
}

