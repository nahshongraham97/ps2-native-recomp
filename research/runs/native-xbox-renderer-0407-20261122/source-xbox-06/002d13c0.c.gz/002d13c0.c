
void FUN_002d13c0(int param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  int unaff_ESI;
  int iVar7;
  int local_8;
  
  pcVar1 = (code *)FUN_002d1010();
  iVar3 = *(int *)(param_1 + 0xc);
  if ((iVar3 == 4) || (iVar3 == 8)) {
    local_8 = 0;
    if (0 < *(int *)(unaff_ESI + 0x10)) {
      iVar3 = *(int *)(unaff_ESI + 0xc);
      do {
        iVar6 = *(int *)(param_1 + 0x10);
        iVar7 = *(int *)(param_1 + 0x14);
        puVar4 = (undefined4 *)(*(int *)(unaff_ESI + 0x18) * local_8 + *(int *)(unaff_ESI + 4));
        iVar5 = 0;
        if (0 < iVar3) {
          do {
            uVar2 = (*pcVar1)(*(int *)(param_1 + 0x18) +
                              (uint)*(byte *)(iVar5 + iVar6 * local_8 + iVar7) * 4);
            *puVar4 = uVar2;
            iVar3 = *(int *)(unaff_ESI + 0xc);
            puVar4 = puVar4 + 1;
            iVar5 = iVar5 + 1;
          } while (iVar5 < iVar3);
        }
        local_8 = local_8 + 1;
      } while (local_8 < *(int *)(unaff_ESI + 0x10));
    }
  }
  else if ((iVar3 == 0x20) && (local_8 = 0, 0 < *(int *)(unaff_ESI + 0x10))) {
    iVar3 = *(int *)(unaff_ESI + 0xc);
    do {
      iVar7 = *(int *)(param_1 + 0x10) * local_8 + *(int *)(param_1 + 0x14);
      puVar4 = (undefined4 *)(*(int *)(unaff_ESI + 0x18) * local_8 + *(int *)(unaff_ESI + 4));
      iVar6 = 0;
      if (0 < iVar3) {
        do {
          uVar2 = (*pcVar1)(iVar7);
          *puVar4 = uVar2;
          iVar3 = *(int *)(unaff_ESI + 0xc);
          iVar7 = iVar7 + 4;
          puVar4 = puVar4 + 1;
          iVar6 = iVar6 + 1;
        } while (iVar6 < iVar3);
      }
      local_8 = local_8 + 1;
    } while (local_8 < *(int *)(unaff_ESI + 0x10));
    return;
  }
  return;
}

