
int __fastcall FUN_002c8f70(int param_1,int param_2)

{
  int in_EAX;
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  sbyte sStack_c;
  
  iVar1 = (*DAT_00835484)(DAT_005c75b8,0x30411);
  XGRAPHC::XGSetTextureHeader
            (*(undefined4 *)(param_2 + 0xc),*(undefined4 *)(param_2 + 0x10),
             *(undefined1 *)(param_1 + 0x13),0,in_EAX,0,iVar1,0,0);
  iVar5 = 0;
  if (in_EAX == 0xc) {
    sStack_c = 3;
  }
  else {
    if ((in_EAX != 0xe) && (in_EAX != 0xf)) {
      uVar2 = *(uint *)(param_2 + 0xc);
      uVar3 = *(uint *)(param_2 + 0x10);
      for (uVar4 = (uint)*(byte *)(param_1 + 0x13); uVar4 != 0; uVar4 = uVar4 - 1) {
        iVar6 = (*(int *)(param_2 + 0x14) >> 3) * uVar3 * uVar2;
        uVar2 = uVar2 >> 1;
        iVar5 = iVar5 + iVar6;
        if (uVar2 == 0) {
          uVar2 = 1;
        }
        uVar3 = uVar3 >> 1;
        if (uVar3 == 0) {
          uVar3 = 1;
        }
      }
      goto LAB_002c9078;
    }
    sStack_c = 4;
  }
  uVar2 = 0;
  if (*(byte *)(param_1 + 0x13) != 0) {
    do {
      uVar3 = *(int *)(param_2 + 0xc) >> ((byte)uVar2 & 0x1f);
      if (uVar3 == 0) {
        uVar3 = 0;
      }
      uVar4 = *(int *)(param_2 + 0x10) >> ((byte)uVar2 & 0x1f);
      if (uVar4 == 0) {
        uVar4 = 0;
      }
      uVar3 = uVar3 >> 2;
      if (uVar3 == 0) {
        uVar3 = 1;
      }
      uVar4 = uVar4 >> 2;
      if (uVar4 == 0) {
        uVar4 = 1;
      }
      iVar5 = iVar5 + (uVar4 * uVar3 << sStack_c);
      uVar2 = uVar2 + 1;
    } while (uVar2 < *(byte *)(param_1 + 0x13));
  }
LAB_002c9078:
  iVar5 = FUN_002c7de0(iVar5 + 3U & 0xfffffffc,0x80);
  *(int *)(iVar1 + 4) = iVar5;
  if (iVar5 == 0) {
    (*DAT_00835488)(DAT_005c75b8,iVar1);
    return 0;
  }
  return iVar1;
}

