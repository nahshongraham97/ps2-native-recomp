
undefined4 recovery0406_002d03b0(undefined4 param_1,undefined4 param_2)

{
  DAT_005c7634 = param_2;
  return 1;
}

