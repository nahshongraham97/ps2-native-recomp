
code * FUN_002d1010(void)

{
  uint in_EAX;
  uint uVar1;
  undefined4 local_8;
  undefined4 local_4;
  
  uVar1 = in_EAX & 0xf00;
  if (uVar1 < 0x401) {
    if (uVar1 == 0x400) {
      return (code *)&LAB_002d0500;
    }
    if (uVar1 == 0x100) {
      return FUN_002d0440;
    }
    if (uVar1 == 0x200) {
      return FUN_002d0410;
    }
    if (uVar1 == 0x300) {
      return FUN_002d0480;
    }
  }
  else {
    if (uVar1 == 0x500) {
      return (code *)&LAB_002d04e0;
    }
    if (uVar1 == 0x600) {
      return (code *)&LAB_002d04c0;
    }
    if (uVar1 == 0xa00) {
      return FUN_002d03e0;
    }
  }
  local_8 = 1;
  local_4 = FUN_002c2400(0x8000000d);
  FUN_002c2370(&local_8);
  return (code *)0x0;
}

