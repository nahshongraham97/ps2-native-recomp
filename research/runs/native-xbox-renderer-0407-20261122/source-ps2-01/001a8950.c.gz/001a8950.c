
undefined8 FUN_001a8950(undefined8 param_1)

{
  if (*(int *)(iGpffffa3f0 + 0x69f2f0) != 0) {
    FUN_001a10a0();
    *(undefined4 *)(iGpffffa3f0 + 0x69f2f0) = 0;
  }
  iGpffffa3f4 = iGpffffa3f4 + -1;
  return param_1;
}

