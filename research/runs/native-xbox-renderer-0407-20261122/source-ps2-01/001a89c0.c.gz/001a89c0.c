
undefined8 FUN_001a89c0(undefined8 param_1,int param_2)

{
  undefined4 uVar1;
  long lVar2;
  
  iGpffffa3f0 = param_2;
  FUN_001dba60(param_2 + 0x69f2bc,0,0x34);
  uVar1 = DAT_005a3700;
  *(undefined4 *)(iGpffffa3f0 + 0x69f2c8) = 0;
  *(undefined4 *)(iGpffffa3f0 + 0x69f2cc) = 0;
  *(undefined4 *)(iGpffffa3f0 + 0x69f2d0) = 0;
  *(undefined1 *)(iGpffffa3f0 + 0x69f2dd) = 0x80;
  *(undefined4 *)(iGpffffa3f0 + 0x69f2c0) = 0;
  *(undefined4 *)(iGpffffa3f0 + 0x69f2c4) = 0;
  *(undefined1 *)(iGpffffa3f0 + 0x69f2dc) = 0;
  *(undefined4 *)(iGpffffa3f0 + 0x69f2b8) = 0;
  *(int *)(iGpffffa3f0 + 0x69f290) = iGpffffa3f0 + 0x69f2bc;
  lVar2 = thunk_FUN_001a0e00(uVar1,uGpffff83b0,4,uGpffff83b4,0x6a3320,0x40407);
  *(int *)(iGpffffa3f0 + 0x69f2f0) = (int)lVar2;
  if (lVar2 == 0) {
    param_1 = 0;
  }
  else {
    iGpffffa3f4 = iGpffffa3f4 + 1;
  }
  return param_1;
}

