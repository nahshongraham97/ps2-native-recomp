
void FUN_001b7060(undefined4 *param_1,int param_2,int *param_3,long param_4)

{
  int iVar1;
  bool bVar2;
  undefined4 *puVar3;
  int iVar4;
  
  iVar4 = 0;
  if (0 < param_2) {
    if (8 < param_2) {
      bVar2 = false;
      if ((-1 < param_2) && (param_2 < 0x7fffffff)) {
        bVar2 = true;
      }
      puVar3 = param_1;
      if (bVar2) {
        do {
          *puVar3 = &LAB_001b7050;
          iVar4 = iVar4 + 8;
          puVar3[1] = &LAB_001b7050;
          puVar3[2] = &LAB_001b7050;
          puVar3[3] = &LAB_001b7050;
          puVar3[4] = &LAB_001b7050;
          puVar3[5] = &LAB_001b7050;
          puVar3[6] = &LAB_001b7050;
          puVar3[7] = &LAB_001b7050;
          puVar3 = puVar3 + 8;
        } while (iVar4 < param_2 + -8);
      }
    }
    if (iVar4 < param_2) {
      puVar3 = param_1 + iVar4;
      do {
        iVar4 = iVar4 + 1;
        *puVar3 = &LAB_001b7050;
        puVar3 = puVar3 + 1;
      } while (iVar4 < param_2);
    }
  }
  iVar4 = (int)param_4;
  if (param_4 != 0) {
    do {
      iVar4 = iVar4 + -1;
      iVar1 = *param_3;
      if ((iVar1 < param_2) && (-1 < iVar1)) {
        param_1[iVar1] = param_3[1];
      }
      param_3 = param_3 + 2;
    } while (iVar4 != 0);
  }
  return;
}

