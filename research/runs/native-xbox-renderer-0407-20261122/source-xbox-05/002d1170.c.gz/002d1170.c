
void FUN_002d1170(void)

{
  undefined1 uVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  int iVar4;
  int unaff_EBX;
  int iVar5;
  int unaff_ESI;
  int iVar6;
  
  iVar5 = 0;
  if (0 < *(int *)(unaff_ESI + 0x10)) {
    iVar4 = *(int *)(unaff_ESI + 0xc);
    do {
      puVar2 = (undefined1 *)(*(int *)(unaff_EBX + 0x10) * iVar5 + *(int *)(unaff_EBX + 0x14));
      puVar3 = (undefined1 *)(*(int *)(unaff_ESI + 0x18) * iVar5 + *(int *)(unaff_ESI + 4));
      iVar6 = 0;
      if (0 < iVar4) {
        do {
          uVar1 = *puVar2;
          puVar2 = puVar2 + 1;
          *puVar3 = uVar1;
          iVar4 = *(int *)(unaff_ESI + 0xc);
          puVar3 = puVar3 + 1;
          iVar6 = iVar6 + 1;
        } while (iVar6 < iVar4);
      }
      iVar5 = iVar5 + 1;
    } while (iVar5 < *(int *)(unaff_ESI + 0x10));
  }
  return;
}

