
undefined4 FUN_002c91c0(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *unaff_EBX;
  uint uVar4;
  undefined4 local_8;
  undefined4 local_4;
  
  uVar1 = (uint)*(byte *)(param_1 + 0x23);
  uVar4 = uVar1 << 8 & 0x4000;
  if ((uVar4 == 0) && ((uVar1 << 8 & 0x2000) == 0)) {
    iVar2 = *(int *)(&DAT_005a6998 + ((uVar1 & 0xf) + param_2 * 0xb) * 8);
  }
  else {
    iVar2 = (*DAT_00835484)(DAT_005c75bc,0x30411);
    unaff_EBX[1] = iVar2;
    XGRAPHICS::XGSetPaletteHeader(-(uVar4 != 0) & 3,iVar2,0);
    iVar2 = FUN_002c7de0(((-(uint)(uVar4 != 0) & 0xffffff20) + 0x100) * 4,0x40);
    *(int *)(unaff_EBX[1] + 4) = iVar2;
    if (iVar2 == 0) {
      (*DAT_00835488)(DAT_005c75bc,unaff_EBX[1]);
      unaff_EBX[1] = 0;
      local_8 = 1;
      local_4 = FUN_002c2400(2,"Failed to create palette.");
      FUN_002c2370(&local_8);
      return 0;
    }
    iVar2 = 0xb;
  }
  *(undefined *)((int)unaff_EBX + 0x12) = (&DAT_005a699d)[((uVar1 & 0xf) + param_2 * 0xb) * 8];
  iVar3 = FUN_002c8f70();
  *unaff_EBX = iVar3;
  if (iVar3 == 0) {
    if (iVar2 == 0xb) {
      FUN_002c90c0();
    }
    local_8 = 1;
    local_4 = FUN_002c2400(2,"Failed to create surface.");
    FUN_002c2370(&local_8);
    return 0;
  }
  return 1;
}

