
undefined4 recovery0406_002b9ae0(void)

{
  return *(undefined4 *)
          ((int)&DAT_00835340 + *(int *)(&DAT_00835368 + DAT_005c7304) * 4 + DAT_005c7304);
}

