
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint recovery0406_002b9d50(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = DAT_005c7304;
  iVar1 = *(int *)(&DAT_00835368 + DAT_005c7304);
  iVar4 = iVar1 + -1;
  *(int *)(&DAT_00835368 + DAT_005c7304) = iVar4;
  uVar2 = *(uint *)((int)&DAT_00835340 + iVar1 * 4 + iVar3);
  iVar4 = (*_DAT_008353b4)(0,*(undefined4 *)((int)&DAT_00835340 + iVar4 * 4 + iVar3),0);
  return -(uint)(iVar4 != 0) & uVar2;
}

