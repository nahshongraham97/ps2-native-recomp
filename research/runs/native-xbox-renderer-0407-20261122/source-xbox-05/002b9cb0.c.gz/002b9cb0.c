
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 recovery0406_002b9cb0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = (*_DAT_008353b4)(0,param_1,0);
  iVar1 = DAT_005c7304;
  if (iVar2 != 0) {
    iVar2 = *(int *)(&DAT_00835368 + DAT_005c7304);
    *(int *)(&DAT_00835368 + DAT_005c7304) = iVar2 + 1;
    *(undefined4 *)((int)&DAT_00835340 + (iVar2 + 1) * 4 + iVar1) = param_1;
    return param_1;
  }
  return 0;
}

