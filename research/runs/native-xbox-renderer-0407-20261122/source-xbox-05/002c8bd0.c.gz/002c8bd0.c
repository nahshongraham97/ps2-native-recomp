
undefined4 FUN_002c8bd0(int param_1,uint param_2)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  undefined4 local_8;
  undefined4 local_4;
  
  bVar1 = (byte)param_2 & 7;
  *(byte *)(param_1 + 0x21) = (byte)param_2 & 0xf8;
  uVar3 = param_2 & 0xff00;
  *(byte *)(param_1 + 0x20) = bVar1;
  bVar2 = (byte)(uVar3 >> 8);
  switch(bVar1) {
  case 0:
    if ((param_2 & 0xf00) != 0) {
      *(uint *)(param_1 + 0x14) = (uint)(byte)(&DAT_005a69f4)[(uVar3 >> 8 & 0xf) * 8];
      *(byte *)(param_1 + 0x23) = bVar2;
      return 1;
    }
    goto LAB_002c8c3b;
  case 1:
    if ((param_2 & 0xf00) == 0) {
      if (DAT_00834488 == 0x10) {
        *(undefined4 *)(param_1 + 0x14) = 0x10;
        *(undefined1 *)(param_1 + 0x23) = 7;
        return 1;
      }
      if (DAT_00834488 == 0x20) {
        *(undefined4 *)(param_1 + 0x14) = 0x20;
        *(undefined1 *)(param_1 + 0x23) = 9;
        return 1;
      }
      goto LAB_002c8e73;
    }
    local_8 = 1;
    local_4 = FUN_002c2400(0x8000000d);
    break;
  case 2:
    if ((param_2 & 0xf00) == 0) {
      *(undefined4 *)(param_1 + 0x14) = DAT_0083447c;
      switch(DAT_00834458) {
      case 2:
      case 0x10:
        *(undefined1 *)(param_1 + 0x23) = 1;
        return 1;
      case 3:
      case 0x1c:
        *(undefined1 *)(param_1 + 0x23) = 10;
        return 1;
      default:
        local_8 = 1;
        local_4 = FUN_002c2400(0x8000000d);
        break;
      case 5:
      case 0x11:
        *(undefined1 *)(param_1 + 0x23) = 2;
        return 1;
      case 6:
      case 0x12:
        *(undefined1 *)(param_1 + 0x23) = 5;
        return 1;
      case 7:
      case 0x1e:
        *(undefined1 *)(param_1 + 0x23) = 6;
        return 1;
      }
    }
    else {
      local_8 = 1;
      local_4 = FUN_002c2400(0x8000000d);
    }
    break;
  default:
    local_8 = 1;
    local_4 = FUN_002c2400(0x8000000d);
    FUN_002c2370(&local_8);
    return 0;
  case 4:
    if ((param_2 & 0xf00) != 0) {
      if (((param_2 & 0x4000) == 0) && ((param_2 & 0x2000) == 0)) {
        *(uint *)(param_1 + 0x14) = (uint)(byte)(&DAT_005a699c)[(uVar3 >> 8 & 0xf) * 8];
        *(byte *)(param_1 + 0x23) = bVar2;
        return 1;
      }
      *(undefined4 *)(param_1 + 0x14) = 8;
      *(byte *)(param_1 + 0x23) = bVar2;
      return 1;
    }
LAB_002c8c3b:
    *(undefined4 *)(param_1 + 0x14) = 0x20;
    *(byte *)(param_1 + 0x23) = bVar2 | 5;
    return 1;
  case 5:
    if ((param_2 & 0xf00) != 0) {
      *(int *)(param_1 + 0x14) = DAT_00834488;
      *(byte *)(param_1 + 0x23) = bVar2;
      return 1;
    }
    if (DAT_00834488 == 0x10) {
      *(undefined4 *)(param_1 + 0x14) = 0x10;
      *(byte *)(param_1 + 0x23) = bVar2 | 2;
      return 1;
    }
    if (DAT_00834488 == 0x20) {
      *(undefined4 *)(param_1 + 0x14) = 0x20;
      *(byte *)(param_1 + 0x23) = bVar2 | 6;
      return 1;
    }
    goto LAB_002c8e73;
  }
  FUN_002c2370(&local_8);
LAB_002c8e73:
  *(byte *)(param_1 + 0x23) = bVar2;
  return 1;
}

