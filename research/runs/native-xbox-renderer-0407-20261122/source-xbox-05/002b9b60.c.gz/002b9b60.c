
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 recovery0406_002b9b60(undefined4 param_1)

{
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  if (0 < *(int *)(&DAT_00835368 + DAT_005c7304)) {
    (*_DAT_008353c0)(0,0,param_1);
    return 1;
  }
  uStack_8 = 1;
  uStack_4 = FUN_002c2400(0x15);
  FUN_002c2370(&uStack_8);
  return 0;
}

