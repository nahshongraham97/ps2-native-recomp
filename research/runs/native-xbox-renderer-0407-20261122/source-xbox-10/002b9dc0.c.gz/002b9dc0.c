
uint FUN_002b9dc0(uint param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  int iVar2;
  
  pcVar1 = DAT_008353d8;
  FUN_002c2dd0();
  iVar2 = (*pcVar1)(param_1,param_2,param_3);
  return -(uint)(iVar2 != 0) & param_1;
}

