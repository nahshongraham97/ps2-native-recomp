
int FUN_002b9e50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = (*DAT_00835484)(*(undefined4 *)((int)&DAT_008353a0 + DAT_005c7304),0x30407);
  pcVar1 = DAT_00835398;
  if (iVar2 != 0) {
    *(undefined4 *)(iVar2 + 0xc) = param_1;
    *(undefined4 *)(iVar2 + 0x10) = param_2;
    *(undefined4 *)(iVar2 + 0x14) = param_3;
    *(undefined1 *)(iVar2 + 0x22) = 0;
    *(undefined1 *)(iVar2 + 0x21) = 0;
    *(undefined2 *)(iVar2 + 0x1c) = 0;
    *(undefined2 *)(iVar2 + 0x1e) = 0;
    *(int *)iVar2 = iVar2;
    *(undefined4 *)(iVar2 + 4) = 0;
    *(undefined4 *)(iVar2 + 8) = 0;
    iVar3 = (*pcVar1)(0,iVar2,param_4);
    if (iVar3 != 0) {
      FUN_002c2b90(&DAT_005a66f8,iVar2);
      return iVar2;
    }
    (*DAT_00835488)(*(undefined4 *)((int)&DAT_008353a0 + DAT_005c7304));
  }
  return 0;
}

