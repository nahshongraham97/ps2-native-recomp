
undefined4 recovery0406_002d04e0(undefined1 *param_1)

{
  return CONCAT31(CONCAT21(CONCAT11(param_1[3],*param_1),param_1[1]),param_1[2]);
}

