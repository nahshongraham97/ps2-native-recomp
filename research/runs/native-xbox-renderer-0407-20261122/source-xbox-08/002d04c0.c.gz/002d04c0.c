
uint recovery0406_002d04c0(byte *param_1)

{
  return ((*param_1 | 0xffffff00) << 8 | (uint)param_1[1]) << 8 | (uint)param_1[2];
}

