
/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_002c7140(void)

{
  int iVar1;
  int iVar2;
  undefined4 *unaff_EBX;
  int unaff_ESI;
  undefined4 *puVar3;
  code *local_dc [55];
  
  iVar2 = 0x1b;
  local_dc[1] = FUN_002c6890;
  local_dc[2] = (code *)0xa;
  local_dc[3] = (code *)&LAB_002c6a60;
  local_dc[4] = (code *)0x15;
  local_dc[5] = FUN_002c70a0;
  local_dc[6] = (code *)0x14;
  local_dc[7] = (code *)&LAB_002c6a70;
  local_dc[8] = (code *)0x2;
  local_dc[9] = FUN_002d0530;
  local_dc[10] = (code *)0x3;
  local_dc[0xb] = FUN_002d0830;
  local_dc[0xc] = (code *)0x7;
  local_dc[0xd] = FUN_002d14c0;
  local_dc[0xe] = (code *)0x6;
  local_dc[0xf] = (code *)&LAB_002d0f10;
  local_dc[0x10] = (code *)0x5;
  local_dc[0x11] = (code *)&LAB_002c95d0;
  local_dc[0x12] = (code *)0x4;
  local_dc[0x13] = (code *)&LAB_002c9380;
  local_dc[0x14] = (code *)0x9;
  local_dc[0x15] = FUN_002d1730;
  local_dc[0x16] = (code *)0x8;
  local_dc[0x17] = (code *)&LAB_002c9800;
  local_dc[0x18] = (code *)0xf;
  local_dc[0x19] = (code *)&LAB_002c85f0;
  local_dc[0x1a] = (code *)0x10;
  local_dc[0x1b] = (code *)&LAB_002c8960;
  local_dc[0x1c] = (code *)0x17;
  local_dc[0x1d] = FUN_002c8ae0;
  local_dc[0x1e] = (code *)0x18;
  local_dc[0x1f] = (code *)&LAB_002c8b70;
  local_dc[0x20] = (code *)0xe;
  local_dc[0x21] = FUN_002d0370;
  local_dc[0x22] = (code *)0xd;
  local_dc[0x23] = (code *)&LAB_002d0350;
  local_dc[0x24] = (code *)0x11;
  local_dc[0x25] = (code *)&LAB_002cffd0;
  local_dc[0x26] = (code *)0x12;
  local_dc[0x27] = (code *)&LAB_002d0010;
  local_dc[0x28] = (code *)0x13;
  local_dc[0x29] = (code *)&LAB_002cfff0;
  local_dc[0x2a] = (code *)0xb;
  local_dc[0x2b] = (code *)&LAB_002d03b0;
  local_dc[0x2c] = (code *)0xc;
  local_dc[0x2d] = (code *)&LAB_002c9810;
  local_dc[0x2e] = (code *)0x19;
  local_dc[0x2f] = FUN_002cee40;
  local_dc[0x30] = (code *)0x1b;
  local_dc[0x31] = FUN_002ceee0;
  local_dc[0x32] = (code *)0x1a;
  local_dc[0x33] = FUN_002cf190;
  local_dc[0x34] = (code *)0x1c;
  local_dc[0x35] = (code *)&LAB_002c9770;
  iVar1 = unaff_ESI;
  puVar3 = unaff_EBX;
  if (0 < unaff_ESI) {
    for (; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar3 = &LAB_002c66c0;
      puVar3 = puVar3 + 1;
    }
  }
  do {
    iVar2 = iVar2 + -1;
    if (1 < unaff_ESI) {
      unaff_EBX[(int)local_dc[iVar2 * 2]] = local_dc[iVar2 * 2U + 1];
    }
  } while (iVar2 != 0);
  return 1;
}

