
int FUN_002c0e90(int param_1,byte *param_2)

{
  int iVar1;
  
  iVar1 = (*DAT_008353a4)(param_1,param_2,0);
  if (iVar1 != 0) {
    if ((*param_2 & 2) != 0) {
      *(byte *)(param_1 + 0x22) = *(byte *)(param_1 + 0x22) | 1;
    }
    return param_1;
  }
  return 0;
}

