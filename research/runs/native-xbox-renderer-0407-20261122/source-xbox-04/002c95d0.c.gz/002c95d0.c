
undefined4 recovery0406_002c95d0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  piVar1 = (int *)(DAT_008343fc + (int)param_2);
  if ((int *)*param_2 == param_2) {
    if (*(char *)((int)param_2 + 0x21) < '\0') {
      if ((char)param_2[8] == '\x05') {
        FUN_002c6720();
      }
      FUN_002c5320(param_2);
      if ((*(byte *)((int)param_2 + 0x23) & 0x60) != 0) {
        puVar2 = (uint *)piVar1[1];
        if ((*puVar2 & 0x780000) != 0) {
          uVar3 = 0;
          do {
            D3D8::D3DDevice_SetPalette(uVar3,0);
            uVar3 = uVar3 + 1;
          } while (uVar3 < 4);
        }
        D3D8::D3DResource_BlockUntilNotBusy(puVar2);
        (*DAT_00835488)(DAT_005c75bc,puVar2);
        piVar1[1] = 0;
      }
      puVar2 = (uint *)*piVar1;
      if ((*puVar2 & 0x780000) != 0) {
        uVar3 = 0;
        do {
          (&DAT_00834dd0)[uVar3] = 0;
          D3D8::D3DDevice_SetTexture(uVar3,0);
          uVar3 = uVar3 + 1;
        } while (uVar3 < 4);
      }
      D3D8::D3DResource_BlockUntilNotBusy(puVar2);
      (*DAT_00835488)(DAT_005c75b8,puVar2);
    }
    else {
      switch((char)param_2[8]) {
      case '\0':
      case '\x04':
      case '\x05':
        if ((char)param_2[8] == '\x05') {
          FUN_002c6720();
        }
        FUN_002c5320(param_2);
        if ((*(byte *)((int)param_2 + 0x23) & 0x60) != 0) {
          FUN_002c90c0();
          piVar1[1] = 0;
        }
        FUN_002c8f10();
        *piVar1 = 0;
        return 1;
      case '\x01':
        if (*piVar1 != DAT_0083444c) {
          FUN_002c6720();
          D3D8::D3DResource_Release(*piVar1);
          *piVar1 = 0;
          return 1;
        }
        break;
      case '\x02':
        goto switchD_002c96ae_caseD_2;
      default:
        uStack_8 = 1;
        uStack_4 = FUN_002c2400(0x8000000d);
        FUN_002c2370(&uStack_8);
        return 0;
      }
    }
    *piVar1 = 0;
  }
switchD_002c96ae_caseD_2:
  return 1;
}

