
undefined4 recovery0406_002c9380(undefined4 param_1,int param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  puVar1 = (undefined4 *)(DAT_008343fc + param_2);
  *(undefined4 *)(param_2 + 0x18) = 0;
  *puVar1 = 0;
  puVar1[1] = 0;
  *(undefined1 *)(puVar1 + 4) = 0xff;
  *(undefined1 *)((int)puVar1 + 0x11) = 0;
  *(undefined1 *)((int)puVar1 + 0x12) = 0;
  *(undefined1 *)(puVar1 + 5) = 0;
  *(undefined1 *)((int)puVar1 + 0x15) = 0;
  if ((char)((uint)param_3 >> 8) < '\0') {
    iVar2 = FUN_002d03c0(*(undefined4 *)(param_2 + 0xc));
    iVar3 = FUN_002d03c0(*(undefined4 *)(param_2 + 0x10));
    if (iVar3 < iVar2) {
      *(char *)((int)puVar1 + 0x13) = (char)iVar2 + '\x01';
    }
    else {
      *(char *)((int)puVar1 + 0x13) = (char)iVar3 + '\x01';
    }
  }
  else {
    *(undefined1 *)((int)puVar1 + 0x13) = 1;
  }
  iVar2 = FUN_002c8bd0(param_2,param_3);
  if (iVar2 == 0) {
    return 0;
  }
  iVar2 = *(int *)(param_2 + 0xc);
  if ((iVar2 == 0) || (*(int *)(param_2 + 0x10) == 0)) {
    *(undefined1 *)(param_2 + 0x21) = 0x80;
  }
  else {
    switch(*(char *)(param_2 + 0x20)) {
    case '\0':
      if (*(char *)(param_2 + 0x21) < '\0') {
        return 1;
      }
      uVar4 = 1;
      break;
    case '\x01':
      if (*(char *)(param_2 + 0x21) < '\0') {
        return 1;
      }
      if (0x3f < (*(int *)(param_2 + 0x14) >> 3) * iVar2) {
        if ((iVar2 == DAT_00834450) && (*(int *)(param_2 + 0x10) == DAT_00834454)) {
          *puVar1 = DAT_0083444c;
          return 1;
        }
        iVar2 = FUN_002c9310(puVar1);
        if (iVar2 != 0) {
          return 1;
        }
        return 0;
      }
      uStack_8 = 1;
      uStack_4 = FUN_002c2400(0x80000010);
      FUN_002c2370(&uStack_8);
      uStack_8 = 1;
      uStack_4 = FUN_002c2400(2,"The minimun pitch for a ZBuffer is 64.");
      FUN_002c2370(&uStack_8);
      return 0;
    case '\x02':
      *(undefined1 *)(param_2 + 0x21) = 0x80;
      *puVar1 = DAT_00834448;
      return 1;
    default:
      uStack_8 = 1;
      uStack_4 = FUN_002c2400(0x8000000d);
      FUN_002c2370(&uStack_8);
      return 0;
    case '\x04':
    case '\x05':
      if (*(char *)(param_2 + 0x21) < '\0') {
        return 1;
      }
      if ((*(char *)(param_2 + 0x20) == '\x05') && ((*(int *)(param_2 + 0x14) >> 3) * iVar2 < 0x40))
      {
        uStack_8 = 1;
        uStack_4 = FUN_002c2400(0x80000010);
        FUN_002c2370(&uStack_8);
        uStack_8 = 1;
        uStack_4 = FUN_002c2400(2,"The minimun pitch for a camera texture is 64.");
        FUN_002c2370(&uStack_8);
        return 0;
      }
      uVar4 = 0;
    }
    iVar2 = FUN_002c91c0(param_2,uVar4);
    if (iVar2 == 0) {
      return 0;
    }
  }
  return 1;
}

