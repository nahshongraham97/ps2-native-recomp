
undefined4 FUN_002d14c0(int *param_1,undefined4 param_2)

{
  byte bVar1;
  bool bVar2;
  byte bVar3;
  int iVar4;
  int local_10;
  undefined4 local_c;
  undefined4 local_8;
  undefined4 local_4;
  
  bVar2 = false;
  local_10 = 0;
  if (*(char *)(*param_1 + 0x11 + DAT_008343fc) != '\0') {
    local_10 = 1;
    local_c = FUN_002c2400(2,"Conversion to compressed rasters is not supported.");
    FUN_002c2370(&local_10);
    return 0;
  }
  bVar1 = *(byte *)((int)param_1 + 0x23);
  if ((*(byte *)((int)param_1 + 0x22) & 4) == 0) {
    iVar4 = FUN_002b9ee0(param_1,0,5);
    if (iVar4 == 0) {
      return 0;
    }
  }
  else {
    local_10 = 1;
  }
  bVar3 = bVar1 & 0x60;
  if (bVar3 != 0) {
    if ((*(byte *)((int)param_1 + 0x22) & 0x10) == 0) {
      iVar4 = FUN_002b9d20(param_1,5);
      if (iVar4 == 0) {
        return 0;
      }
    }
    else {
      bVar2 = true;
    }
  }
  switch(param_1[5]) {
  case 4:
  case 8:
    if (bVar3 == 0) {
      if ((bVar1 & 4) != 0) {
        FUN_002d1170();
      }
    }
    else {
      FUN_002d11c0(param_1,param_2);
    }
    break;
  default:
    local_8 = 1;
    local_4 = FUN_002c2400(0x8000000c);
    FUN_002c2370(&local_8);
    break;
  case 0x10:
    FUN_002d12c0(param_2);
    break;
  case 0x18:
  case 0x20:
    FUN_002d13c0(param_2);
  }
  if ((bVar3 != 0) && (!bVar2)) {
    FUN_002b9c50(param_1);
  }
  if (local_10 == 0) {
    FUN_002b9b40(param_1);
  }
  return 1;
}

