
undefined8 FUN_001b9cf0(ulong param_1)

{
  undefined8 uVar1;
  
  if (param_1 < 0x17) {
                    /* WARNING: Could not recover jumptable at 0x001b9d24. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (*(code *)(&PTR_LAB_005fd160)[(int)param_1])();
    return uVar1;
  }
  return 0;
}

