
int FUN_002b9d90(int param_1)

{
  int iVar1;
  
  if (-1 < *(char *)(param_1 + 0x23)) {
    return 1;
  }
  iVar1 = (*DAT_008353f8)(&param_1,param_1,0);
  if (iVar1 != 0) {
    return param_1;
  }
  return -1;
}

