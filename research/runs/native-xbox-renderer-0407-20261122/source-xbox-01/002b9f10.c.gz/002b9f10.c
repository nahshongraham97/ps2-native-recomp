
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 recovery0406_002b9f10(undefined4 param_1)

{
  if (*(int *)((int)&DAT_008353a0 + DAT_005c7304) != 0) {
    FUN_002c3fc0(*(int *)((int)&DAT_008353a0 + DAT_005c7304));
    *(undefined4 *)((int)&DAT_008353a0 + DAT_005c7304) = 0;
  }
  _DAT_005c7308 = _DAT_005c7308 + -1;
  return param_1;
}

