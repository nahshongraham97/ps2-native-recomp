
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 recovery0406_002b9f70(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)(&DAT_0083536c + param_2);
  for (iVar3 = 0xd; uVar2 = DAT_005a6714, uVar1 = DAT_005a6710, iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  *(undefined4 *)(&DAT_00835378 + param_2) = 0;
  *(undefined4 *)(&DAT_0083537c + param_2) = 0;
  *(undefined4 *)(&DAT_00835380 + param_2) = 0;
  *(undefined1 *)((int)&DAT_0083538c + param_2 + 1) = 0x80;
  *(undefined4 *)((int)&DAT_00835370 + param_2) = 0;
  *(undefined4 *)(&DAT_00835374 + param_2) = 0;
  *(undefined1 *)((int)&DAT_0083538c + param_2) = 0;
  *(undefined4 *)(&DAT_00835368 + param_2) = 0;
  DAT_005c7304 = param_2;
  *(undefined **)((int)&DAT_00835340 + param_2) = &DAT_0083536c + param_2;
  iVar3 = FUN_002c4620(DAT_005a66f8,uVar1,4,uVar2,&DAT_005c730c,0x40407);
  *(int *)((int)&DAT_008353a0 + DAT_005c7304) = iVar3;
  if (iVar3 == 0) {
    return 0;
  }
  _DAT_005c7308 = _DAT_005c7308 + 1;
  return param_1;
}

