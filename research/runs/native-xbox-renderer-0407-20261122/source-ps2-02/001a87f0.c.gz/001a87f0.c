
long FUN_001a87f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  code *pcVar1;
  long lVar2;
  long lVar3;
  int iVar4;
  
  lVar2 = (*pcRam0069f3d4)(*(undefined4 *)(iRam0064e4e0 + 0x69f2f0),0x30407);
  pcVar1 = pcRam0069f2e8;
  if (lVar2 == 0) {
    lVar2 = 0;
  }
  else {
    iVar4 = (int)lVar2;
    *(undefined1 *)(iVar4 + 0x22) = 0;
    *(undefined1 *)(iVar4 + 0x21) = 0;
    *(undefined4 *)(iVar4 + 0xc) = param_1;
    *(undefined4 *)(iVar4 + 0x10) = param_2;
    *(undefined2 *)(iVar4 + 0x1c) = 0;
    *(undefined2 *)(iVar4 + 0x1e) = 0;
    *(undefined4 *)(iVar4 + 0x14) = param_3;
    *(int *)iVar4 = iVar4;
    *(undefined4 *)(iVar4 + 4) = 0;
    *(undefined4 *)(iVar4 + 8) = 0;
    lVar3 = (*pcVar1)(0,lVar2,param_4);
    if (lVar3 == 0) {
      (*pcRam0069f3d8)(*(undefined4 *)(iRam0064e4e0 + 0x69f2f0),lVar2);
      lVar2 = 0;
    }
    else {
      FUN_001a3480(0x5a3700,lVar2);
    }
  }
  return lVar2;
}

