
void FUN_002cd460(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  for (; param_1 != 0; param_1 = *(int *)(param_1 + 0x9c)) {
    uVar3 = *(byte *)(param_1 + 3) | param_2;
    if ((uVar3 & 4) != 0) {
      iVar1 = *(int *)(param_1 + 4);
      if ((*(byte *)(param_1 + 3) & 0x20) == 0) {
        FUN_002be460(param_1 + 0x50,param_1 + 0x10,iVar1 + 0x50);
      }
      else {
        puVar4 = (undefined4 *)(param_1 + 0x10);
        puVar5 = (undefined4 *)(param_1 + 0x50);
        for (iVar2 = 0x10; iVar2 != 0; iVar2 = iVar2 + -1) {
          *puVar5 = *puVar4;
          puVar4 = puVar4 + 1;
          puVar5 = puVar5 + 1;
        }
        FUN_002c1bc0(param_1 + 0x80,param_1 + 0x40,1,iVar1 + 0x50);
        FUN_002be450((undefined4 *)(param_1 + 0x50));
      }
    }
    for (puVar4 = *(undefined4 **)(param_1 + 0x90); puVar4 != (undefined4 *)(param_1 + 0x90);
        puVar4 = (undefined4 *)*puVar4) {
      (*(code *)puVar4[2])(puVar4 + -2);
    }
    *(byte *)(param_1 + 3) = *(byte *)(param_1 + 3) & 0xf3;
    FUN_002cd460(*(undefined4 *)(param_1 + 0x98),uVar3);
  }
  return;
}

