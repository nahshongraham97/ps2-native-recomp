
int FUN_002c2c20(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  
  for (puVar1 = *(undefined4 **)(param_1 + 0x10); puVar1 != (undefined4 *)0x0;
      puVar1 = (undefined4 *)puVar1[0xc]) {
    (*(code *)puVar1[10])(param_2,param_3,*puVar1,puVar1[1]);
  }
  return param_1;
}

