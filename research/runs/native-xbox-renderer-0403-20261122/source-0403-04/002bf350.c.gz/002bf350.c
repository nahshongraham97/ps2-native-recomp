
int FUN_002bf350(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(*(int *)(param_1 + 4) + 0x98);
  if (iVar1 == param_1) {
    *(undefined4 *)(*(int *)(param_1 + 4) + 0x98) = *(undefined4 *)(param_1 + 0x9c);
  }
  else {
    iVar2 = *(int *)(iVar1 + 0x9c);
    while (iVar2 != param_1) {
      iVar1 = *(int *)(iVar1 + 0x9c);
      iVar2 = *(int *)(iVar1 + 0x9c);
    }
    *(undefined4 *)(iVar1 + 0x9c) = *(undefined4 *)(param_1 + 0x9c);
  }
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 0x9c) = 0;
  FUN_002bf000(param_1,param_1);
  FUN_002bf2c0(param_1);
  return param_1;
}

