
void FUN_002cd520(int param_1)

{
  undefined4 *puVar1;
  
  for (; param_1 != 0; param_1 = *(int *)(param_1 + 0x9c)) {
    for (puVar1 = *(undefined4 **)(param_1 + 0x90); puVar1 != (undefined4 *)(param_1 + 0x90);
        puVar1 = (undefined4 *)*puVar1) {
      (*(code *)puVar1[2])(puVar1 + -2);
    }
    *(byte *)(param_1 + 3) = *(byte *)(param_1 + 3) & 0xf7;
    FUN_002cd520(*(undefined4 *)(param_1 + 0x98));
  }
  return;
}

