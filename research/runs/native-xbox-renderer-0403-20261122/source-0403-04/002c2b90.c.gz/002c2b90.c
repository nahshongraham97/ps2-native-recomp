
int FUN_002c2b90(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 0x10);
  while( true ) {
    if (puVar1 == (undefined4 *)0x0) {
      return param_1;
    }
    iVar2 = (*(code *)puVar1[8])(param_2,*puVar1,puVar1[1]);
    if (iVar2 == 0) break;
    puVar1 = (undefined4 *)puVar1[0xc];
  }
  for (puVar1 = (undefined4 *)puVar1[0xd]; puVar1 != (undefined4 *)0x0;
      puVar1 = (undefined4 *)puVar1[0xd]) {
    (*(code *)puVar1[9])(param_2,*puVar1,puVar1[1]);
  }
  return 0;
}

