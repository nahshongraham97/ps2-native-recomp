
undefined4 FUN_002bf840(undefined4 param_1)

{
  FUN_002bf7d0(param_1);
  (*DAT_00835488)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c73fc),param_1);
  return 1;
}

