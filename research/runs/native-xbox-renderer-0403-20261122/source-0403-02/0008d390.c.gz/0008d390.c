
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0008d390(void)

{
  byte bVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *local_8;
  
  for (local_8 = DAT_008353fc; (undefined4 **)local_8 != &DAT_008353fc;
      local_8 = (undefined4 *)*local_8) {
    bVar1 = *(byte *)((int)local_8 + -5);
    if ((bVar1 & 1) == 0) {
      FUN_0008d810(local_8 + -2);
    }
    else {
      if ((bVar1 & 4) != 0) {
        puVar3 = local_8 + 2;
        puVar4 = local_8 + 0x12;
        for (iVar2 = 0x10; iVar2 != 0; iVar2 = iVar2 + -1) {
          *puVar4 = *puVar3;
          puVar3 = puVar3 + 1;
          puVar4 = puVar4 + 1;
        }
      }
      FUN_0008d450(local_8 + -2);
      FUN_0008d760(local_8[0x24],bVar1 & 4);
    }
    *(byte *)((int)local_8 + -5) = bVar1 & 0xf0;
  }
  DAT_008353fc = &DAT_008353fc;
  _DAT_00835400 = &DAT_008353fc;
  return;
}

