
undefined1 * FUN_002bf640(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar2 = (undefined1 *)(*DAT_00835484)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c73fc),0x3000e)
  ;
  if (puVar2 == (undefined1 *)0x0) {
    return (undefined1 *)0x0;
  }
  if (param_2 == (undefined1 *)0x0) {
    param_2 = puVar2;
  }
  *puVar2 = *param_1;
  puVar2[1] = param_1[1];
  puVar2[2] = param_1[2];
  puVar2[3] = param_1[3];
  puVar1 = puVar2 + 0x90;
  *(undefined1 **)puVar1 = puVar1;
  *(undefined1 **)(puVar2 + 0x94) = puVar1;
  *(undefined4 *)(puVar2 + 4) = 0;
  puVar5 = (undefined4 *)(param_1 + 0x10);
  puVar6 = (undefined4 *)(puVar2 + 0x10);
  for (iVar4 = 0x10; iVar4 != 0; iVar4 = iVar4 + -1) {
    *puVar6 = *puVar5;
    puVar5 = puVar5 + 1;
    puVar6 = puVar6 + 1;
  }
  *(undefined4 *)(puVar2 + 0x98) = 0;
  *(undefined4 *)(puVar2 + 0x9c) = 0;
  *(undefined1 **)(puVar2 + 0xa0) = param_2;
  iVar4 = *(int *)(param_1 + 0x98);
  *(undefined1 **)(param_1 + 0xa0) = puVar2;
  while( true ) {
    if (iVar4 == 0) {
      FUN_002c2b90(&DAT_005a6768,puVar2);
      FUN_002c2c20(&DAT_005a6768,puVar2,param_1);
      return puVar2;
    }
    iVar3 = FUN_002bf640(iVar4,param_2);
    if (iVar3 == 0) break;
    *(undefined4 *)(iVar3 + 0x9c) = *(undefined4 *)(puVar2 + 0x98);
    *(int *)(puVar2 + 0x98) = iVar3;
    *(undefined1 **)(iVar3 + 4) = puVar2;
    iVar4 = *(int *)(iVar4 + 0x9c);
  }
  FUN_002bf230(puVar2);
  return (undefined1 *)0x0;
}

