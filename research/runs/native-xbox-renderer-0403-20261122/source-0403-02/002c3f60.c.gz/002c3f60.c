
void FUN_002c3f60(void)

{
  int *piVar1;
  int unaff_EDI;
  
  piVar1 = *(int **)(unaff_EDI + 0x10);
  while (piVar1 != (int *)(unaff_EDI + 0x10)) {
    *(int *)piVar1[1] = *piVar1;
    *(int *)(*piVar1 + 4) = piVar1[1];
    (*DAT_00835478)(piVar1);
    piVar1 = *(int **)(unaff_EDI + 0x10);
  }
  if ((*(byte *)(unaff_EDI + 0x18) & 1) == 0) {
    if ((DAT_005c748c != unaff_EDI) && (DAT_005c748c != 0)) {
      (*DAT_00835488)(DAT_005c748c);
      return;
    }
    (*DAT_00835478)();
  }
  return;
}

