
int FUN_002bf170(void)

{
  int iVar1;
  
  iVar1 = (*DAT_00835484)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c73fc),0x3000e);
  if (iVar1 == 0) {
    return 0;
  }
  FUN_002bf090(iVar1);
  return iVar1;
}

