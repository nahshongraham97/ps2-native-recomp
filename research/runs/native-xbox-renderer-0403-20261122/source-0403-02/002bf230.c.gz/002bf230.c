
void FUN_002bf230(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x98);
    while (iVar2 != 0) {
      iVar1 = *(int *)(iVar2 + 0x9c);
      FUN_002bf230(iVar2);
      iVar2 = iVar1;
    }
    FUN_002c2bf0(&DAT_005a6768,param_1);
    if ((*(byte *)(param_1 + 3) & 3) != 0) {
      **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_1 + 8);
      *(undefined4 *)(*(int *)(param_1 + 8) + 4) = *(undefined4 *)(param_1 + 0xc);
    }
    (*DAT_00835488)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c73fc),param_1);
  }
  return;
}

