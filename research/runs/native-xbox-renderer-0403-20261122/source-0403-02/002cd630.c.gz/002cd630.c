
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_002cd630(void)

{
  undefined4 *puVar1;
  
  for (puVar1 = DAT_008353fc; (undefined4 **)puVar1 != &DAT_008353fc; puVar1 = (undefined4 *)*puVar1
      ) {
    FUN_002cd580(puVar1 + -2);
  }
  DAT_008353fc = &DAT_008353fc;
  _DAT_00835400 = &DAT_008353fc;
  return 1;
}

