
void FUN_002bf2c0(int param_1)

{
  byte bVar1;
  
  bVar1 = *(byte *)(*(int *)(param_1 + 0xa0) + 3);
  if ((bVar1 & 3) == 0) {
    *(int *)(*(int *)(param_1 + 0xa0) + 8) = DAT_008353fc;
    *(int **)(*(int *)(param_1 + 0xa0) + 0xc) = &DAT_008353fc;
    *(int *)(DAT_008353fc + 4) = *(int *)(param_1 + 0xa0) + 8;
    DAT_008353fc = *(int *)(param_1 + 0xa0) + 8;
  }
  *(byte *)(*(int *)(param_1 + 0xa0) + 3) = bVar1 | 3;
  *(byte *)(param_1 + 3) = *(byte *)(param_1 + 3) | 0xc;
  return;
}

