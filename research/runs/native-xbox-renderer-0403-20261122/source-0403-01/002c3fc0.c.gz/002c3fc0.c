
undefined4 FUN_002c3fc0(int param_1)

{
  **(undefined4 **)(param_1 + 0x20) = *(undefined4 *)(param_1 + 0x1c);
  *(undefined4 *)(*(int *)(param_1 + 0x1c) + 4) = *(undefined4 *)(param_1 + 0x20);
  FUN_002c3f60();
  return 1;
}

