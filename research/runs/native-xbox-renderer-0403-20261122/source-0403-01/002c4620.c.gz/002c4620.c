
void FUN_002c4620(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_002c44c0(param_1,param_2,param_4,param_6);
  return;
}

