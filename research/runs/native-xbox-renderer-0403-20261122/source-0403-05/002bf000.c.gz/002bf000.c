
void FUN_002bf000(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x98);
  *(undefined4 *)(param_1 + 0xa0) = param_2;
  for (; iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x9c)) {
    FUN_002bf000(iVar1,param_2);
  }
  return;
}

