
undefined4 FUN_002bf2a0(undefined4 param_1)

{
  FUN_002bf230(param_1);
  return 1;
}

