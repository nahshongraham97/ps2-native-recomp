
undefined4 FUN_002bf890(int param_1,int param_2)

{
  undefined4 extraout_ECX;
  
  if (*(int *)(param_2 + 4) != 0) {
    FUN_002bf350(param_2);
  }
  *(undefined4 *)(param_2 + 0x9c) = *(undefined4 *)(param_1 + 0x98);
  *(int *)(param_1 + 0x98) = param_2;
  *(int *)(param_2 + 4) = param_1;
  FUN_002bf000(param_2,*(undefined4 *)(param_1 + 0xa0));
  return extraout_ECX;
}

