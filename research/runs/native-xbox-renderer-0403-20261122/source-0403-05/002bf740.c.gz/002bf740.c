
int FUN_002bf740(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_002bf640(param_1,0);
  if (iVar1 != 0) {
    *(byte *)(iVar1 + 3) = *(byte *)(iVar1 + 3) & 0xfc;
    FUN_002bf2c0(iVar1);
  }
  return iVar1;
}

