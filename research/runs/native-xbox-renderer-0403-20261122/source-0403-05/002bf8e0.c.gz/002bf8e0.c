
int FUN_002bf8e0(int param_1,int param_2)

{
  if (*(int *)(param_2 + 4) != 0) {
    FUN_002bf350(param_2);
  }
  *(undefined4 *)(param_2 + 0x9c) = *(undefined4 *)(param_1 + 0x98);
  *(int *)(param_1 + 0x98) = param_2;
  *(int *)(param_2 + 4) = param_1;
  FUN_002bf000(param_2,*(undefined4 *)(param_1 + 0xa0));
  if ((*(byte *)(param_2 + 3) & 3) != 0) {
    **(undefined4 **)(param_2 + 0xc) = *(undefined4 *)(param_2 + 8);
    *(undefined4 *)(*(int *)(param_2 + 8) + 4) = *(undefined4 *)(param_2 + 0xc);
    *(byte *)(param_2 + 3) = *(byte *)(param_2 + 3) & 0xfc;
  }
  FUN_002bf2c0(param_2);
  return param_1;
}

