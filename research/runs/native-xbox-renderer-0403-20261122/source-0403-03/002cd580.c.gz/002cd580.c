
void FUN_002cd580(int param_1)

{
  byte bVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  bVar1 = *(byte *)(param_1 + 3);
  if ((bVar1 & 1) == 0) {
    for (puVar3 = *(undefined4 **)(param_1 + 0x90); puVar3 != (undefined4 *)(param_1 + 0x90);
        puVar3 = (undefined4 *)*puVar3) {
      (*(code *)puVar3[2])(puVar3 + -2);
    }
    FUN_002cd520(*(undefined4 *)(param_1 + 0x98));
    *(byte *)(param_1 + 3) = bVar1 & 0xf0;
    return;
  }
  if ((bVar1 & 4) != 0) {
    puVar3 = (undefined4 *)(param_1 + 0x10);
    puVar4 = (undefined4 *)(param_1 + 0x50);
    for (iVar2 = 0x10; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar4 = *puVar3;
      puVar3 = puVar3 + 1;
      puVar4 = puVar4 + 1;
    }
  }
  for (puVar3 = *(undefined4 **)(param_1 + 0x90); puVar3 != (undefined4 *)(param_1 + 0x90);
      puVar3 = (undefined4 *)*puVar3) {
    (*(code *)puVar3[2])(puVar3 + -2);
  }
  FUN_002cd460(*(undefined4 *)(param_1 + 0x98),bVar1 & 4);
  *(byte *)(param_1 + 3) = bVar1 & 0xf0;
  return;
}

