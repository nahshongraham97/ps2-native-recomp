
void FUN_0008d810(int param_1)

{
  int iVar1;
  
  while (param_1 != 0) {
    FUN_0008d450(param_1);
    *(byte *)(param_1 + 3) = *(byte *)(param_1 + 3) & 0xf7;
    iVar1 = *(int *)(param_1 + 0x9c);
    if (iVar1 == 0) {
      param_1 = *(int *)(param_1 + 0x98);
    }
    else {
      FUN_0008d810(*(undefined4 *)(param_1 + 0x98));
      param_1 = iVar1;
    }
  }
  return;
}

