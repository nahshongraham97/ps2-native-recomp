
void FUN_002bf7d0(int param_1)

{
  int iVar1;
  
  FUN_002c2bf0(&DAT_005a6768,param_1);
  if (*(int *)(param_1 + 4) != 0) {
    FUN_002bf350(param_1);
  }
  if ((*(byte *)(param_1 + 3) & 3) != 0) {
    **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_1 + 8);
    *(undefined4 *)(*(int *)(param_1 + 8) + 4) = *(undefined4 *)(param_1 + 0xc);
  }
  for (iVar1 = *(int *)(param_1 + 0x98); iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x9c)) {
    *(undefined4 *)(iVar1 + 4) = 0;
  }
  return;
}

