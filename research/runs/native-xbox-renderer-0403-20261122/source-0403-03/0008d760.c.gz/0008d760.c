
void FUN_0008d760(int param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  
  while (param_1 != 0) {
    uVar2 = *(byte *)(param_1 + 3) | param_2;
    if ((uVar2 & 4) != 0) {
      FUN_002be460(param_1 + 0x50,param_1 + 0x10,*(int *)(param_1 + 4) + 0x50);
    }
    FUN_0008d450(param_1);
    *(byte *)(param_1 + 3) = *(byte *)(param_1 + 3) & 0xf3;
    iVar1 = *(int *)(param_1 + 0x9c);
    if (iVar1 == 0) {
      param_1 = *(int *)(param_1 + 0x98);
      param_2 = uVar2;
    }
    else {
      FUN_0008d760(*(undefined4 *)(param_1 + 0x98),uVar2);
      param_1 = iVar1;
    }
  }
  return;
}

