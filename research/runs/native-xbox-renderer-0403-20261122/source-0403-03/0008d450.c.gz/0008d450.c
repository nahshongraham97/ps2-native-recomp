
void FUN_0008d450(int param_1)

{
  undefined4 *local_8;
  
  for (local_8 = *(undefined4 **)(param_1 + 0x90); local_8 != (undefined4 *)(param_1 + 0x90);
      local_8 = (undefined4 *)*local_8) {
    if ((undefined1 *)local_8[2] == &LAB_002d8b30) {
      FUN_0008d4c0(local_8 + -2);
    }
    else {
      (*(code *)local_8[2])(local_8 + -2);
    }
  }
  return;
}

