
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_002bb670(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  *(float *)(param_1 + 0x84) = param_2;
  if (*(int *)(param_1 + 0x14) == 2) {
    fVar4 = *(float *)(param_1 + 0x80);
  }
  else {
    fVar4 = DAT_004d7b54 / *(float *)(param_1 + 0x80);
    param_2 = DAT_004d7b54 / param_2;
  }
  fVar1 = (DAT_0083535c - DAT_00835358) * _DAT_004dd748;
  fVar2 = DAT_0083535c - fVar1;
  fVar1 = fVar1 + DAT_00835358;
  fVar3 = (fVar2 - fVar1) / (param_2 - fVar4);
  fVar4 = ((fVar2 + fVar1) - (fVar4 + param_2) * fVar3) * DAT_004d7c30;
  *(float *)(param_1 + 0x8c) = fVar3;
  *(float *)(param_1 + 0x90) = fVar4;
  if (*(int *)(param_1 + 4) != 0) {
    FUN_002bf2c0(*(int *)(param_1 + 4));
  }
  return param_1;
}

