
undefined4 FUN_002bb800(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 local_8;
  undefined4 local_4;
  
  if ((0 < param_2) && (param_2 < 3)) {
    *(int *)(param_1 + 0x14) = param_2;
    if (*(int *)(param_1 + 4) != 0) {
      FUN_002bf2c0(*(int *)(param_1 + 4));
    }
    uVar1 = FUN_002ba010();
    return uVar1;
  }
  local_8 = 1;
  local_4 = FUN_002c2400(0x80000003,"Invalid projection type specified");
  FUN_002c2370(&local_8);
  return 0;
}

