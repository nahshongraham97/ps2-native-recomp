
void FUN_002c0480(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  
  if (*(int *)(param_1 + 4) != 0) {
    **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_1 + 8);
    *(undefined4 *)(*(int *)(param_1 + 8) + 4) = *(undefined4 *)(param_1 + 0xc);
  }
  *(int *)(param_1 + 4) = param_2;
  if (param_2 != 0) {
    piVar2 = (int *)(param_2 + 0x90);
    piVar1 = (int *)(param_1 + 8);
    *piVar1 = *piVar2;
    *(int **)(param_1 + 0xc) = piVar2;
    *(int **)(*piVar2 + 4) = piVar1;
    *piVar2 = (int)piVar1;
    FUN_002bf2c0(param_2);
  }
  return;
}

