
int FUN_002c0a80(int param_1)

{
  int iVar1;
  
  iVar1 = DAT_00835320;
  if ((param_1 == 0) && (param_1 = *(int *)((int)&DAT_0083535c + DAT_00835320), param_1 == 0)) {
    *(undefined4 *)((int)&DAT_00835340 + DAT_00835320) = 0;
    return *(int *)((int)&DAT_00835340 + iVar1);
  }
  *(int *)((int)&DAT_00835340 + DAT_00835320) = param_1;
  return param_1;
}

