
int FUN_002c0ac0(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 local_8;
  undefined4 local_4;
  
  iVar1 = DAT_00835320;
  if (param_1 != 0) {
    switch(param_2) {
    case 1:
      *(int *)((int)&DAT_00835350 + DAT_00835320) = param_1;
      return param_1;
    case 2:
      *(int *)((int)&DAT_00835354 + DAT_00835320) = param_1;
      return param_1;
    case 3:
      *(int *)((int)&DAT_00835344 + DAT_00835320) = param_1;
      return param_1;
    case 4:
      *(int *)(&DAT_0083534c + DAT_00835320) = param_1;
      return param_1;
    case 5:
      *(int *)((int)&DAT_00835348 + DAT_00835320) = param_1;
      return param_1;
    case 6:
      *(int *)((int)&DAT_00835358 + DAT_00835320) = param_1;
      return param_1;
    default:
      local_8 = 1;
      local_4 = FUN_002c2400(0x25,param_2);
      FUN_002c2370(&local_8);
      return 0;
    }
  }
  switch(param_2) {
  case 1:
    *(undefined4 *)((int)&DAT_00835350 + DAT_00835320) =
         *(undefined4 *)(&DAT_0083536c + DAT_00835320);
    return *(int *)(&DAT_0083536c + iVar1);
  case 2:
    *(undefined4 *)((int)&DAT_00835354 + DAT_00835320) =
         *(undefined4 *)((int)&DAT_00835370 + DAT_00835320);
    return *(int *)((int)&DAT_00835370 + iVar1);
  case 3:
    break;
  case 4:
    *(undefined4 *)(&DAT_0083534c + DAT_00835320) = *(undefined4 *)(&DAT_00835368 + DAT_00835320);
    return *(int *)(&DAT_00835368 + iVar1);
  case 5:
    iVar1 = *(int *)((int)&DAT_00835364 + DAT_00835320);
    if (iVar1 == 0) {
      *(undefined4 *)((int)&DAT_00835348 + DAT_00835320) = 0;
      return 0;
    }
    *(int *)((int)&DAT_00835348 + DAT_00835320) = iVar1;
    return iVar1;
  case 6:
    *(undefined4 *)((int)&DAT_00835358 + DAT_00835320) =
         *(undefined4 *)(&DAT_00835374 + DAT_00835320);
    return *(int *)(&DAT_00835374 + iVar1);
  default:
    local_8 = 1;
    local_4 = FUN_002c2400(0x25,param_2);
    FUN_002c2370(&local_8);
    return 0;
  }
  iVar1 = *(int *)((int)&DAT_00835360 + DAT_00835320);
  if (iVar1 == 0) {
    *(undefined4 *)((int)&DAT_00835344 + DAT_00835320) = 0;
    return 0;
  }
  *(int *)((int)&DAT_00835344 + DAT_00835320) = iVar1;
  return iVar1;
}

