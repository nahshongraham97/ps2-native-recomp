
int FUN_002bb870(int param_1,undefined4 *param_2)

{
  float fVar1;
  
  fVar1 = DAT_004d7b54;
  *(undefined4 *)(param_1 + 0x68) = *param_2;
  *(undefined4 *)(param_1 + 0x6c) = param_2[1];
  *(float *)(param_1 + 0x70) = fVar1 / *(float *)(param_1 + 0x68);
  *(float *)(param_1 + 0x74) = fVar1 / *(float *)(param_1 + 0x6c);
  if (*(int *)(param_1 + 4) != 0) {
    FUN_002bf2c0(*(int *)(param_1 + 4));
  }
  return param_1;
}

