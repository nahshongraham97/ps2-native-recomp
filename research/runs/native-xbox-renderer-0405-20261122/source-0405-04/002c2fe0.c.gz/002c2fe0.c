
undefined4 FUN_002c2fe0(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  
  **(undefined4 **)((int)&DAT_00835354 + DAT_00835318) =
       *(undefined4 *)((int)&DAT_00835358 + DAT_00835318);
  piVar1 = (int *)((int)&DAT_00835358 + DAT_00835318);
  piVar4 = *(int **)((int)&DAT_00835350 + DAT_00835318);
  iVar5 = DAT_00835318;
  while (DAT_00835318 = iVar5, piVar4 != piVar1) {
    piVar3 = (int *)*piVar4;
    if ((code *)piVar4[5] != (code *)0x0) {
      (*(code *)piVar4[5])(piVar4);
    }
    if ((undefined4 *)piVar4[4] != (undefined4 *)0x0) {
      *(undefined4 *)piVar4[4] = 0;
    }
    if (*piVar4 == 0) {
      (*DAT_00835478)(piVar4);
      piVar4 = piVar3;
      iVar5 = DAT_00835318;
    }
    else {
      *(int *)piVar4[1] = *piVar4;
      *(int *)(*piVar4 + 4) = piVar4[1];
      *(int *)((int)&DAT_00835344 + DAT_00835318) =
           *(int *)((int)&DAT_00835344 + DAT_00835318) - piVar4[2];
      FUN_002ce540();
      piVar4 = piVar3;
      iVar5 = DAT_00835318;
    }
  }
  iVar2 = (int)&DAT_00835350 + iVar5;
  *(int *)iVar2 = iVar2;
  *(int *)((int)&DAT_00835354 + iVar5) = iVar2;
  iVar2 = (int)&DAT_00835358 + iVar5;
  *(int *)iVar2 = iVar2;
  *(int *)((int)&DAT_0083535c + iVar5) = iVar2;
  *(undefined4 *)((int)&DAT_00835348 + iVar5) = 0;
  return 1;
}

