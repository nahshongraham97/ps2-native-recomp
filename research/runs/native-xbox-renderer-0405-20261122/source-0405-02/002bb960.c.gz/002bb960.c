
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 * FUN_002bb960(void)

{
  undefined4 uVar1;
  undefined1 *puVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  puVar2 = (undefined1 *)(*DAT_00835484)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c7354),0x30005)
  ;
  uVar1 = DAT_004d7b54;
  if (puVar2 == (undefined1 *)0x0) {
    return (undefined1 *)0x0;
  }
  *(undefined4 *)(puVar2 + 0x6c) = DAT_004d7b54;
  *(undefined4 *)(puVar2 + 0x68) = uVar1;
  *(undefined4 *)(puVar2 + 0x74) = uVar1;
  *(undefined4 *)(puVar2 + 0x70) = uVar1;
  *(undefined4 *)(puVar2 + 0x7c) = 0;
  *(undefined4 *)(puVar2 + 0x78) = 0;
  *(undefined4 *)(puVar2 + 0x80) = DAT_004d7cb8;
  *(undefined4 *)(puVar2 + 0x84) = DAT_004d7cbc;
  *(undefined4 *)(puVar2 + 0x88) = DAT_004d7c64;
  *puVar2 = 4;
  puVar2[1] = 0;
  puVar2[2] = 0;
  puVar2[3] = 0;
  *(undefined4 *)(puVar2 + 4) = 0;
  *(code **)(puVar2 + 0x10) = FUN_002bb3f0;
  *(code **)(puVar2 + 0x18) = FUN_002bb470;
  *(undefined1 **)(puVar2 + 0x1c) = &LAB_002bb440;
  *(undefined4 *)(puVar2 + 0x60) = 0;
  *(undefined4 *)(puVar2 + 100) = 0;
  *(undefined4 *)(puVar2 + 0x14) = 1;
  fVar3 = (DAT_0083535c - DAT_00835358) * _DAT_004dd748;
  fVar4 = DAT_0083535c - fVar3;
  fVar3 = fVar3 + DAT_00835358;
  fVar5 = (fVar4 - fVar3) * _DAT_0050b150;
  *(float *)(puVar2 + 0x8c) = fVar5;
  *(float *)(puVar2 + 0x90) = ((fVar4 + fVar3) - fVar5 * _DAT_0050b14c) * DAT_004d7c30;
  *(undefined4 *)(puVar2 + 0x2c) = 0;
  FUN_002c2b90(&DAT_005a6718,puVar2);
  return puVar2;
}

