
undefined4 FUN_002bb920(undefined4 param_1)

{
  FUN_002c2bf0(&DAT_005a6718,param_1);
  FUN_002c04d0(param_1);
  (*DAT_00835488)(*(undefined4 *)((int)&DAT_00835340 + DAT_005c7354),param_1);
  return 1;
}

