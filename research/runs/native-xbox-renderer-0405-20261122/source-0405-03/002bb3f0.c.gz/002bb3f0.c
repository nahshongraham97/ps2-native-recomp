
int FUN_002bb3f0(int param_1)

{
  if (*(int *)(param_1 + 0x14) == 1) {
    FUN_002babb0();
    FUN_002ba0b0();
  }
  else {
    FUN_002bb260();
    FUN_002bad50();
  }
  FUN_002cd2b0(param_1 + 0x10c,param_1 + 0x124,8);
  return param_1;
}

