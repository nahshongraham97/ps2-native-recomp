
int FUN_0007f0f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = FUN_002b9e50(param_2,param_3,0x20,5);
  if (iVar1 != 0) {
    iVar2 = FUN_002b9e50(param_2,param_3,0,1);
    if (iVar2 != 0) {
      iVar3 = FUN_002bf170();
      if (iVar3 != 0) {
        iVar4 = FUN_002bb960();
        FUN_002bf490(iVar3,*(int *)(param_1 + 4) + 0x10,0);
        if (iVar4 != 0) {
          *(int *)(iVar4 + 0x60) = iVar1;
          *(int *)(iVar4 + 100) = iVar2;
          FUN_002c0480(iVar4,iVar3);
          FUN_002bb5b0(iVar4,*(undefined4 *)(param_1 + 0x80));
          FUN_002bb670(iVar4,*(undefined4 *)(param_1 + 0x84));
          FUN_002bb870(iVar4,param_1 + 0x68);
          FUN_002d9160(DAT_005b7adc,iVar4);
          return iVar4;
        }
        FUN_002bf840(iVar3);
      }
      FUN_002b9c70(iVar2);
    }
    FUN_002b9c70(iVar1);
  }
  return 0;
}

