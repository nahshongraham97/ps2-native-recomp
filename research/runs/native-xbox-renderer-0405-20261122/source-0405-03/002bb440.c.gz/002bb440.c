
undefined4 module0403_002bb440(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = (*DAT_008353b0)(0,param_1,0);
  if (iVar1 != 0) {
    DAT_00835340 = 0;
    return param_1;
  }
  return 0;
}

