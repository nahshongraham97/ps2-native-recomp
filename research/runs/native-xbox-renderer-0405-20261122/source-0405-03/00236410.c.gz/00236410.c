
int FUN_00236410(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_002bb960();
  if (iVar1 != 0) {
    uVar2 = FUN_002bf170();
    FUN_002c0480(iVar1,uVar2);
    if ((*(int *)(iVar1 + 4) != 0) && (iVar3 = FUN_002b9e50(param_1,param_1,0,1), iVar3 != 0)) {
      *(int *)(iVar1 + 100) = iVar3;
      FUN_002bb800(iVar1,2);
      return iVar1;
    }
  }
  FUN_00236380(iVar1);
  return 0;
}

