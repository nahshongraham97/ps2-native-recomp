
undefined4 FUN_002bb470(undefined4 param_1)

{
  int iVar1;
  
  DAT_00835340 = param_1;
  FUN_002cd630();
  iVar1 = (*DAT_0083538c)(0,param_1,0);
  if (iVar1 != 0) {
    FUN_002c9880(param_1);
    return param_1;
  }
  return 0;
}

