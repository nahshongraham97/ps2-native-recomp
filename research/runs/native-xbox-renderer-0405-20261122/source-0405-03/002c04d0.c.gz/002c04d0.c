
void FUN_002c04d0(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_1 + 8);
    *(undefined4 *)(*(int *)(param_1 + 8) + 4) = *(undefined4 *)(param_1 + 0xc);
  }
  return;
}

