
int FUN_002e8fe0(int param_1,int param_2)

{
  int iVar1;
  
  param_1 = param_1 * 0x1c;
  if (*(char *)(param_1 + 0x6d0918) == '\0') {
    iVar1 = 0;
  }
  else {
    iVar1 = *(int *)(param_1 + 0x6d0914);
  }
  if ((*(int *)(param_1 + 0x6d0924) - *(int *)(param_1 + 0x6d0928)) - iVar1 <
      (int)(*(int *)(param_1 + 0x6d0910) + (param_2 + 0xfU & 0xfffffff0))) {
    iVar1 = 0;
  }
  else if (*(char *)(param_1 + 0x6d0918) == '\0') {
    *(undefined1 *)(param_1 + 0x6d0918) = 1;
    *(int *)(param_1 + 0x6d0914) = param_2;
    iVar1 = *(int *)(param_1 + 0x6d091c) + *(int *)(param_1 + 0x6d0910);
  }
  else {
    iVar1 = 0;
  }
  return iVar1;
}

