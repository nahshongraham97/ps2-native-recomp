
void FUN_002e8d50(void)

{
  bRam006d0919 = bRam006d0919 ^ 1;
  return;
}

