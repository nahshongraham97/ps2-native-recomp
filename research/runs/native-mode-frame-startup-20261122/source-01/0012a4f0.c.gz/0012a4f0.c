
void FUN_0012a4f0(long param_1)

{
  if ((((-1 < param_1) && (param_1 < 9)) && (-1 < *(int *)(&DAT_0059f9a0 + (int)param_1 * 0x24))) &&
     (*(int *)(&DAT_0059f9a0 + (int)param_1 * 0x24) < 4)) {
    FUN_0012a170();
  }
  return;
}

