
bool FUN_003271a0(int *param_1)

{
  long lVar1;
  
  lVar1 = (**(code **)(*param_1 + 0x14))();
  if (lVar1 != 0) {
    FUN_00328ce0();
  }
  return lVar1 != 0;
}

