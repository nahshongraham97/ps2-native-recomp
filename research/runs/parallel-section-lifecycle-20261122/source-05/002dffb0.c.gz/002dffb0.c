
undefined8 FUN_002dffb0(long param_1,undefined4 param_2,long param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  int *piVar4;
  undefined1 auStack_10 [8];
  undefined1 auStack_8 [8];
  
  uVar2 = uRam0064df54;
  if (param_1 == 0) {
    uVar3 = 0;
  }
  else if (param_3 == 0) {
    uVar3 = 0;
  }
  else {
    piVar4 = (int *)param_1;
    if (((param_1 != 0) && (*piVar4 == 0)) && (piVar4[1] != 0)) {
      uRam0064df54 = 0;
      FUN_002e05a0(piVar4 + 1,auStack_8);
      if (piVar4[1] == 0) {
        piVar4[1] = 0;
      }
      else {
        FUN_00327120();
        piVar4[1] = 0;
      }
    }
    iVar1 = iRam00000000;
    if (param_1 != 0) {
      if ((*piVar4 == 0) && (piVar4[1] != 0)) {
        uRam0064df54 = 0;
        FUN_002e05a0(piVar4 + 1,auStack_10);
        if (piVar4[1] == 0) {
          piVar4[1] = 0;
        }
        else {
          FUN_00327120();
          piVar4[1] = 0;
        }
      }
      iVar1 = *piVar4;
    }
    uRam0064df54 = uVar2;
    uVar3 = FUN_00327230(iVar1,param_2,param_3,param_4,1,0,0);
  }
  return uVar3;
}

