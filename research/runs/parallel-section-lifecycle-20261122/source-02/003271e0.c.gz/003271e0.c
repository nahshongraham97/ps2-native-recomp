
long FUN_003271e0(int *param_1)

{
  long lVar1;
  
  lVar1 = (**(code **)(*param_1 + 0x20))();
  if (lVar1 == 0) {
    lVar1 = 0;
  }
  else {
    FUN_00323ff0(0x631a60);
  }
  return lVar1;
}

