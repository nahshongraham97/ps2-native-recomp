
void FUN_003ddef0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if ((iVar1 == 0) || (*(char *)(iVar1 + 0xc) == '\0')) {
LAB_003ddfc0:
    if ((iVar1 != 0) && (*(int *)(iVar1 + 4) != 0)) {
      FUN_002dfe70(iVar1 + 4);
    }
  }
  else {
    do {
      while( true ) {
        if ((iVar1 == 0) || ((*(char *)(iVar1 + 0xc) == '\0' || (*(int *)(iVar1 + 4) != 0))))
        goto LAB_003ddfc0;
        if ((piRam0064df54 == (int *)0x0) || (piRam0064df54[0x3c] == 0)) {
          thunk_FUN_00328ce0();
        }
        else {
          uRam0064df58 = 0x3f800000;
          (**(code **)(*piRam0064df54 + 0x14))();
        }
        if (*(char *)(param_1 + 0x1d) == '\0') break;
        iVar1 = 0;
      }
    } while ((iVar1 == *(int *)(param_1 + 4)) && (*(int *)(iVar1 + 0x14) == param_1));
  }
  return;
}

