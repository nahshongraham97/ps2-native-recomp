
void FUN_003ddcd0(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  
  iVar1 = *(int *)(param_1 + 0x14);
  iVar6 = *(int *)(param_1 + 0x18);
  if (iVar1 == 0) {
    return;
  }
  if (*(int *)(param_1 + 8) == 0) {
    return;
  }
  iVar4 = 0;
  if (*(int *)(iVar1 + 4) != 0) {
    if (*(int *)(*(int *)(iVar1 + 4) + 8) == 0) {
      uVar7 = 0;
      goto LAB_003ddd30;
    }
    iVar4 = FUN_0026ed00();
  }
  uVar7 = iVar4 + 0x7ff;
LAB_003ddd30:
  uVar7 = uVar7 & 0xfffff800;
  iVar4 = *(int *)(iVar1 + 8);
  if ((int)((*(int *)(iVar6 + 4) + (uint)((ulong)((long)*(int *)(iVar6 + 8) << 0x24) >> 0x24)) -
           iVar4) < (int)uVar7) {
    if (iVar4 == 0) {
      piVar3 = *(int **)(iVar1 + 4);
    }
    else {
      iVar6 = *(int *)(iVar1 + 0x18);
      if ((iVar6 != 0) && (*(int *)(iVar6 + 8) == 0)) {
        *(int *)(iVar6 + 8) = iVar4 + *(int *)(iVar1 + 0xc);
      }
      piVar3 = *(int **)(iVar1 + 4);
    }
    if (piVar3 != (int *)0x0) {
      if (piVar3[2] != 0) {
        FUN_0026ed50();
        piVar3[2] = 0;
      }
      if (piRam0064f1b4 == piVar3) {
        piRam0064f1b4 = (int *)0x0;
        FUN_003de330();
        iVar6 = piVar3[1];
      }
      else {
        iVar6 = piVar3[1];
      }
      if (iVar6 == 0) {
        *(undefined4 *)(iVar1 + 4) = 0;
        FUN_001dba60(piVar3,0,0x2c);
        *piVar3 = (int)piRam0064f1b0;
        piRam0064f1b0 = piVar3;
      }
    }
  }
  else {
    iVar2 = *(int *)(iVar1 + 4);
    if (iVar2 == 0) {
      iVar4 = *(int *)(iVar1 + 8);
    }
    else {
      if (*(int *)(iVar2 + 8) != 0) {
        uVar5 = FUN_0026ecb0(iVar4,1,uVar7);
        *(undefined4 *)(iVar2 + 4) = uVar5;
      }
      iVar4 = *(int *)(iVar1 + 8);
    }
    FUN_0019cd30(iVar6,iVar4 + uVar7);
    *(uint *)(iVar1 + 0xc) = uVar7;
    if (*(int *)(iVar1 + 8) == 0) {
      piVar3 = *(int **)(iVar1 + 4);
    }
    else {
      iVar6 = *(int *)(iVar1 + 0x18);
      if ((iVar6 != 0) && (*(int *)(iVar6 + 8) == 0)) {
        *(int *)(iVar6 + 8) = *(int *)(iVar1 + 8) + *(int *)(iVar1 + 0xc);
      }
      piVar3 = *(int **)(iVar1 + 4);
    }
    if (piVar3 != (int *)0x0) {
      if (piVar3[2] != 0) {
        FUN_0026ed50();
        piVar3[2] = 0;
      }
      if (piRam0064f1b4 == piVar3) {
        piRam0064f1b4 = (int *)0x0;
        FUN_003de330();
        iVar6 = piVar3[1];
      }
      else {
        iVar6 = piVar3[1];
      }
      if (iVar6 == 0) {
        *(undefined4 *)(iVar1 + 4) = 0;
        FUN_001dba60(piVar3,0,0x2c);
        *piVar3 = (int)piRam0064f1b0;
        piRam0064f1b0 = piVar3;
      }
    }
  }
  return;
}

