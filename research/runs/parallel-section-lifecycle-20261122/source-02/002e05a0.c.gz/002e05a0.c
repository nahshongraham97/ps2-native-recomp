
void FUN_002e05a0(long param_1,long param_2)

{
  int iVar1;
  bool bVar2;
  long lVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)param_1;
    if ((iVar1 != 0) && (param_2 != 0)) {
      bVar2 = false;
      if (iVar1 != 0) {
        lVar3 = FUN_003271a0();
        bVar2 = lVar3 == 0;
      }
      if (bVar2) {
        do {
          if ((piRam0064df54 == (int *)0x0) || (piRam0064df54[0x3c] == 0)) {
            FUN_00328ce0();
          }
          else {
            uRam0064df58 = 0x3f800000;
            (**(code **)(*piRam0064df54 + 0x14))();
          }
          iVar1 = *(int *)param_1;
          bVar2 = false;
          if ((iVar1 != 0) && (lVar3 = FUN_003271a0(iVar1,param_2), lVar3 == 0)) {
            bVar2 = true;
          }
        } while (bVar2);
      }
    }
  }
  return;
}

