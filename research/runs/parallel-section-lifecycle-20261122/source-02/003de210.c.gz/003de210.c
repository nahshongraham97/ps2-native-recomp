
undefined4 *
FUN_003de210(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined8 param_5,undefined1 param_6,long param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  *param_1 = (int)param_4;
  puVar2 = puRam0064f1b0;
  if (puRam0064f1b0 != (undefined4 *)0x0) {
    puRam0064f1b0 = (undefined4 *)*puRam0064f1b0;
    FUN_001dba60(puVar2,0,0x2c);
  }
  param_1[1] = puVar2;
  puVar2[5] = param_1;
  puVar2[6] = param_2;
  puVar2[7] = param_3;
  if (param_7 == 0) {
    uVar1 = FUN_0026ee40(param_4,0x63f988,param_5);
    puVar2[2] = uVar1;
  }
  else {
    uVar1 = FUN_0026f060();
    puVar2[4] = uVar1;
    *(undefined1 *)(puVar2 + 3) = 1;
    puVar2[9] = (int)param_5;
    *(undefined1 *)((int)puVar2 + 0xf) = param_6;
    puVar2[10] = param_8;
    puVar2[8] = (int)param_4;
    *puRam0064f1ac = puVar2;
    puRam0064f1ac = puVar2;
    *puVar2 = 0;
    *(undefined1 *)((int)puVar2 + 0xd) = 1;
    FUN_003de330();
    puVar2 = (undefined4 *)param_1[1];
  }
  return puVar2;
}

