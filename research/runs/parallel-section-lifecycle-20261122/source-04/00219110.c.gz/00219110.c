
void FUN_00219110(undefined4 *param_1,undefined8 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = param_1[2];
  uVar2 = *(uint *)(param_1[1] + 8);
  if (uVar2 < (uint)(iVar1 + param_3)) {
    param_3 = uVar2 - iVar1;
  }
  iVar3 = *(int *)(param_1[1] + 4);
  param_1[2] = param_1[2] + param_3;
  FUN_002dffb0(*(undefined4 *)*param_1,iVar3 + iVar1,param_2);
  return;
}

