
int FUN_0019cad0(undefined8 param_1,int param_2,undefined8 param_3,int param_4,int param_5)

{
  int *piVar1;
  bool bVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  
  iVar9 = 0;
  piVar6 = (int *)param_1;
  uVar5 = piVar6[2];
  if (uVar5 == 0) {
    iVar9 = 0;
  }
  else {
    piVar7 = (int *)(param_2 + 0x14);
    piVar8 = *(int **)(param_2 + 0x14);
    while (piVar8 != (int *)0x0) {
      piVar1 = (int *)piVar8[6];
      if ((piVar8[2] == 0) || ((uint)piVar8[2] < uVar5)) {
        *piVar7 = (int)piVar1;
        if (*piVar8 == 0) {
          uVar4 = (uint)*(byte *)((int)piVar8 + 0x1f);
        }
        else {
          uVar4 = *(uint *)(*piVar8 + 8);
        }
        if ((uVar4 == 3) && (piVar8[0xb] != 0)) {
          FUN_00215010();
          piVar8[0xb] = 0;
        }
        thunk_FUN_004293f0(piVar8,0,0);
        piVar8 = piVar1;
      }
      else {
        piVar7 = piVar8 + 6;
        piVar8 = piVar1;
      }
    }
    piVar7 = (int *)(param_2 + 0x14);
    piVar8 = *(int **)(param_2 + 0x14);
    while (piVar8 != (int *)0x0) {
      if (piVar8[2] == uVar5) {
        *piVar7 = piVar8[6];
        piVar8[6] = 0;
        goto LAB_0019cbe4;
      }
      piVar7 = piVar8 + 6;
      piVar8 = (int *)piVar8[6];
    }
    piVar8 = (int *)0x0;
LAB_0019cbe4:
    if (piVar8 == (int *)0x0) {
      iVar9 = 0;
    }
    else {
      if (param_5 == 1) {
        bVar2 = true;
      }
      else if (param_5 == 2) {
        bVar2 = true;
      }
      else {
        bVar2 = false;
      }
      if (bVar2) {
        if (param_4 == *piVar8) {
          if (param_5 == 1) {
            iVar9 = 1;
          }
          else if (param_5 == 3) {
            if ((piVar6[0xb] != 0) && (piVar8[0xb] != 0)) {
              FUN_001309c0(piVar8[0xb] + 0x98,piVar6[0xb] + 0x98);
              iVar9 = 1;
            }
          }
          else {
            iVar9 = 1;
          }
          if (iVar9 != 0) {
            *(undefined1 *)((int)piVar8 + 0x1d) = 1;
            *(undefined1 *)((int)piVar6 + 0x1d) = 1;
            *piVar6 = param_4;
            piVar6[3] = piVar8[3];
            FUN_003de720(param_1);
            piVar6[8] = piVar8[8];
            piVar6[5] = piVar8[5];
            *(undefined1 *)(piVar6 + 7) = 0;
          }
        }
        iVar3 = *piVar8;
      }
      else {
        iVar3 = *piVar8;
      }
      if (iVar3 == 0) {
        uVar5 = (uint)*(byte *)((int)piVar8 + 0x1f);
      }
      else {
        uVar5 = *(uint *)(iVar3 + 8);
      }
      if ((uVar5 == 3) && (piVar8[0xb] != 0)) {
        FUN_00215010();
        piVar8[0xb] = 0;
      }
      thunk_FUN_004293f0(piVar8,0,0);
    }
  }
  return iVar9;
}

