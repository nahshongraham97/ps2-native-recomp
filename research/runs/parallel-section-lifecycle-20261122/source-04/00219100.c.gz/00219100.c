
undefined4 FUN_00219100(int param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

