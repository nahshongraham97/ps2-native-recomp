
void FUN_003de5b0(undefined8 param_1,long param_2,long param_3)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  int *piVar4;
  
  piVar4 = (int *)param_1;
  *(undefined1 *)(piVar4 + 3) = 0;
  if (*(char *)((int)piVar4 + 0xe) == '\0') {
    if (param_2 == 0) {
      piVar4[2] = 0;
    }
    else {
      if (param_3 == 0) {
        FUN_0026ed50(param_2);
        param_2 = 0;
      }
      piVar4[2] = (int)param_2;
    }
    (*(code *)piVar4[10])(param_1);
    iVar1 = piVar4[5];
    if ((param_3 == 0) && (iVar1 != 0)) {
      if ((*(int *)(iVar1 + 8) != 0) &&
         ((iVar3 = *(int *)(iVar1 + 0x18), iVar3 != 0 && (*(int *)(iVar3 + 8) == 0)))) {
        *(int *)(iVar3 + 8) = *(int *)(iVar1 + 8) + *(int *)(iVar1 + 0xc);
      }
      uVar2 = FUN_0019c3b0(iVar1);
      FUN_0019cd30(uVar2,*(int *)(iVar1 + 8) + *(int *)(iVar1 + 0xc));
      *(undefined4 *)(iVar1 + 0xc) = 0;
      piVar4 = *(int **)(iVar1 + 4);
      if (piVar4 != (int *)0x0) {
        if (piVar4[2] != 0) {
          FUN_0026ed50();
          piVar4[2] = 0;
        }
        if ((int *)iRam0064f1b4 == piVar4) {
          iRam0064f1b4 = 0;
          FUN_003de330();
          iVar3 = piVar4[1];
        }
        else {
          iVar3 = piVar4[1];
        }
        if (iVar3 == 0) {
          *(undefined4 *)(iVar1 + 4) = 0;
          FUN_001dba60(piVar4,0,0x2c);
          *piVar4 = (int)piRam0064f1b0;
          piRam0064f1b0 = piVar4;
        }
      }
    }
  }
  else {
    FUN_0026ed50(param_2);
    piVar4[2] = 0;
    (*(code *)piVar4[10])(param_1);
    iRam0064f1b4 = 0;
    FUN_003de330();
    FUN_001dba60(param_1,0,0x2c);
    *piVar4 = (int)piRam0064f1b0;
    piRam0064f1b0 = piVar4;
  }
  return;
}

