
undefined4 *
FUN_0026eec0(undefined4 *param_1,undefined8 param_2,undefined8 param_3,long param_4,
            undefined8 param_5)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar4;
  long lVar3;
  
  puVar4 = (undefined4 *)(iRam0064e998 + 0xc);
  puVar2 = *(undefined4 **)(iRam0064e998 + 0xc);
  if (puVar2 == (undefined4 *)0x0) {
LAB_0026ef20:
    puVar4 = (undefined4 *)0x0;
    uVar1 = uRam00000004;
  }
  else {
    uVar1 = *param_1;
    while (lVar3 = FUN_001deb10(*puVar2,uVar1), lVar3 != 0) {
      puVar4 = puVar4 + 3;
      puVar2 = (undefined4 *)*puVar4;
      if (puVar2 == (undefined4 *)0x0) goto LAB_0026ef20;
      uVar1 = *param_1;
    }
    uVar1 = puVar4[1];
  }
  FUN_00219200(uRam0064e99c,uVar1,0);
  if (param_4 != 0) {
    (*(code *)param_4)(param_5,puVar4,1);
  }
  return puVar4;
}

