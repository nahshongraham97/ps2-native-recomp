
void FUN_003de890(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  piVar4 = piRam0064f1a8;
  piVar2 = (int *)0x64f1a8;
  while( true ) {
    piVar3 = piVar4;
    if (piVar3 == (int *)0x0) {
      return;
    }
    if (param_1 == piVar3) break;
    piVar4 = (int *)*piVar3;
    piVar2 = piVar3;
  }
  iVar1 = *piVar3;
  *piVar2 = iVar1;
  if (iVar1 == 0) {
    piRam0064f1ac = piVar2;
  }
  *param_1 = 0;
  *(undefined1 *)((int)param_1 + 0xd) = 0;
  return;
}

