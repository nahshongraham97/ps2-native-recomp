
void FUN_0019c010(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0x10);
  do {
    iVar2 = iVar1;
    if (iVar2 == 0) break;
    iVar1 = *(int *)(iVar2 + 0x18);
  } while (*(int *)(iVar2 + 0x18) != 0);
  if (iVar2 == 0) {
    *(undefined4 *)(param_2 + 8) = *(undefined4 *)(param_1 + 4);
    *(int *)(param_1 + 0x10) = param_2;
  }
  else {
    if (*(int *)(iVar2 + 0xc) == 0) {
      *(undefined4 *)(param_2 + 8) = 0;
    }
    else {
      *(int *)(param_2 + 8) = *(int *)(iVar2 + 8) + *(int *)(iVar2 + 0xc);
    }
    *(int *)(iVar2 + 0x18) = param_2;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 1;
  return;
}

