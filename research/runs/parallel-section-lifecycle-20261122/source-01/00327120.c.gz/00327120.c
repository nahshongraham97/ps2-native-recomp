
void FUN_00327120(long param_1)

{
  if (param_1 != 0) {
    (**(code **)(*(int *)param_1 + 0x2c))();
  }
  return;
}

