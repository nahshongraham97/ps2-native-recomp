
void FUN_002dff50(long param_1)

{
  undefined1 auStack_8 [8];
  
  if (((param_1 != 0) && (*(int *)param_1 != 0)) && (FUN_003271e0(), *(int *)param_1 != 0)) {
    FUN_002e05a0(param_1,auStack_8);
  }
  return;
}

