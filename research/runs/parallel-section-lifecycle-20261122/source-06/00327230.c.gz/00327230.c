
undefined4 *
FUN_00327230(long param_1,ulong param_2,long param_3,ulong param_4,ulong param_5,undefined8 param_6,
            undefined8 param_7)

{
  undefined8 uVar1;
  long lVar2;
  int iVar3;
  ulong uVar4;
  ulong uVar5;
  undefined4 *puStack_4;
  
  if (param_1 == 0) {
    FUN_00323ff0(0x631ab0);
    puStack_4 = (undefined4 *)0x0;
  }
  else if (param_3 == 0) {
    FUN_00323ff0(0x631af0);
    puStack_4 = (undefined4 *)0x0;
  }
  else {
    uVar4 = *(ulong *)((int *)param_1 + 2);
    iVar3 = (int)param_2;
    if (uVar4 < param_2) {
      uVar1 = FUN_00327a40();
      FUN_00323ff0(0x631b30,uVar1,iVar3,uVar4);
      lVar2 = FUN_002df5b0(0x1c,3,0x631b80);
      puStack_4 = (undefined4 *)lVar2;
      if (lVar2 == 0) {
        puStack_4 = (undefined4 *)0x0;
        lVar2 = -10;
      }
      else {
        FUN_00327770(lVar2,param_6,param_7,param_1);
        *puStack_4 = &DAT_00649540;
        *(undefined1 *)(puStack_4 + 6) = 0;
        uVar1 = FUN_00328f90();
        lVar2 = (**(code **)(*(int *)uVar1 + 0x14))(uVar1,lVar2,param_5 & 3);
      }
    }
    else {
      uVar5 = param_4;
      if (uVar4 < param_2 + (param_4 & 0xffffffff)) {
        uVar5 = (ulong)((int)uVar4 - iVar3);
        uVar1 = FUN_00327a40();
        FUN_00323ff0(0x631ba0,uVar1,iVar3,param_4,uVar5);
      }
      if (uVar5 == 0) {
        lVar2 = FUN_002df5b0(0x1c,3,0x631a90);
        puStack_4 = (undefined4 *)lVar2;
        if (lVar2 == 0) {
          puStack_4 = (undefined4 *)0x0;
          lVar2 = -10;
        }
        else {
          FUN_00327770(lVar2,param_6,param_7,param_1);
          *puStack_4 = &DAT_006499b0;
          *(undefined1 *)(puStack_4 + 6) = 0;
          uVar1 = FUN_00328f90();
          lVar2 = (**(code **)(*(int *)uVar1 + 0x14))(uVar1,lVar2,param_5 & 3);
        }
      }
      else {
        lVar2 = (**(code **)(*(int *)param_1 + 0x18))
                          (param_1,&puStack_4,param_2,param_3,uVar5,param_5,param_6,param_7);
      }
    }
    if (lVar2 == 0) {
      FUN_00328ce0();
    }
    else {
      FUN_00323ff0(0x631c10,lVar2);
      puStack_4 = (undefined4 *)0x0;
    }
  }
  return puStack_4;
}

