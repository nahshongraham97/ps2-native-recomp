
void FUN_002df470(undefined4 param_1)

{
  undefined8 uVar1;
  long lVar2;
  undefined1 auStack_30 [4];
  undefined2 uStack_2c;
  undefined2 uStack_2a;
  undefined4 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_10;
  
  FUN_00328f30(auStack_30);
  uStack_2c = 4;
  uStack_2a = 2;
  uStack_24 = 0x23;
  uStack_10 = param_1;
  uVar1 = FUN_002209e0(0x630a80,0);
  FUN_001dec58(0x6d03a0,uVar1);
  uStack_1c = 0x6d03a0;
  lVar2 = FUN_00328dd0(auStack_30);
  if (lVar2 != 0) {
    FUN_001d8ea8(1);
  }
  FUN_00328120(0x630a98,0x630aa0);
  FUN_00328120(0x630aa8,0x630ab0);
  FUN_00328120(0x630ac0,0x630ac8);
  FUN_00328120(0x630ad8,0x630ae0);
  FUN_00328120(0x630af0,0x630af8);
  FUN_00328120(0x630b08,0x630b20);
  FUN_00328120(0x630b38,0x630b40);
  FUN_00328120(0x630b50,0x630b58);
  return;
}

