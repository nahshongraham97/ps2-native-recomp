
void FUN_003270c0(void)

{
  int unaff_s1_lo;
  int *unaff_s3_lo;
  int unaff_s4_lo;
  int unaff_s5_lo;
  
  if (unaff_s3_lo[3] == 0) {
    unaff_s3_lo[3] = unaff_s4_lo;
  }
  else {
    FUN_002df5a0();
    unaff_s3_lo[3] = unaff_s4_lo;
  }
  *unaff_s3_lo = unaff_s5_lo + 1;
  unaff_s3_lo[2] = 0;
  unaff_s3_lo[1] = unaff_s3_lo[1] + unaff_s1_lo;
  return;
}

