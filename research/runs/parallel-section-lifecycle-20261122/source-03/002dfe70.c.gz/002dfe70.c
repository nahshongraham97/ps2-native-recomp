
void FUN_002dfe70(undefined8 param_1)

{
  undefined1 auStack_8 [8];
  
  FUN_002e05a0(param_1,auStack_8);
  return;
}

