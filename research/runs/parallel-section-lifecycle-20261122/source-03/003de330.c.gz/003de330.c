
void FUN_003de330(void)

{
  undefined1 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  long lVar7;
  
  iVar5 = 0;
  if (puRam0064f1b4 == (undefined4 *)0x0) {
    do {
      puVar6 = puRam0064f1a8;
      if (puRam0064f1a8 != (undefined4 *)0x0) {
        puVar2 = (undefined4 *)*puRam0064f1a8;
        *puRam0064f1a8 = 0;
        if (puVar2 == (undefined4 *)0x0) {
          uRam0064f1ac = 0x64f1a8;
        }
        puVar1 = (undefined1 *)((int)puRam0064f1a8 + 0xd);
        puRam0064f1a8 = puVar2;
        *puVar1 = 0;
      }
      lVar7 = 0;
      if (((puVar6 != (undefined4 *)0x0) &&
          (iVar3 = puVar6[5], *(char *)((int)puVar6 + 0xf) != '\0')) &&
         (lVar7 = FUN_0019cad0(iVar3,puVar6[6],puVar6[7],puVar6[8],puVar6[9]), lVar7 != 0)) {
        puVar6 = *(undefined4 **)(iVar3 + 4);
        if (puVar6 != (undefined4 *)0x0) {
          if (puVar6[2] != 0) {
            FUN_0026ed50();
            puVar6[2] = 0;
          }
          if (puRam0064f1b4 == puVar6) {
            puRam0064f1b4 = (undefined4 *)0x0;
            FUN_003de330();
          }
          if (puVar6[1] == 0) {
            *(undefined4 *)(iVar3 + 4) = 0;
            FUN_001dba60(puVar6,0,0x2c);
            *puVar6 = puRam0064f1b0;
            puRam0064f1b0 = puVar6;
          }
        }
        puVar6 = (undefined4 *)0x0;
      }
    } while (lVar7 != 0);
    if (puVar6 != (undefined4 *)0x0) {
      iVar3 = puVar6[4];
      puRam0064f1b4 = puVar6;
      if (iVar3 == 0) {
        uVar4 = puVar6[8];
      }
      else {
        iVar5 = FUN_0026f060();
        if (iVar5 != iVar3) {
          FUN_0026f070(iVar3);
        }
        uVar4 = puVar6[8];
      }
      FUN_0026eec0(uVar4,0x63f988,puVar6[9],0x3de5b0,puVar6);
      if ((iVar5 != iVar3) && (iVar5 != 0)) {
        FUN_0026f070(iVar5);
      }
    }
  }
  return;
}

