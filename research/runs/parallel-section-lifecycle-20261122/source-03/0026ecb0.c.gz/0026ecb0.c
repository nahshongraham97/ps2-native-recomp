
void FUN_0026ecb0(undefined8 param_1,int param_2,int param_3)

{
  FUN_00219100(uRam0064e99c);
  FUN_00219110(uRam0064e99c,param_1,param_2 * param_3);
  return;
}

