
undefined8 FUN_0026ed50(void)

{
  iRam0064e9a8 = iRam0064e9a8 + 1;
  return 0;
}

