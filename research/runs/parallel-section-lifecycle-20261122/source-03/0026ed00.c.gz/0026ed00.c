
undefined4 FUN_0026ed00(int param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

